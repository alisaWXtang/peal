<template>
  <el-dialog
    :title="importing ? titleMap.importing : titleMap.imported"
    :close-on-click-modal="false"
    v-bind="$attrs"
    v-on="$listeners"
    @closed="onClosed"
    class="import-dialog"
    width="420px"
  >
    <span v-if="importing"
      >{{ $t('导入时间可能需要几秒到几分钟') }}，{{
        $t('尽量不要关闭当前窗口')
      }}，{{ $t('否则导致无法接收到导入结果提示') }}。</span
    >
    <span v-else class="dialog-content">
      <i
        v-if="result.type === 'success'"
        class="success el-icon-circle-check"
      ></i>
      <i v-else class="wraning el-icon-warning-outline"></i>
      <span v-html="result.msg || $t('导入完成')"></span>
    </span>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="onOk" :loading="importing">{{
        $t('确定')
      }}</el-button>
    </span>
  </el-dialog>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 导入结果弹窗组件
 * @desc 需求、任务、缺陷导入
 * @author wuqian
 * @date 2020.6.5
 */
export default {
  name: 'ImportDialog',
  data() {
    return {
      visible: false,
      importing: true,
      titleMap: {
        importing: i18n.t('正在导入'),
        imported: i18n.t('导入结果'),
      },
    }
  },
  props: {
    result: {
      type: Object,
      default: () => {},
    },
  },

  watch: {
    result(val) {
      if (val.type) {
        this.importing = false
      }
    },
  },

  methods: {
    onOk() {
      this.$emit('update:visible', false)
    },
    onClosed() {
      // 关闭时恢复默认
      this.importing = true
      this.$emit('update:result', {})
      this.$emit('closed')
    },
  },
}
</script>
<style lang="scss" scoped>
.import-dialog {
  /deep/ .el-dialog__header {
    border-bottom: 0;
  }
  /deep/ .el-dialog__body {
    margin-bottom: 5px;
    line-height: 24px;
  }
  .dialog-content {
    position: relative;
    i {
      position: absolute;
      font-size: 24px;
      padding-right: 5px;
    }
    i.success {
      color: #67c23a;
    }
    i.wraning {
      color: #e6a23c;
    }
    span {
      padding-left: 30px;
      display: inline-block;
    }
  }
}
</style>
