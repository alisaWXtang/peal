<template>
  <div
    v-loading="loading"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <div style="margin-top: -6px">
      <el-row v-if="disabledTestplanCheck" class="buttonSpan">
        <el-button
          v-show="
            $authFunction(
              'FUNCTION_PROJ_REQUIRE_ASSOC_TEST_PLAN',
              3,
              $getUrlParams().projectId || projectId,
            )
          "
          type="text"
          style="margin-right: 6px;"
          @click="dialogTableVisible.show = true"
          >{{ $t('关联测试计划') }}</el-button
        >
        <el-button
          v-show="
            $authFunction(
              'FUNCTION_PROJ_REQUIRE_CREATE_TEST_PLAN',
              3,
              $getUrlParams().projectId || projectId,
            )
          "
          type="text"
          @click="toItest"
          >{{ $t('新建测试计划') }}</el-button
        >
        <!-- <co-dropdown size="medium">
          <co-button suffix-icon="co-icon-arrow-down" type="primary"
            >用例测试</co-button
          >
          <co-dropdown-menu slot="dropdown">
            <co-dropdown-item
              v-show="
                $authFunction(
                  'FUNCTION_PROJ_REQUIRE_ASSOC_TEST_PLAN',
                  3,
                  $getUrlParams().projectId || projectId,
                )
              "
            >
              <el-button
                type="text"
                style="margin-right: 6px;"
                @click="dialogTableVisible.show = true"
                >{{ $t('关联测试计划') }}</el-button
              >
            </co-dropdown-item>
            <co-dropdown-item
              v-show="
                $authFunction(
                  'FUNCTION_PROJ_REQUIRE_CREATE_TEST_PLAN',
                  3,
                  $getUrlParams().projectId || projectId,
                )
              "
            >
              <el-button type="text" @click="toItest">{{
                $t('新建测试计划')
              }}</el-button>
            </co-dropdown-item>
          </co-dropdown-menu>
        </co-dropdown> -->
      </el-row>
      <span
        v-else
        class="fl ml10 task-decompose-title"
        style="color:#cccccc;margin-bottom:10px;display: inline-block;"
      >
        <i class="el-icon-warning" style="color:#409EFF;"></i>&nbsp;{{
          $t('该需求已规划迭代')
        }}，{{ $t('请在迭代详情里关联') }}/{{ $t('新建测试计划') }}
      </span>
    </div>
    <test-plan-association
      :dialog-table-visible="dialogTableVisible"
      :work-item-id="workItemId"
      :project-id="projectId"
      @getTestPlan="getTestPlan"
    ></test-plan-association>
    <test-plan-table
      style="margin-top:0px;"
      :test-plan-id="testPlanId"
      :disabled-testplan-check="disabledTestplanCheck"
      :work-item-id="workItemId"
      :project-id="projectId"
      @delTestPlan="delTestPlan"
    ></test-plan-table>
  </div>
</template>
<script>
/**
 * @title 测试计划入口文件
 * @desc
 * @author heyunjiang
 * @date 2019.10.8
 */
import TestPlanTable from './TestPlanTable'
import TestPlanAssociation from './TestPlanAssociation'
import config from '@/utils/config'
import { assocTestCheck } from '@/service/requirement'
import { projectInfo } from '@/service/project'

export default {
  name: 'TestPlan',
  components: {
    TestPlanTable,
    TestPlanAssociation,
  },

  mixins: [],
  props: {
    disabledTestplan: {
      type: Boolean,
      required: true,
      desc: '显示与隐藏',
    },

    sprintdata: {
      type: [String, Array],
      required: false,
      desc: '有无迭代关联计划',
    },

    workItemId: {
      type: [String, Number],
      required: false,
      desc: '需求id',
    },

    requireInfo: {
      type: [String, Object],
      required: false,
      desc: '需求标题',
    },

    sprintName: {
      type: [String, Number],
      required: false,
      desc: '缺陷标题',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false,
      dialogTableVisible: { show: false },
      testPlanId: [],
      disabledTestplanCheck: true,
      projectName: '',
    }
  },
  computed: {},
  watch: {
    //监听有无管理迭代
    sprintdata() {
      this.getTestdetaildata()
    },
  },

  created() {
    this.getTestdetaildata()
  },
  mounted() {},
  methods: {
    delTestPlan() {
      this.$emit('testPlanSuccess')
    },
    //跳转itest
    async toItest() {
      let sprintId = this.$getUrlParams().sprintId
      let requireId = this.$getUrlParams().requireId
      if (this.workItemId) {
        config.itestJump('newplan', {
          requirementId: this.workItemId,
          type: 1,
          requireName: encodeURI(this.requireInfo.detail.title),
          projectName: encodeURI(this.requireInfo.display.projectName),
        })
      }
      if (requireId === undefined && !this.workItemId) {
        config.itestJump('newplan', {
          sprintId,
          type: 2,
          sprintName: encodeURI(this.sprintName),
          projectName: encodeURI(this.projectName),
        })
      }
    },
    //关联测试计划
    getTestPlan(data) {
      this.testPlanId = data
      this.$emit('testPlanSuccess')
    },
    //检查需求是否可以关联测试计划
    async getTestdetaildata() {
      let projectId = this.projectId || this.$getUrlParams().projectId
      let requireId = this.$getUrlParams().requireId
      if (requireId) {
        this.loading = true
        let result = await assocTestCheck({
          requireId,
          projectId,
        })

        if (result.status === 200) {
          this.loading = false
          this.disabledTestplanCheck = result.data
        }
      }
      if (this.workItemId) {
        this.loading = true
        let result = await assocTestCheck({
          requireId: this.workItemId,
          projectId,
        })

        if (result.status === 200) {
          this.loading = false
          this.disabledTestplanCheck = result.data
        }
      }
      this.loading = true
      let data = await projectInfo({
        id: projectId,
      })

      if (data.status === 200) {
        this.loading = false
        this.projectName = data.data.name
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.buttonSpan .el-button span {
  color: red !important;
}
</style>
