<template>
  <div>
    <el-dialog
      :title="$t('关联测试计划')"
      :visible.sync="dialogTableVisible.show"
      :modal-append-to-body="false"
    >
      <el-row style="margin-bottom: 10px;">
        <span style="margin: 10px;">{{ $t('项目') }}：{{ projectName }}</span>
      </el-row>
      <el-table
        ref="multipleTable"
        v-loading="loading"
        class="multiple-table"
        element-loading-text=" "
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgb(255,255,255)"
        :data="tableList.list"
        tooltip-effect="dark"
        style="width: 100%"
        max-height="450"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column label="id" width="120">
          <template slot-scope="scope">{{ scope.row.id }}</template>
        </el-table-column>
        <el-table-column
          prop="name"
          :label="$t('名称')"
          min-width="120"
        ></el-table-column>
        <el-table-column
          prop="bizName"
          :label="$t('服务名称')"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="createdName"
          :label="$t('创建人')"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="stateStr"
          :label="$t('状态')"
          show-overflow-tooltip
        ></el-table-column>
      </el-table>
      <!-- 分页 -->
      <div class="block" align="center" style="margin-top: 10px;">
        <el-pagination
          :current-page="tableList.pageNum"
          :page-sizes="[20, 50, 100]"
          :page-size="tableList.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="tableList.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>
      <!-- 对话框底部 -->
      <span slot="footer" class="dialog-footer">
        <el-button
          v-show="
            $authFunction(
              'FUNCTION_PROJ_REQUIRE_ASSOC_TEST_PLAN',
              3,
              $getUrlParams().projectId || projectId,
            )
          "
          type="primary"
          style="margin-right: 50px;"
          @click="getTestPlan"
          >{{ $t('确定') }}</el-button
        >
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 关联测试计划 dialog 组件
 * @desc
 * @author
 * @date
 */
import { unAssocTestPlanList } from '@/service/itest'
import { projectInfo } from '@/service/project'
import { assocTestPlan } from '@/service/requirement'
import { assocTestPlan as requirementAssocTestPlan } from '@/service/sprint'
export default {
  name: 'TestPlanAssociation',
  components: {},
  mixins: [],
  props: {
    dialogTableVisible: {
      type: Object,
      required: true,
      desc: '显示与隐藏',
    },

    workItemId: {
      type: [String, Number],
      required: false,
      desc: '需求id',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false,
      arrlist: [], //选中状态id数组
      tableList: {
        paageSize: 20,
        total: 0,
        list: [],
      }, //表格数据
      projectName: '', //项目名称
    }
  },
  computed: {},
  watch: {
    dialogTableVisible: {
      deep: true,
      handler() {
        this.getPage({ page: 1, size: 20 })
      },
    },
  },
  mounted() {
    this.getPage({
      page: 1,
      size: 20,
    })
  },

  created() {},
  methods: {
    //获取数据列表
    async getPage(val) {
      let projectId = this.projectId || this.$getUrlParams().projectId
      this.loading = true
      let result = await unAssocTestPlanList({
        projectId,
        pageNum: val.page,
        pageSize: val.size,
      })

      if (result.status === 200) {
        this.loading = false
        this.tableList = {
          ...this.tableList,
          ...result.data,
        }
      }
      this.loading = true
      let data = await projectInfo({
        id: projectId,
      })

      if (data.status === 200) {
        this.loading = false
        this.projectName = data.data.name
      }
    },
    //设置选中状态
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    //分页
    handleSizeChange(val) {
      this.getPage({
        page: 1,
        size: val,
      })
    },
    handleCurrentChange(val) {
      this.getPage({
        page: val,
        size: this.tableList.pageSize,
      })
    },
    //获取选中测试计划ID
    handleSelectionChange(val) {
      this.arrlist = []
      if (val) {
        val.forEach(row => {
          this.arrlist.push(row.id)
        })
      }
    },
    //关联测试计划
    async assocTestPlan(data) {
      let testPlanIds = data
      let sprintId = this.$getUrlParams().sprintId
      let requireId = this.$getUrlParams().requireId
      let projectId = this.projectId || this.$getUrlParams().projectId
      if (sprintId === undefined) {
        this.loading = true
        let result = await assocTestPlan({
          projectId,
          requireId: this.workItemId,
          testPlanIds,
        })

        if (result.status === 200) {
          this.loading = false
          this.$message({
            type: 'success',
            message: i18n.t('关联成功') + '!',
          })
        }
      }
      if (requireId === undefined && this.workItemId) {
        this.loading = true
        let result = await assocTestPlan({
          projectId,
          requireId: this.workItemId,
          testPlanIds,
        })

        if (result.status === 200) {
          this.loading = false
          this.$message({
            type: 'success',
            message: i18n.t('关联成功') + '!',
          })
        }
      }
      if (requireId === undefined && !this.workItemId) {
        this.loading = true
        let result = await requirementAssocTestPlan({
          projectId,
          sprintId,
          testPlanIds,
        })

        if (result.status === 200) {
          this.loading = false
          this.$message({
            type: 'success',
            message: i18n.t('关联成功') + '!',
          })
        }
      }
    },
    //点击确定关联测试计划
    getTestPlan() {
      if (this.arrlist.length !== 0) {
        this.$emit('getTestPlan', this.arrlist)
        this.assocTestPlan(this.arrlist)
        this.arrlist = []
        this.toggleSelection()
      }
      this.dialogTableVisible.show = false
    },
  },
}
</script>
<style lang="scss" scoped>
/deep/ .el-pagination .el-pagination__sizes-select .el-input {
  width: 94px;
}
</style>
