<template>
  <div
    v-loading="loading"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <div style="padding-bottom: 30px;">
      <el-table :data="TestCaseTableData" class="multiple-table" border>
        <el-table-column
          prop="name"
          :label="$t('名称')"
          min-width="90"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <co-link
              type="primary"
              :underline="false"
              @click="handleClicNamek(scope.row.id)"
              >{{ scope.row.name }}</co-link
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="createdName"
          :label="$t('创建人')"
          width="80"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="appointedNames"
          :label="$t('指派给')"
          width="80"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="bizName"
          :label="$t('服务')"
          min-width="80"
          align="center"
          show-overflow-tooltip
        ></el-table-column>

        <el-table-column
          prop="createdAt"
          :label="$t('创建时间')"
          width="110"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="schedule"
          :label="$t('测试进度')"
          width="110"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="passRate"
          :label="$t('通过率')"
          width="100"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="stateStr"
          :label="$t('状态')"
          width="80"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop
          :label="$t('操作')"
          width="100"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <el-button
              v-show="
                $authFunction(
                  'FUNCTION_PROJ_SPRINT_UNASSOC_TEST_PLAN',
                  3,
                  $getUrlParams().projectId || projectId,
                )
              "
              type="text"
              @click="open(scope.row.id)"
              >{{ $t('解除关联') }}</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 测试计划 table
 * @desc
 * @author
 * @date
 */
import config from '@/utils/config'
import * as requirementService from '@/service/requirement'
import * as sprintService from '@/service/sprint'

export default {
  name: 'TestPlanTable',
  components: {},
  mixins: [],
  props: {
    testPlanId: {
      type: Array,
      required: true,
      desc: '关联数据',
    },

    disabledTestplanCheck: {
      type: Boolean,
      required: true,
      desc: '是否要请求数据',
    },

    workItemId: {
      type: [String, Number],
      required: false,
      desc: '需求id',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false,
      TestCaseTableData: [], //表格数据
      TestplanCheck: true,
    }
  },
  computed: {},
  watch: {
    testPlanId: {
      deep: true,
      handler() {
        setTimeout(() => {
          this.getTestPlantList()
        }, 1000)
      },
    },

    disabledTestplanCheck() {
      this.getTestPlantList()
    },
  },

  created() {},
  mounted() {
    this.getTestPlantList()
  },
  methods: {
    // 获取迭代关联的测试计划列表
    async getTestPlantList() {
      this.TestCaseTableData = []
      let sprintId = this.$getUrlParams().sprintId
      let requireId = this.$getUrlParams().requireId
      let projectId = this.projectId || this.$getUrlParams().projectId
      if (requireId) {
        this.loading = true
        let result = await requirementService.testPlanList({
          projectId,
          requireId: this.workItemId,
        })

        this.loading = false
        if (result.status === 200) {
          this.TestCaseTableData = result.data.list
        }
      }
      if (requireId === undefined && !this.workItemId) {
        this.loading = true
        let result = await sprintService.testPlanList({
          projectId,
          sprintId,
        })

        this.loading = false
        if (result.status === 200) {
          this.TestCaseTableData = result.data.list
        }
      }
      if (requireId === undefined && this.workItemId) {
        this.loading = true
        let result = await requirementService.testPlanList({
          projectId,
          requireId: this.workItemId,
        })

        this.loading = false
        if (result.status === 200) {
          this.TestCaseTableData = result.data.list
        }
      }
    },
    // 点击测试计划名字，跳转到itest的测试计划详情
    async handleClicNamek(id) {
      config.itestJump('planEdit', { id })
    },
    // 迭代解除关联测试计划
    async handleClickDel(testPlanId) {
      let sprintId = this.$getUrlParams().sprintId
      let requireId = this.$getUrlParams().requireId
      let projectId = this.projectId || this.$getUrlParams().projectId
      if (sprintId === undefined) {
        let result = await requirementService.unAssocTestPlan({
          projectId,
          requireId: this.workItemId,
          testPlanId,
        })

        if (result.status === 200) {
          this.$message({
            type: 'success',
            message: i18n.t('解绑成功!') + '!',
          })

          this.getTestPlantList()
          this.$emit('delTestPlan')
        }
      }
      if (requireId === undefined && this.workItemId) {
        let result = await requirementService.unAssocTestPlan({
          projectId,
          requireId: this.workItemId,
          testPlanId,
        })

        if (result.status === 200) {
          this.$message({
            type: 'success',
            message: i18n.t('解绑成功!') + '!',
          })

          this.getTestPlantList()
        }
      }
      if (requireId === undefined && !this.workItemId) {
        let result = await sprintService.unAssocTestPlan({
          projectId,
          sprintId,
          testPlanId,
        })

        if (result.status === 200) {
          this.$message({
            type: 'success',
            message: i18n.t('解绑成功') + '!',
          })

          this.getTestPlantList()
        }
      }
    },
    //是否确认删除关联
    open(testPlanId) {
      this.$confirm(i18n.t('此操作将解除关联, 是否继续?'), i18n.t('提示'), {
        confirmButtonText: i18n.t('确定'),
        cancelButtonText: i18n.t('取消'),
        type: 'warning',
      })
        .then(() => {
          this.handleClickDel(testPlanId)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: i18n.t('已取消解绑'),
          })
        })
    },
    //关联测试计划
    async assocTestPlan() {
      let testPlanIds = this.testPlanId
      let sprintId = this.$getUrlParams().sprintId
      let requireId = this.$getUrlParams().requireId
      let projectId = this.projectId || this.$getUrlParams().projectId
      if (sprintId === undefined) {
        let result = await requirementService.assocTestPlan({
          projectId,
          requireId,
          testPlanIds,
        })

        if (result.status === 200) {
          this.getTestPlantList()
        }
      }
      if (requireId === undefined && this.workItemId) {
        let result = await requirementService.assocTestPlan({
          projectId,
          requireId: this.workItemId,
          testPlanIds,
        })

        if (result.status === 200) {
          this.getTestPlantList()
        }
      }
      if (requireId === undefined && !this.workItemId) {
        let result = await sprintService.assocTestPlan({
          projectId,
          sprintId,
          testPlanIds,
        })

        if (result.status === 200) {
          this.getTestPlantList()
        }
      }
    },
  },
}
</script>
<style lang="scss" scoped></style>
