# 动态字段显示

time: 2019.8.31  
author: heyunjiang

## 说明

动态返回需要的 form 组件，包含 input, textarea, select 等

主要用在自定义字段上面，根据字段类型，返回字段的 template
