<template>
  <div>
    <!-- 单行文本框 -->
    <el-input
      v-if="type === 'SINGLE_TEXT' && !showFilterField"
      v-model="componentValue"
      v-bind="$attrs"
      class="input-typeed-class"
      :class="{ coustom_input: $attrs.prefix }"
      :clearable="isClearable"
      @change="updateModel"
      v-on="currentListeners"
    >
      <i
        v-if="$attrs.prefix"
        slot="prefix"
        class="el-input__icon el-icon-search"
      ></i>
    </el-input>
    <!-- 多行富文本框 -->
    <el-input
      v-if="type === 'MULTI_TEXT' && !showFilterField"
      v-model="componentValue"
      type="textarea"
      class="input-typeed-class"
      v-bind="$attrs"
      v-on="currentListeners"
      @change="updateModel"
      @blur="blurHandler"
    ></el-input>
    <!-- 产品选择 -->
    <select-filter
      v-if="type === 'PRODUCT_CHOICE' && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      :assign-user-choice-focus="false"
      v-bind="$attrs"
      :select-list="selectList"
      :popper-append-to-body="popperAppendToBody"
      @change="updateModel"
      v-on="currentListeners"
    ></select-filter>
    <!-- 成员选择框 -->
    <select-filter
      v-if="type === 'MEMBER_CHOICE' && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      :is-assign-user="true"
      :assign-user-choice-focus="false"
      v-bind="$attrs"
      :select-list="selectList"
      :popper-append-to-body="popperAppendToBody"
      :clearable="isClearable"
      @change="updateModel"
      v-on="currentListeners"
    ></select-filter>
    <!-- 多选框 -->
    <select-filter
      v-if="multipleField && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      :is-assign-user="type === 'MULTI_MEMBER_CHOICE'"
      :assign-user-choice-focus="false"
      v-bind="$attrs"
      :select-list="selectList"
      multiple
      :popper-append-to-body="popperAppendToBody"
      @change="updateModel"
      v-on="currentListeners"
    ></select-filter>
    <!-- 简单时间框 -->
    <custom-date
      v-if="type === 'LITE_DATE_ATTR' && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      v-bind="$attrs"
      :picker-options="{}"
      @change="updateModel"
      v-on="currentListeners"
    ></custom-date>
    <!-- 时间区间框 -->
    <custom-date
      v-if="type === 'LITE_DATE_RANGE_ATTR' && !showFilterField"
      v-model="componentValue"
      type="daterange"
      class="input-typeed-class"
      v-bind="$attrs"
      @change="updateModel"
      v-on="currentListeners"
    ></custom-date>
    <!-- 布尔值选择框 -->
    <el-select
      v-if="type === 'BOOLEAN_ATTR' && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      :clearable="isClearable"
      :popper-append-to-body="popperAppendToBody"
      @change="updateModel"
      v-on="currentListeners"
    >
      <el-option :label="$t('是')" value="true"></el-option>
      <el-option :label="$t('否')" value="false"></el-option>
    </el-select>
    <!-- 整数输入框, 浮点数输入框 -->
    <el-input
      v-if="(type === 'INT_ATTR' || type === 'FLOAT_ATTR') && !showFilterField"
      v-model="componentValue"
      type="number"
      class="input-typeed-class"
      v-bind="$attrs"
      :clearable="isClearable"
      v-on="currentListeners"
      @change="updateModel"
    ></el-input>
    <!-- 级联选择器 -->
    <el-cascader
      v-if="type === 'CASCADER_CHOICE' && !showFilterField"
      ref="cascader"
      v-model="componentValue"
      class="input-typeed-class"
      :options="selectList"
      v-bind="$attrs"
      :clearable="isClearable"
      :props="{
        checkStrictly: true,
        emitPath: false,
      }"
      :show-all-levels="false"
      v-on="currentListeners"
      @change="updateModel"
    >
    </el-cascader>
    <!-- 单选框 -->
    <el-select
      v-if="type === 'SINGLE_CHOICE' && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      v-bind="$attrs"
      :popper-append-to-body="popperAppendToBody"
      :clearable="isClearable"
      @change="updateModel"
      v-on="currentListeners"
    >
      <el-option
        v-for="jtem in selectList"
        :key="jtem.key"
        :label="jtem.value"
        :value="jtem.key"
      ></el-option>
    </el-select>
    <!-- 单选可搜索框 -->
    <!-- 多选框 -->
    <el-select
      v-if="type === 'MULTI_CHOICE' && !showFilterField"
      v-model="componentValue"
      class="input-typeed-class"
      multiple
      v-bind="$attrs"
      :popper-append-to-body="popperAppendToBody"
      v-on="currentListeners"
      @change="updateModel"
    >
      <el-option
        v-for="jtem in selectList"
        :key="jtem.key"
        :label="jtem.value"
        :value="jtem.key"
      ></el-option>
    </el-select>
    <!-- 过滤器中：多选、全部、过滤 -->
    <select-filter
      v-if="showFilterField"
      v-model="componentValue"
      multiple
      class="input-typeed-class"
      :select-list="selectList"
      :is-assign-user="['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(type)"
      :popper-append-to-body="popperAppendToBody"
      @change="handleSelectChange"
    >
      <el-option slot :label="$t('全部')" value="all"></el-option>
    </select-filter>
    <!-- checkbox -->
    <el-checkbox-group
      v-if="type === 'CHECKBOX'"
      v-model="componentValue"
      v-bind="$attrs"
      @change="updateModel"
      v-on="currentListeners"
    >
      <el-checkbox
        v-for="item in selectList"
        :key="item.key"
        :label="item.key"
        >{{ item.value }}</el-checkbox
      >
    </el-checkbox-group>
  </div>
</template>
<script>
/**
 * @title 全局组件 - 动态字段组件
 * @desc
 * @author heyunjiang
 * @date
 */
// import SelectFilter from '@/components/select-filter'
import CustomDate from '@/components/custom-date'
import { isEmpty } from '@/utils'
export default {
  name: 'TypedFormItem',
  components: { [CustomDate.name]: CustomDate },
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      validator: () => {
        return true
      },
    },

    type: {
      type: String,
      required: false,
      default: 'SINGLE_TEXT',
      desc: '字段类型，默认普通 input 框',
    },

    selectList: {
      type: Array,
      default: () => {
        return []
      },
    },

    filterField: {
      type: Boolean,
      required: false,
      default: false,
      desc:
        '是否应用在过滤器中，过滤器中就需要全部是多选，并且拥有过全部这个 option',
    },

    popperAppendToBody: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否渲染到 body',
    },

    isClearable: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否显示清空图标',
    },

    isAssignUser: {
      type: Boolean,
      default: false,
      desc: '是否为指派类型',
    },
  },

  data() {
    return {
      componentValue: '',
      originalValue: '',
      sessionInitName: [], // 用于多选时，实现假删除
    }
  },
  computed: {
    // 多选
    multipleField() {
      return ['MULTI_MEMBER_CHOICE', 'MULTI_CHOICE_SEARCH'].includes(this.type)
    },
    // 是否在过滤器中展示的字段
    showFilterField() {
      return (
        [
          'MEMBER_CHOICE',
          'MULTI_MEMBER_CHOICE',
          'SINGLE_CHOICE',
          'MULTI_CHOICE',
        ].includes(this.type) && this.filterField
      )
    },
    // current listeners，去掉 change 事件，因为 $listeners 和自己手写的 change 会同时执行
    currentListeners() {
      const listeners = {}
      this.$listeners &&
        Object.entries(this.$listeners).forEach(([key, handler]) => {
          if (key === 'change') {
            return
          }
          listeners[key] = handler
        })
      return listeners
    },
  },

  watch: {
    value() {
      this.generateValue()
    },
    selectList() {
      // 保证在生成列表之后，再降 componentValue 由 initName 转换成 value
      this.$nextTick(this.generateValue)
    },
  },

  mounted() {
    this.generateValue()
  },
  methods: {
    generateValue() {
      let componentValue =
        typeof this.value === 'undefined'
          ? this.$store.state.cm.customFieldInitTypeMap[this.type]
          : this.value
      if (this.type === 'BOOLEAN_ATTR') {
        componentValue =
          componentValue != null ? componentValue + '' : componentValue
      }

      // 特殊处理 需求分类
      if (this.type === 'CASCADER_CHOICE') {
        componentValue =
          this.$refs['cascader'].getCheckedNodes()[0]?.data?.value ||
          this.$attrs.initName ||
          this.value
        componentValue += ''
      }
      // 如果是选择框，并且没有提供可选项，则默认让文字展示，而不是 key 展示
      if (
        [
          'MEMBER_CHOICE',
          'MULTI_MEMBER_CHOICE',
          'SINGLE_CHOICE',
          'MULTI_CHOICE',
          'CASCADER_CHOICE',
        ].includes(this.type) &&
        !this.selectList.length &&
        !isEmpty(componentValue)
      ) {
        componentValue = this.$attrs.initName || componentValue
        if (['MULTI_MEMBER_CHOICE', 'MULTI_CHOICE'].includes(this.type)) {
          componentValue =
            this.sessionInitName.length > 0
              ? this.sessionInitName
              : componentValue
          componentValue = Array.isArray(componentValue)
            ? componentValue
            : componentValue.split(',')
        }
      }
      if (this.type === 'CHECKBOX') {
        componentValue = this.value
      }
      this.componentValue = componentValue
      this.originalValue = componentValue
    },
    // 失去焦点时触发事件
    blurHandler() {
      this.$emit('blur')
      if (this.originalValue !== this.componentValue) {
        this.$emit('change', this.componentValue)
      }
    },
    updateModel(value) {
      // 如果是多项选择框，并且没有提供可选项，在删除 name 时，要清除对应的 key
      if (
        ['MULTI_MEMBER_CHOICE', 'MULTI_CHOICE'].includes(this.type) &&
        this.selectList.length === 0
      ) {
        this.sessionInitName = value
        this.$emit('change', value)
        return
      }
      if (this.type === 'BOOLEAN_ATTR') {
        const boolVal = value === 'false' ? false : value ? true : null
        this.$emit('change', boolVal)
        return
      }
      if (this.type === 'CASCADER_CHOICE') {
        this.$emit('change', value)
      }
      // 会自动 emit change 事件
      if (this.type !== 'CASCADER_CHOICE') {
        this.$emit('change', value)
      }
    },
    // 控制全选 select
    handleSelectChange(value) {
      // 如果最后一个选中了全部
      if (value[value.length - 1] === 'all') {
        this.componentValue = ['all']
      }
      // 如果不是最后一个选中了全部
      if (
        this.componentValue.includes('all') &&
        this.componentValue.length > 1
      ) {
        this.componentValue = this.componentValue.filter(item => item !== 'all')
      }
      this.$emit('change', this.componentValue)
    },
  },
}
</script>
<style lang="scss" scoped>
.input-typeed-class {
  width: 100%;
  max-width: 100%;
}
</style>
