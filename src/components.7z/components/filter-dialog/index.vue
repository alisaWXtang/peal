<template>
  <div ref="showFilterDialog" class="filter-dialog-box">
    <div ref="buttonBox" @click="showContent = !showContent">
      <slot name="reference"></slot>
    </div>
    <!--    <div class="mask-box" v-show="showContent" @click="handleClose"></div>-->
    <div v-show="showContent" ref="contentBox" class="content-dialog-box">
      <div class="header-wrap">
        <span>{{ title }}</span>
        <i class="co-icon-close" @click.stop="handleClose"></i>
      </div>
      <slot name="content"></slot>
    </div>
  </div>
</template>

<script>
import { on } from 'element-ui/src/utils/dom'
const paddingTop = 5
export default {
  name: 'FilterDialog',
  props: {
    placement: {
      type: String,
      default: 'bottom',
    },
    height: {
      type: String,
      default: null,
    },
    width: {
      type: String,
      default: '360px',
    },
    title: {
      type: String,
      default: '',
    },
    // 储存点击的元素 不会让本弹窗关闭
    filterElements: {
      type: Array,
      default: () => [],
    },
    // UI规定 距离左边或者右边距最少 8 像素
    disX: {
      type: [String, Number],
      default: 8,
    },
    disY: {
      type: [String, Number],
      default: 8,
    },
    // 弹窗距视口右边的距离
    rightDistance: {
      type: String,
      default: '',
    },
  },
  provide() {
    return {
      closeDialog: () => {
        this.handleClose()
      },
    }
  },
  data() {
    return {
      showContent: false,
      dialogBox: null, // 按钮外盒子
      dialogBoxRect: null, // 按钮外盒子矩阵信息
      contentBox: null, // 内容外盒子
      contentBoxRect: null, // 内容外盒子矩阵信息
    }
  },
  watch: {
    showContent: {
      handler(val) {
        if (val) {
          this.$nextTick(() => {
            this.init()
          })
        }
      },
      immediate: true,
    },
  },
  mounted() {
    // this.init()
    on(document, 'click', this.handleCloseOutSide)
  },
  methods: {
    init() {
      this.dialogBox = this.$refs.showFilterDialog
      this.contentBox = this.$refs.contentBox
      this.dialogBoxRect = this.dialogBox.getBoundingClientRect()
      this.calculateHeightAndWidth()
      if (this.placement === 'bottom') {
        this.calculateStyleForBottom()
      }
      this.calculateCenter()
    },
    calculateStyleForBottom() {
      this.contentBox.style.top = this.dialogBoxRect.height + paddingTop + 'px'
    },
    calculateCenter() {
      // 重新计算位置
      this.dialogBoxRect = this.dialogBox.getBoundingClientRect()
      // 有设置距离视口右边距
      if (this.rightDistance) {
        // 窗口宽度 - 按钮左侧距离 - 弹窗宽度 - 右边距
        this.contentBox.style.left =
          window.innerWidth -
          this.dialogBoxRect.left -
          this.contentBoxRect.width -
          this.rightDistance +
          'px'
        return
      }

      const left = this.contentBoxRect.left
      const right = window.innerWidth - this.contentBoxRect.right
      if (left > right) {
        // 靠右情况
        const dialogWidth = this.dialogBoxRect.width
        const contentWidth = this.contentBoxRect.width
        const disLeft = contentWidth / 2 - dialogWidth / 2 // 暂时距离左边距
        //计算dialog是否超出视口边界
        const x =
          this.dialogBoxRect.right +
          (this.contentBoxRect.width / 2 - this.dialogBoxRect.width / 2) -
          window.innerWidth +
          Number(this.disX)
        if (x > 0) {
          console.log(disLeft, x)
          // 超出视口
          const moveLeft = disLeft + x
          this.contentBox.style.left = -moveLeft + 'px'
        } else {
          this.contentBox.style.left = -disLeft + 'px'
        }
      } else {
        //  靠左 暂时为完成
      }
    },
    calculateHeightAndWidth() {
      this.contentBox.style.height = this.height
        ? this.height + 'px'
        : window.innerHeight -
          this.dialogBoxRect.bottom -
          paddingTop -
          Number(this.disY) +
          'px'
      this.contentBox.style.width = this.width
      this.contentBoxRect = this.contentBox.getBoundingClientRect()
    },
    handleClose() {
      this.$emit('filterDialogClose')
      this.showContent = false
    },
    handleCloseOutSide(e) {
      // 已经展示的，才判断是否点了外面
      if (this.showContent) {
        if (this.isClickSelf(e)) {
          this.handleClose()
        }
      }
    },
    isClickSelf(e) {
      let result = true
      if (this.$el.contains(e.target)) {
        result = false
      } else {
        this.filterElements.forEach(item => {
          if (item instanceof HTMLElement && item.contains(e.target)) {
            result = false
          } else if (typeof item === 'string') {
            let firstStr = item.substr(0, 1)
            let ele
            if (firstStr === '#') {
              ele = document.querySelector(item)
            } else {
              ele = document.querySelector('#' + item)
            }
            if (ele && ele.contains(e.target)) {
              result = false
            }
          }
        })
      }
      return result
    },
  },
}
</script>

<style lang="scss" scoped>
.filter-dialog-box {
  position: relative;
  .el-button-text {
    color: #666666;
  }
  .filter-click {
    color: $--color-primary;
  }
  .hover-filter {
    &:hover {
      color: $--color-primary;
    }
  }
  .content-dialog-box {
    z-index: 101;
    position: absolute;
    top: -10px;
    background: #ffffff;
    padding: 16px 24px 60px 24px;
    box-sizing: border-box;
    border: 1px solid #dcdfe6;
    box-shadow: 0 3px 12px 0 rgba(102, 102, 102, 0.15);
    border-radius: 4px;
    .footer-button-box {
      position: absolute;
      right: 24px;
      bottom: 16px;
    }
  }
  .header-wrap {
    height: 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    span {
      font-family: PingFangSC-Medium;
      font-size: 16px;
      color: #333333;
    }
    i {
      cursor: pointer;
    }
  }
  .mask-box {
    position: fixed;
    background-color: pink;
    opacity: 0.3;
    top: 64px;
    left: 0;
    width: 100%;
    height: calc(100% - 64px);
    z-index: 100;
  }
  .el-button {
    &:focus {
      &.el-button--default {
        &:not(.is-plain) {
          &:not(.el-button--primary) {
            color: #595959;
            border-color: #dcdfe6;
            background-color: #fff;
          }
        }
      }
    }
  }
}
</style>
