<template>
  <div class="diff-box" v-html="result"></div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title diff
 * @desc
 * @author heyunjiang
 * @date 2020.7.8
 */
import htmldiff from './htmldiff'

export default {
  name: 'ColumbusDiff',
  components: {},
  mixins: [],
  props: {
    preContent: {
      type: String,
      required: true,
      desc: '改变前的内容',
    },

    nextContent: {
      type: String,
      required: true,
      desc: '改变后的内容',
    },
  },

  data() {
    return {
      result: '',
    }
  },
  computed: {},
  watch: {
    preContent() {
      this.getDiffValue()
    },
    nextContent() {
      this.getDiffValue()
    },
  },

  created() {},
  mounted() {
    this.getDiffValue()
  },
  methods: {
    // 获取 diff 结果值
    getDiffValue() {
      this.result = htmldiff(this.preContent || '', this.nextContent || '')
    },
  },
}
</script>
<style lang="scss" scoped>
.diff-box {
  /deep/ ins {
    text-decoration: none;
    background-color: #d4fcbc;
  }

  /deep/ del {
    text-decoration: line-through;
    background-color: #fbb6c2;
    color: #555;
  }
}
</style>
