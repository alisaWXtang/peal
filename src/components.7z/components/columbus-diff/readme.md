# @heytap/columbus-diff

time: 2020.7.8  
author: heyunjiang

通用文本 diff 组件

![demo](./demo.jpg)

## 使用方式 

`npm i @heytap/columbus-diff -S`

```javascript
import ColumbusDiff from "@heytap/columbus-diff";

<ColumbusDiff :preContent="preContent" :nextContent="nextContent"></ColumbusDiff>
```

props|说明|类型|是否必须
:--:|:--:|:--:|:--:
preContent|修改前的文本| String | 是
nextContent|修改后的文本| String | 是
