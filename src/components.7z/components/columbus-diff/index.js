import { i18n } from '@/i18n'
import ColumbusDiff from './src/index'

ColumbusDiff.install = Vue => Vue.component(ColumbusDiff.name, ColumbusDiff)

export default ColumbusDiff
