import guideStepImg from '@/assets/guide_step1.svg'
export const guideType = {
  wholeProcess: 'wholeProcess', // 了解敏捷研发
  requirement: 'requirement', // 创建需求
  sprint: 'sprint', // 规划迭代
  sprintProgress: 'sprintProgress', // 进度跟进
  bug: 'bug', // 缺陷管理
  document: 'document', // 文档
}

export const guideStep = {
  requirementCreate: 'requirementCreate', // 创建需求
  requirementSplit: 'requirementSplit', // 拆分子需求
  requirementCollect: 'requirementCollect', // 
  sprintCreate: 'sprintCreate', // 创建迭代
  sprintPlanning: 'sprintPlanning', // 规划迭代
  taskSplit: 'taskSplit', // 任务拆分
  progressOverview: 'progressOverview', // 需求、任务完成进度
  sprintBurnOut: 'sprintBurnOut', // 迭代燃尽图
  bugCreate: 'bugCreate', // 创建缺陷
  bugTrack: 'bugTrack', // 跟踪缺陷
}

export default [
  {
    label: '了解敏捷研发',
    guideType: guideType.wholeProcess,
    img: guideStepImg,
  },
  {
    label: '创建需求',
    jumpUrl: '/requirement/list',
    guideType: guideType.requirement,
    steps: [
      {
        title: '收集需求',
        desc: ['迭代开始前，产品负责人收集各方需求，整理出产品 backlog 记录在系统内,并按照对用户的价值进行优先级排序。']
      },
      {
        title: '创建需求',
        desc: ['产品经理经过需求梳理后录入原始需求，并以用户的视角描述需求的内容。需求模板参考：',
          '【需求背景及价值】',
          '@weaken（阐述需求提出的背景、适用的业务场景及实现的业务价值）',
          '【需求描述】',
          '@weaken（按照故事点拆分原则阐述需求场景、业务逻辑/规则、需求功能描述；如涉及原型设计需附上原型图/原型链接）',
          '【验收标准】',
          '@weaken（定义需求完成的最终验收标准，以用户的视角进行描述）',
          '【其他说明】',
          '@weaken（关于需求的补充说明）',
        ],
        guideStep: guideStep.requirementCreate,
        steps: {
          1: {
            desc: '1、点击“新建需求”',
            position: {
              left: -338,
              top: -40
            },
          },
          2: {
            desc: '2、填写简洁的需求标题',
            position: {
              left: 255,
              top: -39
            },
          },
          3: {
            desc: '3、填写需求描述',
            position: {
              left: 438,
              top: 254
            },
          },
          4: {
            desc: '4、提交需求',
            position: {
              left: -338,
              top: 10,
              pointTop: -40,
            },
          }
        },
      },
      {
        title: '拆分需求',
        desc: [
          '产品经理对需求进行拆分，按照用户使用的功能场景以及需求颗粒度的大小拆分到Epic（史诗）/Feature（特性）/Story（故事），参考如下：',
          '史诗：@bold包含一组功能模块或一系列场景的大型用户故事集合，跨多个迭代实现，建议10~20人天。',
          '特性：@bold具有独立商业价值的功能模块，可单独验证、交付，可以跨迭代实现，建议5~10人天。',
          '故事：@bold独立可测试的系统功能或功能场景，作为最小可测试和可交付单元，在一个迭代内完成，建议2~5人天。',
        ],
        guideStep: guideStep.requirementSplit,
        steps: {
          1: {
            desc: '1、选择需求',
            position: {
              left: 146,
              top: 18,
            },
          },
          2: {
            desc: '2、将需求拆解成子需求，子需求是可以规划进迭代中的需求',
            position: {
              left: 101,
              top: -52,
            },
          },
        }
      },
    ]
  },
  {
    label: '规划迭代',
    jumpUrl: '/sprint/detail',
    guideType: guideType.sprint,
    steps: [
      {
        title: '什么是迭代',
        desc: ['迭代是指把一个复杂且开发周期很长的开发任务，分解为很多小周期可完成的任务，周期通常为2-4周，这样一个周期就是一次迭代的过程。'],
      },
      {
        title: '创建迭代',
        desc: ['指定迭代目标，确定迭代的开始时间和结束时间。'],
        guideStep: guideStep.sprintCreate,
        steps: {
          1: {
            desc: '1、点击“创建迭代”',
            position: {
              left: 125,
              top: -40
            },
          },
          2: {
            desc: '2、填写迭代信息',
            position: {
              left: 480,
              top: -40
            },
          },
          3: {
            desc: '2、点击“确定”，提交迭代',
            position: {
              left: 110,
              top: -39
            },
          },
        }
      },
      {
        title: '规划迭代',
        desc: ['从规划页面勾选本次迭代涉及到的需求放入迭代中。对整个迭代的工作量做评估，确定迭代的需求范围。'],
        guideStep: guideStep.sprintPlanning,
        steps: {
          1: {
            desc: '1、点击“规划”按钮',
            position: {
              left: -320,
              top: -46
            },
          },
          2: {
            desc: '2、勾选左侧未规划进迭代的工作项',
            position: {
              left: 90,
              top: 60
            },
          },
          3: {
            desc: '3、点击“>”箭头，将左侧勾选的工作项规划进右侧迭代',
            position: {
              left: 90,
              top: -41
            },
          },
        }
      },
      {
        title: '任务拆分',
        desc: ['从当确定完迭代的需求范围后，正式进入迭代开发，需要在需求下拆分开发任务，比如一个需求分成前端开发和后端开发任务，两个任务同时完成需求才可交付'],
        guideStep: guideStep.taskSplit,
        steps: {
          1: {
            desc: '1、选择需求进行任务分解',
            position: {
              left: 320,
              top: -50
            },
          },
          2: {
            desc: '2、在需求下进行任务分解',
            position: {
              left: 116,
              top: -47,
            },
          },
        }
      },
    ]
  },
  {
    label: '进度跟进',
    jumpUrl: '/sprint/detail',
    guideType: guideType.sprintProgress,
    steps: [
      {
        title: '迭代完成进度',
        desc: ['进度概览展现整个迭代的需求、任务、缺陷的各项指标情况，可随时跟踪迭代进度'],
        guideStep: guideStep.progressOverview,
        steps: {
          1: {
            desc: '进度概览，可查看需求/任务/缺陷的进度情况',
            position: {
              left: 220,
              top: -40
            },
          },
        }
      },
      {
        title: '迭代燃尽图',
        desc: ['迭代燃尽图，展现迭代中所有需求的剩余规模总和跟随日期的变化而逐日递减的燃尽过程。'],
        guideStep: guideStep.sprintBurnOut,
        steps: {
          1: {
            desc: '可查看需求数量燃尽图，通过燃尽图可知晓迭代中需求进度的健康情况',
            position: {
              left: 220,
              top: -50
            },
          },
          2: {
            desc: '展开全部，可查看关于迭代的更多进度统计报表',
            position: {
              left: 120,
              top: -60
            },
          },
          3: {
            desc: '迭代负责人可通过报表及时跟踪迭代进度',
            position: {
              left: 220,
              top: -50
            },
          },
        }
      },
    ]
  },
  {
    label: '缺陷管理',
    jumpUrl: '/bug/list',
    guideType: guideType.bug,
    steps: [
      {
        title: '创建缺陷',
        desc: ['记录迭代过程中产生的缺陷，指派对应的研发人员处理，并记录跟进bug。'],
        guideStep: guideStep.bugCreate,
        steps: {
          1: {
            desc: '1、点击“新建缺陷”',
            position: {
              left: -338,
              top: -40
            },
          },
          2: {
            desc: '2、言简意赅的缺陷标题',
            position: {
              left: 255,
              top: -39
            },
          },
          3: {
            desc: '3、详细的缺陷描述',
            position: {
              left: 438,
              top: 254
            },
          },
          4: {
            desc: '4、选择缺陷所属的迭代',
            position: {
              left: -338,
              top: -40
            },
          },
          5: {
            desc: '5、点击“保存”提交缺陷',
            position: {
              left: -338,
              top: 10,
              pointTop: -40,
            },
          }
        }
      },
      {
        title: '跟踪缺陷',
        desc: ['统计分析缺陷数据，帮助团队了解迭代质量'],
        guideStep: guideStep.bugTrack,
        steps: {
          1: {
            desc: '可在迭代概览-进度图中查看缺陷缺陷趋势图，跟踪缺陷消解情况',
            position: {
              left: 160,
              top: -50
            },
          },
          2: {
            desc: '可单独新建缺陷类报表,用于分析缺陷',
            position: {
              left: -348,
              top: -45
            },
          },
        },
      },
    ]
  },
  {
    label: '迭代回顾',
    jumpUrl: '/file/fileInfo',
    guideType: guideType.document,
    steps: [
      {
        title: '迭代总结',
        desc: ['迭代结束后，团队一起进行迭代回顾，总结Well和Less Well，发现改进点，提出解决措施，使团队在接下来的迭代中更高效，总结结果可以沉淀在文档中。']
      },
    ]
  },
]