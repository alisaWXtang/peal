<template>
  <div
    @click.stop
    class="guide-step-view"
    :class="[
      stepInfo.visible ? '' : 'hidden',
      stepInfo.position.left > 0 ? 'at-left' : 'at-right',
    ]"
    :style="{
      left: positionLeft,
      top: positionTop,
    }"
  >
    <div class="desc">{{ stepInfo.desc }}</div>
    <div class="btn-box">
      <div class="prev" v-if="showPrev" @click.stop="handlePrev">
        <i class="el-icon-arrow-left" /> 上一步
      </div>
      <div class="next" v-if="showNext" @click.stop="handleNext">
        下一步 <i class="el-icon-arrow-right" />
      </div>
    </div>
    <i class="el-icon-close btn-close" @click="handleClose" />
    <div class="point" :style="{ marginTop: pointTop }">
      <div />
      <div />
    </div>
    <div class="horn" :style="{ marginTop: pointTop }"></div>
  </div>
</template>
<script>
import { guide } from '@/store/mutation-types'
import guideData from './guideData'

export default {
  components: {},
  props: {},
  data() {
    return {
      activeItem: {},
    }
  },
  computed: {
    stepInfo() {
      return this.$store.state.guide.stepInfo
    },
    showPrev() {
      return (
        !!this.stepInfo.prevCallback ||
        !!this.stepInfo.steps[this.stepInfo.step - 1]
      )
    },
    showNext() {
      return (
        !!this.stepInfo.nextCallback ||
        !!this.stepInfo.steps[this.stepInfo.step + 1]
      )
    },
    pointTop() {
      return this.stepInfo.position.pointTop
        ? this.stepInfo.position.pointTop + 'px'
        : 0
    },
    positionLeft() {
      return this.stepInfo.left + this.stepInfo.position.left + 'px'
    },
    positionTop() {
      return this.stepInfo.top + this.stepInfo.position.top + 'px'
    },
  },
  watch: {
    positionTop(val) {
      if (val) {
        this.hideGuideDialog()
      }
    },
  },
  mounted() {
    this.hideGuideDialog()
  },
  methods: {
    handleClose() {
      this.$store.commit(guide.STOP_STEP)
      this.$store.commit(guide.UPDATE_GUIDE_STEP, null)
    },
    async handlePrev() {
      this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      if (this.stepInfo.prevCallback) {
        // 延时50毫秒 处理异步的问题
        if (this.stepInfo.prevCallback() === true) {
          await setTimeout(() => {}, 50)
        }
      }
      if (this.stepInfo.steps[this.stepInfo.step - 1]) {
        this.$store.commit(guide.UPDATE_STEPINFO, {
          nowStep: this.stepInfo.steps[this.stepInfo.step - 1],
          stepIndex: this.stepInfo.step - 1,
        })
      }
    },
    async handleNext() {
      this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      if (this.isLast()) {
        // 执行nextCallback，解决下一步的特殊交互, 比如迭代规划-任务拆分的最后一个步骤点击下一步专场时需要等待关闭弹窗
        let flag = this.stepInfo.nextCallback && this.stepInfo.nextCallback()
        if (flag) {
          await setTimeout(() => {}, 300)
        }
        this.jumpNextModel()
        return
      }
      if (this.stepInfo.nextCallback && this.stepInfo.nextCallback() === true) {
        // 延时50毫秒 处理异步的问题
        await setTimeout(() => {}, 50)
      }
      if (this.stepInfo.steps[this.stepInfo.step + 1]) {
        this.$store.commit(guide.UPDATE_STEPINFO, {
          nowStep: this.stepInfo.steps[this.stepInfo.step + 1],
          stepIndex: this.stepInfo.step + 1,
        })
      }
    },
    // 是否为当前模块的第一个节点的第一步
    isFirst() {
      let nowGuideStep = this.$store.state.guide.guideStep
      let nowGuideType = this.$store.state.guide.guideType
      let nowGuideInfo = guideData.find(item => item.guideType === nowGuideType)
      let nowIndex = null
      nowGuideInfo.steps.find((item, index) => {
        if (item.guideStep === nowGuideStep) {
          nowIndex = index
          return item
        }
      })
      if (nowIndex > 0) return false
      return true
    },
    // 是否为当前模块的最后一个节点的最后一步
    isLast() {
      let nowGuideStep = this.$store.state.guide.guideStep
      let nowGuideType = this.$store.state.guide.guideType
      let nowGuideInfo = guideData.find(item => item.guideType === nowGuideType)
      let nowIndex = 0
      let nowGuideStepInfo = nowGuideInfo.steps.find((item, index) => {
        if (item.guideStep === nowGuideStep) {
          nowIndex = index
          return item
        }
      })
      if (nowIndex + 1 < nowGuideInfo.steps.length) return false
      let nowStepIndex = this.stepInfo.step
      return !!!nowGuideStepInfo.steps[nowStepIndex + 1]
    },
    // 如果当前步骤小弹窗被引导弹窗遮挡，需要隐藏引导弹窗
    hideGuideDialog() {
      // 除去引导弹窗的可视高度
      let clientContent = document.body.clientHeight - (document.body.width > 1600 ? 400 : 330)
      if (
        this.stepInfo.top + this.stepInfo.position.top + 160 >
        clientContent
      ) {
        this.$store.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, false)
      }
    },
    jumpNextModel() {
      let guideType = this.$store.state.guide.guideType
      let nowIndex = 0
      guideData.find((item, index) => {
        if (item.guideType === guideType) {
          nowIndex = index
          return
        }
      })
      let target = guideData[nowIndex + 1]
      this.$store.commit(guide.UPDATE_GUIDE_STEP, null)
      this.$store.commit(guide.UPDATE_GUIDE_TYPE, target.guideType)
      let query = {
        projectId: this.$getUrlParams().projectId,
        guideType: target.guideType,
      }
      if (this.$getUrlParams().sprintId) {
        query.sprintId = this.$getUrlParams().sprintId
      }
      this.$router.push({
        path: target.jumpUrl,
        query: query,
      })
    },
  },
}
</script>
<style lang="scss" scoped>
$bgColor: #599af5;
.guide-step-view {
  width: 290px;
  background-color: $bgColor;
  min-height: 112px;
  border-radius: 5px;
  z-index: 2888;
  color: $color-font-white-common;
  padding: 24px 24px 18px;
  box-sizing: border-box;
  position: fixed;
  // transition: all .3s;
  opacity: 1;
  &.at-right {
    .horn {
      content: '';
      position: absolute;
      right: -5px;
      top: 50%;
      transform: translateY(-50%);
      width: 0;
      height: 0;
      border-top: 5px solid transparent;
      border-left: 5px solid $bgColor;
      border-bottom: 5px solid transparent;
    }
  }
  &.at-left {
    .horn {
      content: '';
      position: absolute;
      left: -5px;
      top: 50%;
      transform: translateY(-50%);
      width: 0;
      height: 0;
      border-top: 5px solid transparent;
      border-right: 5px solid $bgColor;
      border-bottom: 5px solid transparent;
    }
    .point {
      right: auto;
      left: -40px;
    }
  }
  &.hidden {
    z-index: -1;
    opacity: 0;
  }
  .point {
    position: absolute;
    z-index: 1;
    right: -40px;
    top: 50%;
    transform: translateY(-50%);
    width: 26px;
    height: 26px;
    div {
      width: 100%;
      height: 100%;
      position: absolute;
      border-radius: 50%;
      &:first-child {
        opacity: 0.6;
        background-image: radial-gradient(#3081f2 50%, #3081f2 79%);
        z-index: 2;
        animation: ani1 infinite ease-in 1s;
      }
      &:last-child {
        opacity: 0.4;
        background-image: radial-gradient(#3081f2 50%, #3081f2 100%);
        z-index: 1;
        animation: ani2 infinite ease-in 1s;
        animation-delay: 0.6s;
      }
    }
  }
  .btn-close {
    position: absolute;
    right: 0;
    top: 0;
    padding: 10px;
    cursor: pointer;
  }
  .desc {
    font-size: 14px;
    color: $color-font-white-common;
    letter-spacing: 1px;
    line-height: 20px;
    padding-bottom: 24px;
    min-height: 28px;
  }
  .btn-box {
    font-size: 14px;
    color: $color-font-white-common;
    &::after {
      content: '';
      display: block;
      clear: both;
    }
    & > div {
      cursor: pointer;
    }
    .prev {
      float: left;
    }
    .next {
      float: right;
    }
  }
}
@keyframes ani1 {
  from {
    transform: scale(0.3);
    opacity: 0.6;
  }
  to {
    transform: scale(1);
    opacity: 0.45;
  }
}
@keyframes ani2 {
  from {
    transform: scale(0.3);
    opacity: 0.4;
  }
  to {
    transform: scale(1);
    opacity: 0;
  }
}
</style>
