<template>
  <div>
    <transition name="toggle">
      <GuideDialog v-if="visible" />
    </transition>
    <GuideStep v-if="stepVisible" />
  </div>
</template>
<script>
import { guide } from '@/store/mutation-types'
import GuideDialog from './guideDialog'
import GuideStep from './guideStep'
import { guideType } from './guideData'
import storage from '@/utils/localstorage'
import { getProjectList } from '@/service/project-list'

export default {
  components: { GuideDialog, GuideStep },
  computed: {
    visible() {
      return this.$store.state.guide.visible
    },
    stepVisible() {
      return this.$store.state.guide.stepInfo.visible
    },
    step() {
      return this.$store.state.guide.stepInfo.step
    },
  },
  watch: {
    '$route.query'(val, oldVal) {
      if (!val.guideType) {
        // 用户其他操作终止指引
        // this.$store.commit(guide.UPDATE_GUIDE_TYPE, null)
        this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      }
      // if (val.guideType && !oldVal.guideType) {
      //   this.openGuide(true)
      // }
    },
    '$route.path'(val) {
      // 如果403界面时关闭指引
      if (val === '/403') {
        this.closeGuide()
      }
    },
    step(val) {
      // 进入第一个节点第一个步骤时打开引导弹窗
      if (val === 1) {
        this.$store.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, true)
      } else {
        this.$store.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, false)
      }
    },
  },
  mounted() {
    let _guideType = this.$getUrlParams().guideType
    if (_guideType) {
      this.$store.commit(guide.UPDATE_GUIDE_TYPE, _guideType)
      this.openGuide(true)
    }
    // 情景一 判断用户是第一次登陆，则触发用户指引
    if (window.$udp.isShowGuide && window.$udp.isShowGuide()) {
      this.openGuide(true)
    }
    // 情景二 由其他子应用跳转至项目协同，通过"url"中"userGuide===1"判断是否需要用户指引
    if (this.$getUrlParams().userGuide === '1') {
      let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
      delete query.userGuide
      query.guideType = guideType.wholeProcess
      this.$router.replace({
        path: '/project/list',
        query: query,
      })
    }
    // 监听主应用事件
    this.$bus.$on('onGlobalStateChange', this.onGlobalStateChange)

    // 主动清除指引状态，解决用户卡顿出现造成的$guideIsOpen未被清除
    if (storage.getItem('$guideIsOpen')) {
      setTimeout(() => {
        storage.removeItem('$guideIsOpen')
      }, 1000)
    }
  },
  beforeDestroy() {
    this.$bus.$off('onGlobalStateChange', this.onGlobalStateChange)
    // 跳出页面后需要把用户主动关闭的状态取消掉
    if (window.location.pathname !== '/') {
      window.$udp.setAppShareData({
        userToggleGuide: 'open',
      })
    }
  },
  methods: {
    onGlobalStateChange({ state, prev }) {
      if (storage.getItem('$guideIsOpen')) return
      // 在线指引图标触发指引
      if (state.userGuide !== prev.userGuide) {
        window.$udp.setAppShareData({
          userToggleGuide: 'open',
        })
        this.openGuide()
      }
      // 在线指引图标关闭按钮，结束指引
      if (state.userGuideClose !== prev.userGuideClose && this.visible) {
        this.closeGuide()
      }
      // 工作台点击编辑时，结束引导
      if (state.homeEdit !== prev.homeEdit && this.visible) {
        this.closeGuide()
      }
      // 用户退出时，结束当前用户的指引状态
      if (state.logout !== prev.logout && this.$getUrlParams().guideType) {
        let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
        delete query.guideType
        this.$router.replace({
          path: this.$route.path,
          query: query,
        })
        this.initLovalStorage()
      }
    },
    async openGuide(isInit) {
      let urlProjectId = this.$getUrlParams().projectId
      if (urlProjectId && isInit) {
        let res = await getProjectList({
          completed: false,
          pageInfo: {
            pageNumber: 1,
            pageSize: 9999,
          },
        })
        let projectList = res.data?.results || []
        let project = projectList.find(item => item.id === +urlProjectId)
        if (!project) return
      }
      if (storage.getItem('$guideIsOpen')) return
      if (document.getElementById('guideDialog')) return
      let { userToggleGuide } = window.$udp.getAppShareData()
      if (userToggleGuide === 'down') return
      if (
        this.$getUrlParams().projectId ||
        this.$route.path === '/project/list' ||
        window.location.pathname === '/'
      ) {
        this.$store?.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, true)
      } else {
        let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
        query.guideType = guideType.wholeProcess
        this.$router.push({
          path: '/project/list',
          query: query,
        })
      }
      this.initLovalStorage()
    },
    closeGuide() {
      // 结束引导
      this.initLovalStorage()
      this.$store?.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, false)
      this.$sotre?.commit(guide.UPDATE_GUIDE_TYPE, null)
      let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
      delete query.guideType
      this.$router.replace({
        path: this.$route.path,
        query: query,
      })
    },
    initLovalStorage() {
      storage.setItem('$guideIsOpen', 1)
      setTimeout(() => {
        storage.removeItem('$guideIsOpen')
      }, 1000)
    },
  },
}
</script>
<style>
.toggle-enter-active,
.toggle-leave-active {
  transition: all 0.5s;
}
.toggle-enter, .toggle-leave-to /* .toggle-leave-active below version 2.1.8 */ {
  opacity: 0;
  transform: translateY(100%);
}
.udp-user-guide {
  z-index: 2200 !important;
}
</style>
