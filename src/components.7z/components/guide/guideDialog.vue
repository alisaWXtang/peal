<template>
  <div
    id="guideDialog"
    class="guide-dialog-view"
    @click.stop
    v-loading="loading"
  >
    <i
      class="iconfont icon-shouqi1 toggle-btn"
      title="收起指引"
      @click="handleToggle"
    />
    <i
      class="co-icon-close toggle-btn close-btn"
      title="结束指引"
      @click="handleClose"
    />
    <div class="view-left">
      <div class="title">诺亚敏捷研发指引</div>
      <div class="tab-list">
        <div
          class="tab-item"
          :class="guideType === item.guideType ? 'active' : ''"
          v-for="(item, index) in tabList"
          :key="index"
          @click="handleChangeGuideType(item)"
        >
          {{ item.label }}
        </div>
      </div>
    </div>
    <div class="view-right">
      <div class="title">{{ activeItem.label }}</div>
      <div class="warn-message" v-if="warnMessage">
        <i class="co-icon-warning-solid" />{{ warnMessage }}
      </div>
      <img class="guide-img" v-if="activeItem.img" :src="activeItem.img" />
      <div class="step-box" v-else>
        <div
          class="step-list"
          v-for="(rowItem, rowIndex) in stepsArray"
          :key="rowIndex"
        >
          <div
            class="step-item"
            :class="item.guideStep === guideStep ? 'active' : ''"
            v-for="(item, index) in rowItem"
            :key="index"
          >
            <div class="title" :class="!!item.guideStep ? 'can-click' : ''">
              <span @click="handleChangeGuideStep(item)">{{ item.title }}</span>
            </div>
            <div
              class="desc"
              v-for="(descItem, descIndex) in item.desc"
              :key="descIndex"
              :class="descItem.indexOf('@weaken') > -1 ? 'weaken' : ''"
            >
              <template v-if="descItem.indexOf('@bold') > -1">
                <span>{{ descItem.split('@bold')[0] }}</span>
                {{ descItem.split('@bold')[1] }}
              </template>
              <template v-else>
                {{ descItem.replace('@weaken', '') }}
              </template>
            </div>
            <i @click="handleChangeGuideStep(item)">{{ item.index + 1 }}</i>
          </div>
        </div>
      </div>
      <div class="quick-access">
        <div class="quick-access-title">快捷入口</div>
        <a
          class="quick-access-item"
          href="https://noah.myoas.com/docs/front/design?id=10015&version=V%208.0"
          target="_blank"
          >帮助文档</a
        >
        <a class="quick-access-item" target="_blank">最佳实践（建设中）</a
        ><a class="quick-access-item" target="_blank">常见问题（建设中）</a
        ><a class="quick-access-item" target="_blank">视频中心（建设中）</a>
      </div>
    </div>
  </div>
</template>
<script>
import { guide } from '@/store/mutation-types'
import guideData from './guideData'
import { mapState } from 'vuex'
import { guideType } from './guideData'

export default {
  components: {},
  props: {},
  watch: {},
  data() {
    return {
      tabList: guideData,
      loading: false,
    }
  },
  computed: {
    ...mapState({
      visible: state => state.guide.visible,
      position: state => state.guide.position,
      guideType: state => state.guide.guideType,
      guideStep: state => state.guide.guideStep,
      stepInfo: state => state.guide.stepInfo,
      warnMessage: state => state.guide.warnMessage,
      guideStepVisible: state => state.guide.stepInfo.visible,
      projectId: state => state.guide.projectId, // 用于指引的默认项目
      projectStatus: state => state.projectStatus, // 当前项目的状态
    }),
    stepsArray() {
      if (!this.activeItem.steps) return []
      this.activeItem.steps.forEach((item, index) => {
        item.index = index
      })
      return this.group(this.activeItem.steps, 2)
    },
    activeItem() {
      return guideData.find(item => item.guideType === this.guideType) || {}
    },
  },
  watch: {
    '$route.query'(val) {
      if (!val.guideType) {
        this.$store.commit(guide.UPDATE_GUIDE_TYPE, guideType.wholeProcess)
        this.$store.commit(guide.RESET_STEP)
      }
    },
  },
  mounted() {
    if (!this.$getUrlParams().guideType) {
      let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
      query.guideType = guideType.wholeProcess
      this.$router.replace({
        path: this.$route.path,
        query: query,
      })
    }
    // 定位当前指引模块
    let nowGuideType = this.$getUrlParams().guideType || guideType.wholeProcess
    this.handleChangeGuideType(this.getActiveGuideItem(nowGuideType), false)
    this.getPorject()
  },
  methods: {
    junmpToPorjectList() {
      this.$message.warning('当前项目已结束，请重新开始指引')
      this.$router.replace({
        path: '/project/list',
        query: {
          guideType: guideType.wholeProcess,
        },
      })
      this.$store.commit(guide.STOP_STEP)
    },
    getPorject() {
      if (this.projectId) return
      this.$store.dispatch('getGuideProject')
    },
    handleClose() {
      let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
      delete query.guideType
      this.$router.replace({
        path: this.$route.path,
        query: query,
      })
      this.$store.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, false)
      this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      this.$bus.$emit('G_closeGuide')
    },
    handleToggle() {
      this.$store.commit(guide.CHANGE_GUIDE_DIALOG_VISIBLE, false)
      if (window.location.pathname === '/') {
        window.$udp.setAppShareData({
          userToggleGuide: 'down',
        })
      }
    },
    // 引导模块内大步骤切换
    handleChangeGuideStep(item) {
      if (!item.guideStep) return
      if (this.guideStep === item.guideStep && this.stepInfo.visible) return
      // 如果项目为结束状态则跳转回项目列表
      if (this.projectStatus === 2 && this.$getUrlParams().projectId) {
        this.junmpToPorjectList()
        return
      }
      this.$store.commit(guide.RECOVERY_STEP)
      this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      this.$store.commit(guide.UPDATE_GUIDE_STEP, item.guideStep)
      this.$bus.$emit('G_changeGuideStep', item)
    },
    // 引导模块切换
    handleChangeGuideType(item, jumpState = true) {
      let projectId = this.$getUrlParams().projectId || this.projectId
      // 工作台
      if (
        window.location.pathname === '/' &&
        !projectId &&
        item.guideType !== guideType.wholeProcess
      ) {
        window.$udp.openApp({
          // 微应用 key
          key: 'coteam',
          // 微应用路由
          path: '/project/list',
          query: {
            guideType: guideType.wholeProcess,
            needGuide: 1,
          },
        })
        return
      }
      if (
        item.guideType !== guideType.wholeProcess &&
        !projectId &&
        this.$route.path === '/project/list'
      ) {
        this.$bus.$emit('G_projectNeedGuide')
        return
      }
      if (item.guideType !== guideType.wholeProcess && !projectId) {
        this.$router.push({
          path: '/project/list',
        })
        this.$message.warning('请先创建项目')
        return
      }
      // 如果项目为结束状态则跳转回项目列表
      if (this.projectStatus === 2 && this.$getUrlParams().projectId) {
        this.junmpToPorjectList()
        return
      }
      if (
        item.jumpUrl === this.$route.path &&
        item.guideType === this.activeItem.guideType
      )
        return
      this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      this.$store.commit(guide.UPDATE_GUIDE_STEP, null)
      this.$store.commit(guide.RECOVERY_STEP)
      this.$store.commit(guide.UPDATE_GUIDE_TYPE, item.guideType)
      if (!jumpState) return
      this.$store.commit(guide.UPDATE_STEP_VISIBLE, false)
      if (item.jumpUrl) {
        let query = {
          projectId: projectId,
          guideType: item.guideType,
        }
        if (['sprint', 'sprintProgress'].includes(item.guideType)) {
          query.sprintId = this.$getUrlParams().sprintId
        }
        // 如果是工作台
        if (window.location.pathname === '/') {
          window.$udp.openApp({
            // 微应用 key
            key: 'coteam',
            // 微应用路由
            path: item.jumpUrl,
            query: query,
          })
        } else {
          this.$router.push({
            path: item.jumpUrl,
            query: query,
          })
        }
      } else {
        let query = JSON.parse(JSON.stringify(this.$getUrlParams()))
        query.guideType = item.guideType
        this.$router.replace({
          path: item.jumpUrl,
          query: query,
        })
      }

      this.$bus.$emit('G_changeGuideType', item)
    },
    group(array, subGroupLength) {
      if (!array) return []
      let index = 0
      let newArray = []
      while (index < array.length) {
        newArray.push(array.slice(index, (index += subGroupLength)))
      }
      return newArray
    },
    getActiveGuideItem(guideType) {
      return this.tabList.find(item => item.guideType === guideType)
    },
  },
}
</script>
<style lang="scss" scoped>
$testWeaken: #999;
$blue: #3081f2;
.guide-dialog-view {
  position: fixed;
  left: 0;
  bottom: 0;
  height: 400px;
  width: 100%;
  background-color: $color-background-white-common;
  z-index: 5999;
  transform-origin: left top;
  box-shadow: 8px 4px 32px 0 rgba(0, 0, 0, 0.1);
  display: flex;
}
.toggle-btn {
  position: absolute;
  right: 41px;
  top: 8px;
  font-size: 16px;
  padding: 10px 5px;
  z-index: 1;
  cursor: pointer;
  color: $testWeaken;
}
.close-btn {
  right: 11px;
  font-size: 18px;
  top: 7px;
}
.guide-img {
  display: block;
  width: calc(100% - 475px);
  max-height: 100%;
  position: absolute;
  top: 46.5%;
  transform: translateY(-50%);
  left: 26px;
}
.warn-message {
  margin-bottom: 16px;
  font-size: 14px;
  color: #ffaa33;
  line-height: 20px;
  margin-top: -8px;
  i {
    margin-right: 9px;
  }
}
.view-left {
  width: 248px;
  min-width: 248px;
  background-color: #1f5db4;
  background-image: url('~@/assets/guide_bg.jpg');
  background-repeat: no-repeat;
  background-size: cover;
  .title {
    opacity: 0.85;
    line-height: 28px;
    font-size: 20px;
    color: $color-font-white-common;
    padding: 24px 32px;
  }
}
.tab-list {
  height: 324px;
  overflow-y: auto;
  .tab-item {
    font-size: 16px;
    line-height: 22px;
    color: rgba(255, 255, 255, 0.75);
    padding: 9px 32px;
    cursor: pointer;
    &:hover {
      background-color: rgba(255, 255, 255, 0.35);
    }
    &.active {
      background-color: rgba(255, 255, 255, 0.35);
      color: $color-font-white-common;
      position: relative;
      &::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        height: 100%;
        width: 3px;
        background-color: $color-background-white-common;
      }
    }
  }
}
.view-right {
  flex: 1;
  padding-left: 26px;
  padding-right: 225px;
  position: relative;
  height: 100%;
  & > .title {
    font-size: 16px;
    color: $color-font-title-common;
    line-height: 22px;
    font-weight: bold;
    padding-top: 27px;
    padding-bottom: 24px;
  }
}
.step-box {
  display: flex;
  flex-direction: row;
  height: calc(100% - 73px);
  overflow-y: auto;
}
.step-list {
  display: flex;
  flex-direction: column;
  max-width: 480px;
  margin-right: 80px;
  &:last-child {
    margin-right: 60;
  }
  .step-item {
    padding-left: 24px;
    display: inline-block;
    padding-bottom: 40px;
    position: relative;
    &.active {
      .title {
        color: $blue;
      }
      i {
        background-color: $blue;
      }
    }
    .title {
      font-size: 14px;
      color: $color-font-title-common;
      line-height: 20px;
      padding-bottom: 8px;
      font-weight: bold;
      &.can-click {
        cursor: pointer;
        &:hover {
          color: $blue;
        }
      }
    }
    .desc {
      font-size: 14px;
      line-height: 20px;
      color: $textLight;
      &.weaken {
        color: $testWeaken;
        margin-bottom: 5px;
      }
      span {
        font-weight: bold;
        color: $color-font-title-common;
      }
    }
    i {
      width: 16px;
      height: 16px;
      text-align: center;
      line-height: 16px;
      background: #bfbfbf;
      color: $color-font-white-common;
      display: block;
      position: absolute;
      left: 0;
      top: 2px;
      border-radius: 50%;
      font-style: normal;
    }
  }
}
.quick-access {
  position: absolute;
  right: 0;
  top: 24px;
  height: calc(100% - 24px);
  border-left: 1px solid #e5e5e5;
  padding-left: 23px;
  width: 225px;
  box-sizing: border-box;
  padding-top: 50px;
  .quick-access-title {
    font-size: 14px;
    color: $color-font-title-common;
    line-height: 20px;
    padding-bottom: 24px;
    font-weight: bold;
  }
  .quick-access-item {
    font-size: 14px;
    line-height: 20px;
    color: $textLight;
    margin-bottom: 16px;
    cursor: pointer;
    display: block;
  }
}
@media screen and (max-width: 1600px) {
  .guide-dialog-view {
    height: 330px;
  }
}
</style>
