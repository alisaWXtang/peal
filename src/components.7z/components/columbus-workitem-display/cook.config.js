import { i18n } from '@/i18n' // cook.config.js
const path = require('path')
function resolve(dir) {
  return path.join(__dirname, '../../../../', dir)
}

export default {
  build: {
    alias: {
      vue$: 'vue/dist/vue.esm.js',
      '@': resolve('src'),
      '~': resolve('node_modules'),
      base: resolve('src/base'),
      pages: resolve('src/pages'),
      assets: resolve('src/assets'),
      'element-ui': '@heytap/cook-ui',
      'cook-ui': '@heytap/cook-ui',
    },

    type: 'lib',
    output: 'dist',
    entry: 'index.js', // 或者 `src/index.ts` 或者 `src/index.vue`，依次读取
    externals: ['vue', '@heytap/cook-ui'],
  },
}
