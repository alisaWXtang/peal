<template>
  <div>
    <div class="demand-connect">
      <div>
        <div style="overflow:hidden;margin-top: -3px;" class="border">
          <el-button
            v-if="
              disabledRequire &&
                $authFunction('FUNC_COOP_REQT_CREATE', 3, getProjectId())
            "
            type="text"
            class="fl cp"
            style="font-size: 14px;"
            @click="handleAddChildRequrie"
            >+{{ $t('添加子需求') }}</el-button
          >
          <span
            v-else-if="
              $authFunction('FUNC_COOP_REQT_CREATE', 3, getProjectId()) ||
                !disabledRequire
            "
            class="fl task-decompose-title"
            style="color:#cccccc;display: inline-block;padding: 0;"
          >
            <i class="el-icon-warning" style="color:#409EFF;"></i>
            {{ $t('需求已完成') }}/{{ $t('取消不能添加子需求') }}
          </span>
          <span
            v-else
            class="fl task-decompose-title"
            style="color:#cccccc;display: inline-block;padding: 0;"
          >
            <i class="el-icon-warning" style="color:#409EFF;"></i>
            {{ $t('暂无权限') }}
          </span>
        </div>
        <el-table
          :data="childDemandData"
          class="multiple-table"
          style="width: 100%"
          border
        >
          <!-- <el-table-column
            :label="$t('需求ID')"
            show-overflow-tooltip
            width="80"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.isNewAdd"></span>
              <span
                v-else
                class="c-blue-hover cp"
                @click="toRequrieDetailPage(scope.row)"
                >{{ scope.row.id }}</span
              >
            </template>
          </el-table-column> -->
          <el-table-column
            :label="$t('标题')"
            show-overflow-tooltip
            min-width="220"
          >
            <template slot-scope="scope">
              <el-input
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.title"
                v-focus
                style="width:100%;"
                :placeholder="$t('输入标题,回车新建')"
                @keyup.enter.native="handelSaveChildRequire"
              ></el-input>
              <global-input
                v-else
                :init-value="scope.row.display.title"
                :on-change="
                  value => {
                    updateGlobalTitle(scope.row, value)
                  }
                "
              >
                <span slot class="table-input-edit-text c-blue-hover">
                  <span
                    class="font-desgin cp"
                    @click="toRequrieDetailPage(scope.row)"
                    >{{ scope.row.display.title }}</span
                  >
                </span>
              </global-input>
            </template>
          </el-table-column>
          <el-table-column
            :label="$t('优先级')"
            show-overflow-tooltip
            width="80"
          >
            <template slot-scope="scope">
              <el-select
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.priority"
                :disabled="operaisdisable"
              >
                <el-option
                  v-for="(data, index) in priorityList"
                  :key="index"
                  :label="data.value"
                  :value="String(data.key)"
                >
                  <template>
                    <span style="float: left">
                      <span
                        class="mini-circle"
                        :style="{ backgroundColor: data.color }"
                      ></span
                      >{{ data.literal }}
                    </span>
                  </template>
                </el-option>
              </el-select>
              <div v-else>
                <div
                  class="cursor-pointer"
                  style="display: flex;"
                  @click.stop="
                    e =>
                      GlobalSelectTargetClick(
                        scope.row,
                        e,
                        'priority',
                        getDemandRelevance,
                      )
                  "
                  v-html="
                    initNameStatus(
                      scope.row.display.detail.priority.color,
                      scope.row.display.detail.priority.literal,
                    )
                  "
                ></div>
              </div>
            </template>
          </el-table-column>
          <el-table-column
            :label="$t('迭代')"
            show-overflow-tooltip
            min-width="100"
          >
            <template slot-scope="scope">
              <el-select
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.sprintId"
                style="width:100%;"
                :disabled="operaisdisable"
              >
                <el-option
                  v-for="item in sprintList"
                  :key="item.id"
                  :label="item.value"
                  :value="item.key"
                >
                </el-option>
              </el-select>
              <span
                v-else
                class="cursor-pointer current-hover"
                @click.stop="
                  e =>
                    GlobalSelectTargetClick(
                      scope.row,
                      e,
                      'sprintId',
                      getDemandRelevance,
                    )
                "
                >{{ scope.row.display.sprint || '--' }}</span
              >
            </template>
          </el-table-column>

          <el-table-column :label="$t('指派给')" width="120">
            <template slot-scope="scope">
              <select-filter
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.assignUser"
                :is-assign-user="true"
                :assign-user-choice-focus="false"
                :popper-append-to-body="false"
                :select-list="assignUserData"
                :disabled="operaisdisable"
              ></select-filter>
              <select-filter
                v-else-if="scope.row._assignUserChoice"
                v-model="createRequireData.assignUser"
                :is-assign-user="true"
                :select-list="assignUserData"
                :disabled="operaisdisable"
                :assign-user-choice-focus="true"
                :popper-append-to-body="false"
                @change="assignUserEdit"
                @visableChange="
                  val =>
                    selectUserVisibleChange(val, scope.row, '_assignUserChoice')
                "
              ></select-filter>
              <div
                v-else
                class="select-user current-hover"
                @click="handleUserChoice(scope.row, '_assignUserChoice')"
              >
                {{ scope.row.display.assignUser }}
              </div>
            </template>
          </el-table-column>
          <el-table-column :label="$t('开始时间')" width="125">
            <template slot-scope="scope">
              <custom-date
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.startTime"
                type="date"
                style="width: 105px;"
                :disabled="operaisdisable"
                class="date_form1"
                :placeholder="$t('选择日期')"
                :picker-options="{}"
                value-format="yyyy-MM-dd"
                prefix-icon="clean-icon"
              >
              </custom-date>
              <global-input
                v-else
                :init-value="scope.row.startTime || ''"
                input-type="time"
                :on-change="
                  value => {
                    GlobalRequirementUpdate({
                      startTime: value,
                      id: scope.row.id,
                      projectId: scope.row.projectId,
                      cb: updateSuccessHandler,
                    })
                  }
                "
              >
                <span slot class="current-hover">{{
                  scope.row.startTime || '--'
                }}</span>
              </global-input>
            </template>
          </el-table-column>
          <el-table-column :label="$t('结束时间')" width="125">
            <template slot-scope="scope">
              <custom-date
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.endTime"
                type="date"
                :disabled="operaisdisable"
                class="date_form1"
                style="width: 105px;"
                :placeholder="$t('选择日期')"
                :picker-options="{}"
                value-format="yyyy-MM-dd"
                prefix-icon="clean-icon"
              >
              </custom-date>
              <global-input
                v-else
                :init-value="scope.row.endTime || ''"
                input-type="time"
                :on-change="
                  value => {
                    GlobalRequirementUpdate({
                      endTime: value,
                      id: scope.row.id,
                      projectId: scope.row.projectId,
                      cb: updateSuccessHandler,
                    })
                  }
                "
              >
                <span slot class="current-hover">{{
                  scope.row.endTime || '--'
                }}</span>
              </global-input>
            </template>
          </el-table-column>
          <el-table-column
            :label="$t('状态')"
            show-overflow-tooltip
            fixed="right"
            width="100"
          >
            <template slot-scope="scope">
              <!-- <el-select
                新建时状态不需要下拉选择
                v-if="scope.row.isNewAdd == 1"
                v-model="createRequireData.statusId"
                style="width:100%;"
                :disabled="operaisdisable"
              >
                <el-option
                  v-for="(item, index) in nextStatusList"
                  :key="index"
                  :label="item.statusName"
                  :value="item.statusId"
                ></el-option>
              </el-select> -->

              <span
                v-if="scope.row.isNewAdd == 1 && !operaisdisable"
                class="c-blue cp"
                @click="handelSaveChildRequire"
                >{{ $t('保存') }}</span
              >
              <span
                v-if="scope.row.isNewAdd == 1 && !operaisdisable"
                class="c-blue cp"
                @click="handelCancelCreateChildRequire()"
              >
                {{ $t('取消') }}
              </span>
              <span
                v-if="scope.row.isNewAdd == 1 && operaisdisable"
                class="c-disable cp"
                >{{ $t('保存中') }}</span
              >
              <state-flow
                v-else-if="!scope.row.isNewAdd"
                :current-index="0"
                :project-id="getProjectId()"
                :status-id="scope.row.statusId"
                :work-item-type="1"
                :work-item-id="scope.row.id"
                :update-data="updateSuccessHandler"
              >
                <span
                  class="status_name"
                  v-html="
                    initNameStatus(
                      scope.row.display.detail.status.color,
                      scope.row.display.status,
                    )
                  "
                >
                </span>
              </state-flow>
            </template>
          </el-table-column>
          <!-- <el-table-column
            :label="$t('操作')"
            fixed="right"
            show-overflow-tooltip
            :min-width="$isEnglish() ? 140 : 100"
          >
            <template slot-scope="scope">
              <span
                v-if="scope.row.isNewAdd == 1 && !operaisdisable"
                class="c-blue cp"
                @click="handelSaveChildRequire"
                >{{ $t('保存') }}</span
              >
              <span
                v-if="scope.row.isNewAdd == 1 && !operaisdisable"
                class="c-blue cp"
                @click="handelCancelCreateChildRequire()"
              >
                {{ $t('取消') }}
              </span>
              <span
                v-if="scope.row.isNewAdd == 1 && operaisdisable"
                class="c-disable cp"
                >{{ $t('保存中') }}</span
              >
              <span
                v-if="
                  ![1, 2].includes(scope.row.isNewAdd) &&
                    $authFunction(
                      'FUNC_COOP_REQT_PARENT_CHILD_UNBIND',
                      3,
                      getProjectId(),
                    )
                "
                class="c-blue cp"
                @click="
                  () => {
                    handelUnbindParentChildren(scope.row)
                  }
                "
                >{{ $t('关系解绑') }}</span
              >
            </template>
          </el-table-column> -->
        </el-table>
      </div>
    </div>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 需求分解自需求组件
 * @desc
 * @author heyunjiang
 * @date 2020.7.8
 */
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import GlobalSelect from '@/components/field-edit/GlobalSelect.vue'
import GlobalInput from '@/components/field-edit/GlobalInput.vue'
// import FieldEdit from '@/pages/tool/FieldEdit';
import StateFlow from '@/components/state-flow'
import CustomDate from '@/components/custom-date'
import ACTIONSTYPE from '@/store/action-types'
import * as requirementService from '@/service/requirement'
import { priorityList } from '@/service/bug'
import { getUserList } from '@/service/project'
import { getListSprintName } from '@/service/sprint'
import { listUpdateAble } from '@/service/work-status-flow'
import debounce from 'lodash/debounce'

export default {
  name: 'RequirementDetailRequirementDecompose',
  components: {
    GlobalSelect,
    GlobalInput,
    CustomDate,
    // FieldEdit,
    StateFlow,
  },

  mixins: [ProjectCommonMixin, WorkItemTemplateMixin],
  props: {
    detailInfo: {
      type: Object,
      required: true,
      desc: '工作项详情',
    },

    requireId: {
      type: [Number, String],
      default: null,
    },

    projectId: {
      type: [Number, String],
      default: null,
    },

    taskCount: {
      type: Number,
      desc: '当前父需求对应的子任务数量',
    },
  },
  data() {
    return {
      templateInfo: {}, // 模板详情
      childDemandData: [], // 子需求列表
      // 创建子需求模板信息
      createRequireData: {
        isNewAdd: 1,
        title: '',
        projectId: 0,
        parentId: 0,
        sprintId: '',
        priority: '80',
        assignUser: null,
        startTime: '',
        endTime: '',
        // statusId: '',
      },

      priorityList: [], // 优先级列表
      assignUserData: [], // 处理人列表
      sprintList: [], // 迭代列表
      nextStatusList: [], // 分解自需求时可选状态列表
      idVip: null, // 当前更新的工作项 id
      idEditVip: null, // 当前更新的工作项 id
      operaisdisable: false, // 保存中
      localProjectId: this.$getUrlParams().projectId,
    }
  },
  computed: {
    disabledRequire() {
      return this.detailInfo.detail.authority.decomposeChildRequire
    },
  },

  watch: {},
  created() {},
  mounted() {
    this.initData()
  },
  methods: {
    // 读取 projectId 统一入口
    getProjectId() {
      return (
        this.detailInfo?.rawData?.projectId ||
        this.projectId ||
        this.localProjectId
      )
    },
    // 数据初始化
    initData() {
      this.getDemandRelevance()
      this.getPriorityList()
      this.getAssignUser()
      this.getSprintList()
      // this.getNextStatusList(this.detailInfo.rawData.statusId)
    },
    // 获取子需求列表
    getDemandRelevance() {
      if (this.requireId === -1) {
        return
      }
      requirementService
        .demandRelevance({
          projectId: this.getProjectId(),
          id: this.requireId,
        })
        .then(res => {
          this.childDemandData = res.data.children
        })
    },
    // 获取优先级
    getPriorityList() {
      priorityList({
        projectId: this.getProjectId(),
        workItemType: 1,
      }).then(res => {
        this.priorityList = res.data.map(item => {
          return {
            value: item.literal,
            key: item.priority,
            color: item.color,
            ...item,
          }
        })
      })
    },
    // 获取用户
    getAssignUser() {
      getUserList({
        projectId: this.getProjectId(),
        query: null,
      }).then(res => {
        this.assignUserData = res.data.map(item => {
          return {
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
          }
        })
      })
    },
    // 获取迭代列表
    getSprintList() {
      getListSprintName({
        projectId: this.getProjectId(),
        status: 1,
      }).then(res => {
        if (res.status === 200) {
          this.sprintList = res.data.map(item => {
            return {
              value: item.name,
              key: item.id,
              id: item.id,
            }
          })
          this.sprintList.unshift({
            key: 0,
            value: i18n.t('未规划'),
          })
        }
      })
    },
    // 获取下一阶段状态列表 - footer
    getNextStatusList(statusId) {
      if (this.requireId === -1) {
        return
      }
      listUpdateAble({
        workItemType: 1,
        workItemId: this.requireId,
        statusId: statusId,
      }).then(res => {
        this.nextStatusList = []
        if (res.status !== 200 || !res.data) {
          return
        }
        this.nextStatusList = res.data.map(item => {
          return {
            value: item.statusName,
            key: item.statusId,
            ...item,
          }
        })
      })
    },

    // 点击新增子需求
    handleAddChildRequrie: debounce(
      async function() {
        for (var i in this.childDemandData) {
          if (this.childDemandData[i].isNewAdd) {
            return this.$message({
              message: i18n.t('同时只能增加一条子需求'),
              type: 'warning',
            })
          }
        }
        this.createRequireData.priority = this.detailInfo.rawData.priority + ''
        this.templateInfo = await this.getDefaultTemplateInfoForFastCreate(
          this.getProjectId(),
          1,
        ) // 这里不在 data 中声明，因为它不用作为响应式数据
        this.createRequireData.title = this.templateInfo.title
        this.childDemandData.push(this.createRequireData)
      },
      300,
      { leading: true },
    ),
    // 取消新增自需求
    handelCancelCreateChildRequire() {
      this.childDemandData.pop()
    },
    // 更新成功回调
    updateSuccessHandler() {
      this.getDemandRelevance()
      this.$emit('updateInfoSuccess')
    },
    // 新增自需求
    async handelSaveChildRequire() {
      if (
        this.createRequireData.title.length <= 0 ||
        this.createRequireData.title.length > 64
      ) {
        this.$message({
          message: i18n.t('标题长度只能在1~64之间'),
          type: 'error',
        })
        return
      }

      // 必填项校验
      const requiredValid = await this.$store.dispatch(
        ACTIONSTYPE.VALIDTEMPLATEINFOFORFASTCREATE,
        {
          fieldsList: this.templateInfo.fieldsList.map(item => {
            // 忽略子需求状态、指派给的必填校验
            if (['statusId', 'assignUser'].includes(item.attrName)) {
              return {
                ...item,
                required: false,
              }
            }
            return item
          }),
          formInfo: this.createRequireData,
        },
      )

      if (requiredValid.fieldName) {
        this.$message({
          message: `${requiredValid.fieldName}${i18n.t('不能为空')}`,
          type: 'error',
        })

        return false
      }

      if (this.taskCount) {
        const confirmResult = await this.confirmBeforeOperate(
          i18n.t('添加子需求后，父需求下面的任务会移动到子需求下!'),
        )
        if (!confirmResult) {
          return
        }
      }

      this.createRequireData.parentId = this.requireId
      this.createRequireData.projectId = this.getProjectId()
      this.operaisdisable = true

      const res = await requirementService.requirementCreate({
        ...this.templateInfo,
        ...this.createRequireData,
      })

      this.operaisdisable = false
      if (res.status === 200) {
        this.$message({
          message: res.msg || i18n.t('添加子需求成功'),
          type: 'success',
        })

        this.createRequireData.assignUser = ''
        this.getDemandRelevance()
        this.$emit('updateCountInfoSuccess')
      } else {
        this.$message({
          message: res.msg || i18n.t('添加子需求失败'),
          type: 'error',
        })
      }
    },
    // 删除需求
    handelRequirementDelete() {
      let info = this.detailInfo
      if (!info.detail.authority.deletable) {
        this.$message({
          message: info.detail.authority.deleteErrorMsg,
          type: 'warning',
        })

        return
      }
      this.$confirm(
        `${i18n.t('确认删除需求')}"${info.detail.title}"${i18n.t(
          '吗',
        )}？(${i18n.t('需求下所有子需求以及任务均会一并删除，请确认')})`,
        {
          confirmButtonText: i18n.t('确定'),
          cancelButtonText: i18n.t('取消'),
          type: 'warning',
        },
      )
        .then(async () => {
          this.loading = true
          const result = await this.requirementDelete({
            id: info.detail.id,
            projectId: this.projectId || this.$getUrlParams().projectId,
          })
          this.loading = false
          if (result.status === 200) {
            this.$message({
              message: result.msg || i18n.t('需求删除成功'),
              type: 'success',
            })

            // 关闭当前 slider
            if (this.$getUrlParams().requireId) {
              this.$router.replace({
                path: this.$route.path,
                query: { ...this.$route.query, requireId: null },
              })
            }
            this.$emit('deleteOk')
            this.$emit('updateInfoSuccess')

            this.bugClose()
            // 是否是在工作台操作，是则刷新列表
            if (
              this.isInjectFromMine &&
              typeof this.refreshList === 'function'
            ) {
              this.refreshList()
            }
          } else {
            // this.$message({
            //   message: result.msg || "需求删除失败",
            //   type: "warning"
            // });
          }
        })
        .catch(() => {})
    },
    // 需求父子关系解绑
    handelUnbindParentChildren(info) {
      this.$confirm(
        `${i18n.t('确认解除当前需求与')}"${info.display.title}"${i18n.t(
          '的父子关系吗',
        )}`,
        {
          confirmButtonText: i18n.t('确定'),
          cancelButtonText: i18n.t('取消'),
          type: 'warning',
        },
      )
        .then(async () => {
          const result = await this.requirementUnbindParentChild({
            id: info.id,
            parentId: this.requireId,
          })
          if (result.status === 200) {
            this.$message({
              message: result.msg || i18n.t('父子关系解绑成功'),
              type: 'success',
            })

            this.getDemandRelevance()
            this.$emit('updateCountInfoSuccess')
            // 手动更新本地
            this.childDemandData = this.childDemandData.filter(
              item => item.id !== info.id,
            )
          }
        })
        .catch(() => {})
    },
    // 全局更新标题 - add by heyunjiang on 2019.5.8
    updateGlobalTitle(info, value) {
      this.GlobalRequirementUpdate({
        id: info.id,
        title: value,
        projectId: info.projectId || this.getProjectId(),
        cb: this.updateSuccessHandler,
      })
    },
    //需求关联处理人编辑
    assignUserEdit() {
      this.requirementUpdateInfo(
        'assignUser',
        this.createRequireData.assignUser,
      )
      this.createRequireData.assignUser = ''
    },

    // 点击 id, 标题跳转
    toRequrieDetailPage(row) {
      if (this.requireId === -1) {
        return
      }
      this.$goToNewWindowPage('/requirement/list', {
        requireId: row.id,
        projectId: row.projectId,
      })
    },
    // 处理人选择框 - 展示
    handleUserChoice(data, key) {
      this.idVip = this.idEditVip = data.id
      this.$set(data, key, 1)
    },
    // 处理人选择框 - 隐藏
    selectUserVisibleChange(val, item, key) {
      !val && (item[key] = 0)
    },
    // 需求更新 - 处理人专用
    requirementUpdateInfo(key, value) {
      requirementService
        .update({
          id: this.idEditVip,
          [key]: value,
        })
        .then(res => {
          if (res.status === 200) {
            this.updateSuccessHandler()
            this.$message({
              message: res.msg || i18n.t('编辑成功'),
              type: 'success',
            })
          }
        })
        .catch(() => {
          this.getDemandRelevance()
        })
    },
  },
}
</script>
<style lang="scss" scoped>
.demand-connect,
.task-decompose {
  padding-bottom: 20px;
  width: 100%;

  .task-decompose-title {
    padding-bottom: 5px;
  }
}
.status_name {
  display: flex;
  vertical-align: middle;
  border-radius: 4px;
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  box-sizing: border-box;
  color: #fff;
}
</style>
