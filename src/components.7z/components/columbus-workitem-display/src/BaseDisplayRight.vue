<template>
  <div class="detail-content-right">
    <!-- 基本信息 -->
    <div class="bug-basic-info">
      <p class="bug-basic-info-title">
        {{ $t('基本信息')
        }}<span
          :title="
            !$authFunction('FUNC_COOP_WORKITEM_TMPL_UPDATE', 3, getProjectId())
              ? $t('暂无权限设置，请联系管理员')
              : $t('工作项模板设置')
          "
          class="cursor-pointer detail-title-edit"
          :class="{
            'cursor-disabled': !$authFunction(
              'FUNC_COOP_WORKITEM_TMPL_UPDATE',
              3,
              getProjectId(),
            ),
          }"
        >
          <i
            class="el-icon-setting"
            style="position: relative; top: 1px;"
            :class="{
              disabled: !$authFunction(
                'FUNC_COOP_WORKITEM_TMPL_UPDATE',
                3,
                getProjectId(),
              ),
            }"
            @click="jumpToTemplateSetting(getProjectId())"
          ></i
        ></span>
      </p>
      <work-item-basic-info-display
        ref="WorkItemBasicInfoDisplay"
        :project-id="getProjectId()"
        :work-item-type="workItemType"
        :work-item-detail="detailInfo"
        @updateField="workItemUpdate"
        @ChangeFatherRquireFuc="ChangeFatherRquireFuc"
        @deleteParentRequireFuc="deleteParentRequireFuc"
        @refreshData="refreshData"
      ></work-item-basic-info-display>
    </div>
    <!-- 附件上传部分-->
    <div class="bug-attachment">
      <p class="bug-attachment-title">
        {{ $t('附件') }}
        <!--        <el-button-->
        <!--          type="text"-->
        <!--          class="bug-attachment-title-btn"-->
        <!--          @click="fileUpdaloadBoxStatusHandle"-->
        <!--          >{{-->
        <!--            fileUpdaloadBoxStatus ? $t('收起上传') : $t('展开上传')-->
        <!--          }}</el-button-->
        <!--        >-->
      </p>
      <file-upload
        :file-updaload-box-status="fileUpdaloadBoxStatus"
        :uploaded-file-list="uploadedFileList"
        :handle-file-delete="handleFileDelete"
        :detail-info-id="workItemId"
        :handle-upload-success="handleUploadSuccess"
        :work-item-type="workItemType"
      ></file-upload>
    </div>
    <ChangeTaskFatherRquire
      v-if="cloneRquireModalStatus && workItemType == 2"
      style="min-width: 750px"
      :clone-rquire-modal-status="cloneRquireModalStatus"
      :project-name="detailInfo.display.projectName"
      :task-id="workItemId"
      :project-id="getProjectId()"
      :close-modal="closeModal"
      @updata="refreshData"
    >
    </ChangeTaskFatherRquire>
    <ChangeBugFatherRequire
      v-if="cloneRquireModalStatus && workItemType == 3"
      :is-create="false"
      :clone-rquire-modal-status="cloneRquireModalStatus"
      :bug-id="workItemId"
      :require-id="requireId"
      :project-id="getProjectId()"
      :close-modal="closeModal"
      @onChange="refreshData"
    />
    <ChangeRequirementFatherRquire
      v-if="cloneRquireModalStatus && workItemType == 1"
      style="min-width: 750px"
      :clone-rquire-modal-status="cloneRquireModalStatus"
      :ori-parent-id="detailInfo.rawData.parentId"
      :is-showtips="detailInfo.rawData.sprintId !== 0"
      :task-id="workItemId"
      :project-id="getProjectId()"
      :project-name="detailInfo.display.projectName"
      :close-modal="closeModal"
      @updata="refreshData"
    >
    </ChangeRequirementFatherRquire>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 基本信息组件，包含附件上传
 * @desc
 * @author heyunjiang
 * @date
 */
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import FileUpload from '@/components/file-upload'
import ChangeTaskFatherRquire from '@/views/task/ChangeFatherRquire'
import ChangeRequirementFatherRquire from '@/views/requirement/ChangeFatherRquire'
import * as requirementService from '@/service/requirement'
import { taskUpdateParent } from '@/service/task'
import { updateBugParentPost } from '@/service/bug'
import { list, attachmentDelete } from '@/service/attachment'
import ChangeBugFatherRequire from '@/views/bug/ChangeBugFatherRquire'
export default {
  name: 'BaseDisplayRight',
  components: {
    FileUpload,
    ChangeTaskFatherRquire,
    ChangeBugFatherRequire,
    ChangeRequirementFatherRquire,
  },

  mixins: [ProjectCommonMixin, WorkItemTemplateMixin],
  props: {
    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型',
    },

    detailInfo: {
      type: Object,
      required: true,
      desc: '工作项详情',
    },
  },

  data() {
    return {
      cloneRquireModalStatus: false, // 修改父需求弹窗状态
      fileUpdaloadBoxStatus: true, // 上传附件框-展示/隐藏
      uploadedFileList: [], // 已经上传的附件信息
    }
  },
  computed: {
    workItemId() {
      return this.detailInfo.detail.id
    },
    // 父需求/所属需求id
    requireId() {
      return this.detailInfo.rawData?.requireId
    },
  },

  watch: {
    detailInfo() {
      this.getUploadedFileList()
    },
  },

  created() {},
  mounted() {
    this.getUploadedFileList()
  },
  methods: {
    // 读取 projectId 统一入口
    getProjectId() {
      return (
        this.detailInfo.rawData?.projectId || this.$getUrlParams().projectId
      )
    },
    // http 错误统一处理
    httpErrorHandle(param) {
      this.$message({ message: param, type: 'error' })
    },
    // 工作项信息更新接口
    workItemUpdate(obj) {
      this.$emit('workItemUpdate', {
        ...obj,
        errorCallback: () => {
          this.$refs.WorkItemBasicInfoDisplay.lastFieldReset()
        },
      })
    },
    // 删除父需求
    async deleteParentRequireFuc() {
      const textMsg =
        +this.workItemType === 3
          ? '是否确定解绑所属需求?'
          : '是否确定解绑父需求?'
      const result = await this.confirmBeforeOperate(this.$t(textMsg))
      if (!result) {
        return
      }
      this.deleteFather()
    },
    // 执行删除父需求
    async deleteFather() {
      const requireType = 1
      const taskType = 2
      const bugType = 3
      const { parentId } = this.detailInfo.rawData
      const { workItemType } = this
      const paramsMap = {
        [requireType]: {
          id: this.workItemId,
          oriParentId: parentId,
          newParentId: -1,
          confirm: 0,
        },
        [taskType]: {
          id: this.workItemId,
          requireId: 0, // 传0表示解绑
        },
        [bugType]: {
          id: this.workItemId,
          requireId: 0, // 传0表示解绑
        },
      }

      let res = {}
      if (workItemType === requireType) {
        res = await requirementService.requirementUpdateParent(
          paramsMap[workItemType],
        )
      } else if (workItemType === bugType) {
        res = await updateBugParentPost(paramsMap[workItemType])
      } else {
        res = await taskUpdateParent(paramsMap[workItemType])
      }

      if (res.status === 200) {
        this.$message({
          type: 'success',
          message: i18n.t('解绑父需求成功'),
        })
        this.$emit('refreshData')
      }
    },
    // 打开父需求弹窗
    ChangeFatherRquireFuc() {
      this.cloneRquireModalStatus = true
    },
    // 关闭父需求的弹窗
    closeModal() {
      this.cloneRquireModalStatus = false
    },
    // 文件上传 - 上传框是否隐藏
    fileUpdaloadBoxStatusHandle() {
      this.fileUpdaloadBoxStatus = !this.fileUpdaloadBoxStatus
    },
    // 文件上传 - 获取已经上传的文件列表
    getUploadedFileList() {
      if (this.workItemId < 1) {
        return
      }
      list({
        workItemId: this.workItemId,
        workItemType: this.workItemType,
        projectId: this.getProjectId(),
      }).then(result => {
        if (result.status === 200) {
          this.uploadedFileList = result.data.map(item => {
            return {
              name: item.origName,
              url: item.url,
              createUser: item.display.createUser,
              createTime: item.createTime,
              updateTime: item.updateTime,
              size: item.size,
              id: item.id,
            }
          })
        } else {
          this.uploadedFileList = []
        }
      })
    },
    // 文件上传 - 成功处理函数
    handleUploadSuccess(res) {
      if (res.status !== 200) {
        this.$message({
          message: res.msg || i18n.t('文件上传失败'),
          type: 'error',
        })

        return
      }
      this.uploadedFileList.push({
        name: res.data.origName,
        url: res.data.url,
        id: res.data.id,
        createTime: res.data.createTime,
        size: res.data.size,
        updateTime: res.data.updateTime,
        createUser: res.data.display.createUser,
      })
      this.$emit('filesUpdate')
      this.$message({
        message: i18n.t('文件上传成功'),
        type: 'success',
      })
    },
    // 文件上传 - 文件删除
    handleFileDelete(file) {
      if (this.workItemId < 1) {
        return
      }

      attachmentDelete({
        workItemId: this.workItemId,
        workItemType: this.workItemType,
        projectId: this.getProjectId(),
        attachmentId: file.id,
      }).then(result => {
        if (result.status === 200) {
          this.$message({
            message: i18n.t('文件删除成功'),
            type: 'success',
          })
          this.$emit('filesUpdate')
          this.uploadedFileList = this.uploadedFileList.filter(
            item => item.id !== file.id,
          )
        }
      })
    },
    // 更新成功回调
    refreshData(...args) {
      this.$emit('refreshData', ...args)
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/project/ProjectCommon.scss';
</style>
