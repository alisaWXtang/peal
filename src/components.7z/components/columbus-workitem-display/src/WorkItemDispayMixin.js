import { i18n } from '@/i18n'
/**
 * 工作项查看通用 mixin
 * 说明：属于拆分通用工作项 BaseDisplay 之后的 mixin
 * author: heyunjiang
 * time: 2020.7.6
 */

import debounce from 'lodash/debounce'
import { update as requirementUpdate, revisedList } from '@/service/requirement'
import { taskUpdate } from '@/service/task'
import { bugOperateList, bugUpdate } from '@/service/bug'
const data = function() {
  return {
    detailInfo: null, // 工作项详情
    // 操作记录数据信息
    operateInfo: {
      operateList: [],
      operatePageInfo: {
        pageNum: 1,
        pageSize: 20,
        isMore: false,
      },
    },

    revisedList: [], // 修订列表
    revisedPageInfo: { pageSize: 10, pageNumber: 1 }, // 修订列表数据
    revisedDialogVisible: false, // 修订详情查看
    localProjectId: this.$getUrlParams().projectId,
  }
}

const computed = {
  // tab栏数量
  tabCount() {
    const countTypeMap = {
      1: 'requireTabNum',
      2: 'taskTabNum',
      3: 'bugTabNum',
    }

    return this.$store.state.workItemManage[countTypeMap[this.workItemType]]
  },
  // 详情更新 url
  updateFunc() {
    const updateUrlMap = {
      1: requirementUpdate,
      2: taskUpdate,
      3: bugUpdate,
    }

    return updateUrlMap[this.workItemType]
  },
}

const methods = {
  // 读取 projectId 统一入口
  getProjectId() {
    return (
      this.projectId ||
      this.detailInfo?.rawData?.projectId ||
      this.localProjectId
    )
  },
  // workItemId 格式校验
  validWorkItemId() {
    return this.workItemId && this.workItemId > 0
  },
  // 数据重置
  resetData() {
    this.operateInfo = {
      operateList: [],
      operatePageInfo: {
        pageNum: 1,
        pageSize: 20,
        isMore: false,
      },
    }

    this.revisedList = []
    this.revisedPageInfo = { pageSize: 10, pageNumber: 1 }
  },
  // 获取工作项详情
  getDetailInfo: debounce(async function() {
    if (!this.validWorkItemId() || this.getProjectId() < 0) {
      return
    }
    const result = await this.getWorkItemDetail({
      workItemType: this.workItemType,
      id: this.workItemId,
      projectId: this.getProjectId(),
    })

    if (result.status === 500) {
      this.closeHandler()
      return false
    }
    if (result.status === 200 && result.data) {
      this.workItemDetailInfoHandle(result.data)
      this.initGuide && this.initGuide()
    }
  }, 300),
  // 更新工作项详情 - 获取数据结构
  getUpdatePostObj(key, value) {
    let postObj = {
      id: this.workItemId,
      projectId: this.getProjectId(), // 项目id
      [key]: value,
      clearFields: [],
    }

    // progress 等输入框清空处理
    if (key === 'progress' && value === '') {
      postObj.clearFields.push(key)
    }
    if (typeof key === 'object') {
      key.progress === '' && postObj.clearFields.push('progress')
      postObj = { ...postObj, ...key }
    }

    postObj.clearFields = [
      ...postObj.clearFields,
      ...this.emptyTime(postObj).clearFields,
    ]
    return postObj
  },
  // 更新工作项详情
  workItemUpdate: debounce(async function(...args) {
    let result = { status: 0 }
    try {
      result = await this.updateFunc({
        ...this.getUpdatePostObj(...args),
      })
    } catch (_) {
      // 为了解决更新title和描述失败，失败的内容还在上面
      this.getDetailInfo()
    }
    if (result.status === 200) {
      this.$message({
        message: result.msg || i18n.t('更新成功'),
        type: 'success',
      })
      this.workItemDetailInfoHandle(result.data)
      this.$emit('updateInfoSuccess', result)
    } else {
      // 支持错误回调
      if (args[0] && args[0].errorCallback) {
        args[0].errorCallback()
      }
    }
  }, 300),
  // 刷新工作项
  refreshData() {
    this.getDetailInfo()
    this.$refs?.commentList?.getCommentList(false)
    this.$emit('updateInfoSuccess')
  },
  // 工作项详情处理函数
  workItemDetailInfoHandle(result) {
    this.detailInfo = result
    this.getFooterDetail()
  },
  //进入详情时添加上给 url 添加上工作项 id
  urlAddWorkItemId() {
    // 如果是 bug 页面关联项打开，则不更新 url
    if (this.$attrs.assocItemOpen === 'bug') {
      return
    }
    let projectId = this.getProjectId()
    this.$router.replace({
      path: this.$route.path,
      query: {
        ...this.$route.query,
        requireId: this.workItemType === 1 ? this.workItemId : undefined,
        projectId,
        bugId: this.workItemType === 3 ? this.workItemId : undefined,
        taskId: this.workItemType === 2 ? this.workItemId : undefined,
      },
    })
  },
  // 关闭弹窗
  closeHandler(param = {}) {
    this.$emit('HandleSide', param)
  },
  // 删除工作项
  deleteSuccess() {
    this.$emit('deleteSuccess')
    this.closeHandler()
  },
  // 保存缓存
  setUserInputCache() {
    // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
    this.$refs.baseDisplay?.setUserInputCache()
  },

  /* 底部 start */
  // 获取底部 tab 详细数据
  tabRelateditem: debounce(async function() {
    const projectId = this.getProjectId()
    if (projectId && this.workItemId && this.workItemType) {
      this.$store.dispatch({
        type: 'getTabRelateditem',
        payload: {
          workItemType: this.workItemType,
          workItemId: this.workItemId,
          projectId,
        },
      })
    }
  }, 300),
  // 附件上传或附件删除回调
  onFilesUpdate() {
    // 更新统计count
    this.tabRelateditem()
    // 只有tab切换到操作记录时触发更新
    if (this.activeTagName === 'operate' || this.activeTagName === '2') {
      this.getBugOperateRecordList()
    }
  },
  // 操作记录 - 获取记录列表
  getBugOperateRecordList() {
    const { pageNum } = this.operateInfo.operatePageInfo
    bugOperateList({
      workItemId: this.workItemId,
      workItemType: this.workItemType,
      pageNum,
      pageSize: this.operateInfo.operatePageInfo.pageSize,
      projectId: this.getProjectId(),
    }).then(result => {
      if (result.status === 200) {
        if (pageNum <= 1) {
          this.operateInfo.operateList = result.data.list
        } else {
          const duplicateSet = new Set()
          const resultList = []
          this.operateInfo.operateList
            .concat(result.data.list)
            .forEach(item => {
              const { id } = item
              if (duplicateSet.has(id)) {
                return
              }
              resultList.push(item)
              duplicateSet.add(id)
            })
          this.operateInfo.operateList = resultList
        }
        this.operateInfo.operatePageInfo.isMore =
          result.data.total >
          this.operateInfo.operatePageInfo.pageNum *
            this.operateInfo.operatePageInfo.pageSize
      } else {
        this.operateInfo.operateList = []
        this.operateInfo.operatePageInfo.isMore = false
      }
    })
  },
  // 操作记录 - 加载更多
  OperateLoadmoreCallback() {
    if (!this.operateInfo.operatePageInfo.isMore) {
      return false
    }
    this.operateInfo.operatePageInfo.pageNum =
      this.operateInfo.operatePageInfo.pageNum + 1
    this.$nextTick(function() {
      this.getBugOperateRecordList(this.detailInfo)
    })
  },
  // 修订列表 - pageSize
  handleRevisedPageSizeChange(pageSize) {
    this.revisedPageInfo.pageSize = pageSize
    this.getRevisedList()
  },
  // 修订列表 - pageNumber
  handleRevisedPageNumChange(pageNum) {
    this.revisedPageInfo.pageNumber = pageNum
    this.getRevisedList()
  },
  // 修订列表 - 获取修订列表数据
  getRevisedList() {
    let pageInfo = {
      pageNumber: this.revisedPageInfo.pageNumber,
      pageSize: this.revisedPageInfo.pageSize,
    }

    revisedList({
      workItemType: this.workItemType,
      workItemId: this.workItemId,
      projectId: this.getProjectId(),
      pageInfo,
    }).then(res => {
      this.revisedList = res.data.results
      this.revisedPageInfo = res.data.pageInfo
    })
  },
}

export default {
  data,
  computed,
  methods,
}
