<template>
  <div
    v-loading="loading"
    class="detail-content bug-content-box detail-content-show"
    :element-loading-text="$t('拼命加载中')"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)"
  >
    <div v-if="isSlider" class="slide-header">
      <i
        v-show="showBack"
        class="co-icon-reduction m-r10 go-back"
        @click="parentRequireBack"
      ></i>
      <span class="taskinfo-title">{{ baseConfig.title }}</span>
      <div class="slide-header-right">
        <el-button type="text">
          <url-copy :class="{ mr15: !moreOperationList.length }" />
        </el-button>
        <!-- 更多下拉菜单 -->
        <copy-or-delete-dropdown
          v-show="moreOperationList.length"
          :drop-down-list="moreOperationList"
          @handleMoreCommand="handelCloneOrDeleteWorkItem"
        >
        </copy-or-delete-dropdown>
        <el-button
          class="close-slide-btn"
          type="text"
          icon="el-icon-close"
          @click="sliderClose"
        ></el-button>
      </div>
    </div>
    <el-row :gutter="10" class="detail-content-body">
      <el-col
        :xs="16"
        :sm="16"
        :md="16"
        :lg="16"
        :xl="18"
        style="position: relative"
        class="detail-col-left"
      >
        <div class="detail-content-left">
          <!-- 标题 -->
          <div class="detail-content-header">
            <span
              v-if="statusObject.titleInputShowActiveStatus === 'inactive'"
              class="detail-content-header-id"
            >
              <!-- 解决页面闪一下-1的问题 -->
              #{{ workItemId == -1 ? '' : workItemId }}
            </span>
            <ellipsis-block
              v-if="statusObject.titleInputShowActiveStatus === 'inactive'"
              :value="stashTitle"
              class="editable-field title-input-inactive"
              :class="{ 'title-input-inactive-full': isSlider }"
              @click="
                showActiveStatusControl('titleInputShowActiveStatus', 'active')
              "
            ></ellipsis-block>
            <el-input
              v-show="statusObject.titleInputShowActiveStatus === 'active'"
              ref="titleInput"
              v-model="stashTitle"
              class="title-input-active"
              :placeholder="$t('输入标题')"
              size="large"
              @blur="checkTitleChange('titleInputShowActiveStatus', 'inactive')"
            ></el-input>
            <!-- 更多下拉菜单，用于不需要顶部 header 块场景 -->
            <copy-or-delete-dropdown
              v-if="
                !isSlider &&
                  moreOperationList.length &&
                  statusObject.titleInputShowActiveStatus !== 'active'
              "
              class="more-dropdown-no-slide"
              :drop-down-list="moreOperationList"
              @handleMoreCommand="handelCloneOrDeleteWorkItem"
            >
            </copy-or-delete-dropdown>
            <span
              v-if="
                !isSlider &&
                  statusObject.titleInputShowActiveStatus !== 'active'
              "
              class="edit-box-bug-help-btn-copy c-blue"
              :style="{
                'margin-right': moreOperationList.length ? '105px' : '',
              }"
            >
              <url-copy />
            </span>
            <div v-if="warningStatusTitle" class="warning warning-title">
              {{ $t('标题不能超过') }}{{ $isEnglishDisplaySpace() }}127{{
                $isEnglishDisplaySpace()
              }}{{ $t('个字符') }}！
            </div>
          </div>
          <div v-if="$isEnglish()" class="creat-title">
            <span>Created by</span>
            <span>{{
              `${detailInfo.display.createUser}(${detailInfo.rawData.createUser}) `
            }}</span>
            <span>with</span>
            <span>{{ detailInfo.meta.tmplName }}</span>
            <span>at</span>
            <span>{{
              detailInfo.detail.createTime | formatDateByEnglish
            }}</span>
          </div>
          <div v-else class="creat-title">
            <span>{{
              `${detailInfo.display.createUser}(${detailInfo.rawData.createUser}) `
            }}</span
            >{{ $t('于') }} <span>{{ detailInfo.detail.createTime }}</span
            >&nbsp;{{ $t('使用') }}<span>{{ detailInfo.meta.tmplName }}</span
            >{{ $t('创建') }}
          </div>
          <div
            ref="showMorebox"
            class="detail-content-left-content"
            :class="{
              'detail-content-left-content-inactive':
                statusObject.taskDescShowActiveStatus === 'inactive',
              showMore: showMore && isShowmore,
            }"
          >
            <!-- 描述 -->
            <div
              ref="showMoresbox"
              :class="{ 'edit-fullscreen': statusObject.fullScreen }"
            >
              <span
                class="edit-box-bug-help-btn"
                :class="{
                  'edit-box-bug-help-btn-save-new':
                    statusObject.taskDescShowActiveStatus === 'active',
                }"
                @click="
                  showActiveStatusControl(
                    'taskDescShowActiveStatus',
                    taskDescShowActiveStatusValue,
                  )
                "
                >{{
                  statusObject.taskDescShowActiveStatus === 'inactive'
                    ? $t('编辑描述')
                    : $t('保存')
                }}</span
              >
              <span
                v-show="statusObject.taskDescShowActiveStatus === 'active'"
                class="edit-box-bug-help-btn-cancel"
                @click="editCancel"
                >{{ $t('取消') }}</span
              >
              <span
                class="edit-box-bug-help-btn"
                :class="{
                  'edit-box-bug-active':
                    statusObject.taskDescShowActiveStatus === 'active',
                }"
                :style="{
                  right: $isEnglish()
                    ? '58px'
                    : statusObject.taskDescShowActiveStatus === 'active'
                    ? '110px'
                    : '83px',
                }"
                @click="fullScreenMethod"
              >
                {{ !statusObject.fullScreen ? $t('全屏') : $t('退出全屏') }}
              </span>
              <show-larger
                v-show="statusObject.taskDescShowActiveStatus === 'inactive'"
                :value="detailInfo.detail.content"
                :math-rom-id="workItemId"
              ></show-larger>
              <template
                v-if="statusObject.taskDescShowActiveStatus === 'active'"
              >
                <UserInputRestoreTips
                  v-if="workItemId"
                  action-type="edit"
                  :item-type="itemType"
                  :item-id="workItemId"
                  :project-id="getProjectId()"
                  :original-value="detailInfo.detail.content"
                  @restore="restoreContent"
                >
                </UserInputRestoreTips>
                <tiny-mce
                  :min-heigt="minHeight"
                  :value="stashDesc"
                  @watch="editHnadle($event)"
                  @save="
                    showActiveStatusControl(
                      'taskDescShowActiveStatus',
                      taskDescShowActiveStatusValue,
                    )
                  "
                ></tiny-mce>
              </template>
            </div>
          </div>
          <div v-if="showTxtMore && isShowmore" class="textTaskbox">
            <div class="moreText" @click="showMoreBtn">
              {{ $t('展示更多') }}
            </div>
          </div>
        </div>
        <div
          v-if="hideTxtMore && isShowmore"
          class="moreText"
          @click="hideMoreBtn"
        >
          {{ $t('收起更多') }}
        </div>

        <div class="detail-content-footer">
          <slot name="footer"></slot>
        </div>
      </el-col>
      <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6" class="detail-col-right">
        <BaseDisplayRight
          :work-item-type="workItemType"
          :detail-info="detailInfo"
          @refreshData="refreshData"
          @workItemUpdate="workItemUpdate"
          v-on="$listeners"
        ></BaseDisplayRight>
      </el-col>
    </el-row>
    <!-- 复制工作项 -->
    <requirement-clone
      v-if="+workItemType === 1"
      :require-id="workItemId"
      :clone-requirement-modal-status="cloneModalStatus"
      :close-modal="closeCloneModal"
      :project-id="getProjectId()"
      @cloneInProject="handleClone"
    ></requirement-clone>
    <work-item-clone
      v-else
      :work-item-id="workItemId"
      :work-item-type="workItemType"
      :clone-title="cloneTitle"
      :clone-modal-status.sync="cloneModalStatus"
      :close-modal="closeCloneModal"
      :project-id="getProjectId()"
      @cloneInProject="handleClone"
    >
    </work-item-clone>

    <slide
      ref="slide"
      :show="showCloneSlide"
      :after-close="handleCloseCloneSlide"
      :before-close="({ cb }) => $parent.beforeSliderClose({ id: -1, cb })"
      @click.stop
    >
      <div slot="task" class="silder-box">
        <RequirementCreate
          v-if="workItemType === 1"
          ref="workCreate"
          :show="showCloneSlide"
          :other-detail-content="detailInfo.detail.content"
          from-other-detail-type="cloneWorkItem"
          :other-detail-title="detailInfo.detail.title"
          :from-other-detail-id="detailInfo.detail.id"
          :original-detail="detailInfo"
          @HandleSide="handleCloseCloneSlide"
          @copy="handleCopy"
        ></RequirementCreate>
        <TaskCreate
          v-else-if="workItemType === 2"
          ref="workCreate"
          :show="showCloneSlide"
          :other-detail-content="detailInfo.detail.content"
          :original-detail="detailInfo"
          from-other-detail-type="cloneWorkItem"
          :other-detail-title="detailInfo.detail.title"
          :from-other-detail-id="detailInfo.detail.id"
          @copy="handleCopy"
          @HandleSide="handleCloseCloneSlide"
        ></TaskCreate>
        <BugCreate
          v-else
          ref="workCreate"
          :show="showCloneSlide"
          :other-detail-content="detailInfo.detail.content"
          from-other-detail-type="cloneWorkItem"
          :original-detail="detailInfo"
          :other-detail-title="detailInfo.detail.title"
          :from-other-detail-id="detailInfo.detail.id"
          @copy="handleCopy"
          @HandleSide="handleCloseCloneSlide"
        ></BugCreate>
      </div>
    </slide>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 哥伦布 - 工作项查看基础组件
 * @desc 所有工作项查看，都需要引用这个组件作为基础
 * @author heyunjiang
 * @date 2020.6.23
 */
import {
  Input,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  ButtonGroup,
  Button,
  Row,
  Col,
} from '@heytap/cook-ui'
import debounce from 'lodash/debounce'
// import FieldEdit from '@/pages/tool/FieldEdit';
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import TinymceSaveMixin from '@/mixin/tinymce-save-mixin'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import ShowLarger from '@/components/show-larger'
// import StatusChartCommonMixin from '../statusChartCommonMixin'
// import workFlowChart from "../personalManagement/WorkFlowChart"
import UrlCopy from '@/components/url-copy'
// import { cloneDeep } from 'lodash';
// import StateFlow from "@/pages/biz/StateFlow";
// import { log } from 'util';
import UserInputRestoreTips from '@/components/user-input-restore-tips'
import CopyOrDeleteDropdown from '@/components/biz/more-dropdown'
import WorkItemClone from '@/components/project/WorkItemClone'
import RequirementClone from '@/views/requirement/RequirementClone'
import BaseDisplayRight from './BaseDisplayRight'
// import BaseDisplayAssoc from './BaseDisplayAssoc'
import { setEditItemUserInputCache, getItemUserInputCache } from '@/utils/help'
import { WORKITEMCONST } from '@/utils/constant'
import { removeFragmentSpace } from '@/utils'
import { requirementDelete } from '@/service/requirement'
import { deleteTask } from '@/service/task'
import { bugDelete } from '@/service/bug'
import { getBaseInfo } from '@/service/sprint'

const TinyMce = () => import('@/components/tinymce')
import slide from '@/components/slide-slip'
import {
  RequirementCreate,
  TaskCreate,
  BugCreate,
} from '@/components/columbus-workitem-create'

export default {
  name: 'BaseDisplay',
  components: {
    [Input.name]: Input,
    [Dropdown.name]: Dropdown,
    [DropdownMenu.name]: DropdownMenu,
    [DropdownItem.name]: DropdownItem,
    [ButtonGroup.name]: ButtonGroup,
    [Button.name]: Button,
    [Row.name]: Row,
    [Col.name]: Col,
    // StateFlow,
    UserInputRestoreTips,
    TinyMce,
    // FieldEdit,
    ShowLarger,
    // workFlowChart,
    UrlCopy,
    CopyOrDeleteDropdown,
    RequirementClone,
    WorkItemClone,
    BaseDisplayRight,
    // BaseDisplayAssoc,
    slide,
    RequirementCreate,
    TaskCreate,
    BugCreate,
  },
  filters: {
    // 在英语界面下，时间在前，日期在后
    formatDateByEnglish(value) {
      let dateArr = value.split(' ') || []
      return dateArr.length === 2 ? `${dateArr[1]} ${dateArr[0]}` : value
    },
  },
  mixins: [ProjectCommonMixin, TinymceSaveMixin, WorkItemTemplateMixin],
  props: {
    workItemType: {
      type: [String, Number],
      required: true,
      desc: i18n.t('工作项类型'),
    },

    detailInfo: {
      type: Object,
      required: true,
      desc: i18n.t('工作项详情'),
    },

    loading: {
      type: Boolean,
      required: false,
      default: false,
      desc: '组件 loading',
    },

    isShowmore: {
      type: Boolean,
      required: false,
      desc: i18n.t('是否需要展示更多功能'),
      default: false,
    },

    baseConfig: {
      type: Object,
      required: false,
      desc: i18n.t('常量配置'),
      default: () => {
        return {
          title: i18n.t('工作项详情'),
        }
      },
    },
    showBack: {
      type: Boolean,
      default: false,
    },
    isSlider: {
      type: Boolean,
      required: false,
      default: true,
    },
  },

  data() {
    return {
      moreOperationList: [], // 更多操作列表，包括转需求，复制缺陷和删除缺陷
      statusObject: {
        titleInputShowActiveStatus: 'inactive', // 标题是否编辑
        taskDescShowActiveStatus: 'inactive', // 描述是否编辑
        fullScreen: false, //全屏
      },
      stashTitle: '', // 当前编辑的标题
      stashDesc: '', // 当前编辑的描述
      minHeight: null, // 编辑框的初始高度
      cloneModalStatus: false, // 克隆弹窗状态

      showMore: false, // 展示更多
      showTxtMore: true, // 展示更多文字
      hideTxtMore: false, // 关闭展示更多文字
      showCloneSlide: false, // 暂时克隆slide
      cloneData: {}, // 复制工作项数据
      projectId: this.$getUrlParams().projectId,
    }
  },
  inject: {
    isInjectFromMine: {
      default: false,
    },

    refreshList: {
      default: () => () => {},
    },
    slide: {
      default: null,
    },
  },

  computed: {
    workItemId() {
      return this.detailInfo.detail.id
    },
    // 警告状态-标题
    warningStatusTitle: function() {
      return (
        this.stashTitle.length > 127 &&
        this.statusObject.titleInputShowActiveStatus === 'active'
      )
    },
    // 工作项类型英文名
    itemType() {
      return WORKITEMCONST.workItemTypeMap[this.workItemType]
    },
    // 任务描述状态控制
    taskDescShowActiveStatusValue: function() {
      return this.statusObject.taskDescShowActiveStatus === 'inactive'
        ? 'active'
        : 'inactive'
    },
    // 复制标题
    cloneTitle() {
      const chineseMap = {
        1: i18n.t('需求'),
        2: i18n.t('任务'),
        3: i18n.t('缺陷'),
      }
      return `${i18n.t('复制')}${chineseMap[this.workItemType]}`
    },
  },
  watch: {
    // 重置标题、描述
    detailInfo(newval, oldval) {
      // 解决线上问题：需求缺陷在编辑描述时，切换工作项时，上次编辑的内容会复制这新打开工作项的内容
      if (newval?.detail?.id !== oldval?.detail?.id) {
        this.statusObject.taskDescShowActiveStatus = 'inactive'
      }
      this.resetInput()
      if (
        this.statusObject.taskDescShowActiveStatus === 'active' &&
        this.isDirty
      ) {
        this.setUserInputCache(oldval.detail.id)
      }
      // 当数据变化的时候，需要重新计算一次高度
      this.isShowmore && this.boxShowmore()
    },
    // 全屏控制 - slider box 滚动控制，用以去除滚动条
    statusObject: {
      handler(newInfo) {
        if (newInfo.fullScreen) {
          this.slide && (this.slide.$el.style.overflowY = 'hidden')
        } else {
          this.slide && (this.slide.$el.style.overflowY = '')
        }
      },
      deep: true,
    },
  },

  created() {
    window.addEventListener('beforeunload', this.pageUnloadHandler)
  },
  mounted() {
    this.resetInput()
    this.getMoreOperationList()
    this.isShowmore && this.boxShowmore()
  },
  beforeDestroy() {
    this.pageUnloadHandler()
  },
  methods: {
    // 关闭clone侧边弹窗
    handleCloseCloneSlide() {
      this.showCloneSlide = false
      // 复制成功后，打开新的工作项
    },
    // 复制工作项 -- 后置行为
    async handleCopy(data) {
      let res = {}
      const params = { ...data, ...this.cloneData }
      // 复制任务需求id
      if (this.workItemType === WORKITEMCONST.workItemTypeMap.task) {
        params.requireId = this.$refs.workCreate.requireId
      }

      res = await this.$store.dispatch('copyWorkItemContent', params)

      if (res.status === 200 && res.data) {
        const BaseCreate = this.$refs.workCreate.$refs.BaseCreate
        BaseCreate.clearUserInputCache()
        BaseCreate.$refs.userInputTips?.ignoreCache()
        this.sliderClose()
        this.showCloneSlide = false
        this.$emit('updateInfoSuccess')
      }
    },
    // 复制工作项 -- 前置行为
    handleClone(cloneData) {
      this.cloneData = cloneData
      this.cloneModalStatus = false
      this.showCloneSlide = true
    },
    // 读取 projectId 统一入口
    getProjectId() {
      return this.detailInfo?.rawData?.projectId || this.projectId
    },
    // http 错误统一处理
    httpErrorHandle(param) {
      this.$message({ message: param, type: 'error' })
    },
    // 工作项信息更新接口
    workItemUpdate(...args) {
      this.$emit('workItemUpdate', ...args)
    },
    // 更新成功回调
    refreshData(...args) {
      this.$emit('refreshData', ...args)
    },
    // 重置标题、描述
    resetInput() {
      // 标题失去焦点之后就会更新
      this.stashTitle = this.detailInfo.detail.title
      // 描述如果在编辑状态，则不更新
      if (this.statusObject.taskDescShowActiveStatus === 'inactive') {
        this.stashDesc = this.detailInfo.detail.content
      }
    },
    // 标题、描述状态控制，更新标题、描述内容
    showActiveStatusControl(key, value) {
      this.statusObject[key] = value
      if (value === 'active') {
        switch (key) {
          case 'titleInputShowActiveStatus':
            this.$nextTick(function() {
              this.$refs.titleInput.focus()
            })
            break // 标题聚焦
          case 'taskDescShowActiveStatus':
            if (this.workItemType == 1) {
              this.sprintLock()
            }
            if (this.isShowmore) {
              this.showMore = false
              this.showTxtMore = false
              this.hideTxtMore = false
            }
            this.resetDirtyTag()
            break
        }
      }
      if (value === 'inactive') {
        // 更新数据
        switch (key) {
          case 'titleInputShowActiveStatus':
            this.workItemUpdate('title', this.stashTitle)
            break
          case 'taskDescShowActiveStatus':
            this.clearUserInputCache()
            this.workItemUpdate('content', this.stashDesc)
            break
        }
      }
    },
    // 标题变化检测
    checkTitleChange(key, value) {
      // 不能为空检测
      if (this.stashTitle.trim().length < 1) {
        this.httpErrorHandle(i18n.t('标题不能为空'))
        this.stashTitle = this.detailInfo.detail.title
        return false
      }
      // 没有改变检测
      if (this.stashTitle !== this.detailInfo.detail.title) {
        this.showActiveStatusControl(key, value)
      } else {
        this.statusObject[key] = value
      }
    },
    //是否全屏
    fullScreenMethod() {
      this.statusObject.fullScreen = !this.statusObject.fullScreen
      if (this.statusObject.fullScreen) {
        this.minHeight = document.documentElement.clientHeight
      } else {
        this.minHeight = null
      }
      // 由于富文本编辑器只在created时初始化，这样会影响富文本的高度变化，
      // 解决富文本只初始化一次
      if (this.statusObject.taskDescShowActiveStatus === 'active') {
        this.statusObject.taskDescShowActiveStatus = 'inactive'
        this.$nextTick(() => {
          this.statusObject.taskDescShowActiveStatus = 'active'
        })
      }
    },
    // 编辑器监听
    editHnadle(data) {
      this.stashDesc = data
      // 如果编辑了缓存，下次编辑时将内容改变为与原始内容相同，则不显示缓存信息
      const removeSpaceData = removeFragmentSpace(data)
      const removeOrigianlSpaceData = removeFragmentSpace(
        this.detailInfo.detail.content,
      )

      const chacheContent = getItemUserInputCache({
        actionType: 'edit',
        itemId: this.workItemId,
        itemType: this.itemType,
      })

      if (removeSpaceData === removeOrigianlSpaceData && chacheContent) {
        this.clearUserInputCache()
      }
      if (removeSpaceData !== removeOrigianlSpaceData) {
        this.addDirtyTag()
        this.saveTinymceContent({
          value: data,
          id: this.workItemId,
          type: this.itemType, // 需求、任务、缺陷
          isNew: false,
        })
      } else {
        this.resetDirtyTag()
      }
    },
    // 编辑器点击取消
    editCancel() {
      this.stashDesc = this.detailInfo.detail.content
      this.statusObject.taskDescShowActiveStatus = 'inactive'
      this.isShowmore && this.boxShowmore()
    },
    // 验证迭代是否锁定
    sprintLock() {
      getBaseInfo({
        sprintId: this.detailInfo.rawData.sprintId,
        projectId: this.getProjectId(),
      }).then(res => {
        if (res.data && res.data.isLocked) {
          this.$confirm(
            i18n.t('迭代已锁定，修改需求描述会记录需求变更'),
            i18n.t('提示'),
            {
              confirmButtonText: i18n.t('确定'),
              cancelButtonText: i18n.t('取消'),
              type: 'warning',
            },
          ).catch(() => {})
        }
      })
    },
    /* 展示更多 */
    // 展示更多
    showMoreBtn() {
      this.showMore = false
      this.showTxtMore = false
      this.hideTxtMore = true
    },
    // 收起更多
    hideMoreBtn() {
      this.showMore = true
      this.showTxtMore = true
      this.hideTxtMore = false
    },
    parentRequireBack() {
      this.sliderClose()
    },
    // 判断更多的盒子高度
    boxShowmore() {
      setTimeout(() => {
        let boxHeight =
          this.$refs.showMorebox && this.$refs.showMorebox.offsetHeight
        let boxsHeight =
          this.$refs.showMorebox && this.$refs.showMoresbox.offsetHeight
        this.showTxtMore = false
        this.showMore = false
        if (boxsHeight > boxHeight) {
          this.showTxtMore = true
          this.showMore = true
          this.hideTxtMore = false
        } else if (boxHeight > 349) {
          //this.hideTxtMore = true;
          this.showTxtMore = true
          this.showMore = true
          this.hideTxtMore = false
        }
        if (boxsHeight < 349) {
          this.hideTxtMore = false
        }
      }, 300)
    },
    /* 缓存 */
    addDirtyTag() {
      this.isDirty = true
    },
    resetDirtyTag() {
      this.isDirty = false
    },
    pageUnloadHandler() {
      this.setUserInputCache()
      window.removeEventListener('beforeunload', this.pageUnloadHandler)
    },
    // 关闭时验证是否需要保存内容，兼容直接切换整个详情
    setUserInputCache(id) {
      this.isDirty &&
        setEditItemUserInputCache(
          this.itemType,
          {
            content: this.stashDesc,
          },

          id || this.workItemId,
        )

      this.resetDirtyTag()
    },
    restoreContent(value) {
      this.stashDesc = value.content
    },
    clearUserInputCache() {
      this.resetDirtyTag()
      setEditItemUserInputCache(this.itemType, null, this.workItemId)
    },
    /* header 相关操作 */
    // 获取更多下拉列表操作菜单
    getMoreOperationList() {
      let arr = []
      const projectId = this.getProjectId()
      const workItemHeaderOperateMap = {
        1: {
          FUNC_COOP_PROJECT_REQT_COPY: i18n.t('复制需求'),
          FUNC_COOP_REQT_DELETE: i18n.t('删除需求'),
        },

        2: {
          FUNC_COOP_TASK_CREATE: i18n.t('复制任务'),
          FUNC_COOP_TASK_DELETE: i18n.t('删除任务'),
        },

        3: {
          FUNC_COOP_REQUIRE_BUGTRANSFORMATION: i18n.t('缺陷转需求'),
          FUNC_COOP_DEFECT_CREATE: i18n.t('复制缺陷'),
          FUNC_COOP_DEFECT_DELETE: i18n.t('删除缺陷'),
        },
      }
      for (let item in workItemHeaderOperateMap[this.workItemType]) {
        const result = this.authType(item, 3, projectId) // 3 表示项目协同，不 表示工作项类型
        result && arr.push(result)
      }
      this.moreOperationList = arr
    },
    // 更多下拉列表复制或删除工作项
    handelCloneOrDeleteWorkItem(type) {
      switch (type) {
        case 'clone':
          this.cloneModalStatus = true
          break
        case 'delete':
          this.workItemDelete()
          break
        case 'bugToRequirement':
          this.$emit('bugToRequirement')
          break
      }
    },
    // 删除工作项
    workItemDelete: debounce(async function() {
      let info = this.detailInfo
      if (!info.detail.authority.deletable) {
        this.$message({
          message:
            info.detail.authority.deleteErrorMsg ||
            i18n.t('当前状态工作项不可删除'),

          type: 'warning',
        })

        return
      }
      this.$confirm(
        `${i18n.t('确认删除工作项')}"${info.detail.title}"${
          this.$isEnglish() ? '' : i18n.t('吗')
        }？`,
        {
          confirmButtonText: i18n.t('确定'),
          cancelButtonText: i18n.t('取消'),
          type: 'warning',
        },
      )
        .then(async () => {
          const deleteMap = {
            1: requirementDelete,
            2: deleteTask,
            3: bugDelete,
          }

          const result = await deleteMap[this.workItemType]({
            id: this.workItemId,
            projectId: this.getProjectId(),
          })

          if (result.status === 200) {
            this.$message({
              message: result.msg || i18n.t('工作项删除成功'),
              type: 'success',
            })

            // 关闭当前 slider
            const IdMap = {
              1: 'requireId',
              2: 'taskId',
              3: 'bugId',
            }

            const query = JSON.parse(JSON.stringify(this.$route.query))
            delete query[IdMap[this.workItemType]]

            if (this.$getUrlParams()[IdMap[this.workItemType]]) {
              this.$router.replace({
                path: this.$route.path,
                query,
              })
            }
            this.$emit('deleteSuccess')
            // 是否是在工作台操作，是则刷新列表
            if (
              this.isInjectFromMine &&
              typeof this.refreshList === 'function'
            ) {
              this.refreshList()
            }
          }
        })
        .catch(() => {})
    }, 300),
    // 关闭克隆弹窗
    closeCloneModal() {
      this.cloneModalStatus = false
      this.refreshData()
    },
    // 点击关闭按钮
    sliderClose() {
      if (this.stashDesc !== this.detailInfo.detail.content) {
        this.setUserInputCache()
      }
      this.removeTinymceContent(this.workItemId)
      this.$emit('HandleSide')
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/project/ProjectCommon.scss';
/deep/ .edit-fullscreen {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  overflow: auto;
  background-color: white;
  z-index: 99999;
  .tox-editor-header {
    position: fixed;
    top: 0;
    width: 100%;
    z-index: 1;
  }
  .tox-sidebar-wrap {
    margin-top: 38px;
  }
  .edit-box-bug-help-btn,
  .edit-box-bug-help-btn-save-new,
  .edit-box-bug-help-btn-cancel {
    position: fixed !important;
  }
}
/deep/ .basic-title-input-active .el-input__inner {
  height: 26px;
  line-height: 26px;
}
.showMore {
  height: 349px;
  overflow: hidden;
  border-radius: 5px;
}
.moreText {
  text-align: center;
  cursor: pointer;
  color: $--color-text-regular;
  width: 100%;
  font-weight: bold;
  opacity: 0.6;
  background: $--background-gray;
  line-height: 40px;
}
.textTaskbox {
  position: absolute;
  width: 100%;
  background: rgba(218, 210, 210, 0.5);
  bottom: 0;
  height: 40px;
  line-height: 40px;
}
.m-r10 {
  margin-right: 10px;
}

.go-back {
  &:hover {
    cursor: pointer;
    color: $--color-primary;
  }
}
</style>
