<template>
  <div v-if="detailInfo && workItemId && show" class="slider-body">
    <BaseDisplay
      ref="baseDisplay"
      :work-item-type="workItemType"
      :detail-info="detailInfo"
      :is-slider="isSlider"
      :base-config="baseConfig"
      @workItemUpdate="workItemUpdate"
      @refreshData="refreshData"
      @deleteSuccess="deleteSuccess"
      @HandleSide="closeHandler"
      @bugToRequirement="bugToRequirement"
      @filesUpdate="onFilesUpdate"
      @updateInfoSuccess="$emit('updateInfoSuccess')"
    >
      <!-- 状态流转、操作记录 -->
      <template #footer>
        <el-tabs v-model="activeTagName" @tab-click="getFooterDetail">
          <el-tab-pane
            :label="$t('评论') + '(' + tabCount.commentCount + ')'"
            name="comment"
          >
            <div ref="detaild" class="detailed-information1">
              <comment-list
                v-if="activeTagName === 'comment'"
                ref="commentList"
                :work-item-type="workItemType"
                :work-item-id="workItemId"
                :project-id="getProjectId()"
                @discussFun="tabRelateditem"
              ></comment-list>
            </div>
          </el-tab-pane>
          <el-tab-pane :label="$t('关联工作项')" name="assoc">
            <BaseDisplayAssoc
              v-if="activeTagName === 'assoc'"
              :work-item-type="workItemType"
              :detail-info="detailInfo"
            ></BaseDisplayAssoc>
          </el-tab-pane>
          <el-tab-pane :label="$t('状态流转')" name="status">
            <record-chain
              :data="statusRecordInfo.statusRecordList"
              :loadmore-callback="StatusRecordLoadmoreCallback"
              :is-more="statusRecordInfo.statusRecordPageInfo.isMore"
            ></record-chain>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('操作记录') + '(' + tabCount.operationLogCount + ')'"
            name="operate"
          >
            <time-line
              :data="operateInfo.operateList"
              :loadmore-callback="OperateLoadmoreCallback"
              :is-more="operateInfo.operatePageInfo.isMore"
            ></time-line>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('代码提交') + '(' + tabCount.codeCommitCount + ')'"
            name="codeCommit"
          >
            <code-commit
              v-if="activeTagName === 'codeCommit'"
              :work-item-type="workItemType"
              :work-item-id="workItemId"
              :project-id="getProjectId()"
              :update="show"
            ></code-commit>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('测试用例') + '(' + tabCount.testCaseCount + ')'"
            name="testcase"
          >
            <test-case
              v-if="activeTagName === 'testcase'"
              :work-item-id="workItemId"
              :project-id="getProjectId()"
              @testPlanSuccess="tabRelateditem"
            ></test-case>
          </el-tab-pane>
        </el-tabs>
      </template>
    </BaseDisplay>
    <slide
      ref="side"
      :show="requirementCreateShow"
      :after-close="contextmenuNone"
      :before-close="({ cb }) => beforeSliderClose({ id: -1, cb })"
      @click.stop
    >
      <div slot="task" class="silder-box">
        <RequirementCreate
          :show="requirementCreateShow"
          :other-detail-content="detailInfo.detail.content"
          :other-detail-title="detailInfo.detail.title"
          from-other-detail-type="bugTorequirement"
          :from-other-detail-id="detailInfo.detail.id"
          @HandleSide="contextmenuNone"
          @transferSuccess="transferHandler"
        ></RequirementCreate>
      </div>
    </slide>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 缺陷详情组件
 * @desc
 * @author heyunjiang
 * @date 2020.7.8
 */
import BaseDisplay from './BaseDisplay'
import BaseDisplayAssoc from './BaseDisplayAssoc'
import TimeLine from '@/components/time-line'
import CommentList from '@/components/comment-list'
import CodeCommit from '@/components/code-commit/indexNewTable'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import RecordChain from '@/components/record-chain'
import TestCase from '@/components/test-case'
import slide from '@/components/slide-slip'
import { RequirementCreate } from '@/components/columbus-workitem-create'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import WorkItemDispayMixin from './WorkItemDispayMixin'
import { bugStatusList } from '@/service/bug'

export default {
  name: 'BugDetail',
  components: {
    BaseDisplay,
    TimeLine,
    CommentList,
    CodeCommit,
    RecordChain,
    TestCase,
    RequirementCreate,
    slide,
    BaseDisplayAssoc,
  },

  mixins: [WorkItemTemplateMixin, ProjectCommonMixin, WorkItemDispayMixin],
  // props 正常只需要传这些数据，特殊使用时，比如转需求、缺陷，则通过 this.$attrs 读取
  props: {
    workItemId: {
      type: [String, Number],
      required: false,
    },

    projectId: {
      type: [String, Number],
      required: false,
      desc: '因为在获取详情的时候，就必须要传 projectId',
    },

    show: {
      type: Boolean,
      required: true,
      desc: '右侧弹窗是否展开，用于更新 url id',
    },

    isSlider: {
      type: Boolean,
      required: false,
      default: true,
    },
  },

  events: ['HandleSide', 'updateInfoSuccess'],
  inject: {
    isInjectFromMine: {
      default: false,
    },

    refreshList: {
      default: () => () => {},
    },
  },

  data() {
    return {
      workItemType: 3, // 工作项类型
      activeTagName: 'comment', // 当前活跃 tab
      // 状态流转数据信息
      statusRecordInfo: {
        statusRecordList: [],
        statusRecordPageInfo: {
          pageNum: 1,
          pageSize: 100,
          isMore: false,
        },
      },

      requirementCreateShow: false, // 转需求 slider 是否打开
      baseConfig: {
        title: i18n.t('缺陷详情'),
      },
    }
  },
  computed: {},
  watch: {
    workItemId: function(newInfo, oldInfo) {
      if (newInfo !== oldInfo && this.show) {
        this.initData()
      }
    },
    show() {
      if (this.show) {
        this.initData()
      }
    },
  },

  created() {},
  mounted() {
    this.initData()
  },
  methods: {
    initData() {
      this.resetData()
      if (!this.validWorkItemId()) {
        return
      }
      this.activeTagName = 'comment'
      this.getDetailInfo()
      this.urlAddWorkItemId()
    },
    resetData() {
      this.statusRecordInfo = {
        statusRecordList: [],
        statusRecordPageInfo: {
          pageNum: 1,
          pageSize: 100,
          isMore: false,
        },
      }

      this.operateInfo.operatePageInfo = {
        pageNum: 1,
        pageSize: 10,
        isMore: false,
      }
    },
    // tab栏切换
    getFooterDetail({ name } = {}) {
      name && this.countlyLog(`project_bugDetail_workItem_${name}`)
      this.tabRelateditem()
      switch (this.activeTagName) {
        case 'operate':
          this.getBugOperateRecordList()
          break
        case 'status':
          this.getBugStatusRecordList()
          break
      }
    },
    // 状态流转记录 - 获取记录列表 - 排序是根据 id 排序，本该根据时间，但是时间同 id 是相同方向排序的
    getBugStatusRecordList() {
      if (!this.validWorkItemId()) {
        return
      }
      bugStatusList({
        id: this.workItemId,
        pageNum: this.statusRecordInfo.statusRecordPageInfo.pageNum,
        pageSize: this.statusRecordInfo.statusRecordPageInfo.pageSize,
        projectId: this.getProjectId(),
      }).then(result => {
        if (result.status === 200) {
          if (this.statusRecordInfo.statusRecordPageInfo.pageNum === 1) {
            this.statusRecordInfo.statusRecordList = result.data.list.reverse()
          } else {
            // 需要去重
            let sessionList = [
              ...this.statusRecordInfo.statusRecordList.reverse(),
              ...result.data.list,
            ]

            this.statusRecordInfo.statusRecordList = [
              ...new Set(sessionList.map(item => item.id)),
            ]
              .sort((a, b) => b - a)
              .map(item => {
                let record = {}
                for (let i = 0; i < sessionList.length; i++) {
                  if (sessionList[i].id === item) {
                    record = sessionList[i]
                    break
                  }
                }
                return record
              })
              .reverse()
          }
          this.statusRecordInfo.statusRecordPageInfo.isMore =
            result.data.total >
            this.statusRecordInfo.statusRecordPageInfo.pageNum *
              this.statusRecordInfo.statusRecordPageInfo.pageSize
        } else {
          this.statusRecordInfo.statusRecordList = []
          this.statusRecordInfo.statusRecordPageInfo.isMore = false
        }
      })
    },
    // 状态流转记录 - 加载更多
    StatusRecordLoadmoreCallback() {
      if (!this.statusRecordInfo.statusRecordPageInfo.isMore) {
        return false
      }
      this.statusRecordInfo.statusRecordPageInfo.pageNum =
        this.statusRecordInfo.statusRecordPageInfo.pageNum + 1
      this.$nextTick(function() {
        this.getBugStatusRecordList(this.detailInfo)
      })
    },
    bugToRequirement() {
      this.requirementCreateShow = true
    },
    // 转需求成功回调函数
    transferHandler() {
      const query = JSON.parse(JSON.stringify(this.$route.query))
      delete query.bugId
      this.$router.replace({
        path: this.$route.path,
        query,
      })
      this.deleteSuccess()
      this.contextmenuNone()
    },
    // 转需求使用到的关闭函数
    contextmenuNone() {
      this.requirementCreateShow = false
      // 是否是在工作台操作，是则刷新列表
      if (this.isInjectFromMine && typeof this.refreshList === 'function') {
        this.refreshList()
      }
    },
    // 缓存处理透传
    setUserInputCache() {
      // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
      this.$refs.baseDisplay?.setUserInputCache()
    },
  },
}
</script>
<style lang="scss" scoped></style>
