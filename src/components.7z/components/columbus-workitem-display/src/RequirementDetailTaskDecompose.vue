<template>
  <div>
    <div class="task-decompose">
      <el-button
        v-if="
          disabledTask &&
            $authFunction('FUNC_COOP_TASK_CREATE', 3, getProjectId())
        "
        type="text"
        class="fl cp task-decompose-title"
        style="margin-top: -3px;  font-size: 14px;"
        @click="addTaskHandle"
        >+{{ $t('任务分解') }}</el-button
      >
      <span
        v-else-if="
          $authFunction('FUNC_COOP_TASK_CREATE', 3, getProjectId()) &&
            tabCount.childReqtCount > 0
        "
        class="fl task-decompose-title"
        style="color:#cccccc;margin-top: -3px;display: inline-block;"
      >
        <i class="co-icon-info-solid" style="color:#999999;" />
        {{ $t('父需求不能直接进行任务分解') }},{{
          $t('请到子需求下进行任务分解')
        }}
      </span>
      <span
        v-else-if="
          $authFunction('FUNC_COOP_TASK_CREATE', 3, getProjectId()) &&
            !disabledTask
        "
        class="fl task-decompose-title"
        style="color:#cccccc;margin-top: -3px;display: inline-block;"
      >
        <i class="co-icon-info-solid" style="color:#999999;" />
        {{ $t('父需求或者需求已完成') }}/{{ $t('取消不能分解任务') }}
      </span>
      <span
        v-else
        class="fl task-decompose-title"
        style="color:#cccccc;margin-top: -3px;display: inline-block;"
      >
        <i class="el-icon-warning" style="color:#409EFF;" />
        {{ $t('暂无权限') }}
      </span>
      <el-table
        class="multiple-table"
        :data="taskDataList"
        border
        style="width: 100%"
      >
        <el-table-column
          :label="$t('任务标题')"
          show-overflow-tooltip
          min-width="220"
        >
          <template slot-scope="scope">
            <el-input
              v-if="scope.row.isNewAdd == 1"
              v-model="createTaskInfo.title"
              v-focus
              :placeholder="$t('输入标题,回车新建')"
              @keyup.enter.native="saveTask"
            >
            </el-input>
            <global-input
              v-else
              :init-value="scope.row.display.title"
              :on-change="
                value => {
                  updateGlobalTitle(scope.row, value)
                }
              "
            >
              <span slot class="table-input-edit-text c-blue-hover">
                <span class="c-blue cp" @click="toTaskView(scope.row)">{{
                  scope.row.display.title
                }}</span>
              </span>
            </global-input>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('优先级')"
          show-overflow-tooltip
          width="100"
          sortable
          prop="priority"
        >
          <template slot-scope="scope">
            <el-select
              v-if="scope.row.isNewAdd == 1"
              v-model="createTaskInfo.priority"
            >
              <el-option
                v-for="(data, index) in priorityList"
                :key="index"
                :label="data.value"
                :value="data.key"
              >
                <template>
                  <span style="float: left">
                    <span
                      class="mini-circle"
                      :style="{ backgroundColor: data.color }"
                    ></span
                    >{{ data.literal }}
                  </span>
                </template>
              </el-option>
            </el-select>
            <div
              v-else
              class="cursor-pointer"
              @click.stop="
                e =>
                  updateGlobalTaskInfo(
                    scope.row,
                    e,
                    'priority',
                    getTaskDecomposition,
                  )
              "
            >
              <div
                style="display: flex;"
                v-html="
                  initNameStatus(
                    scope.row.display.detail.priority.color,
                    scope.row.display.detail.priority.literal,
                  )
                "
              ></div>
            </div>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('处理人')"
          width="100"
          sortable
          prop="assignUser"
        >
          <template slot-scope="scope">
            <select-filter
              v-if="scope.row.isNewAdd == 1"
              v-model="createTaskInfo.assignUser"
              is-assign-user
              :assign-user-choice-focus="false"
              :popper-append-to-body="false"
              :select-list="assignUserData"
            ></select-filter>
            <select-filter
              v-else-if="scope.row._assignUserChoice"
              v-model="createTaskInfo.assignUser"
              is-assign-user
              :select-list="assignUserData"
              :assign-user-choice-focus="true"
              :popper-append-to-body="false"
              @change="assignUserChange"
              @visableChange="
                val =>
                  selectUserVisibleChange(val, scope.row, '_assignUserChoice')
              "
            ></select-filter>
            <div
              v-else
              class="select-user current-hover"
              @click="handleUserChoice(scope.row, '_assignUserChoice')"
            >
              {{ scope.row.display.assignUser }}
            </div>
          </template>
        </el-table-column>
        <el-table-column :label="$t('预计工时')" width="100">
          <template slot-scope="scope">
            <expect-hour
              v-if="scope.row.isNewAdd == 1"
              :hour.sync="createTaskInfo.expectHour"
              :change-callback="() => taskTimeChange('expectHour')"
            ></expect-hour>
            <span
              v-else
              class="cursor-pointer table-expect-hour-span current-hover"
              @click.stop="
                e =>
                  updateGlobalTaskInfo(
                    scope.row,
                    e,
                    'expectHour',
                    getTaskDecomposition,
                  )
              "
              >{{
                scope.row.expectHour | toShowExpectHour(scope.row.expectHour)
              }}
              <i
                class="el-icon-circle-close expect-hour-close"
                @click.stop="handleClearExpectHour(scope.row)"
              >
              </i>
            </span>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('开始时间')"
          width="125"
          sortable
          prop="startTimeValue"
        >
          <template slot-scope="scope">
            <custom-date
              v-if="scope.row.isNewAdd == 1"
              v-model="createTaskInfo.startTime"
              style="width: 105px;"
              type="date"
              :placeholder="$t('选择日期')"
              value-format="yyyy-MM-dd"
              prefix-icon="clean-icon"
              :picker-options="{}"
              :disabled-date="createTaskDisabledDate"
              @change="taskTimeChange('startTime')"
            ></custom-date>
            <global-input
              v-else
              :init-value="scope.row.startTime || ''"
              input-type="time"
              :on-change="
                value => {
                  GlobalTaskUpdate({
                    startTime: value,
                    id: scope.row.id,
                    projectId: scope.row.projectId,
                    cb: getTaskDecomposition,
                  })
                }
              "
            >
              <span slot class="current-hover">{{
                scope.row.startTime || '--'
              }}</span>
            </global-input>
          </template>
        </el-table-column>
        <el-table-column :label="$t('结束时间')" width="125">
          <template slot-scope="scope">
            <custom-date
              v-if="scope.row.isNewAdd == 1"
              v-model="createTaskInfo.endTime"
              style="width: 105px;"
              type="date"
              :placeholder="$t('选择日期')"
              value-format="yyyy-MM-dd"
              prefix-icon="clean-icon"
              :disabled-date="createTaskDisabledDate"
              :picker-options="{}"
              @change="taskTimeChange('endTime')"
            ></custom-date>
            <global-input
              v-else
              :init-value="scope.row.endTime || ''"
              input-type="time"
              :on-change="
                value => {
                  GlobalTaskUpdate({
                    endTime: value,
                    id: scope.row.id,
                    projectId: scope.row.projectId,
                    cb: getTaskDecomposition,
                  })
                }
              "
            >
              <span slot class="current-hover">{{
                scope.row.endTime || '--'
              }}</span>
            </global-input>
          </template>
        </el-table-column>
        <el-table-column :label="$t('迭代')" show-overflow-tooltip width="100">
          <template slot-scope="scope">
            <el-select
              v-if="scope.row.isNewAdd == 1"
              v-model="createTaskInfo.sprintId"
              :placeholder="$t('请选择活动区域')"
              style="width:100%;"
            >
              <el-option
                v-for="item in sprintList"
                :key="item.id"
                :label="item.value"
                :value="item.key"
              >
              </el-option>
            </el-select>
            <span
              v-else
              class="cursor-pointer table-column-padding current-hover"
              @click.stop="
                e =>
                  updateGlobalTaskInfo(
                    scope.row,
                    e,
                    'sprintId',
                    getTaskDecomposition,
                  )
              "
              >{{ scope.row.display.sprint || '--' }}</span
            >
          </template>
        </el-table-column>
        <el-table-column
          fixed="right"
          :label="$t('状态')"
          show-overflow-tooltip
          width="100"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.isNewAdd == 1"
              class="c-blue cp"
              @click="saveTask"
              >{{ $t('保存') }}</span
            >
            <span
              v-if="scope.row.isNewAdd == 1"
              class="c-blue cp"
              @click="cancelSaveTask"
              >&nbsp;{{ $t('取消') }}</span
            >
            <!-- <span v-if="scope.row.isNewAdd == 1">-</span> -->
            <state-flow
              v-else
              :project-id="getProjectId()"
              :status-id="scope.row.statusId"
              :work-item-type="2"
              :work-item-id="scope.row.id"
              :update-data="updateSuccessHandler"
              :current-index="scope.row.id"
            >
              <span
                class="cursor-pointer status_name"
                v-html="
                  initNameStatus(
                    scope.row.display.detail.status.color,
                    scope.row.display.status,
                  )
                "
              >
              </span>
            </state-flow>
          </template>
        </el-table-column>
        <!-- <el-table-column
          fixed="right"
          :label="$t('操作')"
          show-overflow-tooltip
          min-width="100"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.isNewAdd == 1"
              class="c-blue cp"
              @click="saveTask"
              >{{ $t('保存') }}</span
            >
            <span
              v-if="scope.row.isNewAdd == 1"
              class="c-blue cp"
              @click="cancelSaveTask"
              >&nbsp;{{ $t('取消') }}</span
            >
            <span
              v-if="
                $authFunction('FUNC_COOP_TASK_DELETE', 3, getProjectId()) &&
                  scope.row.isNewAdd != 1 &&
                  scope.row.isNewAdd != 2
              "
              class="cp c-blue"
              @click="taskDelete(scope.row)"
              >{{ $t('删除') }}</span
            >
          </template>
        </el-table-column> -->
      </el-table>
    </div>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 需求详情 - 任务分解
 * @desc
 * @author heyunjiang
 * @date 2020.7.7
 */
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import GlobalSelect from '@/components/field-edit/GlobalSelect.vue'
import GlobalInput from '@/components/field-edit/GlobalInput.vue'
import ExpectHour from '@/components/expect-hour'
import CustomDate from '@/components/custom-date'
// import field-edit from '@/components/FieldEdit';
import StateFlow from '@/components/state-flow'
import ACTIONSTYPE from '@/store/action-types'
import { calcWorkHoursParam } from '@/utils'
import { taskDecomposition } from '@/service/requirement'
import { priorityList } from '@/service/bug'
import { getUserList } from '@/service/project'
import { getListSprintName } from '@/service/sprint'
import * as taskService from '@/service/task'
import debounce from 'lodash/debounce'

export default {
  name: 'RequirementDetailTaskDecompose',
  components: {
    GlobalSelect,
    GlobalInput,
    // FieldEdit,
    StateFlow,
    ExpectHour,
    CustomDate,
  },

  filters: {
    //预计工时
    toShowExpectHour(val) {
      return val > 0 ? val + 'h' : '--'
    },
  },

  mixins: [ProjectCommonMixin, WorkItemTemplateMixin],
  props: {
    detailInfo: {
      type: Object,
      required: true,
      desc: '工作项详情',
    },

    requireId: {
      type: [Number, String],
      default: null,
    },

    projectId: {
      type: [Number, String],
      default: null,
    },
  },

  data() {
    return {
      taskDataList: [], //任务分解
      templateInfo: {}, // 模板详情
      // 创建任务对象
      createTaskInfo: {
        isNewAdd: null, // 新增为 1
        title: '',
        startTime: null,
        endTime: null,
        expectHour: null,
        assignUser: null,
        priority: '',
        projectId: this.projectId,
        requireId: this.requireId,
        sprintId: 0,
      },

      priorityList: [], // 优先级列表
      assignUserData: [], // 处理人列表
      sprintList: [], // 迭代列表
      idVip: null, // 当前更新的工作项 id
      idEditVip: null, // 当前更新的工作项 id
      localProjectId: this.$getUrlParams().projectId,
    }
  },
  computed: {
    // 是否禁止分解任务
    disabledTask() {
      return this.detailInfo.detail.authority.decomposeTask
    },
    // 控制时间选择范围
    createTaskDisabledDate() {
      return this.$store.state.pf.createTaskDisabledDate
    },
    // 需求tab栏数量
    tabCount() {
      return this.$store.state.workItemManage['requireTabNum']
    },
  },

  watch: {},
  created() {},
  mounted() {
    this.initData()
  },
  methods: {
    // 读取 projectId 统一入口
    getProjectId() {
      return (
        this.detailInfo?.rawData?.projectId ||
        this.projectId ||
        this.localProjectId
      )
    },
    // 数据初始化
    initData() {
      this.getTaskDecomposition()
      this.getPriorityList()
      this.getAssignUser()
      this.getSprintList()
    },
    // 获取已经分解的任务列表
    getTaskDecomposition() {
      if (this.requireId === -1) {
        return
      }
      taskDecomposition({
        projectId: this.getProjectId(),
        id: this.requireId,
      }).then(res => {
        res.data.forEach(item => {
          // 方便排序
          item.startTimeValue = new Date(item.startTime || 0).getTime()
        })
        this.taskDataList = res.data
      })
      this.$emit('updateCountInfoSuccess')
    },
    // 获取优先级
    getPriorityList() {
      priorityList({
        projectId: this.getProjectId(),
        workItemType: 2,
      }).then(res => {
        this.priorityList = res.data.map(item => {
          return {
            value: item.literal,
            key: item.priority,
            color: item.color,
            ...item,
          }
        })
      })
    },
    // 获取用户
    getAssignUser() {
      getUserList({
        projectId: this.getProjectId(),
        query: null,
      }).then(res => {
        this.assignUserData = res.data.map(item => {
          return {
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
          }
        })
      })
    },
    // 获取迭代列表
    getSprintList() {
      getListSprintName({
        projectId: this.getProjectId(),
        status: 1,
      }).then(res => {
        if (res.status == 200) {
          this.sprintList = res.data.map(item => {
            return {
              value: item.name,
              key: item.id,
              id: item.id,
            }
          })
          this.sprintList.unshift({
            key: 0,
            value: i18n.t('未规划'),
          })
        }
      })
    },
    // 任务联动 - add by heyunjiang on 2020.7.8
    async taskTimeChange(key) {
      const resultObj = calcWorkHoursParam(this.createTaskInfo)
      if (!resultObj) {
        return
      }
      const { options } = resultObj
      const result = await this.time_linkage_calculate({
        ...options,
        modifiedFiled: key || 'startTime',
      })

      if (result.status === 200) {
        this.createTaskInfo = {
          ...this.createTaskInfo,
          startTime: result.data.timeCalculateResult.startTime,
          endTime: result.data.timeCalculateResult.endTime,
          expectHour: result.data.timeCalculateResult.expectHour,
        }

        // 此处开始声明 lastTimeInfo 对象，不做响应式数据，用以中间数据缓存
        this.lastTimeInfo = {
          startTime: result.data.timeCalculateResult.startTime,
          endTime: result.data.timeCalculateResult.endTime,
          expectHour: result.data.timeCalculateResult.expectHour,
        }
      } else {
        this.lastTimeInfo &&
          (this.createTaskInfo = {
            ...this.createTaskInfo,
            startTime: this.lastTimeInfo.startTime,
            endTime: this.lastTimeInfo.endTime,
            expectHour: this.lastTimeInfo.expectHour,
          })
      }
      this.$emit('updateCountInfoSuccess')
    },
    // 全局更新标题 - add by heyunjiang on 2019.5.8
    updateGlobalTitle(info, value) {
      this.GlobalTaskUpdate({
        id: info.id,
        title: value,
        projectId: info.projectId || this.getProjectId(),
        cb: this.updateSuccessHandler,
      })
    },
    // 更新任务 - add by heyunjiang on 2019.5.15
    updateGlobalTaskInfo(info, e, type) {
      this.GlobalSelectTargetClick(
        { ...info, workItemType: 2 },
        e,
        type,
        this.updateSuccessHandler,
      )
    },
    //进入任务视图
    toTaskView(info) {
      this.$goToNewWindowPage('/task/view', {
        taskId: info.id,
        projectId: info.projectId,
      })
    },

    // 点击添加任务
    addTaskHandle: debounce(
      async function() {
        for (let i of this.taskDataList) {
          if (i.isNewAdd) {
            return this.$message({
              message: i18n.t('同时只能增加一条任务'),
              type: 'warning',
            })
          }
        }
        this.templateInfo = await this.getDefaultTemplateInfoForFastCreate(
          this.getProjectId(),
          2,
        )
        this.createTaskInfo.isNewAdd = 1
        this.createTaskInfo.title = this.templateInfo.title
        this.createTaskInfo.priority = this.detailInfo.rawData.priority
        this.createTaskInfo.assignUser = this.detailInfo.rawData.assignUser
        this.createTaskInfo.expectHour = null
        this.createTaskInfo.startTime = ''
        this.createTaskInfo.endTime = ''
        this.createTaskInfo.sprintId = this.detailInfo.rawData.sprintId
        this.taskDataList.unshift(this.createTaskInfo)
      },
      300,
      { leading: true },
    ),
    //分解任务成功保存
    async saveTask() {
      this.createTaskInfo.projectId = this.getProjectId()
      this.createTaskInfo.requireId = this.requireId
      // 任务工时校验
      if (
        this.createTaskInfo.expectHour &&
        this.createTaskInfo.expectHour % 1 > 0
      ) {
        this.$message({ message: i18n.t('预计工时必须为整数'), type: 'error' })
        return false
      }
      // 开始时间不能晚于结束时间
      if (
        this.createTaskInfo.startTime &&
        this.createTaskInfo.endTime &&
        new Date(this.createTaskInfo.startTime) >
          new Date(this.createTaskInfo.endTime)
      ) {
        this.$message({
          message: i18n.t('开始时间不能晚于结束时间！'),
          type: 'error',
        })
        return false
      }
      // 必填项校验
      const requiredValid = await this.$store.dispatch(
        ACTIONSTYPE.VALIDTEMPLATEINFOFORFASTCREATE,
        {
          fieldsList: this.templateInfo.fieldsList,
          formInfo: this.createTaskInfo,
        },
      )

      if (requiredValid.fieldName) {
        this.$message({
          message: `${requiredValid.fieldName}${i18n.t('不能为空')}`,
          type: 'error',
        })

        return false
      }

      if (this.createTaskInfo.title && this.createTaskInfo.title !== ' ') {
        this.createTask()
        this.taskDataList.shift()
      } else {
        this.$message({
          message: i18n.t('标题为必填项'),
          type: 'error',
        })

        return
      }
    },
    // 确定分解任务
    createTask() {
      taskService
        .createTask({
          ...this.templateInfo,
          ...this.createTaskInfo,
        })
        .then(res => {
          if (res.status === 200) {
            this.getTaskDecomposition()
            this.$message({
              message: i18n.t('分解任务成功'),
              type: 'success',
            })

            this.$emit('updateCountInfoSuccess')
            this.createTaskInfo.assignUser = '' // 这里清空是为了让修改处理人时为空
          }
        })
    },
    //取消创建任务
    cancelSaveTask() {
      this.taskDataList.shift()
    },

    //取消编辑
    HandleTaskEdit() {
      taskService
        .taskUpdate({ id: this.idVip })
        .then(() => {
          this.getTaskDecomposition()
        })
        .catch(() => {
          this.getTaskDecomposition()
        })
    },
    //任务更新
    updateTaskInfo(key, value) {
      let params = {
        id: this.idVip,
        [key]: value,
      }
      taskService
        .taskUpdate(params)
        .then(() => {
          this.updateSuccessHandler()
          this.$message({
            message: i18n.t('编辑成功'),
            type: 'success',
          })
        })
        .catch(() => {
          this.getTaskDecomposition()
        })
    },
    // 更新成功回调
    updateSuccessHandler() {
      this.getTaskDecomposition()
      this.$emit('updateInfoSuccess')
    },
    // 删除
    taskDelete(row) {
      if (!row.display.authority.deletable) {
        this.$message({
          message: row.display.authority.deleteErrorMsg,
          type: 'warning',
        })

        return
      }
      this.$confirm(i18n.t('此操作将删除该数据, 是否继续?'), i18n.t('提示'), {
        confirmButtonText: i18n.t('确定'),
        cancelButtonText: i18n.t('取消'),
        type: 'warning',
      })
        .then(() => {
          taskService.deleteTask({ id: row.id }).then(res => {
            if (res !== undefined) {
              this.$message({
                message: res.msg || i18n.t('删除成功'),
                type: res.status === 200 ? 'success' : 'error',
              })

              this.getTaskDecomposition()
              this.$emit('updateCountInfoSuccess')
            }
          })
        })
        .catch(() => {})
    },
    //处理人更新
    assignUserChange() {
      this.updateTaskInfo('assignUser', this.createTaskInfo.assignUser)
      this.createTaskInfo.assignUser = ''
    },
    //预计工时更新
    blurexpectHour(index) {
      //index = 1表示撞创建状态 2表示更新状态
      if (this.createTaskInfo.startTime) {
        if (
          this.createTaskInfo.expectHour == 4 ||
          this.createTaskInfo.expectHour == 8
        ) {
          this.createTaskInfo.endTime = this._GetDateStr(0)
        } else if (
          this.createTaskInfo.expectHour == 12 ||
          this.createTaskInfo.expectHour == 16
        ) {
          this.createTaskInfo.endTime = this._GetDateStr(1)
        } else if (
          this.createTaskInfo.expectHour == 20 ||
          this.createTaskInfo.expectHour == 24
        ) {
          this.createTaskInfo.endTime = this._GetDateStr(2)
        }
      }
      if (index === 2) {
        this.updateTaskInfo('expectHour', this.createTaskInfo.expectHour)
        this.updateTaskInfo('endTime', this.createTaskInfo.endTime)
      }
    },
    //预计开始日期更新
    startTimeChange(index) {
      //index = 1表示撞创建状态 2表示更新状态
      let nowDate = this.formatDate(new Date(), 'yyyyMMdd')
      let startTime = this.createTaskInfo.startTime.replace(/-/g, '')
      if (parseInt(nowDate.substring(0, 9)) > parseInt(startTime)) {
        this.$message({
          message: i18n.t('预计开始日期不能小于当前日期'),
          type: 'warning',
        })

        return
      }
      this.blurexpectHour(index)
      if (index === 2) {
        this.updateTaskInfo('startTime', this.createTaskInfo.startTime)
      }
    },
    //结束时间更新
    endTimeChange() {
      let nowDate = this.formatDate(new Date(), 'yyyyMMdd')
      let endTime = this.createTaskInfo.endTime.replace(/-/g, '')
      if (parseInt(nowDate.substring(0, 9)) > parseInt(endTime)) {
        this.$message({
          message: i18n.t('预计结束日期不能小于当前日期'),
          type: 'warning',
        })

        return
      }
      this.updateTaskInfo('endTime', this.createTaskInfo.endTime)
    },
    //获取今天明天后天的日期
    _GetDateStr(AddDayCount) {
      let date = new Date(this.createTaskInfo.startTime)
      date.setDate(date.getDate() + AddDayCount)
      let y = date.getFullYear()
      let m = date.getMonth() + 1
      let d = date.getDate()
      return y + '-' + m + '-' + d
    },
    sprintIdChange() {
      this.updateTaskInfo('sprintId', this.createTaskInfo.sprintId)
    },
    // 清除工时
    handleClearExpectHour(row) {
      const { id, projectId, expectHour } = row
      if (!expectHour) {
        return
      }
      this.GlobalTaskUpdate({
        expectHour: 0,
        id,
        projectId,
        cb: this.getTaskDecomposition,
      })
    },
    // 处理人选择框 - 展示
    handleUserChoice(data, key) {
      this.idVip = this.idEditVip = data.id
      this.$set(data, key, 1)
    },
    // 处理人选择框 - 隐藏
    selectUserVisibleChange(val, item, key) {
      !val && (item[key] = 0)
    },
  },
}
</script>
<style lang="scss" scoped>
.demand-connect,
.task-decompose {
  padding-bottom: 20px;
  width: 100%;
  .task-decompose-title {
    padding-bottom: 5px;
  }
}
.table-expect-hour-span {
  .expect-hour-close {
    display: none;
  }
  &:hover {
    .expect-hour-close {
      display: inline-block;
      color: #c2c6ce;
    }
  }
}
.status_name {
  display: flex;
  vertical-align: middle;
  border-radius: 4px;
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  box-sizing: border-box;
  color: #fff;
}
</style>
