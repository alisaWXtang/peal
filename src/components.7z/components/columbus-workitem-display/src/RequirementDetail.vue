<template>
  <div class="slider-body">
    <BaseDisplay
      v-if="detailInfo && show"
      ref="baseDisplay"
      :work-item-type="workItemType"
      :detail-info="detailInfo"
      :base-config="baseConfig"
      is-showmore
      v-bind="$attrs"
      @workItemUpdate="workItemUpdate"
      @refreshData="refreshData"
      @deleteSuccess="deleteSuccess"
      @HandleSide="closeHandler"
      @filesUpdate="onFilesUpdate"
      @updateInfoSuccess="$emit('updateInfoSuccess')"
    >
      <template #footer>
        <el-tabs v-model="activeTagName" @tab-click="getFooterDetail">
          <el-tab-pane
            :label="$t('评论') + '(' + tabCount.commentCount + ')'"
            name="0"
          >
            <div
              v-if="activeTagName === '0'"
              ref="detaild"
              class="detailed-information1"
            >
              <comment-list
                ref="commentList"
                :work-item-type="workItemType"
                :work-item-id="workItemId"
                :project-id="getProjectId()"
                @discussFun="tabRelateditem"
              />
            </div>
          </el-tab-pane>
          <el-tab-pane name="3">
            <span id="taskSplitDom" slot="label">{{
              $t('任务分解') + '(' + tabCount.taskCount + ')'
            }}</span>
            <RequirementDetailTaskDecompose
              v-if="activeTagName === '3'"
              :require-id="workItemId"
              :project-id="getProjectId()"
              :detail-info="detailInfo"
              @updateCountInfoSuccess="refreshData"
            />
          </el-tab-pane>
          <el-tab-pane name="4">
            <span ref="childRequirement" slot="label">{{
              $t('子需求') + '(' + tabCount.childReqtCount + ')'
            }}</span>
            <RequirementDetailRequirementDecompose
              v-if="activeTagName === '4'"
              :require-id="workItemId"
              :project-id="getProjectId()"
              :detail-info="detailInfo"
              :task-count="tabCount.taskCount"
              @updateCountInfoSuccess="refreshData"
            />
          </el-tab-pane>
          <el-tab-pane
            :label="`${$t('缺陷')}(${tabCount.defectCount})`"
            name="bugTab"
          >
            <bug-list-table
              v-if="activeTagName === 'bugTab'"
              :require-id="workItemId"
              :project-id="getProjectId()"
            />
          </el-tab-pane>
          <el-tab-pane :label="$t('关联工作项')" name="7">
            <BaseDisplayAssoc
              v-if="activeTagName === '7'"
              :work-item-type="workItemType"
              :detail-info="detailInfo"
            ></BaseDisplayAssoc>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('评审') + '(' + tabCount.sdlSheetCount + ')'"
            name="6"
          >
            <co-tabs v-if="activeTagName === '6'" v-model="reviewActiveName">
              <!-- TODO 暂时不要需求评审 -->
              <!--                <co-tab-pane :label="$t('需求评审')" name="requirementReview">-->
              <!--                  <requirement-review-->
              <!--                    :require-id="workItemId"-->
              <!--                    :project-id="getProjectId()"-->
              <!--                    :reviewable="detailInfo.detail.authority.reviewable"-->
              <!--                  />-->
              <!--                </co-tab-pane>-->
              <co-tab-pane :label="$t('安全评审')" name="securityReview">
                <security-review
                  :project-id="getProjectId()"
                  :requirement-id="workItemId"
                />
              </co-tab-pane>
            </co-tabs>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('修订列表') + '(' + tabCount.workConentCount + ')'"
            name="1"
          >
            <div v-if="activeTagName === '1'" class="detailed-information1">
              <div>
                <el-table
                  :data="revisedList"
                  :border="revisedList.length !== 0"
                  style="width: 100%"
                >
                  <el-table-column prop="version" :label="$t('修订版本')" />
                  <el-table-column prop="updateTime" :label="$t('修订时间')" />
                  <el-table-column
                    prop="display.createUser"
                    :label="$t('操作人')"
                  />
                  <el-table-column :label="$t('操作')">
                    <template slot-scope="scope">
                      <span
                        class="cp c-blue"
                        @click="viewRequireRevise(scope.row)"
                        >{{ $t('查看') }}</span
                      >
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="revisedList-paging">
                <el-pagination
                  v-show="revisedList && revisedList.length != 0"
                  class="flex-right"
                  style="margin-top: 9px;"
                  :current-page="revisedPageInfo.pageNumber"
                  :page-sizes="[10, 20, 30]"
                  :page-size="revisedPageInfo.pageSize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="revisedPageInfo.totalRecords"
                  @size-change="handleRevisedPageSizeChange"
                  @current-change="handleRevisedPageNumChange"
                />
              </div>
            </div>
            <el-dialog
              :title="$t('修订详情')"
              :visible.sync="revisedDialogVisible"
              class="issuedialog"
              width="1200"
              :modal-append-to-body="false"
            >
              <work-item-diff
                v-if="revisedDialogVisible"
                :api-params="diffParams"
              />
            </el-dialog>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('代码分支') + '(' + tabCount.branchCount + ')'"
            name="5"
          >
            <code-branch
              v-if="activeTagName === '5'"
              :work-item-id="workItemId"
              :work-item-type="workItemType"
              :project-id="getProjectId()"
              @tabRelateditem="getFooterDetail"
            />
          </el-tab-pane>
          <el-tab-pane
            :label="$t('测试计划') + '(' + tabCount.testPlanCount + ')'"
            name="testplan"
          >
            <test-plan
              v-if="activeTagName === 'testplan'"
              :project-id="getProjectId()"
              disabled-testplan
              :sprintdata="operateInfo.operateList"
              :work-item-id="workItemId"
              :require-info="detailInfo"
              @testPlanSuccess="getFooterDetail"
            />
          </el-tab-pane>
          <el-tab-pane
            :label="$t('操作记录') + '(' + tabCount.operationLogCount + ')'"
            name="2"
          >
            <div v-if="activeTagName === '2'" class="detailed-information1">
              <time-line
                :data="operateInfo.operateList"
                :loadmore-callback="OperateLoadmoreCallback"
                :is-more="operateInfo.operatePageInfo.isMore"
              />
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>
    </BaseDisplay>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 需求详情组件
 * @desc
 * @author heyunjiang
 * @date 2020.7.6
 */
import TimeLine from '@/components/time-line'
import CommentList from '@/components/comment-list'
import TestPlan from '@/components/test-plan'
import CodeBranch from '@/views/requirement/CodeBranch'
// import SecurityReview from '@/views/requirement/SecurityReview'
// import RequirementReview from '@/views/requirement/RequirementReview'
import WorkItemDiff from '@/components/work-item-diff'
import RequirementDetailTaskDecompose from './RequirementDetailTaskDecompose'
import RequirementDetailRequirementDecompose from './RequirementDetailRequirementDecompose'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import WorkItemDispayMixin from './WorkItemDispayMixin'
import BaseDisplay from './BaseDisplay'
import BugListTable from './BugListTable'
import BaseDisplayAssoc from './BaseDisplayAssoc'
const SecurityReview = () => import('@/views/requirement/SecurityReview')
import { guide } from '@/store/mutation-types'
import { guideType, guideStep } from '@/components/guide/guideData'

//埋点key值映射
const labelMap = {
  0: 'comment', //评论
  3: 'taskDecomposition', //任务分解
  4: 'childDemand', //子需求
  6: 'safetyEvaluation', //安全评审
  1: 'changeList', //修订列表
  5: 'codeBranch', //代码分支
  testplan: 'testPlan', //测试计划
  bugTab: 'bugTab', //缺陷
  2: 'operate', //操作记录
  7: 'workItemAssoc', // 关联工作项
}

export default {
  name: 'RequirementDetail',
  components: {
    BaseDisplay,
    TimeLine,
    CommentList,
    // GlobalSelect,
    // GlobalInput,
    // FieldEdit,
    TestPlan,
    CodeBranch,
    BaseDisplayAssoc,
    SecurityReview,
    // RequirementReview,
    WorkItemDiff,
    BugListTable,
    RequirementDetailTaskDecompose,
    RequirementDetailRequirementDecompose,
  },

  mixins: [WorkItemTemplateMixin, ProjectCommonMixin, WorkItemDispayMixin],
  // props 正常只需要传这些数据，特殊使用时，比如转需求、缺陷，则通过 this.$attrs 读取
  props: {
    workItemId: {
      type: [String, Number],
      required: false,
    },

    projectId: {
      type: [String, Number],
      required: false,
      desc: '因为在获取详情的时候，就必须要传 projectId',
    },

    show: {
      type: Boolean,
      required: true,
      desc: '右侧弹窗是否展开，用于更新 url id',
    },
  },

  events: ['HandleSide', 'updateInfoSuccess'],
  data() {
    return {
      workItemType: 1, // 工作项类型
      activeTagName: '0', // 当前活跃 tab
      diffParams: {}, // 修订详情 - props
      reviewActiveName: 'securityReview', // 评审tab当前激活
      baseConfig: {
        title: i18n.t('需求详情'),
      },
    }
  },
  computed: {},
  watch: {
    workItemId: function(newInfo, oldInfo) {
      if (Number(newInfo) !== Number(oldInfo) && this.show) {
        this.initData()
      }
    },
    show() {
      if (this.show) {
        this.initData()
      } else {
        this.$store.commit(guide.STOP_STEP)
      }
    },
  },

  created() {},
  mounted() {
    this.initData()
  },
  methods: {
    initGuide(time) {
      if (
        this.$store.state.guide.guideType === guideType.requirement &&
        this.$store.state.guide.guideStep
      ) {
        let _this = this
        this.activeTagName = '4'
        setTimeout(() => {
          this.$store.commit(guide.START_GUIDE, {
            guideType: guideType.requirement,
            guideStep: guideStep.requirementSplit,
            step: 2,
            steps: {
              2: {
                dom: this.$refs.childRequirement,
                prevCallback() {
                  _this.$emit('HandleSide')
                  setTimeout(() => {
                    _this.$store.commit(guide.RECOVERY_STEP)
                    _this.$bus.$emit('G_requirementSplit')
                  }, 500)
                },
                nextCallback() {
                  // 模块最后一步，统一由guideStep组件处理
                },
              },
            },
          })
        }, time || 500)
        return
      }
      if (
        this.$store.state.guide.guideType === guideType.sprint &&
        this.$store.state.guide.guideStep
      ) {
        if (!this.$authFunction('FUNC_COOP_TASK_CREATE', 3, this.projectId)) {
          this.$store.commit(guide.STEP_WARN, {
            warnMessage:
              '你没有任务拆分权限，请在设置中添加权限，再继续浏览此步指引',
            guideStep: guideStep.taskSplit,
          })
          return
        }
        let _this = this
        this.activeTagName = '3'
        setTimeout(() => {
          this.$store.commit(guide.START_GUIDE, {
            guideType: guideType.sprint,
            guideStep: guideStep.taskSplit,
            step: 2,
            steps: {
              2: {
                dom: document.getElementById('taskSplitDom'),
                prevCallback() {
                  _this.$emit('HandleSide')
                  setTimeout(() => {
                    _this.$store.commit(guide.RECOVERY_STEP)
                    _this.$bus.$emit('G_taskSplit')
                  }, 500)
                },
                nextCallback() {
                  // 模块最后一步，统一由guideStep组件处理
                  _this.$emit('HandleSide')
                  return true
                },
              },
            },
          })
        }, time || 500)
      }
    },
    initData() {
      this.resetData()
      if (!this.validWorkItemId()) {
        return
      }
      this.activeTagName = '0'
      this.getDetailInfo()
      this.urlAddWorkItemId()
    },
    // tab栏切换
    getFooterDetail({ name } = {}) {
      name &&
        this.countlyLog(`project_requirementDetail_workItem_${labelMap[name]}`)
      this.tabRelateditem()
      switch (this.activeTagName) {
        case '1':
          this.getRevisedList()
          break
        case '2':
          this.getBugOperateRecordList()
          break
      }
    },
    // 修订列表 - 查看修订记录
    viewRequireRevise(data) {
      this.diffParams = {
        workItemType: data.workItemType,
        workItemId: data.workItemId,
        rightContentId: data.id,
      }

      this.revisedDialogVisible = true
    },
    // 缓存处理透传
    setUserInputCache() {
      // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
      this.$refs.baseDisplay?.setUserInputCache()
    },
  },
}
</script>
<style lang="scss" scoped>
.detailed-information1 {
  width: 100%;
}
</style>
