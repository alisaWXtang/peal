<template>
  <div class="slider-body">
    <BaseDisplay
      v-if="detailInfo && show"
      ref="baseDisplay"
      :work-item-type="workItemType"
      :detail-info="detailInfo"
      :base-config="baseConfig"
      @workItemUpdate="workItemUpdate"
      @refreshData="refreshData"
      @deleteSuccess="deleteSuccess"
      @HandleSide="closeHandler"
      @filesUpdate="onFilesUpdate"
      @updateInfoSuccess="$emit('updateInfoSuccess')"
    >
      <!-- 状态流转、操作记录 -->
      <template #footer>
        <el-tabs v-model="activeTagName" @tab-click="getFooterDetail">
          <el-tab-pane
            :label="$t('评论') + '(' + tabCount.commentCount + ')'"
            name="comment"
          >
            <div ref="detaild" class="detailed-information1">
              <comment-list
                v-if="activeTagName === 'comment'"
                ref="commentList"
                :work-item-type="workItemType"
                :work-item-id="workItemId"
                :project-id="getProjectId()"
                @discussFun="tabRelateditem"
              ></comment-list>
            </div>
          </el-tab-pane>
          <el-tab-pane :label="$t('关联工作项')" name="assoc">
            <BaseDisplayAssoc
              v-if="activeTagName === 'assoc'"
              :work-item-type="workItemType"
              :detail-info="detailInfo"
            ></BaseDisplayAssoc>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('代码提交') + '(' + tabCount.codeCommitCount + ')'"
            name="code"
          >
            <code-commit
              v-if="activeTagName === 'code'"
              :work-item-type="workItemType"
              :work-item-id="workItemId"
              :project-id="getProjectId()"
              :update="show"
            ></code-commit>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('操作记录') + '(' + tabCount.operationLogCount + ')'"
            name="operate"
          >
            <time-line
              :data="operateInfo.operateList"
              :loadmore-callback="OperateLoadmoreCallback"
              :is-more="operateInfo.operatePageInfo.isMore"
            ></time-line>
          </el-tab-pane>
          <el-tab-pane
            :label="$t('修订列表') + '(' + tabCount.workConentCount + ')'"
            name="changeList"
          >
            <div class="detailed-information1">
              <div>
                <el-table
                  :data="revisedList"
                  style="width: 100%"
                  :border="revisedList.length !== 0"
                >
                  <el-table-column
                    prop="version"
                    :label="$t('修订版本')"
                  ></el-table-column>
                  <el-table-column
                    prop="updateTime"
                    :label="$t('修订时间')"
                  ></el-table-column>
                  <el-table-column
                    prop="display.createUser"
                    :label="$t('操作人')"
                  ></el-table-column>
                  <el-table-column :label="$t('操作')">
                    <template slot-scope="scope">
                      <el-button
                        type="text"
                        @click="viewRequireRevise(scope.row.id)"
                        >{{ $t('查看') }}</el-button
                      >
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="revisedList-paging clearfix">
                <el-pagination
                  v-show="revisedList && revisedList.length != 0"
                  class="flex-right"
                  style="margin-top: 9px"
                  :current-page="revisedPageInfo.pageNumber"
                  :page-sizes="[10, 20, 30]"
                  :page-size="revisedPageInfo.pageSize"
                  layout="total, sizes, prev, pager, next, jumper"
                  :total="revisedPageInfo.totalRecords"
                  @size-change="handleRevisedPageSizeChange"
                  @current-change="handleRevisedPageNumChange"
                ></el-pagination>
              </div>
            </div>
            <el-dialog
              :title="$t('修订详情')"
              :visible.sync="revisedDialogVisible"
              width="1200"
              class="issuedialog"
              :modal-append-to-body="false"
            >
              <div
                class="diff-box"
                :data-empty-text="$t('暂无数据')"
                v-html="diffDetail"
              ></div>
            </el-dialog>
          </el-tab-pane>
        </el-tabs>
      </template>
    </BaseDisplay>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
import BaseDisplay from './BaseDisplay'
import BaseDisplayAssoc from './BaseDisplayAssoc'
import TimeLine from '@/components/time-line'
import CommentList from '@/components/comment-list'
import CodeCommit from '@/components/code-commit/indexNewTable'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import WorkItemDispayMixin from './WorkItemDispayMixin'
import { reviseDetail } from '@/service/requirement'

export default {
  name: 'TaskDetail',
  components: {
    BaseDisplay,
    TimeLine,
    CommentList,
    CodeCommit,
    BaseDisplayAssoc,
  },

  mixins: [WorkItemTemplateMixin, ProjectCommonMixin, WorkItemDispayMixin],
  // props 正常只需要传这些数据，特殊使用时，比如转需求、缺陷，则通过 this.$attrs 读取
  props: {
    workItemId: {
      type: [String, Number],
      required: false,
    },

    projectId: {
      type: [String, Number],
      required: false,
      desc: '因为在获取详情的时候，就必须要传 projectId',
    },

    show: {
      type: Boolean,
      required: true,
      desc: '右侧弹窗是否展开，用于更新 url id',
    },
  },

  events: ['HandleSide', 'updateInfoSuccess'],
  data() {
    return {
      workItemType: 2, // 工作项类型
      activeTagName: 'comment', // 当前活跃 tab
      baseConfig: {
        title: i18n.t('任务详情'),
      },
      diffDetail: '',
    }
  },
  computed: {},
  watch: {
    workItemId: function(newInfo, oldInfo) {
      if (newInfo !== oldInfo && this.show) {
        this.initData()
      }
    },
    show() {
      if (this.show) {
        this.initData()
      }
    },
  },

  created() {},
  mounted() {
    this.initData()
  },
  methods: {
    initData() {
      this.resetData()
      if (!this.validWorkItemId()) {
        return
      }
      this.activeTagName = 'comment'
      this.getDetailInfo()
      this.urlAddWorkItemId()
    },
    // tab栏切换
    getFooterDetail({ name } = {}) {
      name && this.countlyLog(`project_taskDetail_workItem_${name}`)
      this.tabRelateditem()
      switch (this.activeTagName) {
        case 'operate':
          this.getBugOperateRecordList()
          break
        case 'changeList':
          this.getRevisedList()
          break
      }
    },
    // 修订列表 - 查看修订记录
    viewRequireRevise(reviseId) {
      reviseDetail(reviseId).then(res => {
        if (res.status == 200 && res.data) {
          this.diffDetail = res.data.content
          this.revisedDialogVisible = true
        }
      })
    },
    // 缓存处理透传
    setUserInputCache() {
      // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
      this.$refs.baseDisplay?.setUserInputCache()
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/work-diff/index.scss';
</style>
