<template>
  <el-dialog
    :visible.sync="modalStatu"
    width="1000px"
    class="AssocWorkItem"
    :title="dialogTitle"
    :modal-append-to-body="false"
  >
    <div v-if="projectId" class="form-iterm-box">
      <el-form :inline="true">
        <!-- 需求不需要类型 -->
        <el-form-item v-if="+workItemType !== 1" :label="$t('类型') + ':'">
          <el-select
            v-model="currentType"
            :placeholder="$t('选择类型')"
            :popper-append-to-body="true"
            class="header-input"
            @change="assocInputGetFocus"
          >
            <el-option
              v-for="item in filterTypeList"
              :key="item.key"
              :label="item.value"
              :value="item.key"
            ></el-option>
          </el-select>
        </el-form-item>
        <!-- 任务不需要项目 -->
        <el-form-item v-if="+workItemType !== 2" :label="$t('项目') + ':'">
          <el-select
            v-model="searchInfo.projectId"
            :placeholder="$t('选择项目')"
            :popper-append-to-body="true"
            class="header-input"
            @change="assocInputGetFocus"
          >
            <el-option
              v-for="item in projectList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('标题') + ':'" class="header-input">
          <el-input
            ref="bugAssocInput"
            v-model="searchInfo.title"
            v-focus
            :placeholder="$t('支持标题或ID搜索')"
          ></el-input>
        </el-form-item>
        <el-form-item>
          <el-button
            @click="
              searchAssocRequrie({
                pageSize: DEFAULT_PAGE_SIZE,
                pageNumber: DEFAULT_PAGE_NUMBER,
              })
            "
            >{{ $t('查询') }}</el-button
          >
        </el-form-item>
      </el-form>
      <div class="table-box-top">
        <el-table
          ref="assocRequireTableRef"
          v-loading="loading"
          :element-loading-text="$t('拼命加载中')"
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgb(255,255,255)"
          :data="assocRequireDataList"
          border
          style="width: 100%; height: 100%; margin-top: 20px"
        >
          <el-table-column
            type="selection"
            width="50"
            :selectable="selectable"
            disabled
          ></el-table-column>
          <el-table-column
            :label="firstLabel"
            show-overflow-tooltip
            :width="$isEnglish() ? 130 : 90"
            prop="id"
          >
            <template slot-scope="scope">
              <span>{{ scope.row.id }}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="display.title"
            show-overflow-tooltip
            :label="secondLabel"
            min-width="180"
          >
            <template slot-scope="scope">
              <span>{{ scope.row.display.title }}</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="display.projectName"
            show-overflow-tooltip
            :label="$t('所属项目')"
            min-width="150"
          ></el-table-column>
          <el-table-column
            prop="display.assignUser"
            :label="$t('处理人')"
            min-width="60"
          >
          </el-table-column>
          <el-table-column
            prop="display.status"
            :label="$t('状态')"
            width="80"
          ></el-table-column>
        </el-table>
      </div>
      <div class="table_b_f_b">
        <el-pagination
          v-show="assocRequireDataList && assocRequireDataList.length > 0"
          class="flex-right"
          style="margin-top: 9px"
          :current-page="searchInfo.pageInfo.pageNumber"
          :page-sizes="[10, 20, 30]"
          :page-size="searchInfo.pageInfo.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="searchInfo.pageInfo.totalRecords"
          @size-change="handleAssocRequirePageSizeChange"
          @current-change="handleAssocRequirePageNumChange"
        ></el-pagination>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <co-button @click="cancel">取 消</co-button>
      <el-button type="primary" @click="handleSureAssocRequrie()">{{
        $t('关联')
      }}</el-button>
    </span>
  </el-dialog>
</template>

<script>
import { i18n } from '@/i18n'
/**
 * @title 关联工作项
 * @desc copy from bugDetail，有改动，支持6种工作项
 * @author heyunjiang
 * @date 2020.7.2
 */
const DEFAULT_PAGE_NUMBER = 1
const DEFAULT_PAGE_SIZE = 10
import { projectList } from '@/service/project'
import { listAssocRequire } from '@/service/requirement'
import { mineTask } from '@/service/mine'
import { bugList } from '@/service/bug'
export default {
  name: 'AssocWorkItem',
  props: {
    // 项目 id
    projectId: {
      type: [Number, String],
    },

    // 工作项 id
    workItemId: {
      type: [Number, String],
      desc: '可选，用于判断可选列表是否包含当前工作项',
    },

    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型',
    },

    // 已经选中的关联工作项
    assocObject: {
      type: [Object, String],
    },

    isShow: {
      type: Boolean,
      required: true,
    },

    // 关联成功回调，返回已经关联好的数据类型及关联选好的id列表
    successCallback: {
      type: Function,
    },

    // 关闭模态框
    onClose: {
      type: Function,
    },
  },

  data() {
    return {
      DEFAULT_PAGE_NUMBER,
      DEFAULT_PAGE_SIZE,
      modalStatu: false,
      loading: false,
      searchInfo: {
        projectId: this.$getUrlParams().projectId,
        title: null,
        isArchived: -1,
        pageInfo: {
          pageNumber: DEFAULT_PAGE_NUMBER,
          pageSize: DEFAULT_PAGE_SIZE,
          totalRecords: 0,
          totalPages: 0,
        },
      },

      // 搜索信息
      projectList: [],
      assocRequireDataList: [],
      assocObjectIdData: [],
      delWorkItemIds: [], //删除的工作项id
      currentType: '', // 当前查询类型
      typeName: {
        requirement: i18n.t('需求'),
        task: i18n.t('任务'),
        bug: i18n.t('缺陷'),
      },
      firstLabel: '',
      secondLabel: '',
    }
  },
  computed: {
    // firstLabel() {
    //   return this.typeName[this.currentType] + 'ID'
    // },
    // secondLabel() {
    //   return this.typeName[this.currentType] + i18n.t('标题')
    // },
    // 过滤器可选类型列表
    filterTypeList() {
      const defalutList = [
        { key: 'task', value: i18n.t('任务') },
        { key: 'bug', value: i18n.t('缺陷') },
      ]

      return this.workItemType !== 2
        ? [{ key: 'requirement', value: i18n.t('需求') }, ...defalutList]
        : defalutList
    },
    // dialog 标题
    dialogTitle() {
      const titleMap = {
        1: i18n.t('关联需求'),
        2: i18n.t('关联任务与缺陷'),
        3: i18n.t('关联工作项'),
      }

      return titleMap[this.workItemType]
    },
  },

  watch: {
    projectId: {
      handler(newVal) {
        if (newVal) {
          this.searchInfo.projectId = +this.projectId
        }
      },
      immediate: true,
    },

    // modalStatu 不能用作计算属性，因为计算属性的值通常会和常规双向绑定数据起冲突，双向绑定数据最多只能应用到监听数据上
    isShow() {
      // this.searchAssocRequrie(); // 何运江注释掉， on 2019.5.23 ，获取具体列表时机不对
      this.modalStatu = this.isShow
      if (!this.isShow) {
        this.resetData()
        this.onClose && this.onClose()
      } else {
        // 初始化获取项目列表数据
        this.getProjectList()
        // 获取input焦点
        this.assocInputGetFocus()
      }
    },
    modalStatu() {
      if (!this.modalStatu) {
        this.resetData()
        this.onClose && this.onClose()
      }
    },
  },

  mounted() {
    // this.searchAssocRequrie();
    this.currentType = this.filterTypeList[0].key
  },
  methods: {
    //获取input焦点
    assocInputGetFocus() {
      this.$nextTick(() => {
        const bugAssocInput = this.$refs.bugAssocInput
        bugAssocInput && bugAssocInput.$refs.input.focus()
      })
    },
    // 获取项目列表
    getProjectList() {
      this.loading = true
      projectList()
        .then(result => {
          this.loading = false
          if (result.status === 200) {
            this.projectList = result.data
            this.searchInfo.projectId = +this.projectId || result.data[0].id
          } else {
            this.projectList = []
          }
          // 查询关联工作项数据 依赖 获取项目列表接口
          this.searchAssocRequrie()
        })
        .catch(e => {
          this.loading = false
          console.log(e)
        })
    },
    // 重置数据
    resetData() {
      this.searchInfo.pageInfo.pageNumber = 1
      this.searchInfo.title = ''
      this.assocRequireDataList = []
    },
    // 查询具体数据
    async searchAssocRequrie({
      pageNumber = DEFAULT_PAGE_NUMBER,
      pageSize,
    } = {}) {
      let func
      switch (this.currentType) {
        case 'requirement':
          func = listAssocRequire
          break
        case 'task':
          func = mineTask
          break
        case 'bug':
          func = bugList
          break
      }

      const { pageInfo } = this.searchInfo
      this.$nextTick(function() {
        this.loading = true
        func({
          ...this.searchInfo,
          pageInfo: {
            ...pageInfo,
            pageSize: pageSize != null ? pageSize : pageInfo.pageSize,
            pageNumber,
          },
        })
          .then(result => {
            this.loading = false
            if (result.status === 200) {
              // 修改table第二、三列标题
              this.firstLabel = this.typeName[this.currentType] + 'ID'
              this.secondLabel =
                this.typeName[this.currentType] + i18n.t('标题')
              this.assocRequireDataList = result.data.result
              this.$nextTick(() => {
                // 保持
                let assocObjectparentrequirements = [
                  ...this.assocObject.requirements,
                  ...this.assocObject.tasks,
                  ...this.assocObject.defects,
                ]

                if (assocObjectparentrequirements.length > 0) {
                  this.assocObjectTableData(
                    assocObjectparentrequirements,
                    this.assocRequireDataList,
                  )
                }
              })
              this.searchInfo.pageInfo = result.data.pageInfo
              this.assocInputGetFocus()
            } else {
              this.assocRequireDataList = []
            }
          })
          .catch(_ => _)
      })
    },
    // 如果是工作项本身，则不可选择
    selectable(row) {
      if (row.id === this.workItemId) {
        return 0
      } else {
        return 1
      }
    },
    // 设置表格选中
    assocObjectTableData(assocObjectData, TableData) {
      this.assocObjectIdData = []
      assocObjectData.forEach(item => {
        TableData.forEach((tableItem, index) => {
          if (item.id === tableItem.id) {
            this.assocObjectIdData.push(tableItem.id)
            this.$refs.assocRequireTableRef.toggleRowSelection(
              TableData[index],
              true,
            ) //添加关联
          }
        })
      })
    },
    // 分页 - 第几页
    handleAssocRequirePageNumChange(pageNumber) {
      // 保存数据
      this.searchAssocRequrie({ pageNumber })
    },
    // 分页 - 每页条数
    handleAssocRequirePageSizeChange(pageSize) {
      // 保存数据
      this.searchAssocRequrie({ pageSize })
    },
    // 获取当前选中数据
    getSelectedItems() {
      let assocRequriements = [] // 对象集合
      let assocRequrieIdData = [] // id 集合
      this.delWorkItemIds = [] // 已删除 id 集合
      this.$refs['assocRequireTableRef'].selection.forEach(item => {
        assocRequriements.push(item)
        assocRequrieIdData.push(item.id)
      })
      // 当前表格已经选中数据 - 只存在于当前页，不表示所有初始数据
      this.assocObjectIdData.forEach(item => {
        if (!assocRequrieIdData.includes(item)) {
          this.delWorkItemIds.push(item)
        }
      })
      return assocRequriements
    },
    cancel() {
      this.modalStatu = false
    },
    // 点击关联
    handleSureAssocRequrie() {
      if (this.getSelectedItems().length == 0) {
        this.$message({
          message: i18n.t('请选择关联的工作项'),
          type: 'warning',
        })

        return
      }
      this.successCallback &&
        this.successCallback(
          this.currentType,
          this.getSelectedItems(),
          this.delWorkItemIds,
        )
    },
  },
}
</script>

<style lang="scss" scoped>
.header-input {
  max-width: 100%;
  margin-bottom: 0;
}
</style>
