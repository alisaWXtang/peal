<template>
  <div class="detail-content-left-assoc">
    <!-- 关联工作项 -->
    <div class="bug-assoc-header">
      <el-button
        v-show="$authFunction('FUNC_COOP_WORKITEM_ASSOC', 0)"
        type="text fl"
        @click="modalStatusChange"
        >+ {{ $t('添加关联') }}</el-button
      >
      <span class="title-common ml5 fr">
        <span
          >{{ $t('需求') }}({{
            relatedWorkItemCount.requirementCount || 0
          }})</span
        >
        <span v-if="workItemType !== 1"
          >{{ $t('任务') }}({{ relatedWorkItemCount.taskCount || 0 }})</span
        >
        <span
          >{{ $t('缺陷') }}({{ relatedWorkItemCount.defectCount || 0 }})</span
        >
      </span>
    </div>
    <div v-if="assocObjectShowList.length" class="bug-assoc-body">
      <div
        v-for="item in assocObjectShowList"
        :key="`${item._text}-${item.info.id}`"
        class="bug-assoc-item"
      >
        <span
          class="bug-assoc-item-text"
          @click.stop="assocItemClick(item.info, item._type)"
        >
          <i class="iconfont" :class="item._icon" />
          {{ item.info.id }}-{{ $t(item._text) }}-{{ item.info.display.title }}
        </span>
        <span class="bug-assoc-item-assiguser">{{
          item.info.display.assignUser
        }}</span>
        <span class="bug-assoc-item-status">{{
          item.info.display.status
        }}</span>
        <span
          v-if="item._text !== '父需求'"
          class="bug-assoc-item-delete"
          @click.stop="assocItemDelete(item.info, item._type)"
        >
          <i class="el-icon-delete"></i>
        </span>
      </div>
    </div>

    <!-- 关联工作项 -->
    <assoc-work-item
      v-if="getProjectId()"
      :key="getProjectId()"
      :project-id="getProjectId()"
      :work-item-type="workItemType"
      :is-show="assocObject.modalStatu"
      :on-close="assocCloseCallback"
      :work-item-id="workItemId"
      :assoc-object="assocObject"
      :success-callback="assocSuccessCallback"
    ></assoc-work-item>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 基础详情 - 关联工作项
 * @desc 支持新建、详情查看2种模式
 * @author heyunjiang
 * @date 2020.7.2
 */
import debounce from 'lodash/debounce'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import AssocWorkItem from './AssocWorkItem'
import { assocRequireService } from '@/service/requirement'

export default {
  name: 'BaseDisplayAssoc',
  components: {
    AssocWorkItem,
  },

  mixins: [ProjectCommonMixin],
  props: {
    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型',
    },

    detailInfo: {
      type: Object,
      required: false,
      desc: '工作项详情',
    },

    projectId: {
      type: [String, Number],
      required: false,
    },
  },

  data() {
    return {
      // 已经关联工作项
      assocObject: {
        parentrequirements: [],
        requirements: [],
        tasks: [],
        defects: [],
        modalStatu: false, // 模态框打开情况
      },
      // 已关联工作项统计count
      relatedWorkItemCount: {},
      localProjectId: this.$getUrlParams().projectId,
    }
  },
  computed: {
    workItemId() {
      return this.detailInfo?.detail.id
    },
    // 如果传入详情，则表示是详情模式
    isDisplay() {
      return !!this.detailInfo
    },
    assocObjectShowList() {
      const result = []
      this.assocObject.parentrequirements.forEach(parentrequirement => {
        result.push({
          _type: 'requirement',
          _text: '父需求',
          _icon: 'icon-xuqiu',
          info: parentrequirement,
        })
      })
      this.assocObject.requirements.forEach(requirement => {
        result.push({
          _type: 'requirement',
          _text: '需求',
          _icon: 'icon-xuqiu',
          info: requirement,
        })
      })
      this.assocObject.tasks.forEach(task => {
        result.push({
          _type: 'task',
          _text: '任务',
          _icon: 'icon-renwu',
          info: task,
        })
      })
      this.assocObject.defects.forEach(defect => {
        result.push({
          _type: 'defect',
          _text: '缺陷',
          _icon: 'icon-quexian',
          info: defect,
        })
      })
      return result
    },
  },

  watch: {
    detailInfo() {
      this.getAssocList()
    },
  },

  created() {},
  mounted() {
    this.getAssocList()
  },
  methods: {
    setRelatedWorkItemCount({ requirementCount, taskCount, defectCount }) {
      this.relatedWorkItemCount = { requirementCount, taskCount, defectCount }
    },
    // 读取 projectId 统一入口
    getProjectId() {
      return (
        this.projectId ||
        this.detailInfo?.rawData?.projectId ||
        this.localProjectId
      )
    },
    // http 错误统一处理
    httpErrorHandle(param) {
      this.$message({ message: param, type: 'error' })
    },
    // 关联工作项-获取已经关联的列表
    getAssocList: debounce(async function() {
      if (this.workItemId < 0 || !this.isDisplay) {
        return
      }
      this.assocItemGetHandle({
        workItemType: this.workItemType,
        workItemId: this.workItemId,
        projectId: this.getProjectId(),
      }).then(result => {
        if (result.status === 200 && result.data !== null) {
          this.assocObject.parentrequirements = result.data.parent
            ? [{ ...result.data.parent }]
            : []
          this.assocObject.requirements = result.data.requirements || []
          this.assocObject.tasks = result.data.tasks || []
          this.assocObject.defects = result.data.defects || []
          this.setRelatedWorkItemCount(result.data)
        } else {
          this.assocObject.parentrequirements = []
          this.assocObject.requirements = []
          this.assocObject.tasks = []
          this.assocObject.defects = []
          this.httpErrorHandle(result.msg)
        }
      })
    }, 300),
    // 关联工作项-点击删除
    assocItemDelete(info, type) {
      this.$confirm(i18n.t('确认删除该关联?'), i18n.t('提示'), {
        confirmButtonText: i18n.t('确定'),
        cancelButtonText: i18n.t('取消'),
        type: 'warning',
      })
        .then(() => {
          let targetWorkItemType = '1'
          switch (type) {
            case 'requirement':
              targetWorkItemType = '1'
              break
            case 'task':
              targetWorkItemType = '2'
              break
            case 'defect':
              targetWorkItemType = '3'
              break
          }

          if (!this.isDisplay) {
            this.assocObject[type + 's'] = this.assocObject[type + 's'].filter(
              item => item.id !== info.id,
            )
            this.$emit('updateInfoSuccess', this.assocObject)
            return
          }
          this.assocItemDeleteHandle({
            targetId: info.id,
            targetType: +targetWorkItemType,
            originId: this.workItemId,
            originType: this.workItemType,
            projectId: this.getProjectId(),
          }).then(result => {
            if (result.status === 200) {
              this.$message({
                message: i18n.t('关联项删除成功'),
                type: 'success',
              })

              this.getAssocList()
              this.$emit('updateInfoSuccess')
            }
          })
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: i18n.t('已取消删除'),
          })
        })
    },
    // 关联工作项-模态框打开
    modalStatusChange() {
      this.assocObject.modalStatu = true
    },
    // 关联工作项-模态框关闭
    assocCloseCallback() {
      this.assocObject.modalStatu = false
    },
    // 关联工作项-模态框点击关联回调
    assocSuccessCallback(key, result, delWorkItemIds) {
      this.assocObject.modalStatu = false
      let assocObjectKey = 'requirements',
        targetWorkItemType = 1
      switch (key) {
        case 'requirement':
          assocObjectKey = 'requirements'
          targetWorkItemType = 1
          break
        case 'task':
          assocObjectKey = 'tasks'
          targetWorkItemType = 2
          break
        case 'bug':
          assocObjectKey = 'defects'
          targetWorkItemType = 3
          break
      }

      let containsRepitDataArray = [
        ...this.assocObject[assocObjectKey],
        ...result,
      ]

      let containsRepitDataArrayIds = [
        ...new Set(containsRepitDataArray.map(item => item.id)),
      ]

      let data = containsRepitDataArrayIds.map(item => {
        return containsRepitDataArray.filter(jtem => jtem.id === item)[0]
      })
      this.assocObject[assocObjectKey] = data.filter(
        item => !delWorkItemIds.includes(item.id),
      ) // 手动设置当前关联工作项

      if (!this.isDisplay) {
        this.$emit('updateInfoSuccess', this.assocObject)
        return
      }
      // 更新服务器保存的实际数据
      assocRequireService({
        origWorkItemType: this.workItemType,
        origWorkItemId: this.workItemId,
        targetWorkItemType,
        targetWorkItemIds: result.map(item => item.id),
        projectId: this.getProjectId(),
        delWorkItemIds,
      }).then(result => {
        if (result.status === 200) {
          this.$message({
            message: result.msg || i18n.t('添加关联工作项成功'),
            type: 'success',
          })

          this.getAssocList(this.detailInfo)
          this.$emit('updateInfoSuccess')
        }
      })
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/project/ProjectCommon.scss';
.bug-assoc-header {
  .title-common {
    color: $--color-text-regular;
    font-weight: normal;
  }
}
</style>
