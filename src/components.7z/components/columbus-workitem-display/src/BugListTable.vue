<template>
  <div>
    <el-table :data="tableData" :border="true" style="width: 100%">
      <el-table-column prop="id" label="ID" width="80px">
        <template slot-scope="scope">
          <span class="c-blue-hover cp" @click="toBugDetailPage(scope.row)">{{
            scope.row.id
          }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="display.title"
        :label="$t('标题')"
        min-width="180px"
      >
        <template slot-scope="scope">
          <global-input
            :init-value="scope.row.display.title"
            :on-change="
              value => {
                GlobalBugUpdate({
                  title: value,
                  id: scope.row.id,
                  projectId: scope.row.projectId,
                  cb: getBugList,
                })
              }
            "
          >
            <el-link
              slot
              type="primary"
              :underline="false"
              class="table-input-edit-text"
              @click="toBugDetailPage(scope.row)"
            >
              <el-tooltip
                v-if="
                  scope.row && scope.row.display && scope.row.display.delayed
                "
                class="item"
                effect="dark"
                :content="$t('已过期')"
                placement="top-start"
              >
                <i class="el-icon-warning warning" />
              </el-tooltip>
              {{ scope.row.display.title }}
            </el-link>
          </global-input>
        </template>
      </el-table-column>
      <el-table-column prop="display.priority" :label="$t('严重程度')">
        <template slot-scope="scope">
          <work-item-table-custom-column
            :scope="scope"
            :field="priorityItem"
            @selectClick="
              e =>
                GlobalSelectTargetClick(
                  { ...scope.row, workItemType: 3 },
                  e,
                  priorityItem.attrName,
                  getBugList,
                  priorityItem,
                )
            "
          />
        </template>
      </el-table-column>
      <el-table-column prop="display.sprint" :label="$t('迭代')">
        <template slot-scope="scope">
          <span
            class="cursor-pointer"
            @click.stop="
              e =>
                GlobalSelectTargetClick(
                  { ...scope.row, workItemType: 3 },
                  e,
                  'sprintId',
                  getBugList,
                )
            "
            >{{ scope.row.display.sprint || '--' }}</span
          >
        </template>
      </el-table-column>
      <el-table-column prop="display.status" :label="$t('状态')">
        <template slot-scope="scope">
          <StateFlow
            :project-id="projectId"
            :status-id="scope.row.statusId"
            :work-item-type="3"
            :work-item-id="scope.row.id"
            :parent-info="scope.row"
            :update-data="getBugList"
          >
            <work-item-table-custom-column
              :scope="scope"
              :field="statusItem"
              @selectClick="
                e =>
                  GlobalSelectTargetClick(
                    { ...scope.row, workItemType: 3 },
                    e,
                    statusItem.attrName,
                    getBugList,
                    statusItem,
                  )
              "
            />
          </StateFlow>
        </template>
      </el-table-column>
      <el-table-column prop="display.assignUser" :label="$t('处理人')">
        <template slot-scope="scope">
          <span
            class="cursor-pointer"
            @click="
              e =>
                GlobalSelectTargetClick(
                  { ...scope.row, workItemType: 3 },
                  e,
                  'assignUser',
                  getBugList,
                )
            "
            >{{ scope.row.display.assignUser }}</span
          >
        </template>
      </el-table-column>
      <el-table-column prop="display.createUser" :label="$t('提出人')" />
    </el-table>
    <el-pagination
      class="page-wrap mt10"
      :current-page.sync="pageInfo.currentPage"
      :page-size="10"
      layout="total, prev, pager, next, jumper"
      :total="pageInfo.total"
      @current-change="handleCurrentChange"
    />
    <GlobalSelect v-bind="GlobalSelectProps" />
  </div>
</template>

<script>
import WorkItemTableCustomColumn from '@/components/project/WorkItemTableCustomColumn'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import GlobalSelect from '@/components/field-edit/GlobalSelect'
import GlobalInput from '@/components/field-edit/GlobalInput'
import StateFlow from '@/components/state-flow'
import { getBugListAPI } from '@/service/requirement'

export default {
  name: 'BugListTable',
  components: {
    WorkItemTableCustomColumn,
    GlobalSelect,
    GlobalInput,
    StateFlow,
  },
  mixins: [ProjectCommonMixin],
  props: {
    requireId: {
      type: [Number, String],
      default: undefined,
    },
    projectId: {
      type: [Number, String],
      default: undefined,
    },
  },
  data() {
    return {
      pageInfo: {
        currentPage: 1,
        total: 0,
      },
      tableData: [],
      priorityItem: {
        attrName: 'priority',
        attrValue: 'SINGLE_CHOICE',
      },
      statusItem: {
        attrName: 'statusId',
        attrValue: 'SINGLE_CHOICE',
      },
    }
  },
  mounted() {
    this.getBugList()
  },
  methods: {
    async getBugList() {
      const res = await getBugListAPI({
        project: this.projectId,
        id: this.requireId,
        pageSize: 10,
        pageNum: this.pageInfo.currentPage,
      })
      if (res.status === 200) {
        this.pageInfo.total = res.data.total
        this.tableData = res.data.list
      }
    },
    handleCurrentChange(val) {
      this.pageInfo.currentPage = val
      this.getBugList()
    },
    // 点击 id, 标题跳转
    toBugDetailPage(row) {
      this.$goToNewWindowPage('/bug/list', {
        bugId: row.id,
        projectId: row.projectId,
      })
    },
  },
}
</script>

<style lang="scss" scoped>
.page-wrap {
  text-align: right;
}

/deep/ .table-input-edit-box .table-input-edit-text {
  width: calc(100% - 20px);
}
</style>
