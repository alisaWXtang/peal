// 全局 vue 插件不可挂载
import TaskDetail from './src/TaskDetail.vue'
import RequirementDetail from './src/RequirementDetail'
import BugDetail from './src/BugDetail'

TaskDetail.install = Vue => Vue.component(TaskDetail.name, TaskDetail)
RequirementDetail.install = Vue =>
  Vue.component(RequirementDetail.name, RequirementDetail)
BugDetail.install = Vue => Vue.component(BugDetail.name, BugDetail)

export { TaskDetail, RequirementDetail, BugDetail }
