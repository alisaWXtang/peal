<template>
  <div
    v-loading="loading"
    class="detail-content bug-content-box"
    :element-loading-text="$t('拼命加载中')"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)"
  >
    <div class="slide-header">
      <span class="taskinfo-title">{{ baseConfig.title }}</span>
      <div class="slide-header-right">
        <!-- 用户引导 -->
        <FunctionGuideTips
          v-if="!updateRequireTipsShown"
          ref="guideTips"
          storage-visible-key="task_bug_tips"
          tips="这里可切换工作项模板，不同模板可设置不同的显示字段和标题/描述模板。"
          placement="left"
        >
          <div style="height: 46px; width: 1px"></div>
        </FunctionGuideTips>
        <!-- 工作项模板 dropdown -->
        <co-dropdown class="template-select" @command="templateChangeHandle">
          <span class="co-dropdown-link"
            >{{ selectedTemplateName
            }}<i class="el-icon-arrow-down el-icon--right"></i
          ></span>
          <co-dropdown-menu
            slot="dropdown"
            class="template-select__menu"
            style="max-height: 50vh; overflow-y: auto"
          >
            <co-dropdown-item
              v-for="item in templateList"
              :key="item.id"
              :command="item.id"
              :class="{
                'el-dropdown-menu-active': item.id === selectedTemplateId,
              }"
              style="min-width: 100px"
              >{{ item.name }}</co-dropdown-item
            >
            <co-dropdown-item
              command="setting"
              style="min-width: 100px"
              :title="
                !$authFunction(
                  'FUNC_COOP_WORKITEM_TMPL_UPDATE',
                  workItemType,
                  currentProjectId,
                )
                  ? $t('暂无权限设置，请联系管理员')
                  : ''
              "
            >
              <span
                :class="{
                  disabled: !$authFunction(
                    'FUNC_COOP_WORKITEM_TMPL_UPDATE',
                    workItemType,
                    currentProjectId,
                  ),
                }"
                ><i class="el-icon-setting"></i>{{ $t('设置') }}</span
              ></co-dropdown-item
            >
          </co-dropdown-menu>
        </co-dropdown>
        <!-- 保存、关闭 -->
        <el-button ref="saveBtn" type="primary" @click="drawerSaveClick">
          {{ $t('保存') }}
        </el-button>
        <el-button type="default" @click="drawerClose">
          {{ $t('取消') }}
        </el-button>
      </div>
    </div>
    <co-row :gutter="10" class="detail-content-body">
      <co-col
        :xs="16"
        :sm="16"
        :md="16"
        :lg="16"
        :xl="18"
        class="detail-col-left"
      >
        <div class="detail-content-left">
          <!-- 标题 -->
          <div
            class="detail-content-header detail-content-header-inactive"
            style="padding-left: 0"
          >
            <co-input
              ref="titleInput"
              v-model="detailInfo.title"
              v-focus
              class="title-input-active"
              :placeholder="$t('输入标题,回车新建')"
              size="large"
              @input="titleInput"
              @keyup.enter.native="drawerSaveClick"
            ></co-input>
            <div
              v-if="detailInfo.title && detailInfo.title.length > 127"
              class="warning warning-title"
            >
              {{ $t('标题不能超过') }}127{{ $t('个字符') }}！
            </div>
          </div>
          <div ref="desc" class="detail-content-left-content" refs="bshaow">
            <UserInputRestoreTips
              ref="userInputTips"
              :project-id="currentProjectId"
              :item-type="itemType"
              action-type="create"
              @restore="restoreContent"
            ></UserInputRestoreTips>
            <!-- 缺陷描述 -->
            <tiny-mce
              :value="detailInfo.content"
              @edit="userEdit"
              @watch="editHandle($event)"
              @save="drawerSaveClick"
            ></tiny-mce>
          </div>
          <div class="detail-content-footer">
            <slot name="footer"></slot>
            <BaseDisplayAssoc
              v-if="associalable && currentProjectId"
              :work-item-type="workItemType"
              :project-id="currentProjectId"
              @updateInfoSuccess="assocUpdate"
            />
          </div>
        </div>
      </co-col>
      <co-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6" class="detail-col-right">
        <div class="detail-content-right">
          <!-- 基本信息 -->
          <div class="bug-basic-info">
            <p class="bug-basic-info-title">
              {{ $t('基本信息')
              }}<span
                :title="
                  !$authFunction(
                    'FUNC_COOP_WORKITEM_TMPL_UPDATE',
                    workItemType,
                    currentProjectId,
                  )
                    ? $t('暂无权限设置，请联系管理员')
                    : $t('工作项模板设置')
                "
                class="cursor-pointer detail-title-edit"
                :class="{
                  'cursor-disabled': !$authFunction(
                    'FUNC_COOP_WORKITEM_TMPL_UPDATE',
                    workItemType,
                    currentProjectId,
                  ),
                }"
              >
                <i
                  class="el-icon-setting"
                  style="position: relative; top: 1px;"
                  :class="{
                    disabled: !$authFunction(
                      'FUNC_COOP_WORKITEM_TMPL_UPDATE',
                      workItemType,
                      currentProjectId,
                    ),
                  }"
                  @click="jumpToTemplateSetting(currentProjectId)"
                ></i
              ></span>
            </p>
            <work-item-basic-info-create
              v-if="currentProjectId"
              ref="WorkItemBasicInfoCreate"
              v-model="workItemCreateBasicFormObject"
              :project-id="currentProjectId"
              :work-item-type="workItemType"
              :current-category-id="currentCategoryId"
              :work-item-create-basic-template-array="
                workItemCreateBasicTemplateArray
              "
              @handleProjectChange="handleProjectChange"
            ></work-item-basic-info-create>
          </div>
          <!-- 附件上传部分-->
          <div class="bug-attachment">
            <p class="bug-attachment-title">
              {{ $t('附件') }}
              <!--              <span-->
              <!--                class="bug-attachment-title-btn"-->
              <!--                @click="fileUpdaloadBoxStatusHandle"-->
              <!--                >{{-->
              <!--                  fileUpdaloadBoxStatus ? $t('收起上传') : $t('展开上传')-->
              <!--                }}</span-->
              <!--              >-->
            </p>
            <file-upload
              is-create
              :file-updaload-box-status="fileUpdaloadBoxStatus"
              :uploaded-file-list="uploadedFileList"
              :upload-url="uploadUrl"
              :extra-data="extraData"
              :handle-file-delete="handleFileDelete"
              :detail-info-id="0"
              :handle-upload-success="handleUploadSuccess"
              :work-item-type="workItemType"
              :project-id="currentProjectId"
            ></file-upload>
          </div>
        </div>
      </co-col>
    </co-row>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 哥伦布 - 工作项创建基础组件
 * @desc 所有工作项新建，都需要引用这个组件作为基础
 * @author heyunjiang
 * @date 2020.6.11
 */
import {
  Input,
  Dropdown,
  DropdownMenu,
  DropdownItem,
  ButtonGroup,
  Button,
  Row,
  Col,
} from '@heytap/cook-ui'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import WorkItemTemplateMixin from '@/mixin/WorkItemTemplateMixin'
// import ExpectHour from '@/components/expect-hour'
import FileUpload from '@/components/file-upload'
import UserInputRestoreTips from '@/components/user-input-restore-tips'
import { setCreateItemUserInputCache } from '@/utils/help'
import FunctionGuideTips from '@/components/biz/function-guide-tips'
import BaseDisplayAssoc from '@/components/columbus-workitem-display/src/BaseDisplayAssoc'
import { WORKITEMCONST } from '@/utils/constant'
import { list } from '@/service/attachment'
import { guide } from '@/store/mutation-types'
import { guideType, guideStep } from '@/components/guide/guideData'

const TinyMce = () => import('@/components/tinymce')

// 工作项默认初始信息
const resetInit = {
  title: '', // 标题
  content: '', // 内容
}
export default {
  name: 'BaseCreate',
  components: {
    [Input.name]: Input,
    [Dropdown.name]: Dropdown,
    [DropdownMenu.name]: DropdownMenu,
    [DropdownItem.name]: DropdownItem,
    [ButtonGroup.name]: ButtonGroup,
    [Button.name]: Button,
    [Row.name]: Row,
    [Col.name]: Col,
    TinyMce,
    // ExpectHour,
    FileUpload,
    UserInputRestoreTips,
    FunctionGuideTips,
    BaseDisplayAssoc,
  },

  mixins: [ProjectCommonMixin, WorkItemTemplateMixin],
  props: {
    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型',
    },

    associalable: {
      type: Boolean,
      required: false,
      desc: '是否支持关联工作项',
    },

    // 特殊处理1: 需求保持分类选中
    currentCategoryId: {
      type: [String, Number],
      desc: '在创建需求时有用',
    },

    // 特殊处理2: 工作项互转
    otherDetailContent: {
      type: String,
      desc: '转工作项 - 内容',
    },

    otherDetailTitle: {
      type: String,
      desc: '转工作项 - 标题',
    },

    fromOtherDetailType: {
      type: String,
      desc: '转工作项 - 原工作项类型',
    },

    fromOtherDetailId: {
      type: [String, Number],
      desc: '转工作项 - 原工作项id',
    },

    baseConfig: {
      type: Object,
      required: false,
      desc: '常量配置',
      default: () => {
        return {
          title: i18n.t('新建工作项'),
          saveBtnText: i18n.t('保存'),
        }
      },
    },
  },

  data() {
    return {
      isLastNext: false, // 用户引导最后一步点击时设置为true
      originalData: { ...resetInit },
      detailInfo: { ...resetInit }, // 工作项详情
      loading: false, // 切换模板、保存
      fileUpdaloadBoxStatus: true, // 上传附件框-展示/隐藏
      uploadedFileList: [], // 已经上传的附件信息
      currentProjectId: '', // 当前基本信息的项目id
      assocObject: {
        requirements: [],
        tasks: [],
        defects: [],
      },
      // 关联工作项
    }
  },
  computed: {
    itemType() {
      return WORKITEMCONST.workItemTypeMap[this.workItemType]
    },
    ProjectListAll() {
      return this.$store.state.pf.ProjectListAll
    },
  },

  watch: {
    // 当基本信息选中的 projectId 变化时，需要更新模板信息
    currentProjectId: {
      handler: function(newValue) {
        if (newValue) {
          // 切换项目，清空关联用户
          this.$store.dispatch({
            type: 'clearAssignUserList',
          })
          this.initData()
          this.$emit('update:projectId', newValue)
        }
      },
      immediate: true,
    },
  },

  created() {
    if (this.$getUrlParams().projectId) {
      this.currentProjectId = this.$getUrlParams().projectId
    } else {
      // 如果是在非项目模块下创建，则需要获取项目信息
      this.getCurrentProjectInfo()
    }
    window.addEventListener('beforeunload', this.pageUnloadHandler)
  },
  beforeDestroy() {
    this.setUserInputCache()
    if (!this.isLastNext) {
      // 用户特殊操作则执行上一步索引
      this.$store.commit(guide.STOP_STEP)
    }
    this.$bus.$off('G_changeGuideStep', this.closeGuide)
  },
  mounted() {
    // 设置附件列表
    if (Array.isArray(this.$attrs.uploadedFileList)) {
      this.uploadedFileList = [...this.$attrs.uploadedFileList]
    } else if (this.fromOtherDetailType === 'cloneWorkItem') {
      this.getUploadedFileList()
    }
    this.$bus.$on('G_changeGuideStep', this.closeGuide)
  },
  methods: {
    initGuide() {
      let _this = this
      if (this.$store.state.guide.guideType === guideType.requirement) {
        setTimeout(() => {
          // 临时索引state.stepIndex存在时 优先使用临时索引
          let steIndex = this.$store.state.guide.stepIndex || 2
          this.$store.commit(guide.START_GUIDE, {
            guideType: guideType.requirement,
            guideStep: guideStep.requirementCreate,
            step: steIndex,
            steps: {
              2: {
                dom: this.$refs.titleInput,
                prevCallback() {
                  _this.$emit('HandleSide')
                  // 等待弹窗关闭
                  _this.isLastNext = true
                  setTimeout(() => {
                    _this.$bus.$emit('G_requirementCreate')
                  }, 500)
                },
              },
              3: { dom: this.$refs.desc },
              4: {
                dom: this.$refs.saveBtn,
                nextCallback() {
                  // isLastNext 避免执行beforeDestroy时触发G_requirementCreate事件
                  _this.isLastNext = true
                  _this.$emit('HandleSide')
                  setTimeout(() => {
                    _this.$bus.$emit('G_requirementSplit')
                  }, 500)
                },
              },
            },
          })
        }, 300)
      } else if (this.$store.state.guide.guideType === guideType.bug) {
        setTimeout(() => {
          // 临时索引state.stepIndex存在时 优先使用临时索引
          let steIndex = this.$store.state.guide.stepIndex || 2
          this.$store.commit(guide.START_GUIDE, {
            guideType: guideType.bug,
            guideStep: guideStep.bugCreate,
            step: steIndex,
            steps: {
              2: {
                dom: this.$refs.titleInput,
                prevCallback() {
                  _this.$emit('HandleSide')
                  // 等待弹窗关闭
                  _this.isLastNext = true
                  setTimeout(() => {
                    _this.$bus.$emit('G_bugCreate')
                  }, 500)
                },
              },
              3: {
                dom: this.$refs.desc,
                nextCallback() {
                  let sprintIdDom = document.getElementById('sprintIdDom')
                  // 如果没有迭代字段则跳过
                  if (!sprintIdDom) {
                    _this.$store.commit(guide.UPDATE_GUIDE_STEPINFO_STEP, 4)
                  }
                  if (sprintIdDom) {
                    let top = sprintIdDom.getBoundingClientRect().top
                    if (top > 500) {
                      // 找到父组件，并进行滚动定位
                      _this.$parent.$parent.$el.scrollTo(0, top + 200)
                    }
                  }
                  return true
                },
              },
              4: {
                dom: document.getElementById('sprintIdDom'),
                prevCallback() {
                  _this.$parent.$parent.$el.scrollTo(0, 0)
                },
                nextCallback() {
                  _this.$parent.$parent.$el.scrollTo(0, 0)
                },
              },
              5: {
                dom: this.$refs.saveBtn,
                prevCallback() {
                  let sprintIdDom = document.getElementById('sprintIdDom')
                  // 如果没有迭代字段则跳过
                  if (!sprintIdDom) {
                    _this.$store.commit(guide.UPDATE_GUIDE_STEPINFO_STEP, 4)
                  }
                  if (sprintIdDom) {
                    let top = sprintIdDom.getBoundingClientRect().top
                    if (top > 500) {
                      // 找到父组件，并进行滚动定位
                      _this.$parent.$parent.$el.scrollTo(0, top + 200)
                    }
                  }
                  return true
                },
                nextCallback() {
                  _this.$store.commit(
                    guide.UPDATE_GUIDE_STEP,
                    guideStep.bugTrack,
                  )
                  _this.$router.push({
                    path: '/sprint/detail',
                    query: {
                      guideType: guideType.bug,
                      projectId: _this.$getUrlParams().projectId,
                    },
                  })
                },
              },
            },
          })
        }, 300)
      }
    },
    closeGuide() {
      if (this.$store.state.guide.stepInfo !== 2) {
        this.isLastNext = true
        this.$emit('HandleSide')
      }
    },
    // 文件上传 - 获取已经上传的文件列表
    getUploadedFileList() {
      if (this.$attrs['original-detail'].detail.id < 1) {
        return
      }
      list({
        workItemId: this.$attrs['original-detail'].detail.id,
        workItemType: this.workItemType,
        projectId: this.$attrs['original-detail'].rawData.id,
      }).then(result => {
        if (result.status === 200) {
          this.uploadedFileList = result.data.map(item => {
            return {
              name: item.origName,
              url: item.url,
              createUser: item.display.createUser,
              createTime: item.createTime,
              size: item.size,
              id: item.id,
            }
          })
        } else {
          this.uploadedFileList = []
        }
      })
    },
    // 数据初始化
    async initData() {
      await this.getTemplateList(this.currentProjectId, this.workItemType)
      // 选中默认模板
      const activeItem = this.templateList.find(item => item.active)
      let tmpId = activeItem?.id || null
      // 是否为复制
      if (this.fromOtherDetailType === 'cloneWorkItem') {
        const originTemplateId = this.templateList.find(
          item => item.id === this.$attrs['original-detail'].meta.tmplId,
        )?.id
        originTemplateId && (tmpId = originTemplateId)
      }
      this.queryTmplateInfo(tmpId)
    },
    // 获取项目列表信息 - 在非项目模块创建项目使用
    async getCurrentProjectInfo() {
      let result = this.ProjectListAll
      if (result.length === 0) {
        result = await this.$store.dispatch({ type: 'getProjectListAll' })
      }
      const projectId = +localStorage.getItem('projectId')
      if (projectId && this.checkProjectId(projectId, result)) {
        this.currentProjectId = projectId
      } else {
        this.currentProjectId = result[0].id
      }
    },
    // 检测projectId在项目列表下是否存在
    checkProjectId(projectId, projectListAll) {
      const index = projectListAll.findIndex(item => {
        return item.id === projectId
      })
      return index === -1 ? false : true
    },
    // 点击右上角关闭按钮
    drawerClose() {
      if (
        this.detailInfo.title !== this.originalData.title ||
        this.detailInfo.content !== this.originalData.content
      ) {
        this.setUserInputCache()
      }
      this.$emit('HandleSide')
    },
    // 点击右上角保存按钮
    drawerSaveClick() {
      // 标题校验
      if (this.detailInfo.title.trim().length === 0) {
        this.$message({
          message: i18n.t('标题不能为空'),
          type: 'warning',
        })

        return false
      }
      // 没有项目权限
      if (this.currentProjectId === '') {
        this.$message({
          message: i18n.t('权限校验失败'),
          type: 'error',
        })
        return false
      }
      // 必填项校验
      if (!this.$refs.WorkItemBasicInfoCreate.checkFields()) {
        return
      }
      const type =
        this.fromOtherDetailType === 'cloneWorkItem' ? 'copy' : 'save'
      this.$emit(type, {
        tmplId: this.selectedTemplateId,
        ...this.detailInfo,
        projectId: this.currentProjectId,
        ...this.workItemCreateBasicFormObject,
        attachments: this.uploadedFileList.map(item => item.id),
        assoc: {
          requirements: this.assocObject.requirements.map(item => item.id),
          tasks: this.assocObject.tasks.map(item => item.id),
          defects: this.assocObject.defects.map(item => item.id),
        },
        // 关联项
      })
    },
    // 标题输入内容监听
    titleInput() {
      this.cachedSaveHandle()
      this.addDirtyTag()
    },
    // 编辑器监听
    editHandle(data) {
      this.detailInfo.content = data
      this.cachedSaveHandle()
    },
    // 编辑器监听
    userEdit() {
      this.addDirtyTag()
    },
    // 模板 - 获取默认模板内容
    async queryTmplateInfo(id = null) {
      let result = {}
      try {
        result = await this.getWorkItemTemplateInfo({
          projectId: this.currentProjectId,
          workItemType: this.workItemType,
          id,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      const normalizedResult = this._normalizeTemplateDetail(result)
      result = this.cachedCreateInfo[normalizedResult.id] || normalizedResult
      this.selectedTemplateId = normalizedResult.id

      this.originalData.title = result.title
      this.originalData.content = result.content
      this.$nextTick(() => {
        // 复制工作项
        if (this.fromOtherDetailType === 'cloneWorkItem') {
          this.formatCloneData()
          return
        } else if (!this.fromOtherDetailType) {
          this.detailInfo.title = result.title
          this.detailInfo.content = result.content
        } else {
          // 如果之前已经初始化过了，则不再重复初始化
          if (this.cannotChangeTitle) {
            return
          }
          this.cannotChangeTitle = true
          this.detailInfo.content = this.otherDetailContent
          this.detailInfo.title = this.otherDetailTitle
        }
        this.initGuide()
      })
    },
    // 处理复制数据
    formatCloneData() {
      this.detailInfo.title = this.otherDetailTitle
      this.detailInfo.content = this.otherDetailContent
      const originalData = this.$attrs['original-detail']
      const workItemCreateBasicFormObject = {
        userDefinedAttrs: {},
      }
      const parentRequire = this.workItemCreateBasicTemplateArray.find(
        item => item.attrName === 'requireId',
      )
      if (parentRequire) {
        parentRequire.initName = originalData.display?.parentTitle || '--'
        parentRequire.initValue = originalData.rawData.requireId
      }
      for (const item of this.workItemCreateBasicTemplateArray) {
        const originValue = originalData.rawData[item.attrName]
        workItemCreateBasicFormObject.userDefinedAttrs[
          item.attrName
        ] = originValue
        workItemCreateBasicFormObject[item.attrName] = originValue
      }
      this.workItemCreateBasicFormObject = workItemCreateBasicFormObject
    },
    // 模板 - 缓存保存
    cachedSaveHandle() {
      this.cachedCreateInfo[this.selectedTemplateId] = {
        id: this.selectedTemplateId,
        title: this.detailInfo.title,
        content: this.detailInfo.content,
        workItemCreateBasicFormObject: this.workItemCreateBasicFormObject,
      }
    },
    // 关联工作项 - 更新
    assocUpdate(value) {
      this.assocObject = value
    },
    // 文件上传 - 成功处理函数
    handleUploadSuccess(res) {
      if (res.status !== 200) {
        this.$message({
          message: res.msg || i18n.t('文件上传失败'),
          type: 'error',
        })

        return
      }
      this.uploadedFileList.push({
        name: res.data.origName,
        url: res.data.url,
        id: res.data.id,
        createTime: res.data.createTime,
        size: res.data.size,
        createUser: res.data.display?.createUser,
      })

      this.$message({
        message: i18n.t('文件上传成功'),
        type: 'success',
      })
    },
    // 文件上传 - 文件删除
    handleFileDelete(file) {
      this.uploadedFileList = this.uploadedFileList.filter(
        item => item.id !== file.id,
      )
    },
    // 文件上传 - 上传框是否隐藏
    fileUpdaloadBoxStatusHandle() {
      this.fileUpdaloadBoxStatus = !this.fileUpdaloadBoxStatus
    },
    // 所属项目切换
    handleProjectChange(id) {
      this.currentProjectId = id
      this.addDirtyTag()
    },
    // 页面关闭事件句柄
    pageUnloadHandler() {
      this.setUserInputCache()
      window.removeEventListener('beforeunload', this.pageUnloadHandler)
    },
    // 缓存 -------------------------------------------------- start
    // 缓存 - 保存
    setUserInputCache() {
      const { title, content } = this.detailInfo
      const cacheContent = { title, content }
      this.isDirty && setCreateItemUserInputCache(this.itemType, cacheContent)
    },
    // 换存 - 恢复
    restoreContent({ title, content }) {
      const { detailInfo } = this
      detailInfo.title = title
      detailInfo.content = content
    },
    // 缓存 - 清除
    clearUserInputCache() {
      setCreateItemUserInputCache(this.itemType, null)
    },
    // 缓存 - 增加标识
    addDirtyTag() {
      this.isDirty = true
    },
    // 缓存 - 去除标识
    resetDirtyTag() {
      this.isDirty = false
    },
    // 缓存 -------------------------------------------------- end
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/project/ProjectCommon.scss';
.detail-content {
  .detail-content-body {
    .detail-content-footer {
      /*min-height: 299px;*/
    }
  }
}
</style>
<style lang="scss">
.template-select__menu {
  .el-dropdown-menu-active {
    color: $--color-primary;
    background-color: $--color-primary-light-9;
  }
}
</style>
