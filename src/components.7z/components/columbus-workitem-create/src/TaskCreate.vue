<template>
  <div class="slider-body">
    <BaseCreate
      v-if="show"
      ref="BaseCreate"
      v-bind="$attrs"
      :work-item-type="2"
      :base-config="baseConfig"
      :project-id.sync="projectId"
      @HandleSide="HandleSide"
      @save="handleSave"
      @copy="data => $emit('copy', data)"
    >
      <template #footer>
        <!-- 选择需求 -->
        <el-tabs value="code">
          <el-tab-pane :label="$t('选择父需求')" name="code" disabled>
            <el-form :inline="true" @submit.native.prevent>
              <el-form-item class="header-input">
                <el-input
                  v-model="searchInfo.title"
                  :placeholder="$t('支持标题或ID搜索')"
                ></el-input>
              </el-form-item>
              <el-form-item>
                <el-button
                  @click="
                    searchRequrieList({
                      pageSize: DEFAULT_PAGE_SIZE,
                      pageNumber: DEFAULT_PAGE_NUMBER,
                    })
                  "
                  >{{ $t('查询') }}</el-button
                >
              </el-form-item>
            </el-form>
            <div class="table-box-top">
              <el-table
                ref="assocRequireTableRef"
                :data="requirementList"
                border
                style="width: 100%; height: 100%"
              >
                <el-table-column width="50" align="center">
                  <template slot-scope="scope">
                    <el-radio v-model="requireId" :label="scope.row.id">{{
                      null
                    }}</el-radio>
                  </template>
                </el-table-column>
                <el-table-column
                  width="90"
                  show-overflow-tooltip
                  :label="$t('需求ID')"
                  prop="id"
                >
                  <template slot-scope="scope">
                    <span
                      class="c-blue cp"
                      @click.stop="assocItemClick(scope.row, 'requirement')"
                      >{{ scope.row.id }}</span
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="display.title"
                  show-overflow-tooltip
                  :label="$t('需求标题')"
                  min-width="180"
                >
                  <template slot-scope="scope">
                    <span
                      class="c-blue cp"
                      @click.stop="assocItemClick(scope.row, 'requirement')"
                      >{{ scope.row.display.title }}</span
                    >
                  </template>
                </el-table-column>
                <el-table-column
                  prop="display.projectName"
                  show-overflow-tooltip
                  :label="$t('所属项目')"
                  min-width="80"
                >
                </el-table-column>
                <el-table-column
                  prop="display.assignUser"
                  show-overflow-tooltip
                  :label="$t('处理人')"
                  min-width="60"
                >
                </el-table-column>
                <el-table-column
                  prop="display.status"
                  show-overflow-tooltip
                  :label="$t('状态')"
                  width="80"
                ></el-table-column>
              </el-table>
            </div>
            <div class="table_b_f_b">
              <el-pagination
                v-show="requirementList && requirementList.length > 0"
                class="mr10 flex-right"
                style="margin-top: 9px"
                :current-page="searchInfo.pageInfo.pageNumber"
                :page-sizes="[10, 20, 30]"
                :page-size="searchInfo.pageInfo.pageSize"
                layout="total, sizes, prev, pager, next, jumper"
                :total="searchInfo.pageInfo.totalRecords"
                @size-change="handleRequirementListPageSizeChange"
                @current-change="handleRequirementListPageNumChange"
              ></el-pagination>
            </div>
          </el-tab-pane>
        </el-tabs>
      </template>
    </BaseCreate>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 任务新建组件
 * @desc
 * @author heyunjiang
 * @date
 */
import BaseCreate from './BaseCreate'
import { createTask } from '@/service/task'
import { parentAble } from '@/service/requirement'

const DEFAULT_PAGE_NUMBER = 1
const DEFAULT_PAGE_SIZE = 10

export default {
  name: 'TaskCreate',
  components: {
    BaseCreate,
  },
  mixins: [],
  // props 正常只需要传这些数据，特殊使用时，比如转需求、缺陷，则通过 this.$attrs 读取
  props: {
    show: {
      type: Boolean,
      required: false,
      desc: '所属 slider 展开与否',
      default: false,
    },
  },
  data() {
    return {
      DEFAULT_PAGE_NUMBER,
      DEFAULT_PAGE_SIZE,
      searchInfo: {
        title: '',
        pageInfo: {
          totalRecords: 0,
          pageNumber: DEFAULT_PAGE_NUMBER,
          pageSize: DEFAULT_PAGE_SIZE,
        },
      },
      requirementList: [], // 可以选择的父需求列表
      requireId: null, // 当前选择的父需求
      baseConfig: {
        title:
          this.$attrs['from-other-detail-type'] === 'cloneWorkItem'
            ? i18n.t('复制任务')
            : i18n.t('新建任务'),
      },
      projectId: null,
    }
  },
  computed: {},
  watch: {
    show() {
      if (!this.show) {
        this.requireId = null
      }
    },
    projectId() {
      this.searchRequrieList()
    },
    $attrs(val) {
      if (val['original-detail']?.rawData?.requireId) {
        this.requireId = val['original-detail'].rawData.requireId
      }
    },
  },
  created() {},
  mounted() {
    this.searchRequrieList()
  },
  methods: {
    // 关闭弹窗
    HandleSide() {
      this.$emit('HandleSide')
    },
    // 保存任务
    async handleSave(info) {
      let progress = info.progress
      // 兼容任务进度不在正常范围
      if (progress) {
        progress = +(+progress).toFixed(1)
        if (progress > 100) {
          progress = 100
        }
        if (progress < 0) {
          progress = 0
        }
        info.progress = progress
      }
      const BaseCreate = this.$refs.BaseCreate
      BaseCreate.loading = true
      let result = { status: 0 }
      try {
        result = await createTask({
          ...info,
          requireId: this.requireId,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      BaseCreate.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('创建成功'),
          type: 'success',
        })
        BaseCreate.clearUserInputCache()
        BaseCreate.$refs.userInputTips?.ignoreCache()
        // 跳转到任务列表页
        this.$router
          .push(`/task/view?projectId=${BaseCreate.currentProjectId}`)
          .then(() => {
            this.$emit('HandleAddSuccess')
          })
        BaseCreate.resetDirtyTag()
      }
    },
    // 缓存处理透传
    setUserInputCache() {
      // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
      this.$refs.BaseCreate?.setUserInputCache()
    },
    // footer ----------------------------------- start
    // 选择需求 - 点击查询
    searchRequrieList({ pageNumber = DEFAULT_PAGE_NUMBER, pageSize } = {}) {
      if (!this.projectId) {
        return
      }
      const { pageInfo } = this.searchInfo
      parentAble({
        title: this.searchInfo.title,
        pageInfo: {
          ...pageInfo,
          pageSize: pageSize != null ? pageSize : pageInfo.pageSize,
          pageNumber,
        },

        projectId: this.projectId,
      }).then(res => {
        if (res.status === 200) {
          this.searchInfo.pageInfo = res.data.pageInfo
          this.requirementList = res.data.result
        } else {
          this.requirementList = []
        }
      })
    },
    // 分页
    handleRequirementListPageSizeChange(pageSize) {
      this.searchRequrieList({
        pageSize,
      })
    },
    // 分页
    handleRequirementListPageNumChange(pageNumber) {
      this.searchRequrieList({
        pageNumber,
      })
    },
    // 点击需求跳转
    assocItemClick(info, type) {
      const currentProjectId = this.projectId
      switch (type) {
        case 'requirement':
          this.$goToNewWindowPage('/requirement/list', {
            requireId: info.id,
            projectId: currentProjectId,
          })
          break
        case 'task':
          this.$goToNewWindowPage('/task/view', {
            taskId: info.id,
            projectId: currentProjectId,
          })
          break
        case 'defect':
          this.$goToNewWindowPage('/bug/list', {
            bugId: info.id,
            projectId: currentProjectId,
          })
          break
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.table-box-top {
  /deep/ .el-table__body-wrapper {
    &::-webkit-scrollbar-thumb {
      background: rgba(0, 0, 0, 0.2);
      border: none;
      border-radius: 4px;
    }
  }
}
</style>
