<template>
  <div class="slider-body">
    <BaseCreate
      v-if="show"
      ref="BaseCreate"
      v-bind="$attrs"
      :work-item-type="1"
      :current-category-id="currentCategoryId"
      :base-config="baseConfig"
      @HandleSide="HandleSide"
      @save="handleSave"
      @copy="data => $emit('copy', data)"
    >
    </BaseCreate>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 需求新建组件
 * @desc
 * @author heyunjiang
 * @date 2020.6.17
 */
import BaseCreate from './BaseCreate'
import * as requirementService from '@/service/requirement'
import { bugTransFormation } from '@/service/bug'
import { statusTransfer } from '@/service/operation'

export default {
  name: 'RequirementCreate',
  components: {
    BaseCreate,
  },

  mixins: [],
  // props 正常只需要传这些数据，特殊使用时，比如转需求、缺陷，则通过 this.$attrs 读取
  props: {
    show: {
      type: Boolean,
      required: false,
      desc: '所属 slider 展开与否',
      default: false,
    },

    currentCategoryId: {
      type: [String, Number],
      desc: '在创建需求时有用',
    },
  },

  data() {
    return {
      baseConfig: {
        title:
          this.$attrs['from-other-detail-type'] === 'cloneWorkItem'
            ? i18n.t('复制需求')
            : i18n.t('创建需求'),
      },
    }
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {
    // 关闭弹窗
    HandleSide() {
      this.$emit('HandleSide')
    },
    // 点击保存
    handleSave(info) {
      // 迭代选择必要参数
      info.innerProject = true
      // 如果是转需求
      if (this.$attrs['from-other-detail-type']) {
        switch (this.$attrs['from-other-detail-type']) {
          case 'bugTorequirement':
            this.saveBugTorequire(info)
            break
          case 'feedbackToRequirement':
            this.saveFeedbackToRequire(info)
            break
        }

        return
      }
      this.saveRequire(info)
    },
    // 保存需求
    async saveRequire(info) {
      const BaseCreateRef = this.$refs.BaseCreate
      BaseCreateRef.loading = true
      let result = { status: 0 }
      try {
        result = await requirementService.requirementCreate({
          ...info,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      BaseCreateRef.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('创建成功'),
          type: 'success',
        })

        BaseCreateRef.clearUserInputCache()
        BaseCreateRef.$refs.userInputTips?.ignoreCache()
        // 跳转到任务列表页
        this.$router
          .push(`/requirement/list?projectId=${BaseCreateRef.currentProjectId}`)
          .then(() => {
            this.$emit('HandleAddSuccess')
          })
        BaseCreateRef.resetDirtyTag()
      }
    },
    // 缺陷转需求
    async saveBugTorequire(info) {
      const BaseCreateRef = this.$refs.BaseCreate
      BaseCreateRef.loading = true
      let result = { status: 0 }
      const bugInfo = {
        defectId: this.$attrs['from-other-detail-id'],
        workItemType: 3,
      }
      try {
        result = await bugTransFormation({
          ...info,
          ...bugInfo,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      BaseCreateRef.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('缺陷转需求成功'),
          type: 'success',
        })
        this.$emit('transferSuccess', true)
        BaseCreateRef.clearUserInputCache()
        BaseCreateRef.resetDirtyTag()
      }
    },
    // 反馈转需求
    async saveFeedbackToRequire(info) {
      const BaseCreateRef = this.$refs.BaseCreate
      BaseCreateRef.loading = true
      let result = { status: 0 }
      const postInfo = {
        id: this.$attrs['from-other-detail-id'],
        action: 'CONVERT_TO_REQUIRE',
        requirement: info,
      }

      try {
        result = await statusTransfer({
          ...postInfo,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      BaseCreateRef.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('反馈转需求成功'),
          type: 'success',
        })
        this.$emit('transferSuccess', true)
        BaseCreateRef.clearUserInputCache()
        BaseCreateRef.resetDirtyTag()
      }
    },
    // 缓存处理透传
    setUserInputCache() {
      // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
      this.$refs.BaseCreate?.setUserInputCache()
    },
  },
}
</script>
<style lang="scss" scoped></style>
