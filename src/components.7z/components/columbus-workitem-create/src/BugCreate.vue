<template>
  <div class="slider-body">
    <BaseCreate
      v-if="show"
      ref="BaseCreate"
      v-bind="$attrs"
      :work-item-type="3"
      :base-config="baseConfig"
      associalable
      @HandleSide="HandleSide"
      @save="handleSave"
      @copy="data => $emit('copy', data)"
    >
    </BaseCreate>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 缺陷新建组件
 * @desc
 * @author heyunjiang
 * @date 2020.6.17
 */
import BaseCreate from './BaseCreate'
import { newBug } from '@/service/bug'
import { statusTransfer } from '@/service/operation'

export default {
  name: 'BugCreate',
  components: {
    BaseCreate,
  },

  mixins: [],
  // props 正常只需要传这些数据，特殊使用时，比如转需求、缺陷，则通过 this.$attrs 读取
  props: {
    show: {
      type: Boolean,
      required: false,
      desc: '所属 slider 展开与否',
      default: false,
    },
  },

  data() {
    return {
      baseConfig: {
        title:
          this.$attrs['from-other-detail-type'] === 'cloneWorkItem'
            ? i18n.t('复制缺陷')
            : i18n.t('新建缺陷'),
      },
    }
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {
    // 关闭弹窗
    HandleSide() {
      this.$emit('HandleSide')
    },
    // 点击保存
    handleSave(info) {
      // 如果是转需求
      if (this.$attrs['from-other-detail-type']) {
        switch (this.$attrs['from-other-detail-type']) {
          case 'feedbackToDefect':
            this.saveFeedbackToDefect(info)
            break
          case 'AlmToDefect':
            this.saveAlmToDefect(info)
            break
        }
        return
      }
      this.saveDefect(info)
    },
    // 保存缺陷
    async saveDefect(info) {
      const BaseCreate = this.$refs.BaseCreate
      BaseCreate.loading = true
      // 获取额外字段
      const urlObjs = this.$getUrlParams()
      delete urlObjs.projectId
      delete urlObjs.bugId

      let result = { status: 0 }
      try {
        result = await newBug({
          ...info,
          ...urlObjs,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      BaseCreate.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('创建成功'),
          type: 'success',
        })
        BaseCreate.clearUserInputCache()
        BaseCreate.$refs.userInputTips?.ignoreCache()
        // 在快捷入口创建时，跳到bug列表
        this.$router
          .push(`/bug/list?projectId=${BaseCreate.currentProjectId}`)
          .then(() => {
            this.$emit('HandleAddSuccess')
            this.$attrs.rightSliderHandle &&
              this.$attrs.rightSliderHandle(false)
            this.$attrs.operateCallback && this.$attrs.operateCallback()
          })
        this.$emit('handleOk', result.data.detail.id)
        BaseCreate.resetDirtyTag()
      }
    },
    // 反馈转缺陷
    async saveFeedbackToDefect(info) {
      const BaseCreate = this.$refs.BaseCreate
      BaseCreate.loading = true
      let result = { status: 0 }
      const postInfo = {
        id: this.$attrs['from-other-detail-id'],
        action: 'CONVERT_TO_DEFECT',
        defect: info,
      }

      try {
        result = await statusTransfer({
          ...postInfo,
        })
        // eslint-disable-next-line no-empty
      } catch (_) {}
      BaseCreate.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('反馈转缺陷成功'),
          type: 'success',
        })
        this.$emit('transferSuccess', true)
        BaseCreate.clearUserInputCache()
        BaseCreate.resetDirtyTag()
      }
    },
    // alm缺陷
    async saveAlmToDefect(info) {
      const BaseCreate = this.$refs.BaseCreate
      BaseCreate.loading = true
      let result = { status: 0 }
      try {
        result = await newBug({
          ...info,
          almDefectId: this.$attrs['alm-defect-id'],
          almDefectCreateUser: this.$attrs['alm-defect-create-user'],
          almProductType: this.$attrs['alm-product-type'],
        })
      } catch (e) {
        console.error(e)
      }
      BaseCreate.loading = false
      if (result.status === 200) {
        this.$message({
          message: result.msg || i18n.t('同步缺陷成功'),
          type: 'success',
        })
        this.$emit('synchronizationSuccess')
        BaseCreate.clearUserInputCache()
        BaseCreate.resetDirtyTag()
      }
    },
    // 缓存处理透传
    setUserInputCache() {
      // 添加?解决badjs报错TypeError: Cannot read property 'setUserInputCache' of undefined
      this.$refs.BaseCreate?.setUserInputCache()
    },
  },
}
</script>
<style lang="scss" scoped></style>
