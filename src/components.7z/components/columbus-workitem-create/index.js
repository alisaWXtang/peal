// 全局 vue 插件不可挂载
import TaskCreate from './src/TaskCreate.vue'
import RequirementCreate from './src/RequirementCreate.vue'
import BugCreate from './src/BugCreate.vue'

TaskCreate.install = Vue => Vue.component(TaskCreate.name, TaskCreate)
RequirementCreate.install = Vue =>
  Vue.component(RequirementCreate.name, RequirementCreate)
BugCreate.install = Vue => Vue.component(BugCreate.name, BugCreate)

export { TaskCreate, RequirementCreate, BugCreate }
