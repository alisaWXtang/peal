<template>
  <div class="treebox">
    <co-input
      v-if="filter"
      v-model.trim="filterText"
      class="tree-input"
      clearable
      :placeholder="$t('输入关键字进行过滤')"
      prefix-icon="co-icon-search"
    >
    </co-input>

    <co-tree
      ref="tree"
      v-bind="$attrs"
      class="treebox-tree scrollbal-common"
      :class="{ 'filter-tree-noicon': !showIcon }"
      node-key="id"
      :data="treeData"
      :props="defaultProps"
      highlight-current
      :current-node-key="currentNodeKey"
      :expand-on-click-node="false"
      :filter-node-method="filterNode"
      :render-content="renderContent"
      :default-expanded-keys="expandedKeys"
      auto-expand-parent
      v-on="$listeners"
    />
  </div>
</template>
<script type="text/jsx">
/**
 * @title 哥伦布通用组件树
 * @desc 支持 menuData 控制展开菜单
 * @author heyunjiang
 * @date
 */
export default {
  name: 'Tree',
  mixins: [],
  props: {
    treeData: {
      type: Array,
      required: false,
      default: () => {
        return [];
      }
    },

    currentNodeKey: {
      type: [String, Number],
      required: false,
      desc: '当前活跃的 key'
    },

    filter: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否支持过滤'
    }
  },

  data() {
    return {
      filterText: '',
      defaultProps: {
        children: 'children',
        label: 'name'
      }
    };
  },
  computed: {
    // 是否展示 icon 图标，如果只有一层，那么缩进就有问题，则不需要展示 icon
    showIcon() {
      return this.treeData.find(item => item.children?.length);
    },
    // 默认展开节点数组
    expandedKeys() {
      return [this.currentNodeKey];
    }
  },

  watch: {
    filterText(val) {
      this.$refs.tree.filter(val);
    },
    treeData() {
      // 保证在树渲染成功之后，更新选项，否则会默认选中第一个
      this.$nextTick(() => {
        this.$refs.tree.setCurrentKey(this.currentNodeKey);
      });
    },
    currentNodeKey() {
      this.$refs.tree.setCurrentKey(this.currentNodeKey);
    }
  },

  created() {},
  mounted() {},
  methods: {
    // 执行过滤
    filterNode(value, data, node) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1 || this.parentMatch(value, node);
    },
    parentMatch(value, node) {
      if (node.parent) {
        return (node.parent?.data?.name && node.parent?.data?.name.indexOf(value) !== -1) || this.parentMatch(value, node.parent)
      } else {
        return false
      }
    },
    // 自定义渲染内容
    renderContent(h, { node, data }) {
      const style = this.showIcon
        ? 'width: calc(100% - 24px);'
        : 'width: calc(100% - 19px);';
      return (
        <span class="render-box" style={style}>
          <span title={node.label}>{node.label}</span>
          {data.menuData?.length && (
            <div class="more-box" onClick={e => e.stopPropagation()}>
              <CoDropdown
                trigger="hover"
                onCommand={e => this.handleCommand(e, data)}
              >
                <div class="more-box-btn">
                  <i class="iconfont icon-operate"/>
                </div>
                <CoDropdownMenu slot="dropdown">
                  {data.menuData.map(item => (
                    <CoDropdownItem command={item.command} key={item.command}>
                      {item.title}
                    </CoDropdownItem>
                  ))}
                </CoDropdownMenu>
              </CoDropdown>
            </div>
          )}
        </span>
      );
    },
    // 点击右侧菜单
    handleCommand(e, data) {
      this.$emit(e, data);
    }
  }
};
</script>
<style lang="scss" scoped>
.treebox {
  /deep/
    .el-tree--highlight-current
    .el-tree-node.is-current
    > .el-tree-node__content,
  /deep/ .el-tree-node__content:hover {
    color: $--color-primary;
    background: $--color-primary-light-9;
  }
  /deep/ .el-tree-node__content {
    height: 29px;
  }
  /deep/.tree-input {
    width: 250px;
    margin-bottom: 16px;

    .el-input__inner {
      padding-left: 30px;
      border-radius: 4px;
    }
  }
  // 隐藏 icon
  .filter-tree-noicon {
    /deep/ .el-tree-node__expand-icon.is-leaf {
      width: 15px;
      padding: 0;
    }
  }
  .treebox-tree {
    margin-top: 10px;
    max-height: calc(100% - 38px);
    overflow-y: auto;
  }
  // render-box 布局
  /deep/ .render-box {
    display: flex;
    align-items: center;
    padding-right: 10px;
    span {
      padding-right: 2px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    div {
      flex-shrink: 0;
      outline: unset;
    }
    // style for seperate button
    .more-box {
      width: 24px;
      height: 16px;
      line-height: 16px;
      border-radius: 2px;
      text-align: center;
      margin-left: 16px;
      display: none;
      .more-box-btn {
        width: 100%;
        height: 100%;
        color: $--color-primary;
      }
      &:hover {
        background-color: #fff;
      }
    }
    &:hover {
      .more-box {
        display: block !important;
      }
    }
  }
}
// 通用-滚动条样式 - webkit
.scrollbal-common {
  &::-webkit-scrollbar {
    /*滚动条整体样式*/
    width: 6px;
    /*高宽分别对应横竖滚动条的尺寸*/
    height: 10px;
  }
  &::-webkit-scrollbar-thumb {
    /*滚动条里面小方块*/
    border-radius: 2px;
    box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
    background: rgba(0, 0, 0, 0.1);
  }
  &::-webkit-scrollbar-track {
    /*滚动条里面轨道*/
    background: #eee;
  }
}
</style>
