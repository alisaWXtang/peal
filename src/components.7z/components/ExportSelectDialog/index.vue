<template>
  <el-dialog 
    :visible="visible" 
    :modal-append-to-body="false" 
    :close-on-click-modal="false" 
    :before-close="handleBeforeClose" 
    width="830px"
  >
  <div slot="title">
    <span class="dia-title-text">{{$t('选择导出字段')}}</span>
    <span class="dia-title-tip">({{$t('工作项导出上限为1000条')}})</span>
  </div>
    <div class="add-field-wrap">
      <div class="can-select-filed">
        <div class="add-field-scrollbar scrollbal-common">
          <el-checkbox 
            v-model="slectedAll" 
          >
            {{ $t('选择所有字段')}}
          </el-checkbox>
          <div class="select-model" v-show="systemAttrs.length">
            <h2 class="small-title">{{$t('系统字段')}}</h2>
            <div class="field-box">
              <div v-for="(item, index) in systemAttrs" :key="index" class="field-item-box">
                <el-checkbox v-model="item.selected" class="required-checkbox" @change="changeHandle(item)">
                </el-checkbox>
                <div class="field-name-title" :title="item.fieldName">{{item.fieldName}}</div>
              </div>
            </div>
          </div>
          <div class="select-model"  v-show="userDefinedAttrs.length">
            <h2 class="small-title">{{$t('自定义字段')}}</h2>
            <div class="field-box">
              <div v-for="(item, index) in userDefinedAttrs" :key="index" class="field-item-box">
                <el-checkbox v-model="item.selected" class="required-checkbox" @change="changeHandle(item)"></el-checkbox>
                <div class="field-name-title" :title="item.fieldName">{{item.fieldName}}</div>
              </div>
            </div>
          </div>
          <div class="select-model" v-if="otherAttr.length&&(workItemType===workItemTypeMap.bug)">
            <h2 class="small-title">{{$t('其他字段')}}</h2>
            <div class="field-box">
              <div v-for="(item, index) in otherAttr" :key="index" class="field-item-box">
                <el-checkbox v-model="item.selected" class="required-checkbox" @change="changeHandle(item)"></el-checkbox>
                <div class="field-name-title" :title="$t(item.fieldName)">{{$t(item.fieldName)}}</div>
              </div>
            </div>
          </div>          
        </div>
      </div>
      <div class="selected-filed">
        <div class="title">{{$t('选定字段')}}
          <span class="title-desc">({{$t('可拖拽排序')}})</span>
        </div>
        <div class="add-field-scrollbar scrollbal-common draggLisr">
          <draggable v-bind="dragOptions" v-model="selectionList" @end="endEvent">
            <div class="field-item" v-for="item in selectionList" :key="item.id">
              <div class="field-name">
                <i class="iconfont icon-drag"></i>
                <span class="field-name" :title="$t(item.fieldName)">{{$t(item.fieldName)}}</span>
              </div>
              <div class="close-opretion">
                <i class="el-icon-close close-icon" @click="deleteHandle(item)"></i>
              </div>
            </div>
          </draggable>
        </div>
      </div>
    </div>
    <div class="filed-dialog-opration">
      <el-button @click="handleBeforeClose">{{$t('取消')}}</el-button>
      <el-button type="primary" @click="successHandle">{{$t('确定')}}</el-button>
    </div>
  </el-dialog>
</template>
<script>
import { i18n } from '@/i18n';
/**
 * @title 自定义导出
 * @desc
 * @author wx
 * @date 2020/3/30
 */
import draggable from 'vuedraggable';
 import cloneDeep from 'lodash/cloneDeep'  
import { getWorkItemAllBasicAttrs } from '@/service/project/projectCommon';
import { WORKITEMCONST } from '@/utils/constant'



export default {
  
  name: 'ExportSelectDialog',
  components: {
    draggable,
  },
  mixins: [],
  props: {
    visible: Boolean,
    workItemType: {
      type: [Number, String],
      required: true,
      desc: '工作项类型，1-需求 2-任务 3-缺陷'
    },
    projectId: {
      type: [Number, String],
      required: true,
      desc: '工作项项目id'
    },
    otherAttrs:{
      type:Array,
      default:()=> [],
      desc: '缺陷其他字段' 
    }
  },

  data() {
    return {
      dragOptions: {
        animation: 500
      },
      workItemTypeMap:WORKITEMCONST.workItemTypeMap,
      selectionList: [],
      dialogInfo: {}, //新建字段
      originSystemAttrs: [], //原始系统字段
      originUserDefinedAttrs: [], //原始自定义字段
      systemAttrs: [], //系统字段列表
      userDefinedAttrs: [], //自定义字段列表
      otherAttr:this.otherAttrs,
      cloneDeepAllData:{},
      workItemExportStatus:'',
      slectedAllCopy:true,
      selectionListALLCopy:[]
    };
  },
  computed: {
    slectedAll:{
      get(){
        return this.systemAttrs.concat(this.userDefinedAttrs,this.otherAttr).every(item=>{ return item.selected }) 
      },
      set(n,o){
        this.systemAttrs.concat(this.userDefinedAttrs,this.otherAttr).forEach(item=>{ item.selected = n });
        n?this.selectionList =[...this.selectionListALLCopy]:this.selectionList=[]
        return n
      }
    }
  },

  watch: { 
    visible(n){
      n &&this.initData()
    }
  },

  mounted() {
  },
  methods: {
    // 重置数据
    initData() {
      this.requestGetWorkItemAllBasicAttrs();
    },
    // 获取全部字段请求
    async requestGetWorkItemAllBasicAttrs(data) {
      const result = await getWorkItemAllBasicAttrs({
        projectId: this.projectId,
        workItemType: this.workItemType,
        forTmplManage: false
      });
  
      if (result.status === 200) {
        // 保存原始数据
        this.originSystemAttrs = result.data.systemAttrs;
        this.originUserDefinedAttrs = result.data.userDefinedAttrs;
        this.deepCloneAllFieldAttrList();
      }
    },
    // 对象转换为array
    objectSwitchArray(object,attrFlag=4) {
      // 接口缺少的字段需要额外加
      const AttrsMap = {
        4:[], //默认
        1:[ //需求
            { fieldName:'id',selected:true,attrName:'id' },
            { fieldName:'标题',selected:true,attrName:'title' },
            { fieldName:'内容',selected:true,attrName:'content' },
            { fieldName:'创建时间',selected:true,attrName:'createTime' },
            { fieldName:'延期类型',selected:true,attrName:'delayType' },
          ],
        2:[ //任务
            { fieldName:'id',selected:true,attrName:'id' },
            { fieldName:'标题',selected:true,attrName:'title' },
            { fieldName:'内容',selected:true,attrName:'content' },        
            { fieldName:'创建时间',selected:true,attrName:'createTime' },
            { fieldName:'延期类型',selected:true,attrName:'delayType' },
        ],
        3:[ //缺陷
            { fieldName:'id',selected:true,attrName:'id' },
            { fieldName:'标题',selected:true,attrName:'title' },
            { fieldName:'内容',selected:true,attrName:'content' },        
            { fieldName:'修改时间',selected:true,attrName:'updateTime' },
            { fieldName:'延期类型',selected:true,attrName:'delayType' },
        ]
      }
      const keys = Object.keys(object);
      keys.forEach(item => {
        AttrsMap[attrFlag].push({...object[item]});
      });
      return AttrsMap[attrFlag];
    },    
    // 对比localStorge里面的值和弹出接口返回的值，主要处理selected属性
    // localStorge如果上次有选中全部，则新增的字段selected为true.没有选中全部则新增的字段selected为false
    compareAttrsToSelect(newData,oldData=[]){
      let tempSelected = this.workItemExportStatus
      let tmpSelectedAll = this.slectedAllCopy
      if(tempSelected){
        tmpSelectedAll = tempSelected.slectedAll
      }
      newData.forEach(nIt=>{
        tmpSelectedAll ? nIt.selected=true : nIt.selected=false
        oldData.forEach(oIt=>{
          if(nIt.attrName===oIt.attrName){
            nIt.selected=oIt.selected
          }
        })
      })
      return newData
    },
    // 拷贝所有需要的值，并且保留所有的origin的值
    deepCloneAllFieldAttrList() {
      let UPDATE_EXPORATTRSflag=''
      let slectedAll
      UPDATE_EXPORATTRSflag = JSON.parse(localStorage.getItem('UPDATE_EXPORATTRS'+this.workItemType)) 
      if(UPDATE_EXPORATTRSflag){ 
        this.workItemExportStatus = UPDATE_EXPORATTRSflag
        slectedAll=this.workItemExportStatus.slectedAll
        this.slectedAll =this.workItemExportStatus.slectedAll
      }

      this.systemAttrs = this.compareAttrsToSelect(this.objectSwitchArray(this.originSystemAttrs,this.workItemType),this.workItemExportStatus.systemAttrs) 
      this.userDefinedAttrs = this.compareAttrsToSelect(this.objectSwitchArray(this.originUserDefinedAttrs),this.workItemExportStatus.userDefinedAttrs);
      this.otherAttr =  this.compareAttrsToSelect(cloneDeep(this.otherAttrs),this.workItemExportStatus.otherAttr),
      this.selectionList = cloneDeep(this.systemAttrs).concat(cloneDeep(this.userDefinedAttrs),cloneDeep(this.otherAttrs)).filter(i=>{
          return i.selected
      })      
      this.selectionListALLCopy = cloneDeep(this.systemAttrs).concat(cloneDeep(this.userDefinedAttrs),cloneDeep(this.otherAttrs)) 
      let cloneDeepAllData = {
        systemAttrs:this.systemAttrs,
        userDefinedAttrs:this.userDefinedAttrs,
        otherAttr:this.otherAttr,
        slectedAll:slectedAll!==undefined?slectedAll:true
      }
    this.cloneDeepAllData = cloneDeep(cloneDeepAllData)
    },
    // 弹窗关闭之前
    handleBeforeClose() {
      this.$emit('update:visible', false)
      this.saveLocalStorage(this.cloneDeepAllData)
    },
    // 复选框改变事件
    changeHandle(data) {
      if (data.selected) {
        // 选中增加一条数据
        this.selectionList.push(data);
      } else {
        this.seletionDelete(data);
      }
    },
    // 选中删除一条数据
    seletionDelete(data) {
      const deleteIndex = this.selectionList.findIndex(item => {
        return item.fieldName === data.fieldName;
      });
      this.selectionList.splice(deleteIndex, 1);
    },
    // 改变复选框状态
    fieldCheckChange(data) {
      let currentOptionsList = this.userDefinedAttrs.concat(this.systemAttrs,this.otherAttr)
      currentOptionsList.forEach(item => {
        if (item.fieldName == data.fieldName) {
          item.selected = false;
        }
        return item;
      });
    },
    // 选定字段删除事件
    deleteHandle(data) {
      this.seletionDelete(data);
      // 可选字段状态更改
      this.fieldCheckChange(data);
    },
    endEvent(e) {
      console.log(e);
    },
    async successHandle() {
      if(this.selectionList.length===0) {
        this.$message({
          message: '请勾选字段导出',
          type: 'error'
        });
        return
      }
      let tempObj = { diyAttr:'',diyHeader:''}
      // 类型为字符串
      let diyAttr=[]; let diyHeader=[]

      const result = await getWorkItemAllBasicAttrs({
        projectId: this.projectId,
        workItemType: this.workItemType,
        forTmplManage: false
      });
      let allfields=[]
      // 导出之前获取最新的字段，与现有的匹配，
      // 新增的字段需要判断是否全选，是：全部导出，否：根据用户所选的字段导出
      // 删减的字段不导出
      if(result.status===200&&result?.data){
        let systemAttrsAll = this.objectSwitchArray(result.data.systemAttrs||[],this.workItemType)
        let userDefinedAttrs = this.objectSwitchArray(result.data.userDefinedAttrs)
        let otherAttr =  this.otherAttrs
        allfields = systemAttrsAll.concat(userDefinedAttrs,otherAttr)
      }

      if(this.slectedAll){
        allfields.forEach((it)=>{
          if(it.attrName===it.attrName){
            if(it.attrName==='statusTransfer'){
              return
            } 
            diyAttr.push(it.displayAttrName||it.attrName)
            diyHeader.push(it.fieldName)
            if(it.attrName==='parentId'&&this.workItemType===WORKITEMCONST.workItemTypeMap.requirement){
              diyAttr.push('parentId')
              diyHeader.push('父需求id')
            }
            if(it.attrName==='requireId'&&this.workItemType===WORKITEMCONST.workItemTypeMap.bug){
              diyAttr.push('requireId')
              diyHeader.push('所属需求id')
            }
            if(it.attrName==='requireId'&&this.workItemType===WORKITEMCONST.workItemTypeMap.task){
            diyAttr.push('parentId')
              diyHeader.push('所属需求id')
            }
          }

        })
      }else{
      this.selectionList.forEach(it=>{ 
        allfields.forEach((item)=>{
          if(it.attrName===item.attrName){
            if(it.attrName==='statusTransfer'){
              return
            } 
            diyAttr.push(it.displayAttrName||it.attrName)
            diyHeader.push(it.fieldName)
            if(it.attrName==='parentId'&&this.workItemType===WORKITEMCONST.workItemTypeMap.requirement){
              diyAttr.push('parentId')
              diyHeader.push('父需求id')
            }
            if(it.attrName==='requireId'&&this.workItemType===WORKITEMCONST.workItemTypeMap.bug){
              diyAttr.push('requireId')
              diyHeader.push('所属需求id')
            }
            if(it.attrName==='requireId'&&this.workItemType===WORKITEMCONST.workItemTypeMap.task){
            diyAttr.push('parentId')
              diyHeader.push('所属需求id')
            }
          }
        })
      })
      }
      tempObj.diyAttr=diyAttr.toString()
      tempObj.diyHeader=diyHeader.toString()

      // diyAttr: 有displayAttrName就用displayAttrName，没有才用attrName
      // 这个字段单独拿出来 ----statusTransfer 控制导出的7个状态

      if(this.otherAttr.length&&this.workItemType===this.workItemTypeMap.bug){
        tempObj.statusTransfer = this.otherAttr.find(i=>i.attrName==='statusTransfer').selected
      }
      this.$emit('exportExcelPassValue',tempObj)
      // 将需求、任务、缺陷单独存储用户的勾选
      try {
        let exportAttrs = {
          systemAttrs:this.systemAttrs,
          userDefinedAttrs:this.userDefinedAttrs,
          otherAttr:this.otherAttr,
          slectedAll:this.slectedAll
        }
        this.saveLocalStorage(exportAttrs)
      } catch (_) {}
      this.$emit('update:visible', false)
    },
    // 本地存储
    saveLocalStorage(exportAttrs){
      localStorage.setItem(
        'UPDATE_EXPORATTRS'+this.workItemType,
        JSON.stringify({
          ...exportAttrs
        })
      );      
    }
  }
};
</script>
<style lang="scss" scoped>
.add-field-wrap {
  display: flex;
}
.dia-title-text{
  line-height: 24px;
  font-size: 18px;
  color: #000;
  margin-right: 5px;
}
.dia-title-tip{
  font-size: 14px;
  color: rgb(128, 145, 165);
}
.add-field-wrap .can-select-filed {
  width: 76%;
  border-right: 1px solid #ccc;
  height: 420px;
  .select-model {
    font-size: 12px;
    .required-checkbox {
      text-align: center;
    }
    /deep/ .required-checkbox .el-checkbox__inner {
      width: 14px;
      height: 14px;
      border-color: #ccc;
    }
    .small-title {
      font-size: 13px;
      .add-field {
        color: #007aff;
        font-size: 12px;
      }
    }
    .field-box {
      display: flex;
      flex-wrap: wrap;
      .field-item-box {
        width: 25%;
        margin-bottom: 10px;
        box-sizing: border-box;
        padding-right: 20px;
        display: flex;
        align-items: center;
        .field-name-title {
          text-overflow: ellipsis;
          overflow: hidden;
          white-space: nowrap;
          margin-left: 3px;
        }
        .field-name-disabled {
          color: #a6aaa7;
        }
      }
    }
  }
}
.add-field-wrap .selected-filed {
  width: 24%;
  height: 420px;
  padding-left: 5px;
  box-sizing: border-box;
}
.add-field-wrap .title {
  font-size: 14px;
  color: rgb(128, 145, 165);
  height: 30px;
}
.add-field-wrap .add-field-scrollbar {
  height: 420px;
  overflow-y: auto;
}
.draggLisr.add-field-scrollbar{
  height: 390px;
}
.add-field-wrap .title .title-desc {
  font-size: 12px;
  margin-left: 4px;
}
.add-field-wrap .field-item {
  display: flex;
  margin: 5px;
  justify-content: space-between;
  align-items: center;
  cursor: move;
  .field-name {
    font-size: 12px;
    margin-right: 5px;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;

  }
  .close-icon {
    font-size: 12px;
    cursor: pointer;
  }
}
.filed-dialog-opration {
  margin-top: 20px;
  text-align: center;
}
.icon-disabled {
  color: #E2E6EE;
  cursor: default !important;
}
</style>
