<template>
  <div
    class="code-statistics"
    v-loading="loading"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <submit-recod
      v-if="listdata.length > 0"
      :value="listdata"
      :loadMoreCallback="CodeLoadMoreCallback"
      :isMore="codePageInfo.isMore"
    ></submit-recod>
    <div v-else class="code-empty empty-text">
      <!-- <el-tooltip
        content="在提交代码添加 commitMessage 时，以 '#'' + '工作项 ID' 即可实现关联代码，比如 <code>'#103890'</code>" placement="top-start">

        <i class="el-icon-question"></i>
      </el-tooltip> -->
      <p>{{ $t('暂无数据') }}</p>
      <!-- <p>
      在提交代码添加 commitMessage 时，以 '#'' + '工作项 ID' 即可实现关联代码，比如 <code>'#103890'</code>
      </p> -->
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 提交记录提示组件
 * @author heyunjiang
 * @date 2019.8.20
 */
import SubmitRecod from '@/components/submit-recod'
import { workItemCodeAssociation } from '@/service/code'
var echarts = require('echarts')
export default {
  name: 'CodeCommit',
  components: { SubmitRecod },
  mixins: [],
  props: {
    workItemId: {
      type: [Number, String],
      required: true,
    },

    workItemType: {
      type: [Number, String],
      required: true,
    },

    update: {
      type: Boolean,
      required: false,
      default: true,
      desc:
        '父组件更新这个值，即可更新列表数据，临时方法，找不到更好的解决方案',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false,
      listdata: [],
      codePageInfo: {
        pageNum: 1,
        pageSize: 5,
        isMore: false,
      },
    }
  },

  watch: {
    workItemId() {
      this.codePageInfo.pageNum = 1
      this.codePageInfo.pageSize = 5
      this.getSprintCodeAssociation()
    },
    workItemType() {
      this.codePageInfo.pageNum = 1
      this.codePageInfo.pageSize = 5
      this.getSprintCodeAssociation()
    },
    update: function(nVal, oVal) {
      if (nVal) {
        this.codePageInfo.pageNum = 1
        this.codePageInfo.pageSize = 5
        this.getSprintCodeAssociation()
      }
    },
  },

  created() {
    this.getSprintCodeAssociation()
  },

  methods: {
    CodeLoadMoreCallback() {
      this.codePageInfo.pageNum = this.codePageInfo.pageNum + 1
      this.getSprintCodeAssociation()
    },
    //获取任务代码提示
    getSprintCodeAssociation() {
      let projectId = this.projectId || this.$getUrlParams().projectId
      let params = {
        workItemId: this.workItemId,
        workItemType: this.workItemType,
        pageNum: this.codePageInfo.pageNum,
        pageSize: this.codePageInfo.pageSize,
        projectId: +projectId,
      }

      // this.listdata.length = 0;
      this.loading = true
      workItemCodeAssociation(params).then(res => {
        this.loading = false
        // console.log(res.data)
        if (!res.data) {
          return
        }
        this.codePageInfo.isMore =
          res.data.gitCommits.total >
          this.codePageInfo.pageNum * this.codePageInfo.pageSize
        if (res.data.gitCommits.pageNum === 1) {
          this.listdata = res.data.gitCommits.list
        } else {
          this.listdata = [...this.listdata, ...res.data.gitCommits.list]
          return
        }
      })
    },
    //提交人分布图形构建
    drawCommitPerson() {
      let commitPerson = echarts.init(document.getElementById('commitPerson'))

      commitPerson.setOption({
        title: {
          text: '提交人分布',
          left: 'center',
        },

        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b}: {c} ({d}%)',
        },

        legend: {
          left: 'center',
          top: '25',
          data: this.commitUser,
        },

        series: [
          {
            name: '访问来源',
            type: 'pie',
            radius: ['30%', '70%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center',
              },
            },

            hoverAnimation: false,
            labelLine: {
              normal: {
                show: false,
              },
            },

            data: this.commitUserData,
          },
        ],
      })
    },
    //提交代码趋势构建
    drawCommitCode() {
      let commitCode = echarts.init(document.getElementById('commitCode'))

      // 绘制图表
      commitCode.setOption({
        color: ['#3398DB'],
        title: {
          text: '需求状态分布图',
          left: 'center',
        },

        tooltip: {},
        xAxis: {
          data: this.commitCodeData.codeXAxis,
        },

        yAxis: {},
        series: [
          {
            //name: '需求',
            type: 'bar',
            barMaxWidth: 34,
            data: this.commitCodeData.codeYAxis,
            label: {
              normal: {
                show: false,
                position: 'inside',
              },
            },
          },
        ],
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.code-statistics {
  .code-title {
    color: #4a4a4a;
  }

  .graph {
    width: 100%;
    display: flex;
    justify-content: space-between;
    height: 400px;

    .graph-commiter {
      border: 1px solid #e8e8e8;
    }

    .graph-commit-code {
      border: 1px solid #e8e8e8;
    }
  }
  .code-empty {
    text-align: center;
  }
}

.line {
  width: 100%;
  height: 1px;
  border-bottom: 1px solid #ccc;
}
</style>
