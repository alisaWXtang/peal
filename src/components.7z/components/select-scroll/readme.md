# select scroll

time: 2021.4.28  
author: 陈小龙

## 说明

基于 element-ui select 组件，提供 滚动加载的 功能
