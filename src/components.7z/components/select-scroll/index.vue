<template>
  <el-select
    v-model="localValue"
    popper-class="select-scroll-container"
    v-bind="$attrs"
    @change="change"
    @visible-change="visibleChange"
  >
    <template>
      <li class="filter-search-container">
        <el-input
          ref="filterHandlePerson"
          v-model.trim="keyword"
          v-focus
          :placeholder="$attrs.placeholder || $t('搜索')"
          @keyup.native="handleSearch"
        ></el-input>
      </li>
    </template>

    <div
      class="infinite-list-wrapper  list-app infinite-list"
      v-infinite-scroll="getData"
      :infinite-scroll-distance="30"
      :infinite-scroll-disabled="finished || loading"
      :infinite-scroll-immediate="false"
    >
      <template v-if="$attrs.multiple && $attrs.clearAll">
        <el-option
          :label="$t('清除选中')"
          value=""
          @click.native="onClearAll"
        ></el-option>
      </template>
      <template v-if="$attrs.multiple && $attrs.pickAll">
        <el-option :label="$t('全部')" value="all"></el-option>
      </template>
      <slot :list="list">
        <el-option
          v-for="item in localList"
          :key="item[valueKey]"
          :label="item[labelKey]"
          :value="item[valueKey]"
        ></el-option>
      </slot>
      <p class="loading-container" v-if="loading">{{ $t(loadingText) }}</p>
      <p class="finished-container" v-if="finished && !loading">
        {{ localList.length ? $t(finishedText) : $t(emptyText) }}
      </p>
    </div>
  </el-select>
</template>

<script>
/**
 * @title 应用下拉框
 * @description 支持搜索，滚动获取
 * @author chenxiaolong
 * @date 2020.7.28
 */
import debounce from 'lodash/debounce'
export default {
  name: 'SelectScroll',
  model: {
    data: 'value',
    event: 'change',
  },
  props: {
    value: {
      type: [Array, String],
    },
    list: {
      type: [Array, Object],
      required: true,
    },
    load: {
      type: Function,
    },
    valueKey: {
      type: String,
      default: 'value',
    },
    labelKey: {
      type: String,
      default: 'label',
    },
    finished: {
      type: Boolean,
      required: true,
      desc: '是否结束',
    },
    finishedText: {
      type: String,
      required: false,
      default: '没有更多了',
    },
    loading: {
      type: Boolean,
      required: true,
      desc: '是否加载中',
    },
    loadingText: {
      type: String,
      default: '加载中...',
    },
    emptyText: {
      type: String,
      default: '暂无数据',
    },
    disable: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      keyword: '',
      localValue: '',
      localList: [],
    }
  },
  computed: {
    init() {
      return this.localList.length > 0
    },
    // current listeners，去掉 change 事件，因为 $listeners 和自己手写的 change 会同时执行
    currentListeners() {
      const listeners = {}
      this.$listeners &&
        Object.entries(this.$listeners).forEach(([key, handler]) => {
          if (key === 'change') {
            return
          }
          listeners[key] = handler
        })
      return listeners
    },
  },
  watch: {
    value: {
      handler(value) {
        if (this.multiple || this.$attrs.multiple) {
          this.localValue = Array.isArray(value)
            ? [...value]
            : value
            ? [value]
            : []
        } else {
          this.localValue = value
        }
      },
      immediate: true,
    },
    list: {
      handler(val) {
        this.localList = val
      },
      immediate: true,
    },
  },
  methods: {
    change(val) {
      if ((this.multiple || this.$attrs.multiple) && this.$attrs.pickAll) {
        if (val[val.length - 1] === 'all' || !val.length) {
          this.$nextTick(() => {
            this.localValue = ['all']
            this.$emit('change', this.localValue)
          })
        } else if (val.length > 1 && val[0] === 'all') {
          this.localValue.splice(0, 1)
          this.$emit('change', this.localValue)
        } else {
          this.$emit('change', val)
        }
      } else {
        this.$emit('change', val)
      }
    },
    visibleChange(visible) {
      if (!visible && this.keyword) {
        this.keyword = ''
        this.$emit('load', this.keyword, true)
        return
      }

      if (this.init) return
      this.$emit('load', this.keyword)
    },
    getData() {
      if (!this.init) return
      this.$emit('load', this.keyword)
    },
    handleSearch: debounce(function() {
      this.localList = []
      /**
       * @param 关键字
       * @param 是否重载
       */
      this.$emit('load', this.keyword, true)
    }, 300),
    onClearAll() {
      let value = ''
      if (this.$attrs.multiple) {
        if (this.$attrs.pickAll) {
          value = ['all']
        } else {
          value = []
        }
      }
      this.$emit('change', value)
    },
  },
}
</script>

<style lang="scss" scoped>
.infinite-list-wrapper {
  max-height: 355px;
  overflow: auto;
  @include scrollbal-common;

  .list-app {
    padding-left: 0;
  }

  p {
    font-size: 14px;
    margin: 5px 0;
    color: #999999;
    text-align: center;
  }
}

.filter-search-container {
  padding: 0 0 5px;
}
</style>

<style>
.select-scroll-container .el-scrollbar__wrap {
  max-height: 500px;
}
</style>
