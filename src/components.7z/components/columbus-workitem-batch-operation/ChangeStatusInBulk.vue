<template>
  <div class="sub-app-coteam">
    <el-dialog
      title="批量状态流转"
      :visible.sync="dialogShow"
      width="1200px"
      class="ChangeStatusInBulk"
      @close="close"
      @open="open"
      :modal="false"
    >
      <!-- 状态菜单栏 -->
      <el-menu
        :default-active="activeId"
        class="el-menu-demo"
        mode="horizontal"
        @select="id => (activeId = id)"
      >
        <el-menu-item
          v-for="item in statusList"
          :key="item.statusId"
          :index="`${item.statusId}`"
          >{{ item.statusName }} ({{
            listMap[item.statusId] | statusLength
          }})</el-menu-item
        >
      </el-menu>
      <!-- 批量流转按钮 -->
      <div class="btn-container">
        <!-- popover无法控制是否打开，所以用v-show控制是否显示，否则没有数据会报错-->
        <el-button
          v-show="!selectLength"
          type="primary"
          class="btn"
          @click="notice"
          >{{ $t('批量流转') }}</el-button
        >
        <StateFlow
          v-show="selectLength"
          :projectId="projectId"
          :statusId="statusId"
          :workItemType="workItemType"
          :workItemId="workItemIds"
          :bulk="true"
          @getStatusInfo="getStatusInfo"
        >
          <el-button type="primary" class="btn" @click="openStatusPop">{{
            $t('批量流转')
          }}</el-button>
        </StateFlow>
      </div>
      <!-- 数据表格 -->
      <el-table
        :data="tableData"
        height="425"
        highlight-current-row
        v-loading="loading"
        border
        class="multiple-table status-table"
        @selection-change="list => (select = list)"
        ref="multipleTable"
      >
        <el-table-column type="selection" width="55px" />
        <el-table-column label="ID" sortable sort-by="ID" width="180px">
          <template slot-scope="scope">
            <div
              class="clickAttr overflow"
              @click.stop="handleClickItem(scope.row, $event)"
            >
              {{ scope.row.id }}
            </div>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('标题')"
          min-width="300px"
          sortable
          show-overflow-tooltip
          sort-by="title"
        >
          <template slot-scope="scope">
            <div
              class="clickAttr overflow"
              @click.stop="handleClickItem(scope.row, $event)"
            >
              {{ scope.row.title }}
            </div>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('迭代')"
          sortable
          show-overflow-tooltip
          sort-by="sprint"
        >
          <template slot-scope="scope">
            <div class="overflow">{{ scope.row.display.sprint }}</div>
          </template>
        </el-table-column>
        <el-table-column :label="$t('优先级')" sortable sort-by="priority">
          <template slot-scope="scope">
            <div
              class="statusbox-list-common"
              :style="{ '--color': scope.row.bgColor }"
            >
              {{ scope.row.display.priority }}
            </div>
          </template>
        </el-table-column>
        <el-table-column
          :label="$t('当前处理人')"
          sortable
          width="140px"
          sort-by="assignUser"
        >
          <template slot-scope="scope">
            <div class="overflow">{{ scope.row.display.assignUser }}</div>
          </template>
        </el-table-column>
      </el-table>
    </el-dialog>
    <div v-if="show" class="custom-bg"></div>
  </div>
</template>

<script>
import StateFlow from '@/components/state-flow'
import { WORKITEMCONST } from '@/utils/constant'
export default {
  data() {
    return {
      loading: false,
      bgColorList: {
        1: {
          100: '#FA0B00', // p0
          90: '#FF9F90', // p1
          80: '#307FE2', // p2
          70: '#58C73B', // p3
        },
        2: {
          100: '#FA0B00', // p0
          90: '#FF9F90', // p1
          80: '#307FE2', // p2
          70: '#58C73B', // p3
        },
        3: {
          100: '#ff0000', //阻塞
          90: '#F6A71F', //严重
          80: '#758fc6', //普通
          70: '#52AC63', //轻微
        },
      }, //优先级背景颜色集合
      statusList: [], //状态列表
      activeId: null, // 当前激活的状态
      select: [], //勾选数据的集合
      listMap: {}, //每个状态下数据的集合
      workItemIds: '', //勾选数据的ID
      statusId: '', //勾选数据的状态ID
    }
  },
  components: {
    StateFlow,
  },
  props: {
    workItemType: {
      type: [String, Number],
      default: '',
    },
    projectId: {
      type: [String, Number],
      default: '',
      dec: '项目ID',
    },
    show: {
      type: Boolean,
      default: false,
      dec: '控制探矿是否显示',
    },
    list: {
      type: Array,
      default: _ => [],
      dec: '选择的需求的源数据',
    },
  },
  computed: {
    dialogShow: {
      get() {
        return this.show
      },
      set(val) {
        this.$emit('update:show', val)
      },
    },
    // 表格数据
    tableData({ listMap, activeId }) {
      return listMap[activeId] || []
    },
    // 显示流转状态弹框条件
    selectLength({ select }) {
      return select.length && select.length <= 50
    },
    // 获取优先级显示北京
    bgColor({ bgColorList, workItemType }) {
      return bgColorList[workItemType]
    },
  },
  filters: {
    // 获取该状态下的数据总数
    statusLength(list) {
      return list.length
    },
  },
  watch: {
    list(val) {
      this.loading = true
      this.listMap = {}
      this.statusList = []
      // 根据状态将传入的数据分类
      val.forEach(item => {
        if (this.listMap[item.statusId] === undefined) {
          this.listMap[item.statusId] = []
        }
        item.bgColor = this.bgColor[item.priority]
        this.listMap[item.statusId].push(item)
        // 添加状态信息
        this.statusList.push({
          statusId: item.statusId,
          statusName: item.detail.status.statusName,
          order: item.detail.status.order,
        })
      })
      // 去重
      const reduceKey = {}
      this.statusList = this.statusList.reduce((item, next) => {
        if (!reduceKey[next.statusId]) {
          reduceKey[next.statusId] = true && item.push(next)
        }
        return item
      }, [])
      // 根据order排序
      this.statusList.sort((current, next) => current.order - next.order)
      this.loading = false
    },
  },
  methods: {
    // 弹框关闭
    close() {
      this.select = []
      this.clearSelectIds()
      // 如果当前状态和默认状态一样，赋值为null重打开时才能触发计算属性
      if (this.statusList[0]?.statusId == this.activeId) {
        this.activeId = null
      }
    },
    // 打开弹框时默认选择第一个状态
    open() {
      this.activeId = `${this.statusList[0].statusId}`
    },
    // 点击按钮时做出提示
    notice() {
      const msgObj = {
        [WORKITEMCONST.workItemTypeMap.requirement]: '请选择需求',
        [WORKITEMCONST.workItemTypeMap.task]: '请选择任务',
        [WORKITEMCONST.workItemTypeMap.bug]: '请选择缺陷',
      }
      this.$message({
        message: this.select.length
          ? '单次操作最多50条'
          : msgObj[this.workItemType],
        type: 'warning',
      })
    },
    // 查看工作项详情
    handleClickItem(row, e) {
      this.$emit('seeTaskHandle', row.data, e)
    },
    // 打开状态流转弹框时，赋值状态ID和需要更改状态的需求的ID
    openStatusPop() {
      this.statusId = this.select[0].statusId || 0
      this.workItemIds = this.select.map(item => item.id)
    },
    // 清空选择数据的ID和工作项ID，清除勾选状态。
    clearSelectIds() {
      this.statusId = ''
      this.workItemId = []
      this.$refs.multipleTable.clearSelection()
    },
    // 状态流转成功回调函数 关闭弹框
    getStatusInfo(statusInfo) {
      this.$emit('updateSuccess')
      // 清空选择数据的ID和工作项ID，清除勾选状态。
      this.clearSelectIds()
      // 修改流转至的状态为当前展示的列表
      this.activeId = `${statusInfo.statusId}`
    },
  },
}
</script>

<style lang="scss" scoped>
/deep/ .ChangeStatusInBulk {
  z-index: 1090 !important;
  .el-menu-demo {
    .is-active,
    .el-menu-item :hover {
      color: $--color-primary !important;
    }
  }
  .el-dialog__header {
    padding: 0;
    margin-bottom: 32px;
    border: none;
    .el-dialog__title {
      font-size: 16px;
      color: #333;
      line-height: 24px;
    }
  }
  .el-dialog__body {
    padding: 0;
    .el-menu--horizontal > .el-menu-item {
      height: 40px;
      padding: 0 8px;
      margin-right: 16px;
      line-height: 40px;
      font-size: 14px;
      color: #666;
    }
    .btn-container {
      width: 80px;
      .btn {
        margin: 16px 0;
      }
    }
    .priority {
      width: 40px;
      height: 24px;
      line-height: 24px;
      text-align: center;
      border: 1px solid;
      border-radius: 4px;
      color: #fff;
    }
    .clickAttr {
      cursor: pointer;

      &:hover {
        color: $--color-primary;
      }
    }
    .overflow {
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }
  .el-dialog__footer {
    display: none;
  }
}
.custom-bg {
  width: 100vw;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  z-index: 1070;
  background: rgba(0, 0, 0, 0.5);
}

.status-table {
  /deep/ .gutter {
    width: 0;
    display: none;
  }
}
</style>
