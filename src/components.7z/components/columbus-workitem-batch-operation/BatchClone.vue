<template>
  <div>
    <el-dialog
      :title="$t(title)"
      :visible.sync="dialogVisible"
      width="550px"
      :append-to-body="true"
      custom-class="work-item-batch-clone"
      @closed="close"
    >
      <el-form :model="form" label-position="right" label-width="30%">
        <el-form-item
          required
          :label="
            `${$t(
              '复制',
            )}${$isEnglishDisplaySpace()}${workItemTypeName}${$isEnglishDisplaySpace()}${$t(
              '到',
            )}`
          "
        >
          <el-select
            v-model="form.toProjectId"
            value-key="id"
            :placeholder="$t('请选择目标项目')"
            :popper-append-to-body="true"
          >
            <el-option
              v-for="item in projectList"
              :key="item.id"
              :value="item.id"
              :label="
                item.name +
                  (item.id === +projectId ? `(${$t('当前项目')})` : '')
              "
              >{{ item.name
              }}{{
                item.id === +projectId ? `(${$t('当前项目')})` : ''
              }}</el-option
            >
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('创建人')">
          <el-radio v-model="form.keepCreateUser" :label="true"
            >{{ $t('保留原') }}{{ $isEnglishDisplaySpace()
            }}{{ workItemTypeName }}{{ $isEnglishDisplaySpace()
            }}{{ $t('的创建人') }}</el-radio
          >
          <el-radio v-model="form.keepCreateUser" :label="false"
            >{{ $t('我') }}({{ userInfo.userName }})</el-radio
          >
        </el-form-item>
        <el-form-item
          v-show="workItemType == 1"
          :label="$t('复制子需求和任务')"
        >
          <el-radio v-model="form.copyChild" :label="true">{{
            $t('是')
          }}</el-radio>
          <el-radio v-model="form.copyChild" :label="false">{{
            $t('否')
          }}</el-radio>
        </el-form-item>
        <el-form-item>
          <div class="tooltip notice">
            ({{ $t('注') }}：{{ $t('复制后的相关状态都为初始状态') }})
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer">
        <el-button @click="dialogVisible = false">{{ $t('取消') }}</el-button>
        <el-button type="primary" @click="saveCopy" :loading="loading">{{
          $t('开始复制')
        }}</el-button>
      </div>
    </el-dialog>

    <el-dialog
      :title="$t('复制进度')"
      :visible.sync="showCloneProgress"
      :close-on-click-modal="false"
      :append-to-body="true"
      :close-on-press-escape="false"
      :show-close="showClose"
      width="480px"
      @closed="cloneProgressClose"
    >
      <div class="clone-progress-container">
        <div class="progress-container">
          <div class="progress-bar">
            <el-progress
              type="circle"
              class="progress-circle"
              :percentage="percentage"
              :width="150"
              :color="color"
            ></el-progress>
          </div>
          <div class="progress-text">
            {{ $t('总共') }} {{ workItemIds.length }} {{ $t('条') }} /
            <span class="now-number" :class="{ 'error-text': cloneStatusError }"
              >{{ $t('当前复制第') }} {{ cloneStart + ' - ' + cloneEnd }}
              {{ $t('条') }}
            </span>
          </div>
        </div>
        <div class="alert-text">
          {{ $t('复制过程中关闭页面或刷新页面将会导致复制失败。') }}
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { cloneTitleMaps } from './constant'
import { mapState } from 'vuex'
import { workItemBatchClone } from '@/service/project'
// 每页处理数据条数
const PageSize = 10
export default {
  name: 'BatchClone',
  props: {
    show: {
      type: Boolean,
      default: false,
      desc: '是否显示',
    },
    workItemType: {
      type: Number,
      default: 1,
      desc: '工作项类型',
    },
    workItems: {
      type: Array,
      required: true,
      desc: '选择的工作项',
    },
  },
  data() {
    return {
      title: cloneTitleMaps[this.workItemType],
      form: {
        toProjectId: this.$route.query.projectId,
        keepCreateUser: true,
        copyChild: true,
      },
      projectId: this.$route.query.projectId,
      loadingObject: {
        getting: false,
        posting: false,
      },
      userInfo: this.$store.state.gd.userInfo,
      loading: false,
      cloneStatusError: false, // 复制失败
      showCloneProgress: false, // 是否显示复制进度
      percentage: 0, // 进度百分比
      cloneStart: 0, // 复制起始值
      cloneEnd: 0, // 复制结束值
      showClose: false, // 是否显示关闭图标
      color: '#3081F2',
    }
  },
  computed: {
    dialogVisible: {
      get() {
        return this.show
      },
      set(val) {
        this.$emit('update:show', val)
      },
    },
    ...mapState({
      cloneProjectList: state => state.workItemManage.cloneProjectList.list, // 获取进行中项目的列表信息
    }),
    projectList() {
      const projectList = [...this.cloneProjectList].filter(
        project => !project.completed,
      )

      // 如果之前选择过的项目不再列表中，则默认为当前项目
      if (!projectList.some(item => item.id === this.form.toProjectId)) {
        this.$set(this.form, 'toProjectId', +this.projectId)
      }
      return projectList
    },
    workItemTypeName() {
      const WorkItemTypeNameObj = {
        1: this.$t('需求'),
        2: this.$t('任务'),
        3: this.$t('缺陷'),
      }
      return WorkItemTypeNameObj[this.workItemType]
    },
    workItemIds() {
      return this.workItems.map(item => item.id)
    },
    // 计算多少页
    pages() {
      return Math.ceil(this.workItemIds.length / PageSize)
    },
  },
  created() {
    this.$store.dispatch('getWorkItemCloneProjectList', {
      type: this.workItemType,
    })
  },
  methods: {
    // 复制工作项
    async saveCopy() {
      if (!this.form.toProjectId) {
        this.$message.warning(this.$t('选择目标项目'))
        return
      }

      this.loading = true
      await this.progressClone()
      // 确保进度条动画完结
      setTimeout(() => {
        if (!this.cloneStatusError) {
          this.showCloneProgress = false
          this.$message.success(this.$t('复制成功'))
          this.dialogVisible = false
          this.$emit('update-data')
        }
      }, 300)
      this.loading = false
    },
    // 持续复制
    async progressClone() {
      this.showCloneProgress = true
      const pagesArr = [...new Array(this.pages).keys()]
      for (const page of pagesArr) {
        const start = (this.cloneStart = page * PageSize)
        let end = start + PageSize
        end = this.cloneEnd =
          end > this.workItemIds.length ? this.workItemIds.length : end
        let res = {}
        try {
          res = await workItemBatchClone({
            ...this.form,
            projectId: Number(this.projectId),
            ids: this.workItemIds.slice(start, end),
            workItemType: this.workItemType,
          })
        } catch (error) {
          res.status = 0
        }

        if (res.status !== 200) {
          this.showClose = true
          this.cloneStatusError = true
          this.color = '#ea3447'
          break
        }

        this.percentage = Math.floor((end / this.workItemIds.length) * 100)
      }
    },
    // 关闭复制进度
    cloneProgressClose() {
      this.cloneStart = 0
      this.cloneEnd = 0
      this.percentage = 0
      this.showClose = false
      this.color = '#3081F2'
      this.cloneStatusError = false
    },
    close() {
      this.loading = false
      this.form = {
        keepCreateUser: true,
        copyChild: true,
        toProjectId: this.projectId,
      }
    },
  },
}
</script>

<style lang="scss">
.work-item-batch-clone {
  .el-dialog__header {
    padding: 0;
  }
}
</style>

<style lang="scss" scoped>
.work-item-batch-clone {
  .notice {
    color: #bdbdbd;
  }
}

.clone-progress-container {
  text-align: center;

  .alert-text {
    margin-top: 10px;
    color: #cccccc;
  }

  .progress-text {
    margin-top: 20px;

    .now-number {
      color: $--color-primary;
      &.error-text {
        color: $--color-danger;
      }
    }
  }
}
</style>
