<template>
  <el-dialog
    :title="$t('批量编辑')"
    :visible.sync="dialogVisible"
    width="480px"
    :append-to-body="true"
    custom-class="custom-workitem-batch-operation"
    @close="close"
  >
    <div class="form-item" :title="$t(fieldTitle)">
      <div class="form-item__title">{{ $t(fieldTitle) }}</div>
      <el-select
        v-model="currentFieldKey"
        :placeholder="$t('选择属性')"
        @change="handleChange"
      >
        <el-option
          v-for="item in localFields"
          :key="item.attrName"
          :label="$t(item.fieldName)"
          :value="item.attrName"
        ></el-option>
      </el-select>
    </div>
    <div class="form-item">
      <div class="form-item__title">{{ $t('更改后的值') }}</div>
      <expect-hour
        v-if="
          (workItemType === workItemTypeMap.requirement ||
            workItemType === workItemTypeMap.task) &&
            ['expectHour', 'actualHour'].includes(currentField.attrName)
        "
        v-bind:hour.sync="currentField.value"
        class="workitem-basic-info-item-select-width"
        :isClearable="currentField.isClearable"
      >
      </expect-hour>
      <typed-form-item
        v-else
        :key="renderKey"
        v-model="currentField.value"
        :type="currentField.attrValue"
        v-bind="currentField.attrs"
        :select-list="currentField.selectList"
        :filter-field="currentField.filterField"
        :popper-append-to-body="currentField.popperAppendToBody"
        :is-clearable="currentField.isClearable"
        :is-assign-user="currentField.isAssignUser"
      ></typed-form-item>
    </div>

    <div slot="footer">
      <el-button @click="dialogVisible = false">{{ $t('取消') }}</el-button>
      <el-button type="primary" @click="handleSave" :loading="loading">{{
        $t('确定')
      }}</el-button>
    </div>
  </el-dialog>
</template>

<script>
/**
 * @title 批量编辑
 * @author chenxiaolong
 * @date 2021.02.05
 */
import TypedFormItem from '@/components/typed-form-item'
import cloneDeep from 'lodash/cloneDeep'
import { customFieldList } from '@/service/custom-field'
import { getUserListReq, workItemBatchEdit } from '@/service/project'
import { queryOptions } from '@/service/work-status-flow'
import { fieldTitleMaps, fieldMaps } from './constant'
import * as requirementCategoryService from '@/service/requirement-category'
import { projectHeaderFilterActionTypes } from '@/store/action-types'
import { priorityList } from '@/service/bug'
import ExpectHour from '@/components/expect-hour'
import { WORKITEMCONST } from '@/utils/constant'
import { isEmpty } from '@/utils'

export default {
  name: 'BatchEdit',
  components: {
    TypedFormItem,
    ExpectHour,
  },
  props: {
    show: {
      type: Boolean,
      desc: '是否显示',
    },
    workItemType: {
      type: Number,
      default: 1,
      desc: '工作项',
    },
    workItems: {
      type: Array,
      default: () => [],
      desc: '勾选的工作项',
    },
  },
  data() {
    return {
      currentFieldKey: '',
      currentField: {
        value: '',
      },
      localFields: [],
      projectId: this.$route.query.projectId,
      customFields: [],
      userList: [],
      hasChangeData: false,
      workItemTypeMap: WORKITEMCONST.workItemTypeMap,
      renderKey: Date.now() + Math.random(),
      loading: false,
    }
  },
  computed: {
    dialogVisible: {
      get() {
        return this.show
      },
      set(val) {
        this.$emit('update:show', val)
      },
    },
    fieldTitle() {
      return fieldTitleMaps[this.workItemType]
    },
    workItemIds() {
      return this.workItems.map(item => item.id)
    },
  },
  async created() {
    await this.getCustomFieldList()
    const fieldList = fieldMaps.filter(item =>
      item.workItemTypes.includes(this.workItemType),
    )
    this.localFields = [...cloneDeep(fieldList), ...this.customFields].map(
      item => {
        item.initValue = item.value

        return item
      },
    )
  },
  methods: {
    // 选择属性
    handleChange(val) {
      this.currentField = this.localFields.find(item => item.attrName === val)
      this.currentField.value = this.currentField.initValue
      this.getSelectList()
      this.renderKey = Date.now() + Math.random()
    },
    // 点击保存
    async handleSave() {
      const { value, dataSource, isCustom, attrName } = this.currentField

      if (!attrName) {
        this.$message.warning(this.$t('选择需要修改的属性'))
        return
      }

      this.loading = true
      const params = {
        projectId: this.projectId,
        ids: this.workItemIds,
        updateFields: [],
        workItemType: this.workItemType,
        clearFields: [],
        userDefinedAttrs: {},
      }

      if (isCustom) {
        params.userDefinedAttrs[attrName] = value
        params.updateFields = [attrName]
      } else {
        params.updateFields = [dataSource]
        params[dataSource] = value
      }

      if (
        dataSource === 'sprintId' &&
        this.workItemType === WORKITEMCONST.workItemTypeMap.requirement
      ) {
        params.updateSubSprint = false
      }

      const valid = this.invalidField(params)

      if (valid === false) {
        this.loading = false
        return
      }

      workItemBatchEdit(params)
        .then(res => {
          if (res.status === 200) {
            this.hasChangeData = true
            this.$message.success(
              this.$t(`修改${this.currentField.fieldName}成功`),
            )
            this.dialogVisible = false
          }
        })
        .finally(() => {
          this.loading = false
        })
    },
    invalidField(params) {
      const { attrName, value } = this.currentField
      // 特殊字段处理 1 progress 检测
      const localValue = Number(value).toFixed(1)
      if (attrName === 'progress') {
        const tofixed = /^(\d{1,2}(\.\d{1})?|100)$/ // 匹配最多一位小数
        if (!tofixed.test(value) && !isEmpty(value)) {
          this.$message({
            showClose: true,
            message: this.$t('进度只能在0到100之间且只保留一位小数'),
            type: 'warning',
          })

          return false
        }

        this.$nextTick(() => {
          this.currentField.value =
            localValue > 100 ? 100 : localValue < 0 ? 0 : localValue
          // 第二次：是为了改变 v-model 绑定的值，对其他地方没有影响
        })
        params[attrName] = localValue
      }
    },
    // 关闭dialog回调
    close() {
      this.currentField = {}
      this.currentFieldKey = ''
      this.hasChangeData && this.$emit('update-data')
      this.hasChangeData = false
      this.loading = false
    },
    // 获取人员列表
    async getUserList() {
      const res = await getUserListReq({
        workItemType: this.workItemType,
        projectId: this.projectId,
      })

      if (res.status === 200 && res.data) {
        this.userList = res.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
          }
        })
      }
    },
    // 获取自定义字段
    async getCustomFieldList() {
      const res = await customFieldList({
        projectId: this.projectId,
        workItemType: this.workItemType,
        onlyEnabled: false,
      })

      if (res.status === 200 && res.data?.attrs) {
        this.customFields = res.data.attrs.map(item => {
          if (
            [
              'MULTI_MEMBER_CHOICE',
              'MEMBER_CHOICE',
              'MULTI_CHOICE',
              'CHECKBOX',
              'SINGLE_CHOICE',
            ].includes(item.attrValue)
          ) {
            item.selectList = []
          }

          item.isAssignUser = ['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(
            item.attrValue,
          )
          item.value = ''
          item.key = item.attrName
          item.isCustom = true
          item.popperAppendToBody = true

          return item
        })
      }
    },
    // 获取属性的候选项
    async getSelectList() {
      const isTime = new Set(['startTimes', 'endTimes', 'finishTimes']).has(
        this.currentField.attrName,
      )
      const { formType, isCustom, attrName, attrValue } = this.currentField

      if (!isTime) {
        if (attrName === 'category') {
          await this.getCategoryList()
        } else if (attrName === 'sprintIds') {
          await this.getSprintList()
        } else if (attrName === 'prioritys') {
          await this.priorityList()
        } else if (
          attrName === 'assignUsers' ||
          ['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(attrValue)
        ) {
          await this.getUserList()
          this.currentField.selectList = this.userList
        } else if (
          formType === 'SELECT' ||
          (isCustom &&
            ['MULTI_CHOICE', 'CHECKBOX', 'SINGLE_CHOICE'].includes(attrValue))
        ) {
          await this.queryOptions()
        }
      }
    },
    // 获取分类
    async getCategoryList() {
      const res = await requirementCategoryService.tree({
        projectId: this.projectId,
      })

      if (res.status === 200 && res.data) {
        function getAllCategoryList(list) {
          return list.map(({ label, id, children }) => ({
            label,
            value: id + '',
            key: id,
            children:
              children.length === 0 ? null : getAllCategoryList(children),
          }))
        }
        this.currentField.selectList = getAllCategoryList(res.data)
      }

      this.currentField.attrs.loading = false
    },
    // 获取迭代列表
    async getSprintList() {
      await this.$store.dispatch(
        projectHeaderFilterActionTypes.GET_FILTER_HEADER_SPRINT_LIST,
        {
          projectId: this.projectId,
          includeUnplanned: true,
        },
      )

      const selectList =
        this.$store.state.projectCommonHeaderFilter.filterSprintList.find(
          item => item.id === 'unarchived',
        )?.children || []
      this.currentField.selectList = selectList.map(item => {
        return {
          ...item,
          key: item.id,
          value: item.name,
        }
      })

      this.currentField.attrs.loading = false
    },
    // 优先级列表
    async priorityList() {
      const res = await priorityList({
        workItemType: this.workItemType,
        projectId: this.projectId,
      })

      if (res.status === 200 && res.data) {
        this.currentField.selectList = res.data.map(item => {
          return {
            ...item,
            key: item.priority,
            value: item.literal,
          }
        })
      }
      this.currentField.attrs.loading = false
    },
    // 查询下拉选项
    async queryOptions() {
      const res = await queryOptions({
        projectId: this.projectId,
        workItemType: this.workItemType,
        attrName: this.currentField.dataSource || this.currentField.attrName,
      })

      if (res.status === 200 && res.data) {
        const selectList = res.data.map(item => {
          if (
            ['assignUsers', 'createUsers', 'relevantUsers'].includes(
              this.currentField.attrName,
            )
          ) {
            return {
              ...item,
              key: item.userId,
              value: `${item.userName}(${item.userId})`,
            }
          } else if (
            ['projectIds', 'sprintIds'].includes(this.currentField.attrName)
          ) {
            return {
              ...item,
              key: item.id,
              value: item.name,
            }
          } else if (['defectStatusIds'].includes(this.currentField.attrName)) {
            return {
              ...item,
              key: item.statusId,
              value: item.statusName,
            }
          } else {
            return {
              ...item,
              key: item.value,
              value: item.label,
            }
          }
        })
        this.$set(this.currentField, 'selectList', selectList)
      }

      this.currentField.attrs && (this.currentField.attrs.loading = false)
    },
  },
}
</script>

<style lang="scss">
.custom-workitem-batch-operation {
  .el-dialog__header {
    padding: 0;
  }
}
</style>

<style lang="scss" scoped>
.form-item {
  margin-bottom: 16px;

  /deep/ .el-date-editor,
  /deep/ .el-cascader {
    width: 100%;
    position: relative;
    line-height: normal;
  }

  .form-item__title {
    font-size: 14px;
    padding-bottom: 5px;
    color: $--color-text-regular;
  }
}
</style>
