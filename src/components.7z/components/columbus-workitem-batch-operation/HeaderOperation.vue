<template>
  <div class="work-item-batch-operation" v-show="show">
    <div class="operation-container">
      <div class="checkbox">
        <el-checkbox
          v-model="allChecked"
          size="small"
          :indeterminate="!allChecked"
          @change="val => $emit('checkbox-change', val)"
        ></el-checkbox>
      </div>
      <div class="count-container">
        {{ $t('已选择') }} <span class="count">{{ checkItems.length }}</span>
        {{ $t('项')
        }}<span class="tooltip">({{ $t('单次操作最多200条') }})</span>
      </div>
      <div
        class="operation-item"
        :class="{ disable: disable || !editAble }"
        :title="!editAble ? $t('暂无权限') : ''"
      >
        <div class="text-container" @click="showEdit = true">
          <i class="el-icon-edit-outline"></i>
          {{ $t('批量编辑') }}
        </div>
      </div>
      <!-- <div class="operation-item" :class="{ disable: disable || !editAble }">
        <div
          class="text-container"
          @click="() => $emit('handleChangeRequire', true)"
        >
          <i
            class="el-icon-document-checked
"
          ></i>
          {{ $t("更改父需求") }}
        </div>
      </div> -->
      <div
        class="operation-item"
        :class="{ disable: disable || !editAble }"
        :title="!editAble ? $t('暂无权限') : ''"
      >
        <div class="text-container" @click="showStatus = true">
          <i class="iconfont icon-jurassic_process"></i>
          {{ $t('状态流转') }}
        </div>
      </div>
      <div
        class="operation-item"
        :class="{ disable: disable || !deleteAble }"
        :title="!deleteAble ? $t('暂无权限') : ''"
      >
        <div class="text-container" @click="handleDelete">
          <i class="el-icon-delete"></i>
          {{ $t('删除') }}
        </div>
      </div>
      <div
        class="operation-item"
        :class="{ disable: disable || !createAble }"
        :title="!createAble ? $t('暂无权限') : ''"
      >
        <div class="text-container" @click="showClone = true">
          <i class="el-icon-document-copy"></i>
          {{ $t('复制') }}
        </div>
      </div>
    </div>

    <batch-edit
      :work-item-type="workItemType"
      :show.sync="showEdit"
      :workItems="checkItems"
      @update-data="$emit('update-data')"
    ></batch-edit>
    <batch-clone
      :work-item-type="workItemType"
      :show.sync="showClone"
      :workItems="checkItems"
      @update-data="$emit('update-data')"
    ></batch-clone>
    <change-status-in-bulk
      :show.sync="showStatus"
      :projectId="projectId"
      @seeTaskHandle="(data, e) => $emit('seeTaskHandle', data, e)"
      :list="checkItems"
      :workItemType="workItemType"
      @updateSuccess="$emit('update-data')"
    ></change-status-in-bulk>
  </div>
</template>
<script>
/**
 * @title 批量操作头部
 * @author chenxiaolong
 * @date 2021.02.04
 */
import BatchEdit from './BatchEdit'
import BatchClone from './BatchClone'
import { WORKITEMCONST } from '@/utils/constant'
import { queryWorkStautsFow } from '@/service/work-status-flow'
import {
  editPermissions,
  deletePermissions,
  createPermissions,
} from './constant'
import debounce from 'lodash/debounce'
import ChangeStatusInBulk from './ChangeStatusInBulk'
import {
  batchRequirementDelete,
  batchTaskDelete,
  batchBugDelete,
} from '@/service/project'

export default {
  name: 'HeaderOperation',
  components: {
    BatchEdit,
    BatchClone,
    ChangeStatusInBulk,
  },
  props: {
    workItemType: {
      type: Number,
      default: 1,
      desc: '工作项类型 1 需求 2 任务 3 缺陷 4迭代',
    },
    isAllChecked: {
      type: Boolean,
      default: false,
      desc: '是否全选',
    },
    checkItems: {
      type: [Array, Object],
      default: () => [],
      desc: '已勾选的工作项',
    },
  },

  data() {
    return {
      count: 0,
      allChecked: this.isAllChecked,
      showEdit: false,
      showClone: false,
      showStatus: false,
      projectId: this.$getUrlParams().projectId,
      statusMaps: {
        // 工作项完成状态id
        REQT_ONLINE: [],
        TASK_COMPLETED: [],
        BUG_END: [],
      },
      confirmInstance: null,
    }
  },
  computed: {
    show() {
      return Object.keys(this.checkItems).length > 0
    },
    disable() {
      return this.checkItems.length > 200
    },
    editAble() {
      return this.$authFunction(
        editPermissions[this.workItemType],
        3,
        this.projectId,
      )
    },
    deleteAble() {
      return this.$authFunction(
        deletePermissions[this.workItemType],
        3,
        this.projectId,
      )
    },
    createAble() {
      return this.$authFunction(
        createPermissions[this.workItemType],
        3,
        this.projectId,
      )
    },
    workItemIds() {
      return this.checkItems.map(item => item.id)
    },
  },
  watch: {
    isAllChecked() {
      this.allChecked = this.isAllChecked
    },
    checkItems(val) {
      if (this.disable) {
        this.alertFunc()
      }
    },
  },
  created() {
    this.alertFunc = debounce(() => {
      this.$message.warning(this.$t('单次操作最多50条'))
    }, 300)
    this.getStatusAllList()
  },
  beforeDestroy() {
    // 路由跳转时没有关闭confirm
    try {
      this.$msgbox.close()
      if (this.confirmInstance) {
        this.confirmInstance.confirmButtonLoading = false
        this.confirmInstance.confirmButtonText = this.$t('仍要删除')
      }
    } catch (_) {}
  },
  methods: {
    async getStatusAllList() {
      const res = await Promise.all([
        this.getStatusList(WORKITEMCONST.workItemTypeMap.requirement),
        this.getStatusList(WORKITEMCONST.workItemTypeMap.task),
        this.getStatusList(WORKITEMCONST.workItemTypeMap.bug),
      ])

      if (res[0]?.status === 200 && res[0]?.data) {
        for (let index = 0; index < res.length; index++) {
          const element = res[index]
          if (index === 0) {
            element.data.defs.forEach(data => {
              if (data.stage === 'REQT_ONLINE') {
                this.statusMaps.REQT_ONLINE.push(data.statusId)
              }
            })
          }

          if (index === 1) {
            element.data.defs.forEach(data => {
              if (data.stage === 'TASK_COMPLETED') {
                this.statusMaps.TASK_COMPLETED.push(data.statusId)
              }
            })
          }

          if (index === 2) {
            element.data.defs.forEach(data => {
              if (data.stage === 'End') {
                this.statusMaps.BUG_END.push(data.statusId)
              }
            })
          }
        }
      }
    },
    // 删除
    handleDelete() {
      const statusIds = this.checkItems.map(item => item.statusId)
      const computedTitle = this.computedDeleteTitle(statusIds)
      this.$confirm(computedTitle.title, {
        showCancelButton: !computedTitle.intersection,
        showConfirmButton: !computedTitle.intersection,
        confirmButtonText: this.$t('仍要删除'),
        cancelButtonText: this.$t('取消'),
        type: 'warning',
        closeOnClickModal: false,
        beforeClose: async (action, instance, done) => {
          if (action === 'confirm') {
            this.confirmInstance = instance
            instance.confirmButtonLoading = true
            instance.confirmButtonText = this.$t('执行中...')
            await this.deleteWorkItems()
            instance.confirmButtonLoading = false
            instance.confirmButtonText = this.$t('仍要删除')
            done()
          } else {
            done()
          }
        },
      })
    },
    // 删除工作项
    async deleteWorkItems() {
      const urlObj = {
        [WORKITEMCONST.workItemTypeMap.requirement]: batchRequirementDelete,
        [WORKITEMCONST.workItemTypeMap.task]: batchTaskDelete,
        [WORKITEMCONST.workItemTypeMap.bug]: batchBugDelete,
      }

      let res = {}
      try {
        res = await urlObj[this.workItemType](this.workItemIds)
      } catch (error) {
        res.status = 0
      }

      if (res.status === 200) {
        this.$message.success(this.$t('删除成功'))
        this.$emit('update-data')
      }
    },
    // 获取所有状态
    getStatusList(workItemType) {
      return queryWorkStautsFow({
        projectId: this.projectId,
        workItemType,
      })
    },
    // 计算删除提示语
    computedDeleteTitle(statusIds) {
      let intersection = false
      let title = ''
      if (this.workItemType === WORKITEMCONST.workItemTypeMap.requirement) {
        const set = new Set(this.statusMaps.REQT_ONLINE)
        intersection = statusIds.filter(v => set.has(v)).length

        if (intersection) {
          title = this.$t('勾选的需求存在状态已完成，不能删除，请重新勾选！')
        } else {
          title = this.$t(
            '勾选的需求将被删除，其所有子需求以及任务均会一并删除，请确认！',
          )
        }
      } else if (this.workItemType === WORKITEMCONST.workItemTypeMap.task) {
        const set = new Set(this.statusMaps.TASK_COMPLETED)
        intersection = statusIds.filter(v => set.has(v)).length

        if (intersection) {
          title = this.$t('勾选的任务存在状态已完成的，不能删除，请重新勾选！')
        } else {
          title = this.$t('勾选的任务将被删除，请确认！')
        }
      } else {
        title = this.$t('勾选的缺陷将被删除，请确认！')
      }

      return {
        title,
        intersection: Boolean(intersection),
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.tooltip {
  color: #999999;
}

.work-item-batch-operation {
  position: absolute;
  z-index: 3;
  top: 0;
  left: 0;
  right: 0;
  background-color: $--background-gray;
  box-shadow: 0 2px 4px 0 rgba(12, 37, 77, 0.08), inset 0 -1px 0 0 #f1f4f9;

  .operation-container {
    padding: 18px 25px 17px 16px;
    display: flex;
    align-items: center;
    color: #333333;
    overflow-x: auto;
    @include scrollbal-common;

    .checkbox {
      margin-right: 24px;
      flex: 0 0 auto;
    }

    .count-container {
      margin-right: 49px;
      flex: 0 0 auto;

      .count {
        color: $--color-primary;
      }
    }

    .operation-item {
      cursor: pointer;
      margin-right: 49px;
      flex: 0 0 auto;

      &.disable {
        cursor: not-allowed;
        color: #999999;

        .text-container {
          pointer-events: none;
        }
      }

      &:not(.disable):hover {
        color: $--color-primary;
      }

      i {
        margin-right: 6px;
        font-size: 14px;
      }
    }
  }
}
</style>
