<template>
  <el-table
    ref="multipleTable"
    border
    class="tree-table multiple-table"
    :data="formatData"
    :row-class-name="tableRowClassName"
    v-bind="$attrs"
    :highlight-current-row="true"
    :span-method="colSpanMethod"
    :default-expand-all="expandAll"
    @selection-change="handleSelectionChange"
    @sort-change="sortaChangeCallBack"
    @click.stop
  >
    <template v-if="formatData[0] && formatData[0].isNewAdd && isChecked">
      <slot name="createCtx"></slot>
    </template>
    <el-table-column
      v-if="isChecked"
      type="selection"
      :reserve-selection="!!$attrs['row-key']"
      width="24"
      :selectable="selectableFunction"
    />
    <el-table-column key="1" width="84" label="ID">
      <template slot-scope="scope">
        <span @mousedown.stop>
          <el-link
            :underline="false"
            class="c-blue-hover"
            @click="handleClickItem(scope.row, $event)"
          >
            {{ getId(scope.row) }}
          </el-link>
          <slot v-if="scope.row.isNewAdd" name="createCtx" />
        </span>
      </template>
    </el-table-column>
    <el-table-column
      key="2"
      prop="title"
      :sortable="titleSortable ? 'custom' : false"
      show-overflow-tooltip
      min-width="280px"
    >
      <template #header>
        <i
          v-if="isCanChangeExpand"
          class="title-icon iconfont"
          :class="expandAll ? 'icon-minus' : 'icon-plus-1'"
          @click.stop="changeExpand(!expandAll)"
        ></i>
        {{ $t('标题') }}
      </template>
      <template slot-scope="scope">
        <global-input
          v-if="!scope.row.isNewAdd"
          :scope="scope"
          :init-value="getTitle(scope.row)"
          :on-change="
            value => {
              updateGlobalTitle(scope.row, value)
            }
          "
        >
          <span slot class="table-input-edit-text c-blue-hover">
            <span
              v-for="space in scope.row._level"
              :key="space"
              class="ms-tree-space"
            />
            <span
              v-if="iconShow(0, scope.row)"
              class="tree-ctrl"
              @click="toggleExpanded(scope.$index)"
            >
              <i v-if="!scope.row._expanded" class="el-icon-plus" />
              <i v-else class="el-icon-minus"></i>
            </span>
            <span
              class="cp c-blue-hover"
              @click="handleClickItem(scope.row, $event)"
              @mousedown.stop
            >
              <span
                :class="getWorkItemType(scope.row.data)"
                class="c-table-icon cp"
              />
              <span>{{ getTitle(scope.row) }}</span>
            </span>
          </span>
          <el-tooltip
            v-if="scope.row && scope.row.display && scope.row.display.delayed"
            class="item item-past-due"
            effect="dark"
            :content="$t('已过期')"
            placement="top-start"
          >
            <i class="el-icon-warning warning" />
          </el-tooltip>
        </global-input>
      </template>
    </el-table-column>
    <!-- columns 暂时用不着 -->
    <el-table-column
      v-for="(column, index) in columns"
      :key="column.value"
      show-overflow-tooltip
      :label="column.text"
      :width="column.width"
    >
      <template slot-scope="scope">
        <!-- <span v-for="space in scope.row._level" v-if="index === 0" :key="space" class="ms-tree-space"/> -->
        <span
          v-if="iconShow(index, scope.row)"
          class="tree-ctrl"
          @click="toggleExpanded(scope.$index)"
        >
          <i v-if="!scope.row._expanded" class="el-icon-plus" />
          <i v-else class="el-icon-arrow-down-solid" />
        </span>
        {{ scope.row[column.value] }}
      </template>
    </el-table-column>
    <slot></slot>
  </el-table>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * 树形数据展示组件 - 需求列表
 * 1. 可配置是否启动，传入 pageInfo 即可启动
 * 2. 适用于分页列表，外部分页，服务器获取数据请求带有分页
 * 实现原理：
 * 1. 保存数据方式：向下滚动，增加一页数据；向上滚动，则更新已有数据，删除 pageNumber + 1 之后的数据
 * 2. window.pageYOffset 保存滚动位置
 * 3. emit 分页请求：滚动到底部，则 emit 分页 + 1；滚动到顶部，则采用缓存数据
 * author: heyunjiang
 * time: 2019.12.31
 */
import treeToArray from './eval'
import GlobalInput from '@/components/field-edit/GlobalInput.vue'
export default {
  name: 'TreeTable',
  components: {
    GlobalInput,
  },

  props: {
    /* eslint-disable */
    data: {
      type: [Array, Object],
      required: false,
    },

    columns: {
      type: Array,
      default: () => [],
    },

    evalFunc: Function,
    evalArgs: Array,
    // multipleSelection: Array,
    expandAll: {
      type: Boolean,
      default: false,
    },

    isChecked: {
      type: Boolean,
      default: true,
    },

    jumpPage: {
      type: String,
      default: null,
    },

    ltype: {
      type: Number,
      default: null,
    },

    updateGlobalTitle: {
      type: Function,
      required: true,
    },

    sortaChangeCallBack: {
      type: Function,
      required: false,
      default: () => {},
    },

    pageInfo: {
      type: Object,
      required: false,
      desc: '分页信息',
    },

    titleSortable: {
      type: Boolean,
      required: false,
      default: false,
    },

    isCanChangeExpand: {
      type: Boolean,
      required: false,
      default: false,
    },
  },

  data() {
    return {
      multipleSelection: [],
      // 无限滚动
      tableObserver: null, // 监听对象
      headTr: null, // 首部 tr ，用于控制 height
      footerTr: null, // 尾部 tr, 用于控制 height
      trHeight: 34, // tr 高度
      formatData: [], // 当前渲染的数据源
      scrollDirection: 'down', // 上一次滚动方向
      lastWindowPageYOffset: 0, // 上一次浏览器 pageYOffset 的距离
      activePageNumbers: [], // 当前活跃的页数
      pageTrCount: {}, // 每页缓存数据，包含 count, cacheList
      isPageNotChange: true, // data 更新时，分页是否变化
      currentTableSelectId: '', //当前行id,主要用于更新数据时，列表更新不会选中当前行问题
    }
  },
  computed: {
    // 格式化数据源
    formatDataPre: function() {
      return this.formatDataPreComputed(this.data)
    },
    // 无限滚动 - 是否已经到达底部
    isScrollBottom() {
      return (
        this.pageInfo &&
        this.pageInfo.totalPages &&
        this.activePageNumbers[this.activePageNumbers.length - 1] ===
          this.pageInfo.totalPages
      )
    },
    // 无限滚动 - 是否已经到达底部提示文字
    isScrollBottomText() {
      return this.isScrollBottom
        ? i18n.t('没有更多了')
        : `${i18n.t('数据加载中')}...`
    },
  },

  mounted() {
    this.initTableInfinitieScroll()
    this.initSetTableSelect()
  },
  watch: {
    // 无限滚动
    formatDataPre() {
      this.formatDataComputed(this.formatDataPre)
      this.tdNoticeUpdate()
    },
    formatData: {
      handler(newValue) {
        if (newValue.length && this.$store.state.st.requireSelectedId) {
          this.setTableSelect(newValue)
        }
      },
    },
  },

  methods: {
    // 格式化数据
    formatDataPreComputed(data, pageNumber) {
      if (!data) {
        return []
      }
      let tmp
      if (!Array.isArray(data)) {
        tmp = [data]
      } else {
        tmp = data
      }
      const func = this.evalFunc || treeToArray
      const args = this.evalArgs
        ? [].concat([tmp, this.expandAll], this.evalArgs)
        : [tmp, this.expandAll]
      const result = func.apply(null, args)
      if (this.pageInfo) {
        result.forEach(item => {
          item.pageNumber = pageNumber || this.pageInfo.pageNumber
          Object.assign(item, item.data)
        }) // 增加每个数据的所属 pageNumber
      }
      return result
    },
    async changeExpand(value) {
      const selectIds = new Set(
        this.$refs.multipleTable.selection.map(item => item.id),
      )
      this.$emit('change-expand', value)
      this.formatData.forEach((item, index) => {
        this.formatData[index]._expanded = value
      })
      await this.$nextTick()
      this.$refs.multipleTable.store.states.selection = this.formatData.filter(
        item => selectIds.has(item.id),
      )
      this.$refs.multipleTable.store.updateAllSelected()
      await this.$refs.multipleTable.$nextTick()
      this.multipleSelection = this.$refs.multipleTable.store.states.selection
      this.$emit('selection-change', this.multipleSelection)
    },
    tableRowClassName: function(row, index) {
      if (!row.row._show) {
        return 'hidden-row'
      }
      return 'display-row'
    },
    // 无限滚动 - 数据重置 - 用于恢复默认数据
    tableInfinitedReset() {
      if (this.footerTr.childNodes.length > 0) {
        this.footerTr.removeChild(this.footerTr.childNodes[0])
      }
      this.pageTrCount = {}
      this.scrollDirection = 'down'
      this.activePageNumbers = [1]
      this.lastWindowPageYOffset = 0
    },
    // 无限滚动 - 初始化 tableObserver 对象，插入顶部 tr 节点
    initTableInfinitieScroll() {
      this.tableObserver = new IntersectionObserver(this.scrollHandle)
      // header tr
      const headerTr = document.createElement('tr')
      this.headTr = headerTr
      // footer tr
      const footerTr = document.createElement('tr')
      this.footerTr = footerTr

      this.$refs.multipleTable.$el
        .querySelector('.el-table__body-wrapper tbody')
        .prepend(headerTr)
      this.$refs.multipleTable.$el
        .querySelector('.el-table__body-wrapper tbody')
        .append(footerTr)
    },
    // 无限滚动 - 顶部、底部提示内容更新
    tdNoticeUpdate() {
      if (this.pageInfo && this.pageInfo.totalRecords === 0) {
        return
      }
      const footerTd = document.createElement('td')
      footerTd.setAttribute('colspan', '1000')
      footerTd.style = `height: ${this.trHeight}px; line-height: ${this.trHeight}px; text-align: center;color: #909399;border-width: 0;background-color: #FFFFFF !important;`
      footerTd.append(this.isScrollBottomText)

      if (this.footerTr.childNodes.length > 0) {
        this.footerTr.replaceChild(footerTd, this.footerTr.childNodes[0])
      } else {
        this.footerTr.append(footerTd)
      }
    },
    // 无限滚动 - 监听特定对象
    initObserver() {
      this.$nextTick(() => {
        const observerTrs = this.$refs.multipleTable.$el
          .querySelector('.el-table__body-wrapper')
          .querySelectorAll('tr')
        // 先停止对所有目标的监控
        this.tableObserver.disconnect()
        // 监控特定目标
        const topPageNumber =
          this.activePageNumbers.length > 1
            ? this.activePageNumbers[this.activePageNumbers.length - 2]
            : 1
        const hiddenPageNumbers = Object.keys(this.pageTrCount).filter(item => {
          return item < topPageNumber
        })
        const hiddenTrCount =
          hiddenPageNumbers.length > 0
            ? hiddenPageNumbers.reduce((total, current) => {
                return this.pageTrCount[current].count + total
              }, 0)
            : 0
        this.tableObserver.observe(observerTrs[hiddenTrCount + 1])
        this.tableObserver.observe(observerTrs[observerTrs.length - 2])
      })
    },
    // 无限滚动 - 滚动事件处理
    scrollHandle(entry) {
      // 初始的时候不执行
      if (entry.length === 2 || this.formatData.length === 1) {
        return
      }
      const { isIntersecting, target } = entry[0]
      if (!target || !target.parentNode) {
        return
      }
      const observerTrs = target.parentNode.querySelectorAll('tr')
      if (isIntersecting) {
        let next = this.activePageNumbers[this.activePageNumbers.length - 1]
        // this.lastWindowPageYOffset = window.pageYOffset; // 缓存之前滚动的节点位置
        if (target.isSameNode(observerTrs[observerTrs.length - 2])) {
          // 到达底部
          this.scrollDirection = 'down'
          this.$emit('scrollBottom', next + 1)
        } else {
          // // 到达顶部
          // next = next - 2
          // this.scrollDirection = 'up'
          // // this.$emit('scrollTop', next); // 向上滚动，则不拿新数据
          // // 向上滚动，如果有缓存数据，则采用缓存数据，解决用户白屏问题
          // if (this.pageTrCount[next]) {
          //   this.formatDataComputed(this.pageTrCount[next].cacheList)
          // }
        }
        this.tdNoticeUpdate()
      }
    },
    // 无限滚动 - 当前渲染的数据源
    formatDataComputed(formatDataPre = []) {
      // 如果不带分页，则直接返回全部数据
      if (!this.pageInfo) {
        this.formatData = formatDataPre
        return
      }
      const pageNumber =
        formatDataPre.length > 0
          ? formatDataPre[0].pageNumber
          : this.pageInfo.pageNumber
      this.pageTrCount[pageNumber] = {
        count: formatDataPre.length,
        cacheList: formatDataPre,
      }
      // 更新每页对应数据
      let curentList = [] // 默认获取到当前展示的所有数据
      this.isPageNotChange = this.activePageNumbers.includes(pageNumber) // 是否分页没有变化
      // 1 如果分页没有变化，表示更新当前已有数据
      if (this.isPageNotChange) {
        for (let i = 1; i <= pageNumber + 1; i++) {
          if (this.pageTrCount[i]) {
            curentList = [...curentList, ...this.pageTrCount[i].cacheList]
          }
        }
      } else {
        // 2 如果是在尾部增加数据
        curentList = [...this.formatData, ...formatDataPre]
      }
      // 3 list 去重
      // let ids = [...new Set(curentList.map(item => item.id))];
      // !this.isPageNotChange && (curentList = curentList.reverse())
      // curentList = ids.map(item => {
      //   return curentList.find(jtem => jtem.id === item);
      // })
      // 4 列表赋值
      this.formatData = this._ArrayUnique(curentList, 'id')
      // 5 更新当前活跃页数
      this.activePageNumbers = [
        ...new Set(curentList.map(item => item.pageNumber)),
      ].sort((a, b) => a - b)

      this.$nextTick(() => {
        this.initObserver()
        if (this.isPageNotChange) {
          return
        }
        // window.scrollTo(0, this.lastWindowPageYOffset);
      })
    },
    // 无限滚动 - 数组去重
    _ArrayUnique(arr, key) {
      let hashTable = {}
      let newArr = []
      for (let i = 0, l = arr.length; i < l; i++) {
        if (!hashTable[arr[i][key]]) {
          hashTable[arr[i][key]] = true
          newArr.push(arr[i])
        }
      }
      return newArr
    },
    // 控制 td rowspan - 用于场景：首行快速创建
    colSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (rowIndex === 0 && row.isNewAdd) {
        if (columnIndex === 0) {
          return [1, 1000]
        } else {
          return [0, 0]
        }
      }
    },
    getWorkItemType(row) {
      if (row != undefined) {
        if (row && row.workItemType == 1) {
          return 'iconfont icon-xuqiu'
        } else if (row && row.workItemType == 2) {
          return 'iconfont icon-task'
        } else if (row && row.workItemType == 3) {
          return 'iconfont icon-bug'
        }
      }
    },
    getId(data) {
      if (data.id) {
        return data.id
      } else if (data.data && data.data.id) {
        return data.data.id
      } else if (data.display && data.display.id) {
        return data.display.id
      } else {
        return ''
      }
    },
    getTitle(data) {
      if (data.title) {
        return data.title
      } else if (data.display && data.display.title) {
        return data.display.title
      } else if (data.data && data.data.title) {
        return data.data.title
      } else {
        return ''
      }
    },
    indexHandle(data) {},
    getMultipleSelectData() {
      return this.multipleSelection
    },
    handleSelectionChange(val) {
      val = val.filter(item => !item.isNewAdd)
      this.multipleSelection = val
      this.$emit('selection-change', val)
    },
    showRow: function(row) {
      const show = row.row.parent
        ? row.row.parent._expanded && row.row.parent._show
        : true
      row.row._show = show
      return show
        ? 'animation:treeTableShow 1s;-webkit-animation:treeTableShow 1s;'
        : 'display:none;'
    },
    // 切换下级是否展开
    async toggleExpanded(trIndex) {
      const selectIds = new Set(
        this.$refs.multipleTable.selection.map(item => item.id),
      )
      const record = this.formatData[trIndex]
      record._expanded = !record._expanded
      await this.$nextTick()
      this.$refs.multipleTable.store.states.selection = this.formatData.filter(
        item => selectIds.has(item.id),
      )
      this.$refs.multipleTable.store.updateAllSelected()
      await this.$refs.multipleTable.$nextTick()
      this.multipleSelection = this.$refs.multipleTable.store.states.selection
      this.$emit('selection-change', this.multipleSelection)
    },
    // 图标显示
    iconShow(index, record) {
      return index === 0 && record.children && record.children.length > 0
    },
    selectableFunction() {
      return true
    },
    async handleClickItem(row, e) {
      // 实时获取用户操作权限
      this.$store.commit('updateRequireSelectedId', {
        id: row.id,
      })

      await this.$router.push({
        query: { ...this.$route.query, requireId: row.id },
      })

      this.$emit('cancleCreateRequire')
      if (this.ltype == 1) {
        this.$emit('seeTaskHandle', row, e)
        return
      }
      if (row.data && row.data.workItemType == 1) {
        this.$emit('seeTaskHandle', row.data, e)
        return
      } else if (row.data && row.data.workItemType == 2) {
        if (this.ltype == 2) {
          this.$emit('seeTaskHandle', row.data, e)
          return
        }
      } else {
        this.$emit('seeTaskHandle', row.data, e)
        return
      }
    },
    // 通过链接进来  选中表格
    initSetTableSelect() {
      if (this.$getUrlParams().requireId) {
        this.$store.commit('updateRequireSelectedId', {
          id: this.$getUrlParams().requireId,
        })

        this.setTableSelect(this.formatData)
      }
    },
    // 选中表格
    setTableSelect(data) {
      let currentItem = data.find(
        item => item.id == this.$store.state.st.requireSelectedId,
      )

      this.$nextTick(() => {
        this.$refs.multipleTable &&
          this.$refs.multipleTable.setCurrentRow(currentItem)
      })
    },
  },
}
</script>
<style rel="stylesheet/css">
@keyframes treeTableShow {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@-webkit-keyframes treeTableShow {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}
</style>
<style lang="scss" rel="stylesheet/scss" scoped>
$space-width: 18px;

.tree-table {
  /deep/ .el-table__expand-icon {
    display: none;
  }
  /deep/ .el-table__indent,
  /deep/ .el-table__placeholder {
    display: none;
  }

  /deep/ .el-checkbox .el-checkbox__inner {
    width: 14px;
    height: 14px;
  }

  /deep/ .el-table__header .el-icon-plus {
    cursor: pointer;
  }
  /deep/ .el-table__header .el-icon-minus {
    cursor: pointer;
  }
  /deep/ .hidden-row {
    display: none;
  }
  /deep/ .display-row {
    animation: treeTableShow 1s;
    -webkit-animation: treeTableShow 1s;
  }
}

.ms-tree-space {
  position: relative;
  top: 1px;
  display: inline-block;
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  width: $space-width;
  height: 14px;

  &::before {
    content: '';
  }
}

.processContainer {
  width: 100%;
  height: 100%;
}

table td {
  line-height: 26px;
}

.tree-ctrl {
  position: relative;
  cursor: pointer;
  //color: $--color-primary;
  margin-left: -$space-width;
  color: #999999;
  font-size: 10px;
}

.inputSet {
  position: relative;
  bottom: 10px;
}
</style>

<style lang="scss" scoped>
>>> .el-table__header .el-icon-plus {
  cursor: pointer;
}
>>> .el-table__header .el-icon-minus {
  cursor: pointer;
}
>>> .hidden-row {
  display: none;
}
>>> .display-row {
  animation: treeTableShow 1s;
  -webkit-animation: treeTableShow 1s;
}

.title-icon {
  color: #999999;
  font-size: 14px;
}
</style>
