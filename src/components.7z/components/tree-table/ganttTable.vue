<template>
  <el-table
    :ref="tableRef"
    :data="formatData"
    :row-class-name="tableRowClassName"
    border
    header-row-class-name="gantt-table-header"
    class="multiple-table"
    v-bind="$attrs"
    height="100%"
    :current-row-key="
      userId != $store.state.st.sprintSelectedUserId && userId
        ? $store.state.st.sprintSelectedId + 'a'
        : $store.state.st.sprintSelectedId
    "
    :highlight-current-row="true"
    @sort-change="sortaChangeCallBack"
    @click.stop
  >
    <!-- current-row-key属性：主要是为了解决在迭代成员视图那里会选中多个表格问题，a时顺便写的一个字符串，主要为了防止重复 -->
    <el-table-column
      v-if="isChecked"
      type="selection"
      width="55"
      :selectable="selectableFunction"
    ></el-table-column>
    <el-table-column width="74" label="ID" show-overflow-tooltip fixed>
      <template slot-scope="scope">
        <span
          :id="'tableIdDom' + getId(scope.row)"
          class="cp c-blue-hover"
          @click="handleClickItem(scope.row, $event)"
          @mousedown.stop
          >{{ getId(scope.row) }}</span
        >
      </template>
    </el-table-column>
    <el-table-column
      v-if="columns.length === 0"
      show-overflow-tooltip
      :sortable="titleSortable ? 'custom' : false"
      prop="title"
      fixed
      min-width="310"
    >
      <template #header>
        <i
          v-if="isCanChangeExpand"
          :class="expandAll ? 'el-icon-minus' : 'el-icon-plus'"
          @click.stop="changeExpand(!expandAll)"
        ></i>
        {{ $t('标题') }}
      </template>
      <template slot-scope="scope">
        <global-input
          :init-value="getTitle(scope.row)"
          :on-change="
            value => {
              updateGlobalTitle(scope.row, value)
            }
          "
        >
          <span slot class="table-input-edit-text c-blue-hover">
            <span
              v-for="space in scope.row._level"
              :key="space"
              class="ms-tree-space"
            ></span>
            <span
              v-if="iconShow(0, scope.row)"
              class="tree-ctrl"
              @click="toggleExpanded(scope.$index)"
            >
              <i v-if="!scope.row._expanded" class="el-icon-plus"></i>
              <i v-else class="el-icon-minus"></i>
            </span>
            <span
              v-if="scope.row.data && scope.row.data.isNewAdd"
              class="inputSet"
            >
              <el-input
                v-model="scope.row.data.title"
                :placeholder="$t('请输入标题')"
              ></el-input>
            </span>
            <!-- <span v-else @click.stop="handleClickItem(scope.row,$event)" class="title-link-common c-blue cp"> -->
            <span
              v-else
              class="cp c-blue-hover"
              @click="handleClickItem(scope.row, $event)"
              @mousedown.stop
            >
              <span
                :class="getworkItemType(scope.row.data)"
                class="title-link-common c-table-icon cp"
              ></span
              >{{ getTitle(scope.row) }}
            </span>
          </span>
          <el-tooltip
            v-if="
              scope.row.data &&
                scope.row.data.display &&
                scope.row.data.display.delayed
            "
            class="item"
            effect="dark"
            :content="$t('已过期')"
            placement="top-start"
          >
            <i class="el-icon-warning warning"></i>
          </el-tooltip>
        </global-input>
      </template>
    </el-table-column>
    <el-table-column
      v-for="(column, index) in columns"
      v-else
      :key="column.value"
      show-overflow-tooltip
      :label="column.text"
      :width="column.width"
    >
      <template slot-scope="scope">
        <!-- <span v-for="space in scope.row._level" v-if="index === 0" :key="space" class="ms-tree-space"/> -->
        <span
          v-if="iconShow(index, scope.row)"
          class="tree-ctrl"
          @click="toggleExpanded(scope.$index)"
        >
          <i v-if="!scope.row._expanded" class="el-icon-plus"></i>
          <i v-else class="el-icon-minus"></i> </span
        >{{ scope.row[column.value] }}
      </template>
    </el-table-column>
    <slot></slot>
  </el-table>
</template>
<script>
/**
 * 说明：仅适用于甘特图的树形图组件
 */
import treeToArray from './eval'
import GlobalInput from '@/components/field-edit/GlobalInput.vue'
export default {
  name: 'GanttTable',
  components: {
    GlobalInput,
  },

  props: {
    /* eslint-disable */
    data: {
      type: [Array, Object],
      required: false,
    },
    titleSortable: {
      type: Boolean,
      required: false,
      default: false,
    },
    columns: {
      type: Array,
      default: () => [],
    },

    evalFunc: Function,
    evalArgs: Array,
    // multipleSelection: Array,
    expandAll: {
      type: Boolean,
      default: false,
    },

    isChecked: {
      type: Boolean,
      default: true,
    },

    jumpPage: {
      type: String,
      default: null,
    },

    ltype: {
      type: Number,
      default: null,
    },

    updateGlobalTitle: {
      type: Function,
      required: true,
    },

    sortaChangeCallBack: {
      type: Function,
      required: false,
      default: () => {},
    },

    expandChangeCallBack: {
      type: Function,
      required: false,
      desc: '收缩监听函数',
    },

    userId: {
      type: [String, Number],
      required: false,
      desc: '处理人id号',
    },

    tableHeight: {
      type: [String, Number],
      // default: 'auto'
    },

    isCanChangeExpand: {
      type: Boolean,
      required: false,
      default: false,
    },
  },

  data() {
    return {
      multipleSelection: [],
      currentTableSelectId: '', //当前行id,主要用于更新数据时，列表更新不会选中当前行问题
    }
  },
  watch: {
    // 选中当前行
    formatData(newValue) {
      // 迭代成员视图选中状态
      if (
        this.userId == this.$store.state.st.sprintSelectedUserId &&
        this.userId
      ) {
        let currentSelectRef =
          'multipleTable' + this.$store.state.st.sprintSelectedUserId
        this.setTableCurrentRow(newValue, currentSelectRef)
        // 迭代 需求和任务选中状态
      } else if (this.$refs.multipleTable && !this.userId) {
        let multipleTable = 'multipleTable'
        this.setTableCurrentRow(newValue, multipleTable)
      }
    },
  },
  created() {
    this.$nextTick(() => {
      const id = this.$route.query.requireId
        ? this.$route.query.requireId
        : this.$route.query.taskId
        ? this.$route.query.taskId
        : this.$route.query.bugId
      let currentItem = this.formatData.find(item => item.data.id == id)
      this.$refs[this.tableRef].setCurrentRow(currentItem)
    })
  },

  computed: {
    tableRef() {
      return 'multipleTable' + (this.userId ? this.userId : '')
    },
    // 格式化数据源
    formatData: function() {
      if (!this.data) {
        return []
      }

      let tmp
      if (!Array.isArray(this.data)) {
        tmp = [this.data]
      } else {
        tmp = this.data
      }
      const func = this.evalFunc || treeToArray
      const args = this.evalArgs
        ? [].concat([tmp, this.expandAll], this.evalArgs)
        : [tmp, this.expandAll]
      const result = func.apply(null, args)
      return result
    },
  },

  methods: {
    changeExpand(value) {
      this.$emit('change-expand', value)
      this.formatData.forEach((item, index) => {
        this.formatData[index]._expanded = value
      })
    },
    tableRowClassName: function(row, index) {
      if (!row.row._show) {
        return 'hidden-row'
      }
      return 'display-row'
    },
    getworkItemType(row) {
      if (row != undefined) {
        if (row && row.workItemType == 1) {
          return 'iconfont icon-xuqiu'
        } else if (row && row.workItemType == 2) {
          return 'iconfont icon-renwu'
        } else if (row && row.workItemType == 3) {
          // return 'iconfont icon-bug'
          return 'iconfont icon-quexian'
        }
      }
    },
    getId(data) {
      if (data.id) {
        return data.id
      } else if (data.data && data.data.id) {
        return data.data.id
      } else if (data.display && data.display.id) {
        return data.display.id
      } else {
        return ''
      }
    },
    getTitle(data) {
      if (data.title) {
        return data.title
      } else if (data.display && data.display.title) {
        return data.display.title
      } else if (data.data && data.data.title) {
        return data.data.title
      } else {
        return ''
      }
    },
    indexHandle(data) {},
    getMultipleSelectData() {
      return this.multipleSelection
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
    },
    // 切换下级是否展开
    toggleExpanded: function(trIndex) {
      const record = this.formatData[trIndex]
      record._expanded = !record._expanded
      if (this.expandChangeCallBack) {
        this.expandChangeCallBack(record.data.key + '', record._expanded)
      }
    },
    // 图标显示
    iconShow(index, record) {
      return index === 0 && record.children && record.children.length > 0
    },
    selectableFunction(row, index) {
      // if(row.data.workItemType == 1){      //需求
      //   if ( row.data.hierarchyRole == 0){   //叶子节点
      //     return true;
      //   } else{   //非叶子节点
      //     return false;
      //   }
      // }else {   //任务
      //   return true;
      // }
      return true
    },
    // 设置当前行选中
    setTableCurrentRow(list, multipRef) {
      let currentItem = list.find(
        item => item.data.id == this.$store.state.st.sprintSelectedId,
      )

      this.$nextTick(function() {
        this.$refs[multipRef].setCurrentRow(currentItem)
      })
    },
    handleClickItem(row, e) {
      this.currentTableSelectId = row.data.id
      this.$store.commit('updateSprintSelectedId', {
        id: row.data.id,
        userId: this.userId,
      })

      this.$router.push({
        query: {
          ...this.$route.query,
          requireId: row.id,
        },
      })

      if (this.ltype == 1) {
        this.$emit('seeTaskHandle', row, e)

        return
      }
      if (row.data && row.data.workItemType == 1) {
        this.$emit('seeTaskHandle', row.data, e)
        return
      } else if (row.data && row.data.workItemType == 2) {
        if (this.ltype == 2) {
          this.$emit('seeTaskHandle', row.data, e)
          return
        }
      } else {
        this.$emit('seeTaskHandle', row.data, e)
        return
      }
    },
  },
}
</script>
<style rel="stylesheet/css">
@keyframes treeTableShow {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}

@-webkit-keyframes treeTableShow {
  from {
    opacity: 0;
  }

  to {
    opacity: 1;
  }
}
.gantt-table-header {
  height: 59px;
}
</style>
<style lang="scss" rel="stylesheet/scss" scoped>
$color-blue: #2196f3;
$space-width: 18px;
.el-table {
  /deep/.el-table__fixed {
    height:auto !important; 
    bottom:6px !important;  
  }
  }
.ms-tree-space {
  position: relative;
  top: 1px;
  display: inline-block;
  font-style: normal;
  font-weight: 400;
  line-height: 1;
  width: $space-width;
  height: 14px;

  &::before {
    content: '';
  }
}

.processContainer {
  width: 100%;
  height: 100%;
}

table td {
  line-height: 26px;
}
.c-blue-hover {
  font-size: 14px !important;
  &:hover {
    color: $color-blue;
    text-decoration: none !important;
    .icon-xuqiu {
      color: $--color-icon-xuqiu;
    }
    .icon-renwu {
      color: $--color-icon-renwu;
    }
    .icon-quexian {
      color: $--color-icon-quexian;
    }
  }
}
.tree-ctrl {
  position: relative;
  cursor: pointer;
  color: #999999;
  margin-left: -$space-width;
}

.inputSet {
  position: relative;
  bottom: 10px;
}
.item {
  position: relative;
  vertical-align: middle;
  left: -16px;
}
</style>

<style scoped>
>>> .gantt-table-header .el-icon-plus {
  cursor: pointer;
}
>>> .gantt-table-header .el-icon-minus {
  cursor: pointer;
}
>>> .hidden-row {
  display: none;
}
>>> .display-row {
  animation: treeTableShow 1s;
  -webkit-animation: treeTableShow 1s;
}
</style>
