<template>
  <div>
    <el-popover
      v-if="isShowPopper"
      ref="popover"
      placement="right"
      popper-class="status-flow"
      :trigger="isLazy ? 'manual' : 'click'"
      v-model="lazyPopperVisible"
      @show="showCustomStatus"
      @hide="hideCustomStatus"
      width="580"
    >
      <custom-status
        v-clickoutside="handleClose"
        v-if="isShow && !noNextStatus"
        :bulk="bulk"
        v-on="$listeners"
        v-bind="$attrs"
        @finish="finish"
        @getStatus="dealStatus"
      ></custom-status>
      <div v-if="noNextStatus" v-clickoutside="handleClose">
        {{ $t('没有可流转状态') }}
      </div>
      <div slot="reference">
        <slot v-if="!isLazy">
          <el-button
            @click="showActiveStatus(currentIndex)"
            class="pop-trigger"
            type="primary"
            :style="{ borderColor: borderColor }"
          >
            <div class="witem-btn__container" :title="displayStatus">
              <ellipsis-block
                class="title"
                :close-click-stop="true"
                :value="displayStatus"
                @click="showActiveStatus(currentIndex)"
              ></ellipsis-block>
              <!-- <span class="title">{{ displayStatus }}</span> -->
            </div>
          </el-button>
        </slot>
      </div>
    </el-popover>
    <span v-if="isLazy" @click="doPopperIns">
      <slot></slot>
    </span>
  </div>
</template>

<script>
import { i18n } from '@/i18n'
import Clickoutside from 'cook-ui/src/utils/clickoutside'
const CustomStatus = () => import('@/components/custom-status')
import EllipsisBlock from '@/components/ellipsis-block'
export default {
  name: 'StateFlow',
  directives: { Clickoutside },
  components: {
    EllipsisBlock,
  },
  props: {
    currentIndex: {
      type: Number,
    },

    bgColor: {
      type: String,
      default: '',
    },

    borderColor: {
      type: String,
      default: '',
    },

    displayStatus: {
      type: String,
      default: '',
    },

    isLazy: {
      type: Boolean,
    },

    // 是否批量修改
    bulk: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      isShowPopper: !this.isLazy,
      lazyPopperVisible: this.isLazy ? false : undefined,
      isShow: false,
      noNextStatus: false,
    }
  },
  components: {
    CustomStatus,
  },

  methods: {
    handleClose() {
      if (this.isLazy) {
        this.$refs.popover.doClose()
      }
    },
    doPopperIns() {
      this.isShowPopper = true
      this.$nextTick(() => {
        this.$refs.popover.updatePopper()
        this.lazyPopperVisible = true
      })
    },
    showActiveStatus(index) {
      this.$emit('select', index)
    },
    showCustomStatus() {
      this.isShow = true
    },
    hideCustomStatus() {
      this.isShow = false
    },
    dealStatus(isNoMoreStatus) {
      this.noNextStatus = isNoMoreStatus
      this.$refs.popover.updatePopper()
    },
    finish(statusInfo) {
      // 状态流转成功时通知父组件更新数据
      if (this.bulk && statusInfo) this.$emit('getStatusInfo', statusInfo)
      this.$refs.popover.doClose()
    },
  },
}
</script>

<style scoped lang="scss">
.witem-btn__container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  line-height: 16px;
  .title {
    display: inline-block;
    min-width: 70px;
  }
}
.el-icon-arrow-down {
  margin-left: 0;
}
</style>
<style lang="scss">
.el-radio-button__inner {
  color: #666;
}
.status-flow {
  border: $borderSolid;
  min-height: 400px;
}
</style>
