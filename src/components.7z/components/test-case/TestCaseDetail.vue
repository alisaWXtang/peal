<template>
  <div class="aaa">
    <co-container>
      <co-header style="margin-top:20px;">
        <!-- 头部信息 -->
        <co-row>
          <span style="margin-left:20px; font-size: 20px;font-weight: 700;">{{
            $t('查看用例')
          }}</span>
          <div class="header-test ">
            <el-button type="warning" @click="toItestedit"
              >{{ $t('编辑') }}
              <i class="el-icon-edit el-icon--right"></i>
            </el-button>
            <el-button type="primary" @click="toItestCaseDetail"
              >{{ $t('更多') }}
              <i class="el-icon-zoom-in el-icon--right"></i>
            </el-button>
            <el-button
              type="danger"
              circle
              class="close-btn"
              @click="unshowslide"
              >X</el-button
            >
          </div>
        </co-row>
      </co-header>
      <co-main class="main">
        <div>
          <span>
            <i class="el-icon-star-on icon"></i>{{ $t('用例名称') }}：
          </span>
          <el-input v-model="testCaseInfo.name" type="text" disabled></el-input>
        </div>
        <div class="overflow">
          <div class="floatleftwidth50">
            <span class="floatleft">{{ $t('用例编号') }}：</span>
            <el-input
              v-model="testCaseInfo.caseNoTotal"
              type="text"
              class="floatleft"
              disabled
              style="max-width: 200px;"
            ></el-input>
          </div>
          <div class="floatleftwidth50">
            <span class="floatleft">{{ $t('用例状态') }}：</span>
            <el-input
              v-model="testName[testCaseInfo.caseStatus]"
              type="text"
              class="floatleft"
              disabled
              style="max-width: 200px;"
            ></el-input>
          </div>
        </div>
        <div class="selecttag">
          <span>{{ $t('用例标签') }}：</span>
          <el-select
            v-model="tagList"
            class="cursorNot"
            style="width: 76%;border-radius: 4px; "
            size="medium"
            multiple
            disabled
            allow-create
            default-first-option
            :placeholder="$t('请选择用例标签')"
          >
            <el-option
              v-for="item in testCaseInfo.tagList"
              :key="item.value"
              class="cursorNot"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div class="overflow">
          <span class="floatleft">{{ $t('前置条件') }}：</span>
          <div class="floatleft width80">
            <el-input
              v-model="testCaseInfo.preCondition"
              type="textarea"
              :autosize="{ minRows: 5 }"
              disabled
            ></el-input>
          </div>
        </div>
        <div class="overflow">
          <span class="floatleft">{{ $t('测试步骤') }}：</span>
          <div class="floatleft width80">
            <div class="floatleftwidth40">
              <span class="width100">{{ $t('步骤描述') }}</span>
              <el-input
                v-model="testCaseInfo.content"
                type="textarea"
                :autosize="{ minRows: 5 }"
                disabled
              ></el-input>
            </div>
            <div class="floatleftwidth40  floatrightwidth40">
              <span class="width100">{{ $t('预期结果') }}</span>
              <el-input
                v-model="testCaseInfo.expected"
                type="textarea"
                :autosize="{ minRows: 5 }"
                disabled
              ></el-input>
            </div>
          </div>
        </div>
        <div class="overflow">
          <div class="floatleftwidth50">
            <el-row>
              <span class="floatleft">{{ $t('一级模块') }}：</span>
              <el-input
                v-model="testCaseInfo.firstModule"
                type="text"
                class="floatleft"
                disabled
                style="max-width: 200px;"
              ></el-input>
            </el-row>
          </div>
          <div class="floatleftwidth50">
            <el-row>
              <span class="floatleft">{{ $t('一级模块') }}：</span>
              <el-input
                v-model="testCaseInfo.firstModule"
                type="text"
                class="floatleft"
                disabled
                style="max-width: 200px;"
              ></el-input>
            </el-row>
          </div>
        </div>
        <div>
          <span>
            <i class="el-icon-star-on icon"></i>{{ $t('优先级') }}：
          </span>
          <el-radio-group v-model="testCaseInfo.priority" disabled>
            <el-radio :label="'S'">S</el-radio>
            <el-radio :label="'A'">A</el-radio>
            <el-radio :label="'B'">B</el-radio>
            <el-radio :label="'C'">C</el-radio>
            <el-radio :label="'D'">D &nbsp;</el-radio>
          </el-radio-group>
          <el-tooltip class="item" effect="dark" placement="top-start">
            <div slot="content">
              <p>
                S：{{ $t('核心模块和常用模块的常用基本功能点检') }}，{{
                  $t('占比')
                }}5%
              </p>
              <p>
                A：{{ $t('核心模块和常用模块的常用基本功能测试') }}，{{
                  $t('非常用模块的常用基本功能点检')
                }}，{{ $t('占比不超过') }}25%
              </p>
              <p>
                B：{{ $t('核心模块和常用模块的非常用基本功能测试') }}，{{
                  $t('非常用模块的常用基本功能')
                }}，{{ $t('占比') }}45%{{ $t('左右') }}
              </p>
              <p>
                C：{{ $t('非常用模块的非常用基本功能') }}，{{
                  $t('以及核心模块和常用模块的性能')
                }}、{{ $t('容错') }}、{{ $t('兼容性') }}、{{
                  $t('压力测试')
                }}，{{ $t('占比') }}15%{{ $t('左右') }}
              </p>
              <p>
                D：{{ $t('纯') }}ROM{{ $t('设计规则类') }}，{{
                  $t('底层无耦合的成熟功能')
                }}，{{ $t('以及非常用模块的性能') }}、{{ $t('容错') }}、{{
                  $t('兼容性')
                }}、{{ $t('压力测试') }}，D{{ $t('级用例占比') }}10%{{
                  $t('左右')
                }},D{{ $t('级用例只需要') }}DVT{{ $t('和') }}PVT{{
                  $t('各阶段测试一次')
                }}
              </p>
            </div>
            <i class="el-icon-question"></i>
          </el-tooltip>
        </div>
        <div class="overflow">
          <span class="floatleft">{{ $t('用例备注') }}：</span>
          <div class="floatleft width80">
            <el-input
              v-model="testCaseInfo.des"
              type="textarea"
              :autosize="{ minRows: 5 }"
              disabled
            ></el-input>
          </div>
        </div>
        <div>
          <span class="cursorNot">{{ $t('附件上传') }}：</span>
          <div
            v-for="(item, index) in testCaseInfo.attachList"
            :key="index"
            class="cursorNot"
            style="margin-left: 120px;"
          >
            {{ item.originalName }}
          </div>
        </div>
      </co-main>
    </co-container>
  </div>
</template>
<script>
/**
 * @title 测试用例详情
 * @desc 结合 tool/slideSlip 弹框使用，参考需求、任务、缺陷右侧滑窗详情实现
 * @author
 * @date  2019.10.08
 */
import config from '@/utils/config'
export default {
  name: 'TestCaseDetail',
  components: {},
  mixins: [],
  props: {
    testCaseInfoDetail: {
      type: Object,
      required: true,
      desc: '表格数据',
    },
  },

  data() {
    return {
      tagList: [], //用例标签
      testName: { 1: '正常', 2: '失效' },
      testCaseInfo: { tagList: {}, attachList: {}, detail: {} },
      tableData: [],
    }
  },
  computed: {},
  watch: {
    testCaseInfoDetail: {
      deep: true,
      handler() {
        this.tagList = []
        this.testCaseInfo = { ...this.testCaseInfo, ...this.testCaseInfoDetail }
        for (let i = 0; i < this.testCaseInfo.tagList.length; i++) {
          this.tagList.push(this.testCaseInfo.tagList[i].name)
        }
      },
    },
  },

  created() {},
  methods: {
    //隐藏侧边框
    unshowslide() {
      this.$emit('unshowslide', false)
    },
    //跳转itest
    toItestedit() {
      config.itestJump('caseDetail', {
        id: this.testCaseInfo.id,
        bizCode: this.testCaseInfo.bizCode,
        mid: this.testCaseInfo.mid,
        type: 1,
      })
    },
    toItestCaseDetail() {
      config.itestJump('caseDetail', {
        id: this.testCaseInfo.id,
        bizCode: this.testCaseInfo.bizCode,
        mid: this.testCaseInfo.mid,
        type: 2,
      })
    },
  },
}
</script>
<style lang="scss" scoped>
$border-color: #dde5ef;
.header-test {
  float: right;
  margin-right: 80px;
}
/deep/.el-input__inner,
/deep/.el-textarea__inner {
  border-color: $border-color !important;
}
/deep/.el-textarea {
  border: none !important;
}

.header-test /deep/.el-button.close-btn {
  width: 32px;
  // height: 32px;
  // box-sizing: border-box;
  // min-width: auto;
}
.main {
  padding: 0 40px;
  & > div {
    margin-top: 20px;
    font-size: 14px;
    span {
      display: inline-block;
      line-height: 24px;
      text-align: right;
      width: 120px;
      font-weight: 400;
    }
    .icon {
      color: red;
      font-size: 12px;
    }
    input {
      width: 80%;
      height: 24px;
    }
    .inlineblock {
      display: inline-block;
      width: 80%;
    }
  }
  .overflow {
    overflow: hidden;
  }
  .floatleft {
    float: left;
  }
  .input {
    width: 30%;
    margin-right: 30px;
    padding: 0 10px;
  }
  .width80 {
    width: 80%;
  }
  .floatleftwidth40 {
    float: left;
    margin-right: 4%;
    width: 45%;
    .el-input {
      position: relative;
      font-size: 14px;
      display: inline-block;
      width: 60%;
      border: 1px solid $border-color;
      border-radius: 4px;
      cursor: not-allowed;
    }
  }
  .floatleftwidth50 {
    float: left;
    width: 50%;
    .el-inpu {
      width: 40%;
    }
  }
  .floatrightwidth40 {
    float: right;
    margin-right: 16px;
  }
  .width100 {
    width: 100%;
    text-align: center;
  }
  input:disabled {
    background-color: rgb(255, 255, 255);
    border-color: rgb(169, 169, 169);
    border-radius: 4px;
  }
  .el-input {
    font-size: 12px;
    color: rgb(169, 169, 169);
  }
  .el-input {
    position: relative;
    font-size: 14px;
    display: inline-block;
    width: 76%;
    // border: 1px solid #000;
    border-radius: 4px;
    cursor: not-allowed;
  }
  .el-textarea {
    border: 1px solid rgb(169, 169, 169);
    border-radius: 4px;
    width: 96%;
  }
}
</style>
