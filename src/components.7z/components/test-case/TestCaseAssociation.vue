<template>
  <div>
    <el-dialog
      :title="$t('关联测试用例')"
      :visible.sync="dialogTableVisible.show"
      :modal-append-to-body="false"
    >
      <el-row style="margin-bottom: 20px;">
        <div style="marginBottom: 10px;">
          {{ $t('项目') }}：{{ projectName }}
        </div>
        <div>
          <span>{{ $t('测试计划') }}：</span>
          <el-select
            v-model="filterInfo.pid"
            class="test-plan-select"
            filterable
            :placeholder="$t('无测试计划')"
            @change="getPage"
          >
            <el-option
              v-for="item in options"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            ></el-option>
          </el-select>
        </div>
      </el-row>
      <el-table
        ref="multipleTable"
        v-loading="loading"
        class="multiple-table"
        :data="tableList.list"
        tooltip-effect="dark"
        style="width: 100%"
        max-height="500"
        element-loading-text=" "
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgb(255,255,255)"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55"></el-table-column>
        <el-table-column label="ID" width="80" align="center">
          <template slot-scope="scope">{{ scope.row.id }}</template>
        </el-table-column>
        <el-table-column
          prop="caseNoTotal"
          :label="$t('用例编号')"
          width="120"
          align="center"
        ></el-table-column>
        <el-table-column
          prop="name"
          :label="$t('用例名称')"
          min-width="150"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="priority"
          :label="$t('优先级')"
          width="70"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="createdUser"
          :label="$t('创建人')"
          width="70"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="createdAt"
          :label="$t('创建时间')"
          show-overflow-tooltip
        ></el-table-column>
      </el-table>
      <!-- 分页 -->
      <div class="block" align="center" style="margin-top: 10px;">
        <el-pagination
          :current-page="tableList.pageNum"
          :page-sizes="[20, 50, 100]"
          :page-size="tableList.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="tableList.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        ></el-pagination>
      </div>
      <!-- 对话框底部 -->
      <span slot="footer" class="dialog-footer">
        <!-- <el-button @click="dialogTableVisible.show = false">取 消</el-button> -->
        <el-button type="primary" @click="getTestCase">{{
          $t('确定')
        }}</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 关联测试用例 dialog 组件
 * @desc
 * @author
 * @date
 */
import { projectInfo } from '@/service/project'
import {
  testPlanList,
  defectTestCaseList,
  assocTestCase,
} from '@/service/itest'
export default {
  name: 'TestCaseAssociation',
  components: {},
  mixins: [],
  props: {
    dialogTableVisible: {
      type: Object,
      required: true,
      desc: '显示与隐藏',
    },

    workItemId: {
      type: [String, Number],
      required: true,
      desc: '缺陷id',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false,
      filterInfo: {
        pid: '',
        pageSize: 20,
        pageNum: 1,
        nameSearch: null,
        projectId: this.projectId,
      },

      //对话框请求参数
      tableData: {
        total: 200,
        list: [],
      },

      //表格数据
      value: '',
      options: { data: {} },
      tableList: {
        pageSize: 20,
        total: 0,
        list: [],
      },
      arrlist: [],
      projectName: '', //项目名称
    }
  },
  computed: {},
  watch: {
    dialogTableVisible: {
      deep: true,
      handler() {
        this.getPage()
      },
    },
  },
  mounted() {
    this.getPage()
  },

  created() {},
  methods: {
    //获取数据列表
    async getPage() {
      let projectId = this.projectId || this.$getUrlParams().projectId
      this.loading = true
      let data = await projectInfo({
        id: projectId,
      })

      if (data.status === 200) {
        this.loading = false
        this.projectName = data.data.name
      }
      if (this.filterInfo.pid === '') {
        this.loading = true
        let result = await testPlanList({
          projectId: this.projectId,
        })

        if (result.status === 200) {
          this.loading = false
          this.options = result.data.list
          this.filterInfo.pid =
            result.data.list.length === 0 ? 0 : result.data.list[0].id
        }
      }
      if (this.filterInfo.pid === 0) {
        this.filterInfo.pid = ''
      } else {
        this.loading = true
        let result = await defectTestCaseList(this.filterInfo)

        if (result.status === 200) {
          this.loading = false
          this.tableList = {
            ...this.tableList,
            ...result.data,
          }
        }
      }
    },
    //设置选中状态
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row)
        })
      } else {
        this.$refs.multipleTable.clearSelection()
      }
    },
    //分页
    handleSizeChange(val) {
      this.filterInfo.pageSize = val
      this.getPage()
    },
    handleCurrentChange(val) {
      this.filterInfo.pageNum = val
      this.getPage()
    },
    //获取选中测试计划ID
    handleSelectionChange(val) {
      this.arrlist = []
      if (val) {
        val.forEach(row => {
          this.arrlist.push(row.id)
        })
      }
    },
    //关联测试用例
    async assocTestCase(data) {
      let cids = data
      let pid = this.filterInfo.pid
      this.loading = true
      let result = await assocTestCase({
        cids,
        defectId: this.workItemId,
        pid,
      })

      if (result.status === 200) {
        this.loading = false
        this.$message({
          type: 'success',
          message: i18n.t('关联成功') + '!',
        })

        this.$emit('getTestPlan', this.arrlist)
      }
    },
    //点击确定关联测试用例
    getTestCase() {
      if (this.arrlist.length !== 0) {
        this.assocTestCase(this.arrlist)
        this.arrlist = []
        this.toggleSelection()
      }

      this.dialogTableVisible.show = false
    },
  },
}
</script>
<style lang="scss" scoped>
.test-plan-select {
  width: auto;
}
/deep/ .el-pagination .el-pagination__sizes-select .el-input {
  width: 94px;
}
</style>
