<template>
  <div
    v-loading="loading"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <div style="padding-bottom: 30px;">
      <el-table
        ref="table"
        :data="tableData"
        max-height="800"
        class="multiple-table"
        highlight-current-row
      >
        <el-table-column
          prop="name"
          :label="$t('用例名称')"
          min-width="120"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <co-link
              type="primary"
              :underline="false"
              @click="handleClickTestCaseDetail(scope.row)"
              >{{ scope.row.name }}</co-link
            >
          </template>
        </el-table-column>
        <el-table-column
          prop="firstModule"
          :label="$t('一级模块')"
          width="120"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="subModule"
          :label="$t('二级模块')"
          width="120"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="priority"
          :label="$t('优先级')"
          width="80"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="preCondition"
          :label="$t('前置条件')"
          width="130"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="content"
          :label="$t('步骤描述')"
          width="120"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="expected"
          :label="$t('预期结果')"
          width="130"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="createdUser"
          :label="$t('创建人')"
          width="80"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop="createdAt"
          :label="$t('创建时间')"
          width="120"
          align="center"
          show-overflow-tooltip
        ></el-table-column>
        <el-table-column
          prop
          :label="$t('操作')"
          width="100"
          align="center"
          show-overflow-tooltip
        >
          <template slot-scope="scope">
            <el-button
              v-show="
                $authFunction(
                  'FUNCTION_PROJ_DEFECT_UNASSOC_TEST_CASE',
                  3,
                  $getUrlParams().projectId || projectId,
                )
              "
              type="text"
              @click="handleClickDel(scope.row)"
              >{{ $t('解除关联') }}</el-button
            >
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 测试用例 table
 * @desc
 * @author
 * @date
 */
export default {
  name: 'TestCaseTable',
  components: {},
  mixins: [],
  props: {
    //表格数据
    tableData: {
      type: Array,
      required: true,
      desc: '表格数据',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false, //加载中
    }
  },
  computed: {},
  watch: {},

  created() {},
  methods: {
    //点击名称显示侧边栏
    handleClickTestCaseDetail(data) {
      this.$refs.table.setCurrentRow(data)
      this.$emit('showDetail', data)
    },
    //缺陷解除关联测试用例
    handleClickDel(data) {
      this.$confirm(i18n.t('此操作将解除关联, 是否继续?'), i18n.t('提示'), {
        confirmButtonText: i18n.t('确定'),
        cancelButtonText: i18n.t('取消'),
        type: 'warning',
      })
        .then(() => {
          this.$emit('TestCaseDel', data)
        })
        .catch(() => {
          this.$message({
            type: 'info',
            message: i18n.t('已取消解绑'),
          })
        })
    },
  },
}
</script>
<style lang="scss" scoped></style>
