<template>
  <div
    v-loading="loading"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <el-button
      v-show="
        $authFunction(
          'FUNCTION_PROJ_DEFECT_ASSOC_TEST_CASE',
          3,
          $getUrlParams().projectId || projectId,
        )
      "
      type="text"
      @click="dialogTableVisible.show = true"
      >{{ $t('关联测试用例') }}</el-button
    >
    <test-case-association
      :dialog-table-visible="dialogTableVisible"
      :work-item-id="workItemId"
      :project-id="projectId"
      @getTestPlan="getTestPlan"
    ></test-case-association>
    <test-case-table
      :table-data="tableData"
      :project-id="projectId"
      @showDetail="showDetail"
      @TestCaseDel="TestCaseDel"
    ></test-case-table>
    <!-- 查看测试用例 -->
    <slide :show.sync="testCaseDetailDialogModalStatus">
      <div slot="task" class="taslinfo">
        <test-case-detail
          :test-case-info-detail="testCaseInfoDetail"
          @unshowslide="unshowslide"
        ></test-case-detail>
      </div>
    </slide>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 测试用例入口文件
 * @desc
 * @author heyunjiang
 * @date 2019.10.8
 */
import TestCaseTable from './TestCaseTable'
import TestCaseDetail from './TestCaseDetail'
import TestCaseAssociation from './TestCaseAssociation'
import slide from '@/components/slide-slip'
import { defectAssocTestCaseList, unAssocTestCase } from '@/service/itest'
export default {
  name: 'TestCase',
  components: {
    TestCaseTable,
    TestCaseDetail,
    TestCaseAssociation,
    slide,
  },

  mixins: [],
  props: {
    workItemId: {
      type: [String, Number],
      required: true,
      desc: '缺陷id',
    },

    projectId: {
      type: [Number, String],
      required: false,
    },
  },

  data() {
    return {
      loading: false,
      dialogTableVisible: { show: false }, //测试用例对话框展示与否
      testCaseDetailDialogModalStatus: false, // 测试用例右侧滑窗展示与否
      tableData: [], // 关联的测试用例数据
      testCaseInfoDetail: {}, //测试用例详情数据
      testPlanId: [],
    }
  },
  computed: {},
  watch: {
    testPlanId: {
      deep: true,
      handler() {
        setTimeout(() => {
          this.getTestdetaildata()
        }, 1000)
      },
    },

    //缺陷id变化，刷新测试用例组件信息
    workItemId() {
      this.getTestdetaildata()
    },
  },

  created() {
    this.getTestdetaildata()
  },
  mounted() {},
  methods: {
    //获取测试用例详情数据
    async getTestdetaildata() {
      this.loading = true
      let result = await defectAssocTestCaseList({
        defectId: this.workItemId,
        projectId: this.projectId,
      })

      if (result.status === 200) {
        this.loading = false
        this.tableData = result.data.list
      }
    },
    // 测试用例右侧滑窗展示
    showDetail(data) {
      this.testCaseDetailDialogModalStatus = true
      this.testCaseInfoDetail = data
    },
    // 测试用例右侧滑窗关闭
    unshowslide() {
      this.testCaseDetailDialogModalStatus = false
    },
    //缺陷解除关联测试用例
    async TestCaseDel(testPlanId) {
      let cids = []
      let defectId = parseInt(this.workItemId)
      cids.push(testPlanId.id)
      let pid = testPlanId.pid
      this.loading = true
      let result = await unAssocTestCase({
        defectId,
        cids,
        pid,
      })

      if (result.status === 200) {
        this.loading = false
        this.$message({
          type: 'success',
          message: i18n.t('解绑成功') + '!',
        })

        this.getTestdetaildata()
        this.$emit('testPlanSuccess')
      }
    },
    //关联测试用例
    getTestPlan(data) {
      this.testPlanId = data
      this.$emit('testPlanSuccess')
    },
  },
}
</script>
<style lang="scss" scoped>
.sider-right {
  min-width: 45%;
  max-width: 850px;
}
</style>
