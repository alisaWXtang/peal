# TwoBlockWidthChanger

time: 2019.7.23  
author: heyunjiang

## 说明

边界拖拽组件，一个 div 分为左右2块，中间分界栏拖拽，实现左右块宽度自适应效果

使用模块

1. 甘特图
2. 需求列表
3. 缺陷列表
