<template>
  <div class="user-input-tips" v-show="isShowTips">
    <div class="content">
      {{ $t('检测到有未保存内容') }}，{{ $t('是否恢复') }}？
    </div>
    <div>
      <el-button type="text" @click="restoreCache">{{ $t('恢复') }}</el-button>
    </div>
    <el-button type="text" @click="ignoreCache">{{ $t('忽略') }}</el-button>
  </div>
</template>

<script>
import { i18n } from '@/i18n'
import { getItemUserInputCache, clearItemUserInputCache } from '@/utils/help'
import { removeFragmentSpace } from '@/utils/index'
const WorkItemTypeObj = {
  requirement: 1,
  task: 2,
  bug: 3,
}

export default {
  name: 'UserInputTips',
  props: {
    actionType: {
      type: String,
      required: true,
    },

    itemType: {
      type: String,
      required: true,
    },

    itemId: {
      type: [String, Number],
    },

    projectId: {
      type: [String, Number],
    },

    originalValue: {
      type: String,
      require: false,
      desc: '工作项编辑时原保存内容',
    },
  },

  data() {
    return {
      isShowTips: false,
      hasRequestTemplate: false,
    }
  },
  created() {
    // this.judgeShowTips();
  },
  mounted() {
    this.judgeShowTips()
  },
  watch: {
    // 只有创建工作项的时候才需要去获取工作项模板作对比
    projectId(val) {
      if (val && !this.hasRequestTemplate && this.actionType === 'create') {
        this.getWorkItemTemplateInfo()
        this.hasRequestTemplate = true
      }
    },
  },

  methods: {
    // 判断是否显示提示信息
    judgeShowTips() {
      // 如果是创建的时候则需要查询初始模板
      if (this.actionType == 'create') {
        if (this.projectId) {
          this.getWorkItemTemplateInfo()
          this.hasRequestTemplate = true
        } else if (this.itemType === 'feedback') {
          const templateObj = {
            title: '',
            content: '<p><strong>【反馈内容】</strong>：</p>\n<p>&nbsp;</p>',
          }

          this.isCacheEqualRawTem(templateObj)
        }
      } else {
        // 需要查询缓存信息是否与已保存的初始内容显示的一致
        this.isCacheEqualRawContent()
      }
    },
    // 判断缓存是否与初始内容一致
    isCacheEqualRawContent() {
      const cacheContent = this.getCacheContent()
      // 没有缓存信息undefined 或者缓存信息为null
      if (cacheContent == null) {
        this.isShowTips = false
        return
      }
      // 替换空格和↵字符,其中\u21b5代表↵字符，当富文本进行缓存时会带这个字符
      const escapeSpaceOriginalValue =
        this.originalValue && removeFragmentSpace(this.originalValue)
      const escapeSpaceCacheContent = removeFragmentSpace(
        cacheContent?.content || '',
      ).replace(/\u21b5/gi, '')
      this.isShowTips = escapeSpaceOriginalValue !== escapeSpaceCacheContent
    },
    // 判断缓存是否与初始模板一致
    isCacheEqualRawTem(rawTemplate) {
      const cacheInfo = this.getCacheContent()
      // 初始新建任务和缺陷没有缓存的情况
      if (!cacheInfo) {
        return
      }
      const cacheContent = cacheInfo?.content || ''
      const cacheTitle = cacheInfo?.title
      // 替换空格和↵字符,其中\u21b5代表↵字符，当富文本进行缓存时会带这个字符
      const cacheContentEqualRaw =
        cacheContent &&
        removeFragmentSpace(cacheContent).replace(/\u21b5/gi, '') !==
          removeFragmentSpace(rawTemplate.content)
      this.isShowTips = cacheContentEqualRaw || cacheTitle !== rawTemplate.title
    },
    /// 获取工作项详情
    getWorkItemTemplateInfo() {
      const workItemType = WorkItemTypeObj[this.itemType]
      this.$store
        .dispatch('getWorkItemTemplateInfo', {
          projectId: this.projectId,
          workItemType: workItemType,
        })
        .then(res => {
          this.isCacheEqualRawTem(res)
        })
    },
    getCacheContent() {
      const { actionType, itemId, itemType } = this
      return getItemUserInputCache({ actionType, itemId, itemType })
    },
    restoreCache() {
      this.$emit('restore', this.getCacheContent())
      this.isShowTips = false
    },
    ignoreCache() {
      const { actionType, itemId, itemType } = this
      clearItemUserInputCache({ actionType, itemId, itemType })
      this.isShowTips = false
    },
  },
}
</script>

<style lang="scss" scoped>
.user-input-tips {
  position: absolute;
  top: 45px;
  left: 8px;
  z-index: 1;
  display: inline-flex;
  align-items: center;
  padding: 0 3px 0 10px;
  font-size: 12px;
  background: #f1f1f1;
  border-radius: 2px;
}
.content {
  line-height: 28px;
  color: #333;
}
</style>
