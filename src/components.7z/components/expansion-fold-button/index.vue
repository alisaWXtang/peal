<template>
  <div class="expansion-fold__container">
    <div class="icon-wrap" @click="handleToggle">
      <i
        class="icon el-icon-d-arrow-left"
        :style="{
          transform: this.folded_ ? 'rotate(-90deg)' : 'rotate(90deg)',
        }"
      ></i>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 展开/折叠 button
 * @desc 用于缺陷列表、迭代详情
 * @author wuqian
 * @date 2020.4.24
 */
export default {
  name: 'ExpansionFoldButton',
  components: {},
  props: {
    defaultFold: {
      type: Boolean, // 是否折叠状态
      default: false,
    },
  },

  data() {
    return {
      folded_: false,
    }
  },
  watch: {
    defaultFold: {
      handler: function(val) {
        this.folded_ = val
      },
      immediate: true,
    },
  },

  methods: {
    handleToggle() {
      this.folded_ = !this.folded_
      this.$emit('toggle', this.folded_)
    },
  },
}
</script>
<style lang="scss" scoped>
.expansion-fold__container {
  display: inline-block;
  .icon-wrap {
    cursor: pointer;
    display: flex;
    width: 50px;
    height: 20px;
    justify-content: center;
    align-items: center;
    background: url('~@/assets/expansion-close-bg.png');
    background-size: 100% 100%;
    .icon {
      transition: all 0.3s;
      color: #c6c7c7;
      font-size: 16px;
      transform: rotate(-90deg);
    }
  }
}
</style>
