# select list

time: 2019.6.24  
author: heyunjiang

## 背景

竖型列表，采用 ul + li 实现的列表，可以单选、多选。  
有许多地方用到该类似组件，所以特地抽象出来
