<template>
  <div class="main">
    <div v-if="addBtnName" class="add-btn" @click="handleAddEvent('add')">
      <i class="el-icon-circle-plus-outline"></i> {{ addBtnName }}
    </div>
    <ul v-if="listData.length > 0" class="list">
      <li
        v-for="item in listData"
        :key="item.id"
        :class="{ active: currentId == item.id }"
        @click="switchListItem(item.id)"
      >
        <span :title="item.name">{{ item.name }}</span>
        <!-- <div
          v-if="menuData.length > 0 && !item.hiddenMore"
          class="more-opr"
          
        ></div> -->
        <el-dropdown
          v-if="menuData.length > 0 && !item.hiddenMore"
          class="more-opr"
          trigger="click"
          @command="handleCommand($event, item)"
        >
          <div class="btn" @click.stop><i class="el-icon-more"></i></div>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item
              v-for="menu in menuData.filter(jtem => jtem.show === item.show)"
              :key="menu.command"
              :command="menu.command"
              >{{ menu.title }}</el-dropdown-item
            >
          </el-dropdown-menu>
        </el-dropdown>
      </li>
    </ul>
    <div v-else class="nodata">{{ $t('暂无数据') }}</div>
  </div>
</template>
<script>
/**
 * @title 管理者视图，标签、团队通用列表
 * @desc 展示项目标签和成员团队列表
 * @author lili
 * @date 2020.4.13
 */
export default {
  name: 'SelectListWithoutBorder',
  props: {
    addBtnName: {
      type: String,
      required: false,
      default: '',
      desc: '添加按钮的名字', // 有值显示，无值不显示
    },
    listData: {
      type: Array,
      required: true,
      desc: '列表数据',
    },

    activeId: {
      type: [String, Number],
      required: false,
      default: '',
      desc: '当前光标选中的',
    },

    menuData: {
      type: Array,
      required: false,
      desc: '操作菜单',
    },
  },

  data() {
    return {
      btnText: '添加',
      currentId: 0,
    }
  },
  watch: {
    activeId(val) {
      this.currentId = val
    },
  },

  created() {
    this.currentId = this.activeId
  },
  mounted() {},
  methods: {
    // 添加事件
    handleAddEvent() {
      this.$emit('add', { command: 'add' })
    },
    // 切换项目
    switchListItem(id) {
      this.currentId = id
      this.$emit('itemClick', { id })
    },
    // 选择操作菜单
    handleCommand(command, item) {
      this.$emit('menuClick', { command, ...item })
    },
  },
}
</script>
<style lang="scss" scoped>
.add-btn {
  // padding: 0 0 10px 15px;
  color: $--color-primary;
  cursor: pointer;
  font-size: 14px;
}
.list {
  width: 100%;
  max-height: 700px;
  overflow-y: auto;
  padding: 0;

  li {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 32px;
    line-height: 32px;
    padding: 5px 10px 5px 15px;
    box-sizing: border-box;
    border-radius: 4px;
    cursor: pointer;
    .more-opr {
      display: none;
      cursor: pointer;
      transform: rotate(90deg);

      .btn {
        outline: none;
      }
    }
    span {
      flex: 1;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      padding-right: 2px;
    }
    div {
      flex-shrink: 0;
    }
    &:hover {
      background-color: #e2e9ef;
      .more-opr {
        display: block;
      }
    }
    &.active {
      color: #ffffff;
      background-color: $--color-primary;
      .more-opr {
        color: #ffffff;
      }
    }
  }
}
.nodata {
  height: 40px;
  line-height: 40px;
  color: #bdbdbd;
  text-align: center;
}
</style>
