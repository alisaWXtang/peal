<template>
  <ul class="select-box">
    <li
      v-for="item in listData"
      :key="item.key"
      class="select-box-item ellipsis"
      :class="{ 'select-box-item-active': item.key === activeItem.key }"
      @click="clickCallback(item)"
    >
      <div :class="{ 'select-box-item-content': item.deleteAble }">
        <global-input
          v-if="item.editable"
          :init-value="item.value"
          :on-change="
            value => {
              finishEdit({ key: item.key, value })
            }
          "
        >
          <span class="common-input-edit-text">{{ item.value }}</span>
        </global-input>
        <span v-else>{{ item.value }}</span>
      </div>
      <div v-if="item.deleteAble" class="select-box-item-delete">
        <i
          class="el-icon-delete"
          @click="
            () => {
              finishDelete(item)
            }
          "
        ></i>
      </div>
    </li>
    <li v-if="addAble" class="select-box-item ellipsis">
      <span
        v-if="!addStatus.statu"
        class="select-box-item-add"
        @click="addClick"
        >+{{ $t('添加') }}</span
      >
      <el-input
        v-else
        ref="addInput"
        v-model.trim="addStatus.value"
        @blur="finishAdd"
        @change="finishAdd"
      ></el-input>
    </li>
    <li v-if="listData.length === 0" class="select-box-item-empty">
      {{ $t('暂无数据') }}
    </li>
  </ul>
</template>
<script>
// import { i18n } from '@/i18n'
/**
 * @title 竖型列表组件
 * @desc 支持单选、单项编辑删除、增加
 * @TODO 多选
 * @author heyunjiang
 * @date 2019.6.24
 */
import GlobalInput from '@/components/field-edit/GlobalInput'

export default {
  name: 'SelectList',
  components: {
    GlobalInput,
  },

  mixins: [],
  props: {
    listData: {
      type: Array,
      required: true,
      desc: '列表数据',
    },

    activeObj: {
      type: Object,
      required: false,
      default: () => {
        return { key: null, value: null }
      },
      desc: '默认选中值',
    },

    clickCallback: {
      type: Function,
      default: () => {},
      required: false,
    },

    addAble: {
      type: Boolean,
      required: false,
      desc: '是否可以新增',
      default: false,
    },
  },

  data() {
    return {
      activeItem: this.activeObj,
      addStatus: {
        statu: false,
        value: '',
      },
    }
  },
  computed: {},
  watch: {
    activeObj() {
      this.activeItem = this.activeObj
    },
  },

  created() {},
  methods: {
    // 点击添加
    addClick() {
      this.addStatus.statu = true
      this.$nextTick(() => {
        this.$refs.addInput.focus()
      })
    },
    // 添加完成
    finishAdd() {
      if (this.addStatus.statu && this.addStatus.value) {
        this.$emit('add', this.addStatus.value)
      }
      this.addStatus = {
        statu: false,
        value: '',
      }
    },
    // 修改完成
    finishEdit(info) {
      this.$emit('edit', info)
    },
    // 删除完成
    finishDelete(info) {
      this.$emit('delete', info)
    },
  },
}
</script>
<style lang="scss" scoped>
.select-box {
  list-style-type: none;
  margin: 0;
  padding: 0;
  border: 1px solid $color-border-common;
  // background: $color-background-light-common;
  border-radius: 3px;
  .select-box-item-active {
    color: $color-font-active-common;
    background-color: $color-active-background-common;
  }
  .select-box-item-empty {
    height: 40px;
    line-height: 40px;
    color: $color-font-notice-common;
    text-align: center;
  }
  .select-box-item {
    height: 34px; // 增加高度，保证 element-input 能合理展示
    line-height: 34px;
    cursor: pointer;
    color: $color-font-inactive-common;
    padding-left: 5px;
    border-bottom: 1px solid $color-border-common;
    box-sizing: border-box;
    &:hover {
      @extend .select-box-item-active;
    }
    .select-box-item-content {
      float: left;
      width: 90%;
    }
    .select-box-item-delete {
      float: right;
      width: 10%;
      text-align: center;
      position: relative;
      top: 1px;
    }
    .select-box-item-add {
      display: inline-block;
      width: 100%;
    }
  }
}
.common-input-edit-text {
  color: red;
}
</style>
