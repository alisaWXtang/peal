<template>
  <div
    ref="selectBox"
    data-type="select-box"
    class="select-box scrollbal-common"
    @click.stop
  >
    <el-input
      v-if="localSearch"
      ref="searchPeople"
      v-model="filter"
      data-type="select-box-filter"
      class="select-box-input"
      :placeholder="$t('搜索')"
    ></el-input>
    <div class="select-box-child scrollbal-common">
      <div v-if="GlobalLoading" class="loading-text">
        {{ $t('数据加载中') }}
      </div>
      <!-- currentValue == item.key为了解决，当点击多下统一个元素，样式不会保留 -->
      <template v-for="item in selectList">
        <div
          v-if="item.status !== 0"
          :key="item.key"
          class="select-box-item"
          :class="{
            'select-box-item-active':
              currentSelectValue.includes(item.key) || currentValue == item.key,
            'statusbox-list-common': colorType === 'bg',
            'statusbox-list-bg': colorType === 'font',
            'select-box-item-label': isNeddShowLabel,
            'select-option_invalid': item.status === 0,
          }"
          :style="{
            '--color':
              colorType === 'bg' || colorType === 'font' ? item.color : '',
          }"
          :title="item.value"
          data-type="select-box-item"
          @click="itemClick(item)"
        >
          <span
            v-if="item.color && colorType === 'circle'"
            class="mini-circle"
            :style="{ backgroundColor: item.color }"
          ></span>
          <span
            v-if="colorType === 'font' && item.color && item.font"
            :style="{ color: colorType === 'font' ? '' : item.color }"
            >{{ item.value }}</span
          >
          <span v-else>{{ item.value }}</span>
          <span v-if="isNeddShowLabel" class="showmore-label">{{
            item.label
          }}</span>
          <template
            v-if="
              currentSelectValue.includes(item.key) || currentValue === item.key
            "
          >
            <i
              v-if="colorType === 'font' || colorType === 'bg'"
              class="el-icon-circle-check select-protity-icon"
              :style="{ color: item.color }"
            ></i>

            <i v-else class="el-icon-check"></i>
          </template>
        </div>
      </template>
      <div
        v-show="customInput"
        class="select-box-item select-box-item-custom"
        data-type="select-box-item"
        style="padding:0;"
      >
        <el-input
          v-if="customInput"
          ref="relatedPerson"
          v-model="customValue"
          v-focus
          :placeholder="customInputPlaceHolder"
          @change="customInputChange"
        ></el-input>
      </div>
      <div
        v-if="isNeddShowMore"
        class="select-box-item showmore"
        @click="showmoreClick"
      >
        {{ showMore ? $t('收起') : $t('更多') }}
      </div>
    </div>
  </div>
</template>

<script>
import { i18n } from '@/i18n'
/**
 * @title field 编辑组件 - select 模块
 * @desc 该模块作为普通 field-edit 和 globalSelect 组件的最终 select 选择组件；自己有定位，并且 globalselect 也有定位
 * @author heyunjiang
 * @date 2019-3-5
 * @update 2019.6.19
 */

export default {
  name: 'SelectBox',
  props: {
    onChange: Function,
    selectValue: Array,
    currentValue: {
      validator: () => {
        return true
      },
    },

    colorType: String,
    localSearch: Boolean,
    multiple: Boolean,
    // eslint-disable-next-line vue/prop-name-casing
    GlobalLoading: Boolean,
    attrValueType: {
      type: String,
      required: false,
      desc: '字段类型',
    },

    show: {
      type: Boolean,
      required: false,
      default: false,
      desc: 'select 框是否显示，可读，不可写',
    },

    customInput: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否允许自定义输入',
    },

    customInputPlaceHolder: {
      type: String,
      required: false,
      default: i18n.t('自定义'),
      desc: '是否允许自定义输入 placeholder',
    },

    customInputChange: {
      type: Function,
      required: false,
      default: () => {},
      desc: '自定义输入变化回调',
    },
  },

  data() {
    return {
      currentSelectValue: [],
      filter: '',
      showMore: false,
      customValue: null,
    }
  },
  computed: {
    selectList() {
      let result = this.selectValue
      // 如果过滤
      if (this.filter.trim().length > 0) {
        result = this.selectValue.filter(item => {
          return item.value.indexOf(this.filter) !== -1
        })
      }
      // 如果需要展示更多操作
      if (result.filter(item => item.showMore).length > 0) {
        result = result.filter(item => {
          if (!this.showMore) {
            return !item.showMore
          } else {
            return true
          }
        })
      }
      return result
    },
    isMultiple() {
      return this.multiple
    },
    // 是否需要展示更多模式，当字段存在 showMore 时，则需要点击更多才能展示
    isNeddShowMore() {
      return this.selectValue.filter(item => item.showMore).length > 0
    },
    // 是否需要展示 label 模式
    isNeddShowLabel() {
      return this.selectValue.filter(item => item.label).length > 0
    },
  },

  watch: {
    currentValue() {
      this.setCurrentValue()
    },
    show() {
      if (!this.show) {
        this.filter = ''
        this.customValue = null
      } else {
        this.inputAutofocus()
      }
    },
    selectValue() {
      this.filter = ''
      this.$nextTick(this.resetPosition)
    },
  },
  created: function() {
    this.setCurrentValue()
  },

  mounted: function() {
    this.resetPosition()
    this.inputAutofocus()
  },

  methods: {
    // input自动聚焦
    inputAutofocus() {
      // 这个是解决第一次打开的时候自动聚焦会失效，暂时没想到其他办法，后面有时间回来在想下办法
      setTimeout(() => {
        this.inputLocalOrCustom()
      }, 500)
      this.$nextTick(() => {
        this.inputLocalOrCustom()
      })
    },
    inputLocalOrCustom() {
      if (this.localSearch) {
        this.$refs.searchPeople && this.$refs.searchPeople.$refs.input.focus()
      } else if (this.customInput) {
        this.$refs.relatedPerson && this.$refs.relatedPerson.$refs.input.focus()
      }
    },
    // 修复线上问题:主要为了解决在缺陷详情模式，当框靠在最右边会被覆盖一部分，原因是它的祖先级别加了overflow:auto，和overflow:hidden,但是代码又不能随意删，有一个还是加在公共组件上的，所以在这里用hack的方法解决下，至于70是调试出来感觉比较合适。
    getInstanceRightNum() {
      return this.$route.name === 'bugList' &&
        [null, 'false'].includes(localStorage.getItem('bugManagementPageType'))
        ? 70
        : 0
    },
    // 重新渲染位置
    resetPosition() {
      if (!this.$parent.$refs.selectBoxSibling) {
        return
      }
      const selectRect = this.$refs.selectBox.getBoundingClientRect()
      const transformObj = {
        x: '-5px',
        y: '0',
      }

      if (selectRect.right > window.innerWidth) {
        transformObj.x =
          window.innerWidth -
          selectRect.right -
          this.getInstanceRightNum() +
          'px'
      }
      if (selectRect.bottom > window.innerHeight) {
        transformObj.y = window.innerHeight - selectRect.bottom + 'px'
      }
      if (
        selectRect.right > window.innerWidth ||
        selectRect.bottom > window.innerHeight
      ) {
        this.$refs.selectBox.style.transform =
          'translate(' + transformObj.x + ', ' + transformObj.y + ')'
      }
    },
    itemClick: function(item) {
      let result = [...this.currentSelectValue].filter(
        jtem => !['', null, undefined].includes(jtem),
      )
      if (this.currentSelectValue.includes(item.key)) {
        // 如果是多项选择，则删除，单项选择，则不删除
        if (this.isMultiple) {
          result = result.filter(jtem => jtem !== item.key)
          this.currentSelectValue = [...result]
        } else {
          this.currentSelectValue = []
        }
      } else {
        result.push(item.key)
      }
      // 兼容一些写法
      if (this.isMultiple) {
        this.onChange(result)
      } else {
        this.onChange(item)
      }
    },
    // 设置当前选中值，可以是单选或多选
    setCurrentValue() {
      if (this.isMultiple) {
        this.currentSelectValue = Array.isArray(this.currentValue)
          ? this.currentValue
          : []
      } else {
        this.currentSelectValue = [this.currentValue]
      }
    },
    showmoreClick() {
      this.showMore = !this.showMore
    },
  },
}
</script>

<style lang="scss" scoped>
$select-box-item-height: 28px;

.select-box {
  position: absolute;
  top: 30px;
  left: 0;
  max-width: 400px;
  min-width: 160px;
  margin: 0;
  padding: 10px 0;
  border: 1px solid #e9eef6;
  border-radius: 4px;
  box-shadow: 0 3px 12px 0 rgba(102, 102, 102, 0.15);
  background-color: #fff;

  box-sizing: border-box;
  z-index: 1100;
  .select-box-child {
    overflow-x: hidden;
    overflow-y: auto;
    max-height: 300px;
    background-color: #fff;
    padding: 8px;
  }
  .select-box-input {
    display: block;
    width: 92%;
    margin: auto;
  }
  .select-box-item {
    width: 100%;
    font-size: 14px;
    box-sizing: border-box;
    padding: 1px 30px 1px 10px;
    line-height: 40px;
    height: 40px;
    border-radius: $--card-border-radius;
    cursor: pointer;
    color: $--color-text-regular;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    position: relative;
    &:hover {
      background-color: #f8f8f8;
    }

    // 通用-状态盒子-列表
    &.statusbox-list-bg,
    &.statusbox-list-common {
      overflow: visible;
      font-size: $font-size-small;
      cursor: pointer;
      color: var(--color);
      border: 1px solid var(--color);
      border-radius: 4px;
      padding: 2px 5px;
      line-height: 16px;
      background-color: #fff;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      height: 30px;
      &:hover {
        color: #fff;
        background-color: var(--color);
        transition: all 0.3s ease;
      }
      &:not(:first-child) {
        margin-top: 8px;
      }
    }
  }
  .select-box-item-label {
    display: flex;
    flex-flow: row nowrap;
    justify-content: space-between;
  }
  .select-box-item-active {
    color: $--color-primary;
    background-color: $--color-primary-light-9;

    .showmore-label {
      color: $--color-primary-light-3;
    }

    &:hover {
      color: $--color-primary;
      background-color: $--color-primary-light-9;
    }

    .el-icon-check {
      position: absolute;
      right: 10px;
      top: 14px;
      color: $--color-primary;
    }
    .el-icon-circle-check {
      @extend .el-icon-check;
      top: 6px;
      right: 1px;
      z-index: 3000;
      font-size: 16px;
      background-color: white;
      border-radius: 50%;
      line-height: 1;
    }
    .select-protity-icon {
      top: -7px;
      right: -4px;
    }
  }
  .select-box-item-bgtype {
    padding-left: 5px;
    color: $color-font-white-common;
  }
  .select-box-item-custom {
    min-width: 80px;
  }
  .loading-text {
    text-align: center;
    font-size: 12px;
  }
}
.showmore {
  cursor: pointer;
  text-align: center;
}
.showmore-label {
  color: #8492a6;
  font-size: 14px;
}
</style>
