<template>
  <div v-show="show" class="global-belctbox" :style="currentPosition">
    <select-box
      :color-type="colorType"
      :local-search="localSearch"
      :select-value="selectValue"
      :on-change="onFieldValueChange"
      :current-value="selectTypeValue"
      :multiple="multiple"
      :global-loading="GlobalLoading"
      :show="show"
      :custom-input="customInput"
      :custom-input-place-holder="customInputPlaceHolder"
      :custom-input-change="onCustomInputChange"
    ></select-box>
  </div>
</template>

<script>
import { i18n } from '@/i18n'
/**
 * @title 全局 select 组件，仅可使用在 el-table 中
 * @desc 目前支持功能：
 * @func 1 单选、多选
 * @func 2 小圆圈、背景色、文字颜色
 * @func 3 可搜索
 * @func 4 点击选项钩子
 * @author heyunjiang
 * @date 2019.4.26
 * @todo 换成 popover
 */
import SelectBox from './SelectBox'
import isEqual from 'lodash/isEqual'
import { isEmpty, getRootEl } from '@/utils'

export default {
  name: 'GlobalSelect',
  components: {
    SelectBox,
  },

  props: {
    initValue: {
      type: [String, Number, Array, Boolean],
      required: true,
      desc: '当前选择框的值，多选必须是 array',
    },

    selectValue: {
      type: Array,
      required: true,
      validator: () => {
        // 后面再验证，要求是 [{key, value}] 格式，并且 length > 1
        return true
      },
      desc: '选择框的所有选项',
    },

    onChange: {
      type: Function,
      required: false,
      default: () => {},
      desc: 'value 选择之后回调函数',
    },

    beforeSelect: {
      type: Function,
      required: false,
      desc: 'value 选择之前回调函数',
    },

    onOtherClose: {
      type: Function,
      required: true,
      desc: '点击任意地方可以关闭',
    },

    // select item 样式
    colorType: {
      type: String,
      required: false,
      desc: '目前支持小圆圈、背景、字体3种状态，默认无',
      validator: value => {
        return ['circle', 'bg', 'font'].indexOf(value) !== -1
      },
    },

    // 是否支持过滤
    localSearch: {
      type: Boolean,
      required: false,
      desc: '是否支持本地搜索',
    },

    multiple: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否支持多选',
    },

    show: {
      type: Boolean,
      required: true,
      desc: '是否展示',
    },

    // eslint-disable-next-line vue/prop-name-casing
    GlobalLoading: {
      type: Boolean,
      required: false,
      default: false,
      desc: 'loading',
    },

    target: {
      type: [HTMLHtmlElement, HTMLSpanElement],
      required: true,
      desc: '点击的目标节点',
    },

    customInput: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否允许自定义输入',
    },

    customInputPlaceHolder: {
      type: String,
      required: false,
      default: i18n.t('自定义'),
      desc: '是否允许自定义输入 placeholder',
    },

    customInputChange: {
      type: Function,
      required: false,
      desc: '自定义输入变化回调',
    },
  },

  data() {
    return {
      selectTypeValue: '', // 当前选中的值
      currentPosition: {},
      listenerDom: [],
      parentNode: null,
    }
  },
  watch: {
    show() {
      if (!this.show) {
        this.listenerDom.forEach(item => {
          item && item.removeEventListener('click', this.bodyEvent)
        })
      } else {
        setTimeout(() => {
          this.listenerDom.forEach(item => {
            item && item.addEventListener('click', this.bodyEvent)
          })
        })
      }
    },
    target() {
      this.$nextTick(this.globalSelectDisplayHandle)
    },
    selectValue() {
      this.$nextTick(this.globalSelectDisplayHandle)
    },
    $route() {
      this.onOtherClose()
    },
    // 当 initValue 变化时，更新 selectTypeValue 值
    initValue() {
      this.selectTypeValue = this.initValue
    },
  },
  mounted() {
    // 绑定关闭的 dom ：#app
    const domArray = [getRootEl()]
    domArray.push(this.$el.closest('.bug-content-box')) // slider
    this.listenerDom = domArray
    this.selectTypeValue = this.initValue
  },

  beforeDestroy() {
    if (this.show) {
      this.parentNode.removeChild(this.$el)
    }
  },
  methods: {
    // 自定义字段 被删除的选项需要 by wangling
    delectFieldNotDisplay() {
      if (this.multiple) {
        let result = [...this.selectTypeValue]
        // 为空字符串或者为[]都不执行以下方法,没获取到自定义字段列表不执行以下方法,解决全部清空的问题,,兼容处理
        if (
          this.selectValue.length === 0 ||
          isEmpty(this.selectTypeValue) ||
          this.selectTypeValue === '[]'
        ) {
          return
        }
        this.selectTypeValue.forEach(item => {
          if (!this.isContainsElement(this.selectValue, item)) {
            result.splice(result.indexOf(item), 1)
          }
        })
        this.selectTypeValue = result
      }
    },
    isContainsElement(arr, element) {
      return arr.find(item => {
        return item.key === element
      })
    },
    // select 值变化操作，只考虑点击项的时候做关闭前的钩子，不考虑点击任意位置关闭的钩子
    onFieldValueChange(result) {
      if (this.beforeSelect) {
        this.beforeSelect(result, hookResult => {
          if (hookResult && !this.multiple) {
            this.onOtherClose()
          }
        })
      } else {
        if (!this.multiple) {
          this.onOtherClose()
          this.selectTypeValue = result.key
          this.onChange && this.onChange(result.key)
        } else {
          this.selectTypeValue = result
          this.onChange && this.onChange(result)
        }
      }
    },
    // selectbox 展示框事件监听函数
    bodyEvent: function(e) {
      if (
        !e.target.hasAttribute('data-type') ||
        !e.target.getAttribute('data-type').indexOf('select-box') !== -1
      ) {
        this.isNeedUpdatedBydeleteField()
        this.onOtherClose(this.selectTypeValue)
      }
    },
    // 外部任意位置点击 是否发送更新请求
    isNeedUpdatedBydeleteField() {
      this.delectFieldNotDisplay()
      // 外部任意位置点击
      const isSelectValueChange = !isEqual(this.initValue, this.selectTypeValue)
      if (this.multiple && isSelectValueChange) {
        this.onChange && this.onChange(this.selectTypeValue)
      }
    },
    // select 渲染
    globalSelectDisplayHandle() {
      if (this.target.tagName.toLowerCase() !== 'span') {
        return
      }
      this.currentPosition = this.position
      // 判断 target 距离 table 底部距离
      const targetRect = this.target.getBoundingClientRect()
      const tableRect = this.target
        .closest('.el-table__body')
        .getBoundingClientRect()
      const selectRect = this.$el
        .querySelector('.select-box')
        .getBoundingClientRect()
      const isOverTable =
        tableRect.bottom - targetRect.bottom > selectRect.height // 是否超出了 table 底部边框
      const isOverBody =
        window.innerHeight - tableRect.bottom > selectRect.height // table 底部距离是否足够
      const isTargetToBodyEnough =
        window.innerHeight - targetRect.bottom > selectRect.height // target底部距离是否足够

      // const sliderElement = document.querySelector(".sider-right");
      const sliderElement = this.target.closest('.sider-right')
      const parentRect = sliderElement
        ? sliderElement.getBoundingClientRect()
        : {}
      if (sliderElement && parentRect.left < window.innerWidth) {
        // 如果是在 slider 层渲染
        const top = isOverTable
          ? targetRect.top + sliderElement.scrollTop
          : targetRect.top + sliderElement.scrollTop - selectRect.height - 34
        this.currentPosition = {
          left: targetRect.left - parentRect.left + 'px',
          top: top + 'px',
          zIndex: isOverTable ? '999' : '1999',
        }

        sliderElement.appendChild(this.$el)
        this.parentNode = sliderElement
      } else {
        // 如果是在普通 body 渲染
        let top =
          isOverTable && isTargetToBodyEnough
            ? targetRect.top + window.pageYOffset
            : targetRect.top + window.pageYOffset - 34 - selectRect.height

        if (!isOverTable && isOverBody) {
          top = targetRect.top + window.pageYOffset
        }
        // 如果到达浏览器顶部
        if (top < -30) {
          top = -30
        }
        // 如果到达浏览器最右侧
        let left = targetRect.left
        let positionObj = {
          left: left + 'px',
        }

        if (selectRect.width + left > window.innerWidth) {
          positionObj = {
            right: '0',
            left: 'inherit',
          }
        }
        this.currentPosition = {
          ...positionObj,
          top: top + 'px',
          zIndex: isOverTable ? '999' : '1999',
        }

        document.body.appendChild(this.$el)
        this.parentNode = document.body
      }
    },
    // 自定义输入变化回调
    onCustomInputChange(value) {
      this.onOtherClose()
      this.customInputChange && this.customInputChange(value)
    },
  },
}
</script>

<style lang="scss" scoped>
.global-belctbox {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  /deep/ .select-box {
    position: relative;
  }
}
</style>
