<template>
  <div class="table-input-edit-box pointerhover">
    <template v-if="!isEditable">
      <template v-if="['text'].includes(inputType)">
        <slot></slot>
        <i class="el-icon-edit table-input-edit-icon" @click="editable"></i>
      </template>
      <template v-else>
        <span class="ellipsis" @click="editable">
          <slot></slot>
        </span>
      </template>
    </template>
    <template v-if="isEditable">
      <el-input
        v-if="['text', 'textarea'].includes(inputType)"
        ref="textEditable"
        v-model="currentData"
        :type="inputType"
        class="editable-input"
        :placeholder="$t('请输入内容')"
        @blur="unEditable"
        @change="unEditable"
      ></el-input>
      <el-input
        v-else-if="['progress', 'number'].includes(inputType)"
        :ref="inputType === 'progress' ? 'progressEditable' : 'textEditable'"
        v-model="currentData"
        type="number"
        class="editable-input"
        :placeholder="$t('请输入内容')"
        @blur="unEditable"
        @change="unEditable"
      >
        <template #suffix>
          <i
            class="el-input__icon el-icon-circle-close el-input__clear"
            @mousedown="whenClearFieldValue"
          ></i>
        </template>
      </el-input>
      <custom-date
        v-else-if="['date', 'time'].includes(inputType)"
        ref="globalDatepicker"
        v-model="currentData"
        class="globalDatepicker"
        :picker-options="{}"
        @blur="unEditable"
      ></custom-date>
      <el-select
        v-if="['boolean'].includes(inputType)"
        v-model="currentData"
        class="input-typeed-class"
        @change="unEditable"
      >
        <el-option :label="$t('是')" :value="true"></el-option>
        <el-option :label="$t('否')" :value="false"></el-option>
      </el-select>
      <!-- <div @click.stop>
        <el-radio-group v-if="['boolean'].includes(inputType)" @change="unEditable" @blur="unEditable" v-model="currentData">
          <el-radio :label="true">是</el-radio>
          <el-radio :label="false">否</el-radio>
        </el-radio-group>
      </div> -->
    </template>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 支持 文本、日期、数字、日期、布尔
 * @desc 主要用于全局 input 的修改
 * @author heyunjiang
 * @date
 */
import CustomDate from '@/components/custom-date'
export default {
  name: 'GlobalInput',
  components: {
    CustomDate,
  },
  mixins: [],
  props: {
    initValue: {
      validator: () => {
        return true
      },
      required: true,
      desc: '当前输入的初始值',
    },

    onChange: {
      type: Function,
      required: true,
      desc: 'value 变化之后回调函数',
    },

    inputType: {
      type: String,
      required: false,
      default: 'text',
      validator: value => {
        return [
          'text',
          'time',
          'progress',
          'textarea',
          'boolean',
          'number',
          'date',
        ].includes(value)
      },
    },

    attrValueType: {
      type: String,
      required: false,
      default: 'SINGLE_TEXT',
      desc: '字段类型，默认普通 input 框',
    },

    projectText: {
      type: String,
      required: false,
      default: 'text',
    },

    daisableTime: {
      type: [String, Number],
      required: false,
      default: null,
    },
  },

  data() {
    return {
      isEditable: false, // 是否在编辑状态
      originalData: '',
      currentData: '',
      lasteUneditableTime: 0, // 模拟节流实现：上次 blur 或 change 时间
      isClearClicked: false,
    }
  },
  computed: {},
  watch: {
    initValue() {
      this.initData()
    },
  },

  created() {},
  mounted() {
    this.initData()
  },
  methods: {
    // 初始化數據
    initData() {
      this.originalData = this.initValue
      this.currentData = this.initValue
    },
    // 进入编辑状态
    editable() {
      //解决上一次更新失败，失败的数据还保留问题
      if (this.currentData !== this.initValue) {
        this.currentData = this.initValue
      }
      this.isEditable = true
      this.$nextTick(() => {
        ;['text', 'textarea', 'number'].includes(this.inputType) &&
          this.$refs.textEditable.focus()
        ;['progress'].includes(this.inputType) &&
          this.$refs.progressEditable.focus()
        ;['time', 'date'].includes(this.inputType) &&
          this.$refs.globalDatepicker.focus()
      })
    },
    // 编辑结束,进度的判断
    progressUnEditAble() {
      // 单纯输入空格,更新有问题
      if (typeof this.currentData === 'string') {
        this.currentData = this.currentData.replace(/(^\s*)|(\s*$)/g, '')
      }
      const progressvalue = Number(this.currentData)
      const tofixed = /^(\d{1,2}(\.\d{1})?|100)$/ //只保留一位小数
      if (!tofixed.test(progressvalue)) {
        this.$message({
          showClose: true,
          message: i18n.t('进度只能在0到100之间且只保留一位小数'),
          type: 'warning',
        })

        this.currentData = this.originalData
      }
    },
    // 编辑结束，进入未编辑状态
    unEditable() {
      // 节流实现
      const now = new Date().getTime()
      if (now - this.lasteUneditableTime < 100) {
        return false
      }
      this.lasteUneditableTime = now
      this.isEditable = false
      if (this.inputType === 'progress') {
        this.progressUnEditAble()
        if (this.currentData == this.originalData && !this.isClearClicked) {
          return
        }
      }
      this.isClearClicked && (this.currentData = '')
      if (this.currentData === this.originalData) {
        this.isClearClicked = false
        return
      }
      if ([null, '', []].includes(this.currentData)) {
        this.currentData = this.$store.state.cm.customFieldInitTypeMap[
          this.attrValueType
        ]

        if (['date', 'time'].includes(this.inputType)) {
          // this.currentData = '2001-01-01';
        }
        if (['text', 'textarea', 'number'].includes(this.inputType)) {
          this.$nextTick(() => {
            this.currentData = this.originalData
          })
        }
        this.onChange(this.currentData)
      } else if (this.currentData !== this.originalData) {
        this.onChange(this.currentData)
      }
      if (this.daisableTime == 1) {
        this.currentData = this.originalData
      }
      this.isClearClicked = false
    },
    // 点击清空选择按钮
    whenClearFieldValue() {
      this.isClearClicked = true
    },
  },
}
</script>
<style lang="scss" scoped>
.globalDatepicker {
  max-width: 100%;
}

// .pointerhover {
//   cursor: pointer;
//   padding: 1px;

//   .ellipsis {
//     &:hover {
//       box-shadow: 0 0 0 1px #ccc;
//     }
//   }

// }
</style>
