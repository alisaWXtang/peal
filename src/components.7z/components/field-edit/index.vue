<template>
  <div
    class="field-edit-box"
    :style="
      `color: ${
        attrName === 'priority' ? attrColor : '#666'
      };border: 1px solid ${
        attrName === 'priority' ? attrColor : '#fff'
      };width:auto;height: ${userSelectActive && multiple ? 'auto' : ''} `
    "
    :class="{
      'editable-field': showOuterBorder && showText && !userSelectActive,
      'field-input-box': inputType !== 'select',
      'hover-show-close-icon': isShowCloseIcon,
    }"
  >
    <span
      v-if="!userSelectActive && showText"
      ref="selectBoxSibling"
      class="cursor-pointer editable-field-label editable-field-label-ellipsis"
      :title="titleNotice"
      @click="fieldClick"
      v-html="value"
    ></span>
    <i
      v-if="isShowCloseIcon"
      class="el-icon-circle-close hour-select-close"
      :title="$t('删除')"
      @click="handleClearHour"
    ></i>
    <template v-if="status === 'active'">
      <!-- 用户单选，多选 -->
      <global-user-select
        v-if="isUserSelect"
        ref="globalUserSelect"
        :is-focus="true"
        :env-type="$attrs.envType || 'PROJECT'"
        :filter-invalid="true"
        :multiple="multiple"
        :api-params="{ projectId }"
        :value="defaultSelectValue"
        :placeholder="$t('输入拼音/工号/姓名')"
        @visibleChange="selectUserVisibleChange"
        @change="onFieldValueChange"
      ></global-user-select>
      <!-- 单选、多选 -->
      <select-box
        v-if="!isUserSelect && inputType === 'select'"
        :color-type="colorType"
        :attr-value-type="attrValueType"
        :show="inputType === 'select'"
        :local-search="localSearch"
        :select-value="selectValue"
        :on-change="onFieldValueChange"
        :current-value="inputTypeValue"
        :custom-input="customInput"
        :custom-input-place-holder="customInputPlaceHolder"
        :custom-input-change="onCustomInputChange"
        :multiple="multiple"
      ></select-box>
      <!-- cascader -->
      <el-cascader
        v-if="inputType === 'cascader'"
        ref="cascader"
        v-model="inputTypeValue"
        :options="selectValue"
        :props="{
          multiple: multiple,
          value: 'id',
          label: 'name',
          emitPath: false,
        }"
        :show-all-levels="false"
        class="editable-cascader"
        popper-class="cascader-custom-height"
        :placeholder="$t('请选择')"
        filterable
        @change="onFieldValueChange"
      >
      </el-cascader>
      <!-- 普通文本框、textarea输入 -->
      <el-input
        v-if="['text', 'textarea'].includes(inputType)"
        ref="textInput"
        v-model="inputTypeValue"
        data-type="text"
        :type="inputType"
        class="editable-input el-input-lowheight"
        :placeholder="$t('请输入内容')"
        @blur="unEditable"
        @change="unEditable"
      ></el-input>
      <!-- 简单时间框 -->
      <custom-date
        v-if="['date'].includes(inputType)"
        ref="dateInput"
        v-model="inputTypeValue"
        class="editable-input el-input-lowheight"
        :picker-options="{}"
        :placeholder="$t('选择日期')"
        @blur="unEditable"
      ></custom-date>
      <!-- 布尔值选择框 -->
      <el-select
        v-if="['boolean'].includes(inputType)"
        v-model="inputTypeValue"
        class="input-typeed-class"
        @change="unEditable"
      >
        <el-option :label="$t('是')" :value="true"></el-option>
        <el-option :label="$t('否')" :value="false"></el-option>
      </el-select>
      <!-- 整数输入框, 浮点数输入框 -->
      <el-input
        v-if="['number', 'progress'].includes(inputType)"
        ref="numberInput"
        v-model="inputTypeValue"
        type="number"
        data-type="number"
        class="editable-input el-input-lowheight"
        @blur="unEditable"
        @change="unEditable"
      >
        <template #suffix>
          <i
            v-if="isClearable"
            class="el-input__icon el-icon-circle-close el-input__clear"
            @mousedown="whenClearFieldValue"
          ></i>
        </template>
      </el-input>
    </template>
  </div>
</template>

<script>
/**
 * @title select 组件
 * @desc 缺陷：展示与否应该通过 props 更新，而不是自己控制，目前只支持在缺陷内部使用
 * @desc 目前支持功能：
 * @func 1 单选、多选、普通文本输入、日期输入、布尔输入、富文本输入、数字输入
 * @func 2 小圆圈、背景色、文字颜色
 * @func 3 展示值html可自行传入
 * @func 4 可搜索
 * @func 5 点击选项钩子
 * @func 6 点击展示值的事件 FieldEditFieldClick
 * @author heyunjiang
 * @date 2019-3-5
 * @update 2019.4.23
 */
import { i18n } from '@/i18n'
import SelectBox from './SelectBox'
import GlobalUserSelect from '@/components/global-user-select'
import { sanitizeHTML, isEmpty, getRootEl } from '@/utils'
import CustomDate from '@/components/custom-date'
export default {
  name: 'FieldEdit',
  components: {
    SelectBox,
    GlobalUserSelect,
    CustomDate,
  },

  props: {
    inputType: {
      type: String,
      required: false,
      default: 'select',
      validator: value => {
        return [
          'select',
          'text',
          'textarea',
          'boolean',
          'number',
          'date',
          'progress',
          'cascader',
        ].includes(value)
      },
    },

    attrValueType: {
      type: String,
      required: false,
      default: 'SINGLE_TEXT',
      desc: '字段类型，默认普通 input 框',
    },

    initValue: {
      validator: () => {
        return true
      },
      required: true,
      desc: '当前选择框的值，多选必须是 array',
    },

    initName: {
      type: [String, Boolean],
      required: false,
      desc:
        '当前选择框展示的值，名字取错了，不是初始值，是外部控制它的选中的展示值',
    },

    selectValue: {
      type: Array,
      required: false,
      default: () => {
        return []
      },
      validator: () => {
        // 后面再验证，要求是 [{key, value}] 格式，并且 length > 1
        return true
      },
      desc: '选择框的所有选项',
    },

    onChange: {
      type: Function,
      required: false,
      default: () => {},
      desc: 'value 选择之后回调函数',
    },

    beforeSelect: {
      type: Function,
      required: false,
      desc: 'value 选择之前回调函数',
    },

    // select item 样式
    colorType: {
      type: String,
      required: false,
      desc: '目前支持小圆圈、背景、字体3种状态，默认无',
      validator: value => {
        return ['circle', 'bg', 'font'].indexOf(value) !== -1
      },
    },

    // 是否支持过滤
    localSearch: {
      type: Boolean,
      required: false,
      desc: '是否支持本地搜索',
    },

    // 是否展示鼠标悬浮外框
    showOuterBorder: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否展示鼠标悬浮外框',
    },

    multiple: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否支持多选',
    },

    customInput: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否允许自定义输入',
    },

    customInputPlaceHolder: {
      type: String,
      required: false,
      default: i18n.t('自定义'),
      desc: '是否允许自定义输入 placeholder',
    },

    customInputChange: {
      type: Function,
      required: false,
      desc: '自定义输入变化回调',
    },

    isClearable: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否可清空内容',
    },

    attrName: {
      type: String,
      default: '',
      desc: '字段属性名',
    },

    attrColor: {
      type: String,
      default: '#fff',
      desc: '小精灵反馈优先级颜色',
    },
  },

  data() {
    return {
      inputTypeValue: '',
      type: 'text',
      status: 'inactive', // inactive, active
      lasteUneditableTime: 0, // 模拟节流实现：上次 blur 或 change 时间
      isClearClicked: false, // 是否点击了清空按钮
      userSelectActive: false,
    }
  },
  computed: {
    projectId() {
      return this.$store.state.pf.ProjectId
    },
    // 超出长度做提示
    titleNotice() {
      // eslint-disable-next-line no-useless-escape
      const titleReg = /\<|\>/
      if (!this.initName || this.initName.length < 8) {
        return false
      }
      return titleReg.test(this.initName) ? false : this.initName
    },
    // 设置当前展示的 name
    value() {
      const selected = this.selectValue.filter(item => {
        return this.multiple
          ? this.inputTypeValue.includes(item.key)
          : item.key === this.inputTypeValue
      })
      let content = this.initName
        ? this.initName
        : selected.length > 0
        ? selected[0].value
        : '--'
      if (this.attrValueType === 'MULTI_MEMBER_CHOICE' && this.initValue > 0) {
        content = content
          .split(',')
          .map((Item, index) => `${Item}(${this.initValue[index]})`)
          .join('，')
      }
      // colorType
      if (['text', 'textarea'].includes(this.inputType)) {
        content = sanitizeHTML(content)
      }
      return content
    },
    // 绑定关闭的 dom ：#app, .bug-content-box
    listenerDom() {
      let arr = [getRootEl()]
      if (this.$refs.selectBoxSibling) {
        arr.push(this.$refs.selectBoxSibling.closest('.bug-content-box'))
      }
      return arr
    },
    // 是否展示 selectBoxSibling 文字，只有在 select 和 非 select 且 status 为 inactive 时展示
    showText() {
      return (
        this.inputType === 'select' ||
        (this.inputType !== 'select' && this.status === 'inactive')
      )
    },
    // 是否显示删除图标
    isShowCloseIcon() {
      return (
        this.isClearable &&
        this.status === 'inactive' &&
        ['expectHour', 'actualHour'].includes(this.attrName)
      )
    },
    isUserSelect() {
      return ['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(
        this.attrValueType,
      )
    },
    defaultSelectValue() {
      if (
        this.multiple &&
        this.attrValueType.indexOf('MULTI_MEMBER_CHOICE') > -1
      ) {
        const userNames = this.initName.split(',')
        const options = []
        Array.isArray(this.initValue) &&
          this.initValue.forEach((userId, key) => {
            options.push({
              userId,
              userName: userNames[key],
            })
          })

        return options
      }

      return ''
    },
  },

  watch: {
    status() {
      if (this.status === 'inactive') {
        this.userSelectActive = false
        this.delectFieldNotDisplay()
        if (this._isEqual(this.initValue, this.inputTypeValue)) {
          this.$emit('inactiveWithoutValueChange')
        } else {
          this.$emit('inactive', this.inputTypeValue)
        }
        this.listenerDom.forEach(item => {
          item && item.removeEventListener('click', this.bodyEvent)
        })
      } else {
        setTimeout(() => {
          this.listenerDom.forEach(item => {
            item && item.addEventListener('click', this.bodyEvent)
          })
        })
      }
    },
    // 当 initValue 变化时，更新 inputTypeValue 值
    initValue() {
      this.inputTypeValue = this.initValue
    },
  },

  mounted() {
    this.inputTypeValue = this.initValue
  },
  methods: {
    // 选择用户失去焦点时触发事件
    selectUserVisibleChange(val) {
      if (val) {
        this.userSelectActive = true
      } else {
        this.userSelectActive = false
        this.status = 'inactive'
      }
    },
    // 自定义字段 被删除的选项需要 by wangling
    delectFieldNotDisplay() {
      if (this.multiple) {
        let result = [...this.inputTypeValue]
        // 为空字符串或者为[]都不执行以下方法,没获取到自定义字段列表不执行以下方法,解决全部清空的问题,,兼容处理
        if (
          this.selectValue.length === 0 ||
          isEmpty(this.inputTypeValue) ||
          this.inputTypeValue === '[]'
        ) {
          return
        }
        this.inputType === 'select' &&
          this.inputTypeValue.forEach(item => {
            if (!this.isContainsElement(this.selectValue, item)) {
              result.splice(result.indexOf(item), 1)
            }
          })
        this.inputTypeValue = result
      }
    },
    isContainsElement(arr, element) {
      return arr.find(item => {
        return item.key === element
      })
    },
    // 判断数据是否相等 -- 不完整，只判断简单类型和数组
    _isEqual(pre, next) {
      if (pre == null || next == null) {
        return false
      }
      if (typeof pre !== typeof next) {
        return false
      }
      if (typeof pre === 'object') {
        if (Array.isArray(pre)) {
          if (pre.length === next.length) {
            pre = [...pre].sort()
            next = [...next].sort()
            let isequal = true
            for (let i = 0; i < next.length; i++) {
              if (pre[i] !== next[i]) {
                isequal = false
                break
              }
            }
            return isequal
          } else {
            return false
          }
        }
        return false
      } else {
        return pre === next
      }
    },
    // 点击编辑框，进入编辑状态
    fieldClick() {
      // 当更新失败时，更新失败输入的值还保留着的，主要是解决这个问题
      if (this.inputTypeValue !== this.initValue) {
        this.inputTypeValue = this.initValue
      }
      this.status = 'active'
      this.$emit('FieldEditFieldClick')
      // 设置聚焦
      this.$nextTick(() => {
        let elementDom = null
        switch (this.inputType) {
          case 'text':
          case 'textarea':
            elementDom = this.$refs.textInput
            break
          case 'date':
            elementDom = this.$refs.dateInput
            break
          case 'progress':
          case 'number':
            elementDom = this.$refs.numberInput
            break
        }

        elementDom && elementDom.focus()

        if (this.inputType === 'cascader') {
          this.$refs.cascader.toggleDropDownVisible(true)
        }
      })
    },
    // select 值变化操作，只考虑点击项的时候做关闭前的钩子，不考虑点击任意位置关闭的钩子
    onFieldValueChange(result) {
      if (this.beforeSelect) {
        this.beforeSelect(result, hookResult => {
          if (hookResult && !this.multiple) {
            this.status = 'inactive'
          }
        })
      } else {
        if (!this.multiple) {
          const { key: resultKey, userId } = result
          this.status = 'inactive'
          this.userSelectActive = false
          let changedValue = !this.isUserSelect ? resultKey : userId
          this.inputTypeValue = changedValue
          // 判断是否清空当前选择
          if (this.isClearable) {
            if (
              (this.isUserSelect && this.initValue === userId) ||
              (!this.isUserSelect && this.initValue === resultKey)
            ) {
              changedValue = null
            }
          }
          ;['expectHour', 'actualHour'].includes(this.attrName) &&
            !changedValue &&
            (changedValue = 0)
          // 没有变化， 不触发事件
          if (
            this._isEqual(
              this.initValue,
              !this.isUserSelect ? resultKey : userId,
            ) &&
            !this.isClearable
          ) {
            return
          }
          this.onChange && this.onChange(changedValue)
        } else {
          if (this.attrValueType === 'MULTI_MEMBER_CHOICE') {
            const userIds = []
            Array.isArray(result) &&
              result.forEach(element => {
                userIds.push(element.userId)
              })
            this.inputTypeValue = userIds
            if (this._isEqual(this.initValue, userIds)) {
              return
            }
            this.onChange && this.onChange(userIds)
          } else {
            this.inputTypeValue = result
            if (this._isEqual(this.initValue, result)) {
              return
            }
            this.onChange && this.onChange(result)
          }
        }
      }
    },
    // 编辑结束,进度的判断
    progressUnEditAble() {
      const tofixed = /^(\d{1,2}(\.\d{1})?|100)$/ // 匹配最多一位小数
      if (!tofixed.test(this.inputTypeValue)) {
        this.$message({
          showClose: true,
          message: i18n.t('进度只能在0到100之间且只保留一位小数'),
          type: 'warning',
        })

        this.inputTypeValue = this.initValue
      }
    },
    // 输入框完成事件处理
    unEditable() {
      // 节流实现
      const now = new Date().getTime()
      if (now - this.lasteUneditableTime < 100) {
        return false
      }
      this.lasteUneditableTime = now
      this.status = 'inactive'
      if (this.inputType === 'progress') {
        this.progressUnEditAble()
        if (
          String(this.inputTypeValue) == String(this.initValue) &&
          !this.isClearClicked
        ) {
          return
        }
      }
      this.isClearClicked && (this.inputTypeValue = '')
      if (this.inputTypeValue === this.initValue) {
        this.isClearClicked = false
        return
      }
      if ([null, '', []].includes(this.inputTypeValue)) {
        this.inputTypeValue = this.$store.state.cm.customFieldInitTypeMap[
          this.attrValueType
        ]
      }
      this.onChange && this.onChange(this.inputTypeValue)
      this.isClearClicked = false
    },
    // selectbox 展示框事件监听函数
    bodyEvent: function(e) {
      if (
        !(
          e.target.hasAttribute('data-type') &&
          /select-box|text|number/.test(e.target.getAttribute('data-type'))
        )
      ) {
        // 外部任意位置点击
        this.status = 'inactive'
      }
    },
    // 自定义输入变化回调
    onCustomInputChange(value) {
      this.status = 'inactive'
      this.customInputChange && this.customInputChange(value)
    },
    // 点击清空选择按钮
    whenClearFieldValue() {
      this.isClearClicked = true
    },
    // 清除工时value
    handleClearHour() {
      // 当工时不为0 时，删除工时设置为0
      this.onChange && this.value !== '0h' && this.onChange(0)
    },
  },
}
</script>

<style lang="scss" scoped>
.field-edit-box {
  border-radius: 4px;
  display: inline-block;
  padding: 0 5px;
  position: relative;
  height: 100%;
  box-sizing: border-box;
  .editable-field-label-ellipsis {
    font-size: 14px !important;
  }
}
.editable-field {
  //max-width: calc(100% - 105px); // 最大宽度
  margin-left: 0;
  border: 1px solid #fff;
}
.editable-field:hover {
  box-shadow: 0 0 0 1px $border-gray;
}
// 如果为 input 类型的框
.field-input-box {
  max-width: calc(100% - 105px); // 最大宽度
  vertical-align: top;
  .editable-input {
    width: 100%;
  }
}
.cursor-pointer {
  cursor: pointer;
}
.editable-field-label {
  height: 100%;
}
.editable-field-label-ellipsis {
  width: 100%;
  display: inline-block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  padding: 0 5px;
  font-size: 14px;
}
.hover-show-close-icon {
  padding-right: 20px;
  &:hover {
    .hour-select-close {
      display: block;
      color: #c2c6ce;
      &:hover {
        cursor: pointer;
        color: #999;
      }
    }
  }
}
.hour-select-close {
  bottom: 5px;
  right: 0;
  position: absolute;
  display: none;
}

.editable-cascader {
  z-index: 1;
}
</style>
