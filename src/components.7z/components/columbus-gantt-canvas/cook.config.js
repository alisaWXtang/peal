// cook.config.js
export default {
  build: {
    type: 'lib',
    output: 'dist',
    entry: 'index.js',  // 或者 `src/index.ts` 或者 `src/index.vue`，依次读取
    externals: ['vue', '@heytap/cook-ui', '@heytap/cook-ui/lib/table-column', '@heytap/cook-ui/lib/table']
  }
}
