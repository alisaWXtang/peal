import ganttTable from './ganttTable';

ganttTable.install = (Vue) => Vue.component(ganttTable.name, ganttTable)

export default ganttTable;

