<template>
  <div
    class="block-box"
    ref="blockBox"
    :class="showLeftCol ? '' : 'left--hidden'"
  >
    <span
      class="opreatebtn opreatebtn-left"
      :class="{ 'include-text': iconText }"
      v-show="showLeftIcon && isShowLeft"
      @click="handleLeft"
      ref="operatebtnLeft"
    >
      <span class="opreatebtn-text" v-if="iconText">{{ iconText }}</span>
      <i
        :class="{
          'el-icon-d-arrow-left': !isLeftHidden,
          'el-icon-d-arrow-right': isLeftHidden,
        }"
        class="opreatebtn-icon"
      ></i>
    </span>
    <span
      class="opreatebtn opreatebtn-right"
      :class="{ 'include-text': iconText }"
      v-show="enableCollspan && !isRightHidden && isShowLeft"
      @click="handleRight"
      ref="operatebtnRight"
    >
      <span class="opreatebtn-text" v-if="iconText">{{ iconText }}</span>
      <i
        :class="{
          'el-icon-d-arrow-left': isRightHidden,
          'el-icon-d-arrow-right': !isRightHidden,
        }"
        class="opreatebtn-icon"
      ></i>
    </span>
    <div
      v-show="isShowLeft"
      class="block-box-left"
      :class="{
        'block-box-full': !showRight,
        'left-box-fixed': isLeftBoxTop,
        border0: !showLeftCol,
      }"
      ref="blockBoxLeft"
    >
      <slot name="left"></slot>
    </div>
    <div
      class="switch-btn"
      v-if="expandBtn && isShowLeft && isShowLeft"
      @click="toggleExpand"
    >
      <i class="icon el-icon-arrow-left"></i>
    </div>
    <div
      class="block-box-middle"
      :class="{
        hidden: isLeftBoxTop || barType === 'none',
        'block-box-middle-tiny': barType === 'tiny',
        border0: !showLeftCol,
        shadow: !expandBtn,
      }"
      v-show="showRight && isShowLeft"
      ref="middleLine"
    ></div>
    <div
      class="block-box-middle-proxy"
      :class="{
        hidden: isLeftBoxTop || barType === 'none',
        'block-box-middle-tiny': barType === 'tiny',
        border0: !showLeftCol,
      }"
      v-show="showRight && isShowLeft"
      ref="middleLineProxy"
    ></div>
    <div
      class="block-box-right project-content"
      v-show="showRight"
      ref="blockBoxRight"
    >
      <slot name="right"></slot>
    </div>
  </div>
</template>
<script>
/**
 * @title 边界拖拽组件
 * @desc
 * @author heyunjiang
 * @date
 */
const barConfig = {
  tiny: 1,
  middle: 8,
}
export default {
  name: 'TwoBlockWidthChanger',
  components: {},
  mixins: [],
  props: {
    expandBtn: {
      type: Boolean,
      default: false,
      desc: '展开收起功能按钮，收起展开功能与icon隐藏显示功能独立，请单独使用',
    },
    iconText: {
      type: String,
    },
    initLeftWidth: {
      type: [String, Number, Object],
      required: false,
      desc: '初始时左侧block宽度，支持详细 px 值及百分比',
      default: '50%',
    },
    showRight: {
      type: Boolean,
      required: false,
      desc: '是否展示右侧部分',
      default: true,
    },
    fixedLeft: {
      type: Boolean,
      required: false,
      desc: '是否在有需要时，固定左侧部分',
      default: false,
    },
    enableCollspan: {
      type: Boolean,
      required: false,
      desc: '是否需要展开/收缩功能',
      default: false,
    },
    barType: {
      type: String,
      required: false,
      desc: '中间 bar 类型',
      default: 'tiny',
      validator: value => {
        return ['tiny', 'middle', 'none'].includes(value)
      },
    },
    isShowLeft: {
      type: Boolean,
      default: true,
      desc: '用于需求页面左侧导航是否显示',
    },
  },
  data() {
    return {
      showLeftCol: true, // 是否收起左栏
      isLeftBoxTop: false, // 左侧是否滚动到顶部了
      initWidthTypeNumber: true, // 初始左侧 block 宽度是否传入的是像素，不是百分比
      isLeftHidden: false, // 左侧是否隐藏
      isLeftIconHidden: false, // 左侧icon是否隐藏
      isRightHidden: false, // 右侧是否隐藏
      letfBoxHeight: 0,
      rightBoxHeight: 0,
    }
  },
  computed: {
    showLeftIcon() {
      return this.enableCollspan && !this.isLeftHidden && !this.isLeftIconHidden
    },
  },
  watch: {
    initLeftWidth(val) {
      setTimeout(() => {
        const width =
          typeof val === 'object'
            ? this.initLeftWidth.width
            : this.initLeftWidth
        this.middleLineDragEnd(this.computedLeftWidth(width))
        this.refreshMiddleLineHeight()
      })
    },
    isShowLeft() {
      this.init()
    },
  },
  mounted() {
    this.init()
  },
  beforeDestroy() {
    this.uninit()
  },
  methods: {
    // 切换收起展开功能
    toggleExpand() {
      this.showLeftCol = !this.showLeftCol
      if (this.showLeftCol) {
        this.middleLineDragEnd(this.initLeftWidth)
      } else {
        this.middleLineDragEnd(0)
      }
    },
    uninit() {
      try {
        window.removeEventListener('resize', this.initMiddleLineProxyEvent)
        window.removeEventListener('scroll', this.scrollHandle)
      } catch (e) {
        console.log(e)
      }
    },
    // 初始化
    init() {
      this.uninit()

      // 使用 setTimeout 是保证左右 slot 内容渲染完毕之后，触发 dragend 事件
      setTimeout(() => {
        // 计算左侧初始宽度
        this.middleLineDragEnd(this.computedLeftWidth(this.initLeftWidth))
        // 初始化中间栏拖拽事件
        this.initMiddleLineProxyEvent()
      })

      window.addEventListener('resize', this.initMiddleLineProxyEvent)
      this.fixedLeft &&
        window.addEventListener('scroll', this.scrollHandle, { passive: true })
    },
    // 中间栏拖拽 - 事件处理
    initMiddleLineProxyEvent() {
      const middleLine = this.$refs.middleLineProxy
      const blockBoxLeft = this.$refs.blockBoxLeft
      const blockBox = this.$refs.blockBox
      const mousedownHandleEvent = event => {
        const middleLineRect = middleLine.getBoundingClientRect()
        const boxLeft = blockBox.getBoundingClientRect().left
        const boxWidth = blockBox.getBoundingClientRect().width
        const dragState = {
          startMouseLeft: event.clientX, // 初始偏移量
          startLeft: middleLineRect.left,
          endLeft: middleLineRect.left,
          canMoveLine: false,
        }
        // 去掉默认的可选择、可拖拽功能
        // document.onselectstart = function() { return false; };
        // document.ondragstart = function() { return false; };

        const handleMouseMove = e => {
          if (this.isLeftHidden || this.isRightHidden) {
            return false
          }
          const deltaLeft = e.clientX - dragState.startMouseLeft // 鼠标移动 event 偏移量
          const proxyLeft = dragState.startLeft + deltaLeft - boxLeft
          let leftWidth = Math.min(boxWidth - 100, Math.max(200, proxyLeft)) // 最短不能到左边框，最长不能到右边框
          leftWidth = this.computedLeftWidth(leftWidth)
          dragState.endLeft = leftWidth
          dragState.canMoveLine = true
          middleLine.style.left = leftWidth + 'px'
        }
        const handleMouseUp = () => {
          dragState.canMoveLine && this.middleLineDragEnd(dragState.endLeft)
          document.removeEventListener('mousemove', handleMouseMove)
          document.removeEventListener('mouseup', handleMouseUp)
          document.onselectstart = null
          document.ondragstart = null
        }

        document.removeEventListener('mousemove', handleMouseMove)
        document.removeEventListener('mouseup', handleMouseUp)
        document.addEventListener('mousemove', handleMouseMove)
        document.addEventListener('mouseup', handleMouseUp)
      }
      middleLine.removeEventListener('mousedown', mousedownHandleEvent)
      middleLine.addEventListener('mousedown', mousedownHandleEvent)

      // 计算 middleLine 和 middleLineProxy 的高度
      this.refreshMiddleLineHeight()
    },
    // 中间栏拖拽 - 拖拽结束处理
    middleLineDragEnd(leftWidth) {
      if (!this.$refs.operatebtnLeft) {
        return
      } // 当前组件是否被销毁，之前没有处理内存泄漏临时方法
      leftWidth = Number(leftWidth)
      const leftWidthP = this.initWidthTypeNumber
        ? leftWidth + 'px'
        : leftWidth + '%'
      const rightWidth = this.initWidthTypeNumber
        ? 'calc(100% - ' + (2 + leftWidth) + 'px)'
        : 'calc(' + (100 - +leftWidth) + '% - 2px)'
      this.$refs.operatebtnLeft.style.left = 'calc(' + leftWidthP + ' - 28px)'
      this.$refs.operatebtnRight.style.left = 'calc(' + leftWidthP + ' + 2px)'
      this.$refs.middleLine.style.left = leftWidthP
      this.$refs.middleLineProxy.style.left = leftWidthP
      // this.$refs.middleLine.style.left = 'calc(' + leftWidthP + ' - 2px)'
      // this.$refs.middleLineProxy.style.left = 'calc(' + leftWidthP + ' - 2px)'
      this.$refs.blockBoxLeft.style.width = leftWidthP
      if (this.isShowLeft) {
        this.$refs.blockBoxRight.style.width = rightWidth
      } else {
        this.$refs.blockBoxRight.style.width = '100%'
      }
      this.$emit('dragend', { leftWidth: leftWidthP, rightWidth })
    },
    // 滚动事件处理
    scrollHandle() {
      // 若果左块高度大于右块，则会出现界面闪烁
      if (this.letfBoxHeight > this.rightBoxHeight) {
        return
      }
      const sourceElement = this.$refs.blockBox
      if (sourceElement.getBoundingClientRect().top <= 0) {
        this.isLeftBoxTop = true
      } else {
        this.isLeftBoxTop = false
      }
    },
    // 计算左侧 block width 百分比
    computedLeftWidth(width) {
      if (/\%$/.test(width)) {
        this.initWidthTypeNumber = false
        return width.replace(/\%/, '')
      } else {
        this.initWidthTypeNumber = true
        return width
      }

      // const boxWidth = this.$refs.blockBox.getBoundingClientRect().width;
      // width = Number(width);
      // return ((width*100)/boxWidth).toFixed(2);
    },
    // 计算中间线高度 - 保持跟左侧 block 一样高
    refreshMiddleLineHeight() {
      if (!this.$refs.blockBoxLeft) {
        return
      }
      const boxLeftHeight = this.$refs.blockBoxLeft.getBoundingClientRect()
        .height
      this.$refs.middleLine.style.height = boxLeftHeight + 'px'
      this.$refs.middleLineProxy.style.height = boxLeftHeight + 'px'
      this.letfBoxHeight = boxLeftHeight
      this.rightBoxHeight = this.$refs.blockBoxRight.getBoundingClientRect().height
    },
    // 收起/展开 - 点击向左
    handleLeft() {
      // 如果右侧已经隐藏了
      if (this.isRightHidden) {
        this.middleLineDragEnd(this.computedLeftWidth('50%'))
        this.isRightHidden = false
        this.isLeftIconHidden = true
        this.$emit('rightVisableChange', true)
      } else {
        // 如果右侧没有隐藏，则为初始状态
        this.middleLineDragEnd(this.computedLeftWidth('100%'))
        this.isLeftHidden = true
      }
    },
    // 收起/展开 - 点击向右
    handleRight() {
      // 如果左侧已经隐藏了
      if (this.isLeftHidden) {
        this.middleLineDragEnd(this.computedLeftWidth('50%'))
        this.isLeftHidden = false
      } else {
        this.isLeftIconHidden = false
        // 如果左侧没有隐藏，则为初始状态
        this.middleLineDragEnd(this.computedLeftWidth('100%'))
        this.isRightHidden = true
        this.$emit('rightVisableChange', false)
      }
    },
  },
}
</script>
<style lang="scss" scoped>
$header-height: 0;

.border0 {
  border: 0 !important;
}
.block-box {
  display: flex;
  align-items: stretch;
  position: relative;
  height: 100%;
  .block-box-left {
    // border: 1px solid #e4e7ed;
    border-right: 0;
    border-top-left-radius: 4px;
    border-bottom-left-radius: 4px;
    min-height: $header-height;
    align-self: stretch;
    overflow: hidden;
    position: relative;
    height: 100%;
  }
  .block-box-full {
    width: 100%;
    height: auto;
  }
  .block-box-middl-common {
    position: absolute;
    display: inline-block;
    left: 50%;
    width: 5px;
    min-height: $header-height;
    box-sizing: border-box;
    cursor: col-resize;
    //background: rgba(#d1d1d1, 0.2);
    z-index: 2;
    transition: background 0.3s ease-out;
  }
  .block-box-middle {
    @extend .block-box-middl-common;
    // z-index: 2;
    width: 7px;

    &.shadow {
      background: linear-gradient(
        to right,
        rgba(102, 102, 102, 0.07),
        transparent
      );
    }
  }
  .block-box-middle-proxy {
    @extend .block-box-middl-common;
    &:hover {
      background: rgba(102, 102, 102, 0.1);
    }
  }
  // .block-box-middle-tiny {
  // width: 5px;
  // border-left: 1px solid #eee;
  //background: #eee;
  // &:hover {
  //   background: transparent;
  // }
  // }
  .block-box-right {
    @extend .block-box-left;
    //margin-left: 2px;
    position: relative;
    background: #fff;
    // z-index: 1;
    // border: 1px solid #eee;
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
    border-top-right-radius: 4px;
    border-bottom-right-radius: 4px;
    box-sizing: border-box;
    // padding-left: 14px;
    overflow: auto;
  }
  .hidden {
    visibility: hidden;
  }
  // 收起功能
  .opreatebtn {
    position: absolute;
    top: -4px;
    display: inline-block;
    width: 15px;
    height: 50px;
    transform: scale(0.8);
    text-align: center;
    border-radius: 5px;
    color: white;
    background-color: #ccc;
    // border: 1px solid #ccc;
    z-index: 10;
    font-size: 12px;
    box-sizing: border-box;
    cursor: pointer;
    transition: background-color 0.1s ease-out;
    left: 0;
    &:hover {
      background-color: #9a9898;
    }
    .opreatebtn-icon {
      width: 10px;
      height: 35px;
      line-height: 50px;
      position: absolute;
      right: 2px;
    }
    .opreatebtn-text {
      width: 12px;
      font-size: 12px;
      display: inline-block;
    }
  }
  .opreatebtn.opreatebtn-left {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    span {
      position: absolute;
      right: 3px;
    }
    .opreatebtn-icon {
      left: 1px;
    }
  }
  .opreatebtn.opreatebtn-right {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
    span {
      position: absolute;
      left: 2px;
    }
  }
  .include-text {
    width: 30px;
  }
}
.left--hidden {
  .icon {
    transform: rotate(180deg);
  }
}
.switch-btn {
  align-self: center;
  //margin-left: 2px;
  width: 12px;
  height: 90px;
  line-height: 90px;
  text-align: center;
  z-index: 3;
  //padding: 27px 0;
  box-sizing: border-box;
  background-color: $--background-block;
  cursor: pointer;
  border-top-right-radius: 7px;
  border-bottom-right-radius: 7px;
  .icon {
    font-size: 16px;
    color: #666666;
    width: 16px;
    height: 16px;
    position: relative;
    left: -2px;
  }
}
</style>
