<template>
  <co-table
    :data="tasks"
    border
    header-row-class-name="table-header-row"
    header-cell-class-name="table-header-cell"
    cell-class-name="table-body-cell"
    ref="multipleTable"
    v-bind="$attrs"
    v-on="$listeners"
  >
    <slot></slot>
  </co-table>
</template>
<script>
/**
 * @title 无限滚动 table 实现
 * @desc cookui table 在甘特图中的应用封装，内部 column 需要自己通过 slot 传入；独立组件，可以作为单独 npm 包发布
 * @design 参考 src/pages/tool/TreeTable/index.vue 实现无限滚动
 * @design 1. 数据缓存：传入的所有数据都被缓存起来 (暂时不提供分页功能，需要用户自行实现)
 * @design 2. 滚动加载：通过 IntersectionObserver api 来判断到底/到顶
 * @design 3. 渲染：渲染所有已加载的数据
 * @design 4. 滚动同步：滚动结果 event 暴露，同时也提供接口主动滚动
 * @design 5. 样式统一：保持跟 gantt-canvas 样式统一
 * @author heyunjiang
 * @date 2020.8.5
 */
import Table from '@heytap/cook-ui/lib/table';

export default {
  name: "TableInfinity",
  components: {
    [Table.name]: Table,
  },
  mixins: [],
  props: {
    tasks: {
      type: Array,
      required: true,
      desc: "table 数据来源"
    }
  },
  data() {
    return {}
  },
  computed: {},
  watch: {
    tasks: {
      handler: function() {
        this.initObserver();
      },
      immediate: true
    }
  },
  created() {},
  mounted() {
    this.initTableInfinitieScroll();
    this.bindScrollEvent();
  },
  beforeDestroy() {
    this.tableObserver.disconnect();
    this.tableWrapper.removeEventListener('scroll', this.scrollHandler.bind(this), {passive: true});
  },
  methods: {
    // 无限滚动 - 初始化 tableObserver 对象，插入顶部 tr 节点
    initTableInfinitieScroll() {
      this.tableObserver = new IntersectionObserver(this.scrollHandle);
      // header tr
      const headerTr = document.createElement('tr');
      // headerTr.classList.add('header-tr');
      this.headTr = headerTr;
      // footer tr
      const footerTr = document.createElement('tr');
      footerTr.classList.add('footer-tr');
      this.footerTr = footerTr;

      this.tableBody = this.$refs.multipleTable.$el.querySelector(".el-table__body-wrapper tbody");
      this.tableWrapper = this.tableBody.closest('table').parentNode;
      this.tableBody.prepend(headerTr);
      this.tableBody.append(footerTr);
    },
    // 无限滚动 - 监听特定对象
    initObserver() {
      this.$nextTick(() => {
        // 先停止对所有目标的监控
        this.tableObserver.disconnect();
        this.tableObserver.observe(this.headTr);
        this.tableObserver.observe(this.footerTr);
      })
    },
    // 无限滚动 - 滚动事件处理
    scrollHandle(entry) {
      // 初始的时候不执行：前后虚拟 tr 初次渲染，或者整体任务长度不够
      if(this.tasks.length < 2) {return ;}
      if (entry.length === 2 && entry[0].isIntersecting === entry[1].isIntersecting && entry[0].isIntersecting) {return ;}

      entry.forEach(item => {
        const {isIntersecting, target} = item;
        if(!target || !target.parentNode) {return ;}
        
        if(isIntersecting) {
          if(target.isSameNode(this.footerTr)) {
            // 到达底部
            this.$emit('scrollBottom');
          } else if(target.isSameNode(this.headTr)) {
            this.$emit('scrollTop');
          }
        }
      })
    },
    // 滚动到指定位置
    scrollToY(y) {
      if (this.tableWrapper.scrollTop === y) {return ;}
      // this.tableWrapper.scroll({top: y})
      this.tableWrapper.scrollTop = y;
    },
    // 绑定 table 滚动事件
    bindScrollEvent() {
      this.tableWrapper.removeEventListener('scroll', this.scrollHandler.bind(this), {passive: true});
      this.tableWrapper.addEventListener('scroll', this.scrollHandler.bind(this), {passive: true});
    },
    // 滚动事件处理
    scrollHandler() {
      this.$emit('scroll', this.tableWrapper.scrollTop)
    }
  }
}
</script>
<style lang="scss" scoped>
  /deep/ {
    .header-tr,
    .footer-tr {
      height: 2px;
    }
  }
</style>
