<template>
  <TwoBlockWidthChanger :initLeftWidth="initLeftWidth" @dragend="resize">
    <template #left>
      <slot name="left"></slot>
      <TableInfinity
        ref="TableInfinity"
        :tasks="tasks"
        row-key="id"
        class="gantt-table"
        :height="$attrs.height || '800px'"
        :row-class-name="_rowClassName"
        @scroll="ganttCanvasScrollTo"
        @cell-mouse-enter="tableOnHighlightChange"
        @cell-mouse-leave="clearGanttHighlight"
        v-bind="$attrs"
        v-on="$listeners"
      >
        <!-- <co-table-column label="名称" prop="name"></co-table-column> -->
        <slot></slot>
      </TableInfinity>
    </template>
    <template #right>
      <ganttVue
        ref="ganttVue"
        class="gantt-vue"
        :tasks="tasks"
        :options="options"
        @on_taskbar_click="task => commonEventEmit('on_taskbar_click', task)"
        @on_date_change="info => commonEventEmit('on_date_change', info)"
        @on_view_change="mode => commonEventEmit('on_view_change', mode)"
      ></ganttVue>
    </template>
  </TwoBlockWidthChanger>
</template>
<script>
/**
 * @title gantt table 源码组件
 * @desc 包含 table 基础实现、样式设计，使用 gantt-vue 组件，属于使用甘特图组件
 * @author heyunjiang
 * @date 2020.8.6
 */
import ganttVue from '../gantt-vue'
import TableInfinity from './TableInfinity'
import TwoBlockWidthChanger from './TwoBlockWidthChanger'
// import TableColumn from '@heytap/cook-ui/lib/table-column';

export default {
  name: 'ganttTable',
  components: {
    ganttVue,
    TwoBlockWidthChanger,
    TableInfinity,
    // [TableColumn.name]: TableColumn
  },
  mixins: [],
  props: {
    tasks: {
      type: Array,
      required: true,
      desc: '展示的数据源',
    },
    initLeftWidth: {
      type: [String, Number, Object],
      required: false,
      desc: '初始时左侧block宽度，支持详细 px 值及百分比',
      default: '20%',
    },
    ganttOptions: {
      type: Object,
      desc: '甘特图 option 配置',
      default: () => {
        return {}
      },
    },
  },
  data() {
    return {
      options: {
        ...this.ganttOptions,
        on_after_scroll: this.ganttTableScrollTo,
        on_highlight_change: this.tableHighlightSetting,
      },
      // 通过注释列出属性，是为了避免 vue 响应式数据监听，节省内存
      // currentHighlightId: null, // 高亮 id
      // currentHighlightTr: null, // 高亮 tr
    }
  },
  computed: {},
  watch: {
    tasks() {
      this.initScroll()
      this._setBorder()
    },
  },
  created() {},
  mounted() {
    // 初次滚动到今天，需要等待 gantt 绘制完毕
    this.initScroll()
    this._setBorder()
    window.addEventListener('resize', this.resize)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.resize)
  },
  methods: {
    // 初始滚动
    initScroll() {
      if (this.tasks.length > 0 && !this.isScrolled) {
        this.isScrolled = true
        setTimeout(this.scrollToday)
      }
    },
    scrollToday() {
      this.$refs.ganttVue.gantt_chart.scroll_today()
    },
    resize() {
      this.$refs.ganttVue.resize()
    },
    // table 滚动
    ganttTableScrollTo({ x, y }) {
      this.$refs.TableInfinity.scrollToY(y)
    },
    // gantt 滚动
    ganttCanvasScrollTo(y) {
      const gantt_chart = this.$refs.ganttVue.gantt_chart
      const lastScrollY = gantt_chart.lastScroll.y
      if (y === lastScrollY) {
        return
      }
      gantt_chart.scrollHandler(0, y - lastScrollY)
    },
    // table - 手动设置高亮, id 不传表示移除高亮
    tableHighlightSetting(id) {
      if (this.currentHighlightId === id) {
        return
      }
      this.currentHighlightId = id
      if (this.currentHighlightTr) {
        this.currentHighlightTr.className = this.currentHighlightTr.className.replace(
          ' row-highlight',
          '',
        )
        this.currentHighlightTr = null
      }
      if (id == undefined) {
        return
      }
      // 操作 dom 速度快于 vue 数据更新
      this.currentHighlightTr = this.$refs.TableInfinity.tableBody.querySelector(
        '.table-body-row-highlight-' + id,
      )
      this.currentHighlightTr.className =
        this.currentHighlightTr.className + ' row-highlight'
    },
    clearGanttHighlight() {
      this.currentHighlightId = null
      this.$refs.ganttVue.gantt_chart.clear_grid_bar_highlight()
    },
    // table - 高亮改变
    tableOnHighlightChange(row) {
      if (row.id === this.currentHighlightId) {
        return
      }
      this.tableHighlightSetting()
      this.currentHighlightId = row.id
      this.$refs.ganttVue.gantt_chart.grid_bar_highlight_setting(row.id)
    },
    // table tr class 设置，该方法很慢，耗时
    _rowClassName({ row, rowIndex }) {
      const { id } = row || {}
      const { isAssignUser: nextIsAssignUser } = this.tasks[rowIndex + 1] || {}
      const hasDivider = rowIndex + 1 >= this.tasks.length || nextIsAssignUser
      return `table-body-row-highlight-${id} ${
        hasDivider ? 'table-row-divider' : ''
      }`
    },
    // 触发事件
    commonEventEmit(type, value) {
      this.$emit(type, value)
    },
    // 设置 border 填满
    _setBorder() {
      if (!this.$attrs['border-full']) {
        return
      }
      // 如果之前已经生成过，则先清除高度
      if (this.addedTr) {
        this.addedTr.style.height = '0px'
      }
      setTimeout(() => {
        const bodyWrapper = this.$el.querySelector('.el-table__body-wrapper')
        const tbody = bodyWrapper.querySelector('tbody')
        const tbodyHeight = tbody.getBoundingClientRect().height
        const bodyWrapperHeight = bodyWrapper.getBoundingClientRect().height
        let overHeight = bodyWrapperHeight - tbodyHeight
        if (this.addedTr) {
          overHeight += this.addedTr.getBoundingClientRect().height
        }

        // 如果已经填满，则不做处理
        if (overHeight < 0) {
          if (this.addedTr) {
            this.addedTr.parentNode.removeChild(this.addedTr)
            this.addedTr = null
          }
          return
        } else if (this.addedTr) {
          // 如果之前已经生成过，则改变高度即可
          this.addedTr.style.height = overHeight + 'px'
          return
        }

        const tdLength = this.$el.querySelector(
          '.el-table__header-wrapper tr.table-header-row',
        ).childElementCount
        const tr = document.createElement('tr')
        tr.classList.add('additional-tr')
        tr.style.height = overHeight + 'px'
        tr.innerHTML = '<td rowspan="1" colspan="1" class="table-body-cell"></td>'.repeat(
          tdLength,
        )
        this.addedTr = tr
        tbody.appendChild(tr)
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.gantt-table {
  overflow-y: auto;
}
.gantt-vue,
.gantt-table,
/deep/ .gantt-container {
  height: 800px;
  width: 100%;
}
.gantt-table.el-table {
  // 兼容 gantt-canvas 样式设定，样式来源 - 哥伦布甘特图
  /deep/ {
    // 表头 th
    .table-header-cell {
      padding: 26px 0 25px; // table 本身有 1px border
      //background-color: #fff;
      border-color: #eee;
      border-width: 1px;
      // border-bottom-width: 4px;
      border-bottom-style: solid;
      font-size: 14px;
      color: #292f3a;
      &:last-of-type {
        border-right: none;
      }
      .cell {
        height: 24px;
      }
    }
    // 表体 td
    .table-body-cell {
      padding: 0; // 是为了覆盖原有 padding
      border-width: 1px;
      border-color: #eee;
      border-bottom: 1px solid #eee;
      background-color: #fff;
      height: 32px;
      font-size: 14px;
      color: #666666;
    }
    // 表体 body wrapper
    .el-table__body-wrapper {
      background-color: #f7f8fb;
    }
    // 取消 td hover bg 动画
    .el-table--enable-row-transition .el-table__body td {
      transition: none;
    }
    // empty 提示文字居中下
    .gantt-container .gantt-empty-show .gantt-empty-text {
      position: relative;
      top: 8;
    }

    // 附加 td 背景色不改变
    .el-table__body .additional-tr {
      td.table-body-cell {
        height: auto;
      }
      &:hover td {
        background-color: #fff;
      }
    }

    // 分割线
    .el-table__row {
      td {
        border-bottom-color: #fff;
      }

      &.table-row-divider td {
        border-bottom-color: #eee;
      }
    }

    // 高亮
    .el-table__body tr:hover,
    .row-highlight {
      td {
        background-color: rgba(241, 244, 249, 0.7);
      }
    }
  }
}
</style>
