# gantt-table

time: 2020.8.4  
author: heyunjiang

## 说明

gantt 结合左侧 table 的一种实现

使用 cookui table
