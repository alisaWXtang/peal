import Vue from 'vue';
import ganttTable from './ganttTable.vue';
import '@heytap/cook-ui/lib/theme-chalk/table.css';
import '@heytap/cook-ui/lib/theme-chalk/table-column.css';

const tasks =  [
  {
    start: '2018-10-01',
    end: '2018-10-14',
    name: 'hello world',
    id: 1,
    backgroundColor: "#A6B0F5"
  },
  {
    start: '2018-10-03',
    end: '',
    name: '软件商店版本迭代',
    id: 2,
    dragable: true,
    progress: 5,
    dependencies: 1,
    backgroundColor: "lime",
    projectName: "哥伦布",
    statu: "处理中",
    assignUser: "哈哈(80240000)"
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: 3,
    dragable: true,
    progress: 10,
    dependencies: 2
  },
  {
    start: '2018-10-03',
    end: '2018-10-06',
    name: '软件商店版本迭代',
    id: 4,
    progress: 5,
    dependencies: 1,
    projectName: "哥伦布",
    statu: "处理中",
    assignUser: "哈哈(80240000)"
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: 5,
    progress: 10,
    dependencies: 2
  },
  {
    start: '2018-10-08',
    end: '2018-10-09',
    name: 'Review',
    id: 6,
    progress: 95,
    dependencies: 3
  },
  {
    start: '2018-10-08',
    end: '2018-10-10',
    name: 'Deploy',
    id: 7,
    progress: 0,
    dependencies: 3
  },
  {
    start: '2018-10-11',
    end: '2019-1-11',
    name: 'Go Live!',
    id: 8,
    progress: 0,
    dependencies: 5,
    custom_class: 'bar-milestone'
  },
  {
    start: '2018-10-01',
    end: '2018-10-08',
    name: 'Redesign website',
    id: 9,
    progress: 80
  },
  {
    start: '2018-10-03',
    end: '2018-10-06',
    name: 'Write new content',
    id: 10,
    progress: 5,
    dependencies: 1
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: 11,
    progress: 10,
    dependencies: 2
  },
  {
    start: '2018-10-08',
    end: '2018-10-09',
    name: 'Review',
    id: 12,
    progress: 5,
    dependencies: 3
  },
  {
    start: '2018-10-03',
    end: '2018-10-06',
    name: 'Write new content',
    id: 13,
    progress: 5,
    dependencies: 1
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: 14,
    progress: 10,
    dependencies: 2
  },
  {
    start: '2018-10-08',
    end: '2018-10-09',
    name: 'Review',
    id: 15,
    progress: 5,
    dependencies: 3
  },
  // {
  //   start: '2014-01-05',
  //   end: '2019-10-12',
  //   name: 'Long term task',
  //   id: "Task 6",
  //   progress: 0
  // }
]
const preLength = tasks.length;
const newLength = 1000; // 修改此处控制模拟数据条数
for (let i = preLength; i < newLength; i++) {
  tasks.push({
    start: '2018-10-03',
    end: '2018-10-06',
    name: '软件商店版本迭代',
    // id: "Task 1",
    progress: 5,
    dependencies: 'Task 0',
    projectName: "哥伦布",
    statu: "处理中",
    assignUser: "哈哈(80240000)"
  })
}

new Vue({
  render: createElement => createElement(ganttTable, {props: {tasks}}) 
}).$mount('#app');
