import ganttVue from './ganttVue';

ganttVue.install = (Vue) => Vue.component(ganttVue.name, ganttVue)

export default ganttVue;