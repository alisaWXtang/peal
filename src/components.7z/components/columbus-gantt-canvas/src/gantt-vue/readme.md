# gantt-vue

time: 2020.8.4  
author: heyunjiang

## 说明

本组件是 gantt-canvas 的 vue 版本实现

## 使用方式

## 本地开发调试

```
npm install -g @vue/cli-service-global

vue serve demo.vue
```
