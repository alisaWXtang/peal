<template>
  <div class="gantt-box">gantt-vue</div>
</template>
<script>
/**
 * @title 
 * @desc 
 * @author heyunjiang
 * @date 
 */
import Gantt from '../gantt-canvas/index.js';

export default {
  name: "ganttVue",
  components: {},
  mixins: [],
  props: {
    tasks: {
      type: Array,
      required: true,
      desc: "需要渲染的数据"
    },
    options: {
      type: Object,
      default: () => {
        return {}
      },
      desc: '基本配置'
    }
  },
  data() {
    return {}
  },
  computed: {},
  watch: {
    tasks() {
      this.gantt_chart && this.gantt_chart.refresh(this.tasks);
    }
  },
  created() {},
  mounted() {
    this.ganttInit();
  },
  beforeDestroy() {
    this.gantt_chart && this.gantt_chart.dispose();
  },
  methods: {
    ganttInit() {
      const vm = this;
      this.gantt_chart = new Gantt(this.$el, this.tasks, {
        on_taskbar_click: function (task) {
          vm.$emit('on_taskbar_click', task);
        },
        on_date_change: function(task, start, end) {
          vm.$emit('on_date_change', {task, start, end});
        },
        // on_progress_change: function(task, progress) {
        //   vm.$emit('on_progress_changet', {task, progress});
        // },
        on_view_change: function(mode) {
          vm.$emit('on_view_change', mode);
        },
        stripe: false,
        view_mode: 'Day',
        language: 'zh',
        headerFix: true,
        ...vm.options
      });
    },
    resize(obj = {}) {
      this.gantt_chart.resize(obj);
    }
  }
}
</script>
<style lang="scss" scoped>
</style>
