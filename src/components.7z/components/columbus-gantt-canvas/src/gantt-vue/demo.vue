<template>
  <ganttVue :tasks="tasks"></ganttVue>
</template>
<script>
/**
 * @title 
 * @desc 
 * @author heyunjiang
 * @date 
 */
import ganttVue from "./ganttVue";

export default {
  name: "",
  components: {
    ganttVue
  },
  mixins: [],
  props: {},
  data() {
    return {
      tasks: [
        {
          start: '2018-10-01',
          end: '2018-10-14',
          name: '',
          id: "Task 0",
          backgroundColor: "#A6B0F5"
        },
        {
          start: '2018-10-03',
          end: '2018-10-06',
          name: '软件商店版本迭代',
          id: "Task 1",
          progress: 5,
          dependencies: 'Task 0',
          projectName: "哥伦布",
          statu: "处理中",
          assignUser: "哈哈(80240000)"
        },
        {
          start: '2018-10-04',
          end: '2018-10-08',
          name: 'Apply new styles',
          id: "Task 2",
          progress: 10,
          dependencies: 'Task 1'
        },
        {
          start: '2018-10-03',
          end: '2018-10-06',
          name: '软件商店版本迭代',
          id: "Task 1",
          progress: 5,
          dependencies: 'Task 0',
          projectName: "哥伦布",
          statu: "处理中",
          assignUser: "哈哈(80240000)"
        },
        {
          start: '2018-10-04',
          end: '2018-10-08',
          name: 'Apply new styles',
          id: "Task 2",
          progress: 10,
          dependencies: 'Task 1'
        },
        {
          start: '2018-10-08',
          end: '2018-10-09',
          name: 'Review',
          id: "Task 3",
          progress: 95,
          dependencies: 'Task 2'
        },
        {
          start: '2018-10-08',
          end: '2018-10-10',
          name: 'Deploy',
          id: "Task 4",
          progress: 0,
          dependencies: 'Task 2'
        },
        {
          start: '2018-10-11',
          end: '2019-1-11',
          name: 'Go Live!',
          id: "Task 5",
          progress: 0,
          dependencies: 'Task 4',
          custom_class: 'bar-milestone'
        },
        {
          start: '2018-10-01',
          end: '2018-10-08',
          name: 'Redesign website',
          id: "Task 0",
          progress: 80
        },
        {
          start: '2018-10-03',
          end: '2018-10-06',
          name: 'Write new content',
          id: "Task 1",
          progress: 5,
          dependencies: 'Task 0'
        },
        {
          start: '2018-10-04',
          end: '2018-10-08',
          name: 'Apply new styles',
          id: "Task 2",
          progress: 10,
          dependencies: 'Task 1'
        },
        {
          start: '2018-10-08',
          end: '2018-10-09',
          name: 'Review',
          id: "Task 3",
          progress: 5,
          dependencies: 'Task 2'
        },
        // {
        //   start: '2014-01-05',
        //   end: '2019-10-12',
        //   name: 'Long term task',
        //   id: "Task 6",
        //   progress: 0
        // }
      ]
    }
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {}
}
</script>
<style lang="scss" scoped>

</style>
