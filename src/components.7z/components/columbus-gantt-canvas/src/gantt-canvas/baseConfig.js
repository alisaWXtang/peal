// 基本常量配置提取
const baseConfig = {
  borderWidth: 2, // 整体竖线宽度
  fontBase: {
    fontFamily: 'microsoft yahei',
    fontSize: 12,
    textFill: '#666',
  },
  // 头部上层文字配置
  headerTopText: {
    textFill: '#292F3A',
  },
  // 头部下层文字配置
  headerBottomText: {},
  // 附加文字样式，比如日视图具体日期
  attachBase: {
    fontSize: 10,
    textFill: '#B2B2B2',
    // textPadding: [2, 0, 0, 10], // 这里不同与 css 的计算方向，注意一下
  },
  emptyText: {
    en: 'No Data',
    zh: '暂无数据',
  },
}

const theme = {
  background: 'white', // 整体背景色
  headerTop: '#f0f3f7', // 表头上层背景色
  headerBottom: '#f0f3f7', // 表头下层背景色
  weekend: '#F4F6FB', // 周末填充颜色
  stripeColor: '#F1F4F9', // 斑马纹颜色
  lineColor: '#EEEEEE', // 网格线条颜色

  barBackground: '#0ED29E', // bar 默认背景色
  barBaseBackground: '#FFFFFF', // bar 底层背景色
  barBaseBorderColor: '#D8D8D8', // bar 底层 border color
  barInvalidBackground: 'red', // invalid bar 背景色
  progressBackground: '#56D7C0', // bar 已完成背景色

  rectHighlight: '#F1F4F9', // 高亮色彩
  todyHighlight: '#3081f2', // 今日高亮
  transparent: 'transparent', // 透明
}

const zlevel = {
  header: 3,
  bar: 2,
  grid: 1,
  hidden: 0,
}

export { baseConfig, theme, zlevel }
