/**
 * 甘特图基础数据
 * 用于准备数据，本身不可被实例化
 * time: 2020.8.4
 * author: heyunjiang
 */
import date_utils from './date_utils';
import {baseConfig} from './baseConfig';
import zrender from 'zrender';

const VIEW_MODE = {
  QUARTER_DAY: 'Quarter Day',
  HALF_DAY: 'Half Day',
  DAY: 'Day',
  WEEK: 'Week',
  MONTH: 'Month',
  YEAR: 'Year'
};

export default class ganttBase {
  constructor(wrapper, tasks, options) {
    if (new.target === ganttBase) {
      throw new Error("ganttBase cannot be instantiate")
    }
    this.data_init();
    this.setup_options(options);
    this.setup_wrapper(wrapper);
    this.setup_tasks(tasks);
  }
  // 所有对象属性初始化
  data_init() {
    // 设置 dom 节点
    this.$canvas = null;
    this.$container = null;
    this.popup_wrapper = null;
    // options
    this.options = {};
    // tasks
    this.tasks = [];
    // task dependency
    this.dependency_map = [];
    // 甘特图表头默认 开始|结束 时间点
    this.gantt_start = null;
    this.gantt_end = null;
    // 设置甘特图整体需要绘制的格子数据
    this.dates = [];
    // 基础图层
    this.layers = {};
    // 滚动控制
    this.lastScroll = {
        x: 0,
        y: 0
    }
    // popup 位置
    this.popupTargetPosition = {
        x: 0,
        y: 0,
        widht: 0,
        height: 0
    }
    // 整体几何属性数据
    this.gridRectInfo = {
        height: 0,
        width: 0
    }
    this.headerRectInfo = {
        height: 0,
        width: 0
    }
    this.canvasHeight = 0;
    this.canvasWidth = 0;
    // draw bar debounce time
    this.lastDrawBar = new Date().getTime();
    // 高亮 row rect 对象缓存
    this.lastHighLightRow = null;
    // row rect 对象缓存
    this.rowMap = {};
  }
  // 1. 设置 this.$canvas, this.$container, this.popup_wrapper 节点
  // <$container>
  //   <$canvas>
  //   <popup_wrapper>
  //   <scroll-bar>
  setup_wrapper(element) {
    // CSS Selector is passed
    if (typeof element === 'string') {
        element = document.querySelector(element);
    }

    // get the CANVASElement
    if (element instanceof HTMLElement) {
        this.$canvas = element;
    }  else {
        throw new TypeError(
            'Columbus Gantt only supports usage of a string CSS selector,' +
                " HTML DOM element for the 'element' parameter"
        );
    }

    // canvas element
    this.$canvas.classList.add('gantt');

    // wrapper element
    this.$container = document.createElement('div');
    this.$container.classList.add('gantt-container');

    // empty element
    this.$empty = document.createElement('div');
    this.$empty.classList.add('gantt-empty-hidden');
    this.$empty.innerHTML = `<span class="gantt-empty-text">${baseConfig.emptyText[this.options.language]}</span>`;
    this.$container.appendChild(this.$empty);

    const parent_element = this.$canvas.parentElement;
    parent_element.appendChild(this.$container);
    this.$container.appendChild(this.$canvas);
    this.$canvas = zrender.init(this.$canvas);

    // popup wrapper
    this.popup_wrapper = document.createElement('div');
    this.popup_wrapper.classList.add('popup-wrapper');
    this.$container.appendChild(this.popup_wrapper);
  }

  // 2. 生成 this.options
  setup_options(options = {}) {
    const default_options = {
        header_height: 76, // 表头 - 整体高度
        header_top_height: 32, // 表头 - 区间高度
        header_bottom_height: 44, // 表头 - 区体高度
        column_width: 30,
        step: 24, // 1个阶段，单位 hour
        view_modes: [...Object.values(VIEW_MODE)],
        bar_height: 16,
        bar_corner_radius: 3,
        arrow_curve: 5,
        padding: 16,
        view_mode: 'Day',
        date_format: 'YYYY-MM-DD',
        popup_trigger: 'click',
        custom_popup_html: null,
        language: 'zh',
        isScrollToday: true, // 是否定位到今日
        stripe: true, // 是否为斑马纹
        headerFix: true, // 是否固定头部
        browserScrollPrevent: true, // 是否阻止浏览器同步滚动
        bg_full: true, // 是否背景填满整体高度
    };
    this.options = Object.assign({}, default_options, options);
  }

  // 3. 生成 this.tasks，数据规范化
  setup_tasks(tasks = []) {
    // task 规范化处理：日期、dependencies、id
    this.tasks = tasks.map((task, i) => {
        // convert to Date objects
        task._start = date_utils.parse(task.start);
        task._end = date_utils.parse(task.end);

        // 如果长度超过 1 年，则处理为不完整时间区间
        // if (date_utils.diff(task._end, task._start, 'year') > 1) {
        //     task.end = null;
        // }

        // cache index
        task._index = i;

        // 处理不完整时间区间 task 长度
        if (!task.start && !task.end) {
            const today = date_utils.today();
            task._start = today;
            task._end = date_utils.add(today, 2, 'day');
        }

        if (!task.start && task.end) {
            task._start = date_utils.add(task._end, -2, 'day');
        }

        if (task.start && !task.end) {
            task._end = date_utils.add(task._start, 2, 'day');
        }

        // 如果没有提供时分秒，则增加 24 h，满足结束日当天满天
        // e.g: 2018-09-09 becomes 2018-09-09 23:59:59
        const task_end_values = date_utils.get_date_values(task._end);
        if (task_end_values.slice(3).every(d => d === 0)) {
            task._end = date_utils.add(task._end, 24, 'hour');
        }

        // invalid flag
        if (!task.start || !task.end) {
            task.invalid = true;
        }

        // dependencies
        if (typeof task.dependencies === 'string' || !task.dependencies) {
            let deps = [];
            if (task.dependencies) {
                deps = task.dependencies
                    .split(',')
                    .map(d => d.trim())
                    .filter(d => d);
            }
            task.dependencies = deps;
        } 
        if (typeof task.dependencies === 'number') {
            task.dependencies = [task.dependencies];
        }

        // uids
        if (!task.id) {
            task.id = generate_id(task);
        }

        return task;
    });

    this.setup_dependencies();
  }

  // 4. this.dependency_map 依赖全局提取
  setup_dependencies() {
      this.dependency_map = {};
      for (let t of this.tasks) {
          for (let d of t.dependencies) {
              this.dependency_map[d] = this.dependency_map[d] || [];
              this.dependency_map[d].push(t.id);
          }
      }
  }

  // 设置日期入口
  setup_dates() {
    this.setup_gantt_dates();
    this.setup_date_values();
  }

  // 5. 设置甘特图整体时间区间
  setup_gantt_dates() {
    // date 维度 map
    const TimeModeMap = {
        [VIEW_MODE.QUARTER_DAY]: 'day',
        [VIEW_MODE.HALF_DAY]: 'day',
        [VIEW_MODE.DAY]: 'day',
        [VIEW_MODE.WEEK]: 'month',
        [VIEW_MODE.MONTH]: 'Year',
        [VIEW_MODE.YEAR]: 'Year'
    }
    this.gantt_start = this.gantt_end = null;
    const minsteps = Math.ceil(this.canvasWidth/this.options.column_width);
    const currentMode = TimeModeMap[this.options.view_mode];

    // 甘特图时间范围设置
    for (let task of this.tasks) {
        // set global start and end date
        if (!this.gantt_start || task._start < this.gantt_start) {
            this.gantt_start = task._start;
        }
        if (!this.gantt_end || task._end > this.gantt_end) {
            this.gantt_end = task._end;
        }
    }

    // 如果是没有数据，则默认展示今天前后几天
    if (this.gantt_start === null) {
        this.gantt_start = date_utils.add(date_utils.today(), -Math.ceil(minsteps/2) + 2, currentMode);
        this.gantt_end = date_utils.today();
    }

    // 设置为一天开始
    this.gantt_start = date_utils.start_of(this.gantt_start, 'day');
    this.gantt_end = date_utils.start_of(this.gantt_end, 'day');

    // add date padding on both sides
    if (this.view_is([VIEW_MODE.QUARTER_DAY, VIEW_MODE.HALF_DAY, VIEW_MODE.DAY])) {
        this.gantt_start = date_utils.add(this.gantt_start, -2, 'day');
        this.gantt_end = date_utils.add(this.gantt_end, 7, 'day');
    } else if (this.view_is(VIEW_MODE.MONTH)) {
        this.gantt_start = date_utils.start_of(this.gantt_start, 'year');
        this.gantt_end = date_utils.add(this.gantt_end, 1, 'year');
    } else if (this.view_is(VIEW_MODE.YEAR)) {
        this.gantt_start = date_utils.add(this.gantt_start, -2, 'year');
        this.gantt_end = date_utils.add(this.gantt_end, 2, 'year');
    } else {
        this.gantt_start = date_utils.add(this.gantt_start, -1, 'month');
        this.gantt_end = date_utils.add(this.gantt_end, 1, 'month');
    }
    if (date_utils.diff(this.gantt_end, this.gantt_start, currentMode) < minsteps) {
        this.gantt_end = date_utils.add(this.gantt_start, minsteps - 1, currentMode);
    }
  }

  // 6. 设置甘特图整体需要绘制的格子数据，this.dates 数据集合
  setup_date_values() {
    this.dates = [];
    let cur_date = null;

    while (cur_date === null || cur_date < this.gantt_end) {
        if (!cur_date) {
            cur_date = date_utils.clone(this.gantt_start);
        } else {
            if (this.view_is(VIEW_MODE.YEAR)) {
                cur_date = date_utils.add(cur_date, 1, 'year');
            } else if (this.view_is(VIEW_MODE.MONTH)) {
                cur_date = date_utils.add(cur_date, 1, 'month');
            } else {
                cur_date = date_utils.add(
                    cur_date,
                    this.options.step,
                    'hour'
                );
            }
        }
        this.dates.push(cur_date);
    }
  }

  // 7. 设置 options.step, options.column_width
  update_view_scale(view_mode) {
    this.options.view_mode = view_mode;

    if (view_mode === VIEW_MODE.DAY) {
        this.options.step = 24;
        // this.options.column_width = 30;
    } else if (view_mode === VIEW_MODE.HALF_DAY) {
        this.options.step = 24 / 2;
        // this.options.column_width = 30;
    } else if (view_mode === VIEW_MODE.QUARTER_DAY) {
        this.options.step = 24 / 4;
        // this.options.column_width = 30;
    } else if (view_mode === VIEW_MODE.WEEK) {
        this.options.step = 24 * 7;
        this.options.column_width = 140;
    } else if (view_mode === VIEW_MODE.MONTH) {
        this.options.step = 24 * 30;
        this.options.column_width = 120;
    } else if (view_mode === VIEW_MODE.YEAR) {
        this.options.step = 24 * 365;
        this.options.column_width = 120;
    }
  }

  trigger_event(event, args) {
    if (this.options['on_' + event]) {
        this.options['on_' + event].apply(null, Array.isArray(args) ? args : [args]);
    }
  }   

  /**
     * Clear all elements from the parent svg element
     *
     * @memberof Gantt
     */
  clear() {
    this.$svg.innerHTML = '';
  }
  clear_canvas() {
    this.$canvas && this.$canvas.clear();
  }
  // 销毁实例
  dispose() {
    this.$canvas && this.$canvas.dispose();
    window.removeEventListener('resize', this.resize);
  }
}

function generate_id(task) {
    return (
        task.name +
        '_' +
        Math.random()
            .toString(36)
            .slice(2, 12)
    );
}
