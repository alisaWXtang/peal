/**
 * 滚动条模拟实现
 * @param {parent | HTMLElement} 父节点 dom
 * time: 2020.8.13
 * author: heyunjiang
 */
export default class scrollbar {
  constructor(parent, options) {
    this.setup_options(options)
    this.setup_wrapper(parent)
    this.bindScrollEvent()
  }
  setup_options(options = {}) {
    const default_options = {
      contentWidth: 0, // 内容宽度
      height: 32, // 滚动条容器宽度
    }
    this.options = Object.assign({}, default_options, options)
  }
  setup_wrapper(element) {
    // 准备 this.$parent
    if (typeof element === 'string') {
      element = document.querySelector(element)
    }

    if (element instanceof HTMLElement) {
      this.$parent = element
    } else {
      throw new TypeError(
        'Columbus Gantt only supports usage of a string CSS selector,' +
          " HTML DOM element for the 'element' parameter",
      )
    }

    this.$parent.style.position = 'relative'

    this.destroy()

    this.$container = document.createElement('div')
    this.$container.classList.add('gantt-scrollbar-container')
    this.$container.style =
      'width: 100%;height: ' +
      this.options.height +
      'px;overflow-x: auto;position: absolute;left: 0;bottom: 0;'

    this.$content = document.createElement('div')
    this.$content.style =
      'width: ' +
      this.options.contentWidth +
      'px;height: 1px;background: transparent;'

    this.$container.appendChild(this.$content)
    this.$parent.appendChild(this.$container)
  }
  refresh(options) {
    this.setup_options({
      ...this.options,
      ...options,
    })
    this.setup_wrapper(this.$parent)
    this.bindScrollEvent()
  }
  bindScrollEvent() {
    const scrollEvent = () => {
      this.trigger_event('scroll', this.$container.scrollLeft)
    }
    this.$container.addEventListener('scroll', scrollEvent, { passive: true })
  }
  set_scroll(scrollLeft) {
    this.$container.scrollLeft = scrollLeft
  }
  trigger_event(event, args) {
    if (this.options['on_' + event]) {
      this.options['on_' + event].apply(
        null,
        Array.isArray(args) ? args : [args],
      )
    }
  }
  destroy() {
    if (!this.$container) {
      return
    }
    this.$parent.removeChild(this.$container)
    this.$container = null
    this.$content = null
  }
}
