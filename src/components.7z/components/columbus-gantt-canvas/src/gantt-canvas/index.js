import date_utils from './date_utils'
import Bar from './bar'
// import Arrow from './arrow';
import Popup from './popup'
import scrollbar from './scrollbar'

import './gantt.scss'

import zrender from 'zrender'
import { baseConfig, theme, zlevel } from './baseConfig'
import ganttBase from './ganttBase'

const VIEW_MODE = {
  QUARTER_DAY: 'Quarter Day',
  HALF_DAY: 'Half Day',
  DAY: 'Day',
  WEEK: 'Week',
  MONTH: 'Month',
  YEAR: 'Year',
}

export default class Gantt extends ganttBase {
  constructor(wrapper, tasks, options) {
    super(wrapper, tasks, options)
    this.resize = this.resize.bind(this) // 解决全局 window 绑定事件 this 指向问题
    // this.render_empty();
    this.change_view_mode()
    this.bind_events()
  }

  // 1. 允许直接刷新 ui
  refresh(tasks) {
    this.setup_tasks(tasks)
    // this.render_empty();
    this.change_view_mode()
    this.bind_events()
  }

  // 2. 改变视图格式，展示 年/月/周 等视图格式
  change_view_mode(mode = this.options.view_mode) {
    this.canvasHeight = this.$canvas.getHeight()
    this.canvasWidth = this.$canvas.getWidth()
    this.update_view_scale(mode)
    this.setup_dates()
    this.renderCanvas()
    // fire viewmode_change event
    this.trigger_event('view_change', [mode])
  }

  // 3. 事件绑定
  bind_events() {
    if (this.tasks.length === 0) {
      return
    }
    this.bind_scroll_event()
    this.bind_grid_event()
    this.bind_bar_events_canvas()
    this.bind_bar_move_event()
    this.bind_resize_event()
  }

  // 4. 绘制入口
  renderCanvas() {
    this.clear_canvas()
    this.setup_layers_canvas()
    this.make_grid_canvas()
    this.make_header_dates_canvas()
    this.make_bars_canvas()
    this.make_scrollbar()
    // this.make_arrows();
    // this.map_arrows_on_bars();
    // 在绘制完成之后，滚动到默认位置
    this.scrollHandler()
  }

  // 绘制 - 空内容
  render_empty() {
    this.$empty.className = this.tasks.length
      ? 'gantt-empty-hidden'
      : 'gantt-empty-show'
  }

  // 绘制 - group
  setup_layers_canvas() {
    // 在 refresh 之后，旧对象会被 gc 回收
    this.layers = {}
    const layers = ['header', 'grid', 'bar']
    // make group layers
    for (let layer of layers) {
      const g = new zrender.Group()
      this.layers[layer] = g
    }
  }

  // 绘制 - 基本 grid 背景
  make_grid_canvas() {
    this.make_grid_background_canvas()
    this.make_grid_rows_canvas()
    this.make_header_bg_canvas() // 放在这里是方便在绘制竖线时，也直接绘制了头部竖线
    this.make_grid_ticks_canvas()
    this.make_grid_highlights()
    this.$canvas.add(this.layers.grid)
  }

  // 绘制 grid - 背景
  make_grid_background_canvas() {
    const bgRect = new zrender.Rect({
      shape: {
        x: 0,
        y: 0,
        width: this.$canvas.getWidth(),
        height: this.$canvas.getHeight(),
      },
      cursor: 'default',
      style: {
        fill: theme.background,
      },
    })
    this.$canvas.add(bgRect)
  }

  // 绘制 grid - rows
  make_grid_rows_canvas() {
    const row_width = this.dates.length * this.options.column_width
    const row_height = this.options.bar_height + this.options.padding

    // y 方向偏移量
    let row_y = this.options.header_height // 距离顶部留白
    const stripe = this.options.stripe

    this.rowMap = {}

    this.tasks.forEach((task, index) => {
      const rowRect = new zrender.Rect({
        shape: {
          x: 0,
          y: row_y,
          width: row_width,
          height: row_height,
        },
        cursor: 'default',
        style: {
          fill:
            stripe && index % 2 === 0 ? theme.stripeColor : theme.background,
        },
        surportHighLight: true,
        taskId: task.id,
      })
      this.layers.grid.add(rowRect)
      this.rowMap[task.id] = rowRect
      // 暂时不绘制底线
      row_y += this.options.bar_height + this.options.padding
    })
    this.gridRectInfo = {
      height: row_height * this.tasks.length + 15, // +15 是保证底部滚动条不遮挡内容，保证左侧 table 可以顺利滚动到底部加载内容
      width: row_width,
    }
  }

  // 绘制 grid - 竖线
  make_grid_ticks_canvas() {
    let tick_x = 0
    let tick_y = this.options.header_height + baseConfig.borderWidth
    let tick_height =
      (this.options.bar_height + this.options.padding) * this.tasks.length
    let tick_y_end =
      this.options.header_height + baseConfig.borderWidth + tick_height // 结束绘制竖线点

    if (tick_y_end < this.canvasHeight && this.options.bg_full) {
      tick_y_end = this.canvasHeight
      tick_height = this.canvasHeight - tick_y
    }

    function addLine(
      x1,
      y1,
      x2,
      y2,
      stroke = theme.lineColor,
      lineWidth = 1,
      type = 'grid',
    ) {
      if (x1 == 0) {
        return
      } // 第一条边线不画
      this.layers[type].add(
        new zrender.Line({
          shape: {
            x1,
            y1,
            x2,
            y2,
          },
          cursor: 'default',
          style: {
            stroke,
            lineWidth,
          },
          silent: true,
          zlevel: zlevel[type],
        }),
      )
    }
    function addRect(x, y, width, height) {
      this.layers.header.add(
        new zrender.Rect({
          shape: {
            x,
            y: this.options.header_top_height,
            width,
            height: this.options.header_bottom_height,
          },
          cursor: 'default',
          silent: true,
          style: {
            fill: theme.weekend,
            opacity: 0.5,
          },
          zlevel: zlevel.header,
        }),
      )
      this.layers.grid.add(
        new zrender.Rect({
          shape: { x, y, width, height },
          cursor: 'default',
          silent: true,
          style: {
            fill: theme.weekend,
            opacity: 0.5,
          },
          zlevel: zlevel.grid,
        }),
      )
    }

    for (let date of this.dates) {
      // 日视图
      if (this.view_is(VIEW_MODE.DAY)) {
        switch (date.getDay()) {
          // 周一前整体分割线
          case 1:
            // addLine.call(this, tick_x, 0, tick_x, this.options.header_height, 'white', baseConfig.borderWidth, 'header');
            addLine.call(
              this,
              tick_x,
              0,
              tick_x,
              this.options.header_height,
              theme.lineColor,
              1,
              'header',
            )
            break

          // 每周六、日 - 绘制深色背景
          case 6:
          case 0:
            addRect.call(
              this,
              tick_x,
              tick_y,
              this.options.column_width,
              tick_height,
            )

          default:
            addLine.call(
              this,
              tick_x,
              this.options.header_top_height,
              tick_x,
              this.options.header_height,
              theme.lineColor,
              1,
              'header',
            )
            break
        }
      } else if (
        this.view_is(VIEW_MODE.WEEK) &&
        date.getDate() >= 1 &&
        date.getDate() < 8
      ) {
        // 周视图 - 每月第一周
        addLine.call(
          this,
          tick_x,
          0,
          tick_x,
          this.options.header_height,
          'white',
          baseConfig.borderWidth,
          'header',
        )
      } else if (
        this.view_is(VIEW_MODE.MONTH) &&
        (date.getMonth() + 1) % 3 === 0
      ) {
        // 月视图 - 每季度结束
        addLine.call(
          this,
          tick_x,
          0,
          tick_x,
          this.options.header_height,
          'white',
          baseConfig.borderWidth,
          'header',
        )
      }

      // grid 竖线
      addLine.call(this, tick_x, tick_y, tick_x, tick_y_end)
      tick_x += this.options.column_width
    }
  }

  // 绘制 grid - 今天高亮
  make_grid_highlights() {
    // highlight today's date
    const today = date_utils.today()
    this.todayRectX = null
    if (
      this.view_is(VIEW_MODE.DAY) &&
      today > this.gantt_start &&
      today < this.gantt_end
    ) {
      let x =
        (date_utils.diff(today, this.gantt_start, 'hour') / this.options.step) *
        this.options.column_width
      const y = 0

      const width = this.options.column_width
      let height =
        (this.options.bar_height + this.options.padding) * this.tasks.length +
        this.options.header_height

      if (height < this.canvasHeight && this.options.bg_full) {
        height = this.canvasHeight
      }
      if (this.options.isScrollToday) {
        // 今天高亮改为线
        this.layers.grid.add(
          new zrender.Line({
            shape: {
              x1: x + width / 2,
              y1: this.options.header_height,
              x2: x + width / 2,
              y2: height,
            },
            cursor: 'default',
            style: {
              stroke: theme.todyHighlight,
              lineWidth: 1,
            },
            silent: true,
            zlevel: zlevel.grid,
          }),
        )
      } else {
        let min = this.gantt_start
        if (this.tasks.length) {
          min = this.tasks[0]._start
          for (let i = 1; i < this.tasks.length; i++) {
            let start = this.tasks[i]._start
            if (start < min) {
              min = start
            }
          }
        }
        x = (date_utils.diff(min, this.gantt_start, 'hour') / this.options.step) *
          this.options.column_width
      }
      this.todayRectX = x
    }
  }

  // 绘制 header - 表头
  make_header_bg_canvas() {
    const header_width = this.dates.length * this.options.column_width
    const headerRectTop = new zrender.Rect({
      shape: {
        x: 0,
        y: 0,
        width: header_width,
        height: this.options.header_top_height,
      },
      cursor: 'default',
      style: {
        fill: theme.headerTop,
      },
      zlevel: zlevel.header,
    })
    const headerRectBottom = new zrender.Rect({
      shape: {
        x: 0,
        y: this.options.header_top_height,
        width: header_width,
        height: this.options.header_bottom_height,
      },
      cursor: 'default',
      style: {
        fill: theme.headerBottom,
      },
      zlevel: zlevel.header,
    })
    this.headerRectInfo = {
      width: header_width,
      height:
        this.options.header_top_height + this.options.header_bottom_height,
    }
    this.layers.header.add(headerRectTop)
    this.layers.header.add(headerRectBottom)

    // 绘制 header 的横线
    const width = this.options.column_width * this.dates.length
    function addRowLine(y, lineWidth = 1) {
      this.layers.header.add(
        new zrender.Line({
          shape: {
            x1: 0,
            y1: y,
            x2: width,
            y2: y,
          },
          cursor: 'default',
          style: {
            stroke: theme.lineColor,
            lineWidth,
          },
          silent: true,
          zlevel: zlevel.header,
        }),
      )
    }
    addRowLine.call(this, this.options.header_top_height)
    addRowLine.call(this, this.options.header_height)
  }

  // 绘制 header - 日期入口
  make_header_dates_canvas() {
    for (let date of this.get_dates_to_draw()) {
      if (!date.lower_text) {
        continue
      }
      const textGraph = {
        cursor: 'default',
        style: {
          text: date.lower_text,
          ...baseConfig.fontBase,
          textAlign: 'center',
          // textVerticalAlign: "middle",
          textFill:
            date.lower_text === '六' || date.lower_text === '日'
              ? baseConfig.attachBase.textFill
              : baseConfig.fontBase.textFill,
          x: date.lower_x,
          y: date.lower_y + this.options.header_bottom_height / 10,
        },
        zlevel: zlevel.header,
      }
      // 如果下底文字有附加右上角字段
      if (date.lower_text_attach) {
        const dayTextGraph = {
          cursor: 'default',
          style: {
            text: date.lower_text_attach,
            ...baseConfig.attachBase,
            textAlign: 'center',
            // textVerticalAlign: "middle",
            x: date.lower_x,
            y: date.lower_y - this.options.header_bottom_height / 3,
          },
          zlevel: zlevel.header,
        }
        // textGraph.style = {
        //     ...textGraph.style,
        //     text: '{attach|' + date.lower_text_attach + '}\n' + textGraph.style.text,
        //     rich: {
        //         attach: {
        //             // textBackgroundColor: "blue", // 颜色保留是方便调试查看
        //             ...baseConfig.attachBase
        //         }
        //     }
        // }
        this.layers.header.add(new zrender.Text(dayTextGraph))
      }
      this.layers.header.add(new zrender.Text(textGraph))

      if (date.upper_text) {
        this.layers.header.add(
          new zrender.Text({
            cursor: 'default',
            style: {
              text: date.upper_text,
              ...baseConfig.fontBase,
              ...baseConfig.headerTopText,
              textAlign: 'center',
              textVerticalAlign: 'middle',
              x: date.upper_x,
              y: date.upper_y,
            },
            zlevel: zlevel.header,
          }),
        )
      }
    }
    this.$canvas.add(this.layers.header)
  }

  // 绘制顶部日期 - 遍历 dates 对象
  get_dates_to_draw() {
    let last_date = null
    const dates = this.dates.map((date, i) => {
      const d = this.get_date_info(date, last_date, i)
      last_date = date
      return d
    })
    return dates
  }

  // 绘制顶部日期 - 获取绘制数据对象
  get_date_info(date, last_date, i) {
    if (!last_date) {
      last_date = date_utils.add(date, 1, 'year')
    }
    const date_text = {
      'Quarter Day_lower': date_utils.format(date, 'HH', this.options.language),
      'Half Day_lower': date_utils.format(date, 'HH', this.options.language),
      Day_lower: date_utils.getWeekText(date, this.options.language),
      Day_lower_text_attach: date_utils.format(
        date,
        'D',
        this.options.language,
      ),
      Week_lower:
        date.getMonth() !== last_date.getMonth()
          ? date_utils.format(date, 'D MMM', this.options.language)
          : date_utils.format(date, 'D', this.options.language),
      Month_lower: date_utils.format(date, 'MMMM', this.options.language),
      Year_lower: date_utils.format(date, 'YYYY', this.options.language),

      'Quarter Day_upper':
        date.getDate() !== last_date.getDate()
          ? date_utils.format(date, 'D MMM', this.options.language)
          : '',
      'Half Day_upper':
        date.getDate() !== last_date.getDate()
          ? date.getMonth() !== last_date.getMonth()
            ? date_utils.format(date, 'D MMM', this.options.language)
            : date_utils.format(date, 'D', this.options.language)
          : '',
      Day_upper:
        date.getDay() === 1
          ? date_utils.format(date, 'YYYY.MM.DD', this.options.language) +
            '-' +
            date_utils.format(
              date_utils.add(date, 6, 'day'),
              'YYYY.MM.DD',
              this.options.language,
            ) +
            '  ' +
            (date_utils.diff(date, new Date(date.getFullYear() + ''), 'week') +
              1) +
            '周'
          : '',
      Week_upper:
        date.getMonth() !== last_date.getMonth()
          ? date_utils.format(date, 'MMMM', this.options.language)
          : '',
      Month_upper:
        date.getFullYear() !== last_date.getFullYear()
          ? date_utils.format(date, 'YYYY', this.options.language)
          : '',
      Year_upper:
        date.getFullYear() !== last_date.getFullYear()
          ? date_utils.format(date, 'YYYY', this.options.language)
          : '',
    }

    const base_pos = {
      x: i * this.options.column_width,
      lower_y:
        this.options.header_top_height + this.options.header_bottom_height / 2,
      upper_y: this.options.header_top_height / 2,
    }

    const x_pos = {
      'Quarter Day_lower': (this.options.column_width * 4) / 2,
      'Quarter Day_upper': 0,
      'Half Day_lower': (this.options.column_width * 2) / 2,
      'Half Day_upper': 0,
      Day_lower: this.options.column_width / 2, // 格子居中
      Day_upper: (this.options.column_width * 7) / 2,
      Week_lower: this.options.column_width / 2,
      Week_upper: (this.options.column_width * 4) / 2,
      Month_lower: this.options.column_width / 2,
      Month_upper: (this.options.column_width * 12) / 2,
      Year_lower: this.options.column_width / 2,
      Year_upper: (this.options.column_width * 30) / 2,
    }

    return {
      upper_text: date_text[`${this.options.view_mode}_upper`],
      lower_text: date_text[`${this.options.view_mode}_lower`],
      lower_text_attach:
        date_text[`${this.options.view_mode}_lower_text_attach`],
      upper_x: base_pos.x + x_pos[`${this.options.view_mode}_upper`],
      upper_y: base_pos.upper_y,
      lower_x: base_pos.x + x_pos[`${this.options.view_mode}_lower`],
      lower_y: base_pos.lower_y,
    }
  }

  // 绘制 bar
  make_bars_canvas() {
    // const time = new Date().getTime();
    this.make_bars_data()
    this.make_bars_draw()
    // console.log(new Date().getTime() - time)
  }

  // 生成 this.bars，并缓存起来
  make_bars_data() {
    this.bars = this.tasks.map(task => {
      const bar = new Bar(this, task)
      return bar
    })
  }

  // 绘制 | 更新 bar，读取 this.bars 缓存数据
  make_bars_draw() {
    this.$canvas.remove(this.layers.bar)
    this.layers.bar.removeAll()

    const scrollY = this.lastScroll.y
    const { bar_height, padding } = this.options
    const canvasHeight = this.canvasHeight || this.$canvas.getHeight()
    const barLength = this.bars.length

    /**
     * 滚动优化算法：只展示在 y 轴可视范围内的 bar
     * 1. 采用普通 for 循环，使用 break 跳出循环
     * 2. 顶层 bar 的底部边缘显示：显示范围 y_start = bar.y + bar_height + padding - scrollY 大于 0
     * 3. 底层 bar 的顶部边缘显示：显示范围 y_end = bar.y - scrollY 小于 canvasHeight
     * 4. this.bars 数据按几何从上到下排序稳定
     * TODO：目前是基于 this.bars 来做的优化，在处理 10W 条数据时，还是会卡，因为内存占用过高，后续改用 this.tasks 来做优化
     */
    for (let i = 0; i < barLength; i++) {
      const bar = this.bars[i]
      const y_start = bar.y + bar_height + padding - scrollY
      const y_end = bar.y - scrollY

      // 顶部隐藏
      if (y_start < 0) {
        continue
      }
      // 底部隐藏
      if (y_end > canvasHeight) {
        break
      }
      this.layers.bar.add(bar.group)
    }

    this.$canvas.add(this.layers.bar)
  }

  // 绘制 make_bars_draw - debounce 实现，在数据超过 1w 条之后使用，降低刷新频率，保证滚动不卡顿
  make_bars_draw_wraper() {
    if (this.bars.length < 10001) {
      this.make_bars_draw()
      return
    }
    const now = new Date().getTime()
    const delay = 100
    if (now - this.lastDrawBar > delay) {
      this.lastDrawBar = now
      this.lastDrawBarHandler && clearTimeout(this.lastDrawBarHandler)
      this.lastDrawBarHandler = setTimeout(
        this.make_bars_draw.bind(this),
        delay,
      )
    }
  }

  // 绘制 bar 无中生有
  make_bar_invalid_handler(e) {
    let targetBar = this.get_bar(e.target.taskId)
    let lastTargetBar = this.lastTargetBar
    let canDraw = false // 是否可以绘制

    const offsetX = e.offsetX + this.lastScroll.x
    const startHour =
      this.options.step * Math.floor(offsetX / this.options.column_width)

    // 如果是已经创建了一次，则清除已有内容(点击任意空白区域)
    if (targetBar && targetBar.setInvalidRect) {
      targetBar.setInvalidRect = false
      this.lastTargetBar = null
    } else if (lastTargetBar && lastTargetBar.setInvalidRect) {
      // 如果之前有创建了一次的
      lastTargetBar.setInvalidRect = false
      this.lastTargetBar = null
      lastTargetBar.prepare_values()
      lastTargetBar.draw(false)
    } else if (targetBar && targetBar.task.dragable && targetBar.invalid) {
      // 创建一个 step 跨度的任务
      targetBar.task._start = date_utils.add(
        this.gantt_start,
        startHour,
        'hour',
      )
      targetBar.task._end = date_utils.add(
        this.gantt_start,
        startHour + this.options.step,
        'hour',
      )
      targetBar.setInvalidRect = true
      this.lastTargetBar = targetBar
      canDraw = true
    }

    targetBar.prepare_values()
    targetBar.draw(canDraw)

    // 执行绘制
    this.make_bars_draw()
  }

  // 绘制 滚动条
  make_scrollbar() {
    if (!this.scrollbar) {
      this.scrollbar = new scrollbar(this.$container, {
        contentWidth: this.tasks.length ? this.headerRectInfo.width : 0,
        on_scroll: scrollLeft => {
          if (scrollLeft === this.lastScroll.x) {
            return
          }
          this.scrollHandler(scrollLeft - this.lastScroll.x)
        },
      })
    } else {
      this.scrollbar.refresh({
        contentWidth: this.tasks.length ? this.headerRectInfo.width : 0,
      })
    }
  }

  // 绘制 箭头 - TODO
  make_arrows() {
    // this.arrows = [];
    // for (let task of this.tasks) {
    //     let arrows = [];
    //     arrows = task.dependencies
    //         .map(task_id => {
    //             const dependency = this.get_task(task_id);
    //             if (!dependency) return;
    //             const arrow = new Arrow(
    //                 this,
    //                 this.bars[dependency._index], // from_task
    //                 this.bars[task._index] // to_task
    //             );
    //             this.layers.arrow.appendChild(arrow.element);
    //             return arrow;
    //         })
    //         .filter(Boolean); // filter falsy values
    //     this.arrows = this.arrows.concat(arrows);
    // }
  }

  // 绘制 箭头 - TODO
  map_arrows_on_bars() {
    for (let bar of this.bars) {
      bar.arrows = this.arrows.filter(arrow => {
        return (
          arrow.from_task.task.id === bar.task.id ||
          arrow.to_task.task.id === bar.task.id
        )
      })
    }
  }

  // 滚动到今天
  scroll_today() {
    if (!this.todayRectX) {
      return
    }
    const boxwidth = this.$canvas.getWidth()
    const scrollWidth =
      this.todayRectX +
      this.options.column_width / 2 -
      boxwidth / 2 -
      this.lastScroll.x
    this.scrollHandler(scrollWidth)
  }

  // 滚动处理函数，调用地方：本地直接滚动、外部滚动调用接口(自定义滚动条、table 滚动联动)，x | y 表示每次的增量
  scrollHandler(x = 0, y = 0) {
    const layers = Object.keys(this.layers)

    let deltaX = this.lastScroll.x + x
    let deltaY = this.lastScroll.y + y
    // 控制滚动范围：最小不能超过最左侧/顶端，最大不能超过内容边缘/容器边缘
    this.lastScroll.x = Math.max(
      Math.min(deltaX, this.gridRectInfo.width - this.canvasWidth),
      0,
    )
    this.lastScroll.y = Math.max(
      Math.min(
        deltaY,
        this.gridRectInfo.height +
          this.headerRectInfo.height -
          this.canvasHeight,
      ),
      0,
    )
    // layer 滚动
    for (let layer of layers) {
      let layerOffsetY = -this.lastScroll.y
      // 如果固定头部
      if (this.options.headerFix && layer === 'header') {
        layerOffsetY = 0
      }
      this.layers[layer].attr('position', [-this.lastScroll.x, layerOffsetY])
    }
    // popup 滚动
    if (this.popup && this.popup.isshow) {
      this.popup.refreshPosition({
        ...this.popupTargetPosition,
        x: this.popupTargetPosition.x - this.lastScroll.x,
        y: this.popupTargetPosition.y - this.lastScroll.y,
      })
    }
    // scrollbar 滚动
    if (this.scrollbar) {
      this.scrollbar.set_scroll(this.lastScroll.x)
    }

    // y 轴滚动不优化
    if (y === 0) {
      return
    }
    requestAnimationFrame(() => {
      this.make_bars_draw_wraper()
    })
    // this.make_bars_draw_wraper();
  }

  // 自定义实现横向滚动、竖向滚动
  bind_scroll_event() {
    const canScroll =
      this.canvasHeight < this.gridRectInfo.height + this.headerRectInfo.height
    // 禁止浏览器同步滚动
    const browserScrollPrevent = this.options.browserScrollPrevent
    this.preventParentScroll =
      this.preventParentScroll || (e => e.preventDefault())

    // 滚动处理函数
    const scrollFunction = e => {
      e = e.event
      // 滚动开始钩子
      this.trigger_event('before_scroll', { ...this.lastScroll, e })
      this.scrollHandler(e.deltaX, e.deltaY)

      if (browserScrollPrevent) {
        /**
         * 同步滚动条件
         * 1. 可滚动 + 滚动到底部 + 继续向下滚
         * 2. 可滚动 + 滚动到顶部 + 继续向上滚
         * 3. 不可滚动
         */
        const isScrollBottom =
          this.lastScroll.y ===
          this.gridRectInfo.height +
            this.headerRectInfo.height -
            this.canvasHeight
        if (
          !canScroll ||
          (isScrollBottom && e.deltaY > 0) ||
          (this.lastScroll.y === 0 && e.deltaY < 0)
        ) {
          this.trigger_event('parent_scroll', { x: e.deltaX, y: e.deltaY })
        }
      }

      // 滚动结束钩子
      this.trigger_event('after_scroll', { ...this.lastScroll, e })
    }

    // 初始判断 - 可以滚动，阻止事件同步
    if (browserScrollPrevent) {
      this.$container.removeEventListener(
        'mousewheel',
        this.preventParentScroll,
        { passive: false },
      )
      this.$container.addEventListener('mousewheel', this.preventParentScroll, {
        passive: false,
      })
    } else {
      this.$container.removeEventListener(
        'mousewheel',
        this.preventParentScroll,
        { passive: false },
      )
    }

    this.$canvas.off('mousewheel', scrollFunction)
    this.$canvas.on('mousewheel', scrollFunction)
  }

  // 绑定 grid, header 点击事件
  bind_grid_event() {
    const globalClickFunction = e => {
      if (e.target.surportHighLight) {
        this.make_bar_invalid_handler(e)
      }
      this.hide_popup()
    }
    const mouseoverHandler = e => {
      if (e.target.surportHighLight) {
        this.grid_bar_highlight_setting(e.target)
      }
    }

    // this.layers.grid.off('mouseover', mouseoverHandler)
    this.layers.grid.on('mouseover', mouseoverHandler)
    // 鼠标移出时，清除高亮
    this.layers.grid.on('mouseout', this.clear_grid_bar_highlight.bind(this))
    // this.layers.header.off('click', globalClickFunction);
    // this.layers.grid.off('click', globalClickFunction);
    this.layers.header.on('click', globalClickFunction)
    this.layers.grid.on('click', globalClickFunction)
  }

  // 撤销上次活跃 row
  clear_grid_bar_highlight() {
    if (this.lastHighLightRow) {
      this.lastHighLightRow.attr({
        style: { fill: theme.background },
        zlevel: zlevel.hidden,
      })
      this.lastHighLightRow = null

      // 触发表格的高亮改变事件
      this.trigger_event('highlight_change')
    }
  }

  // 高亮设置 targetRow 可以是 task.id
  grid_bar_highlight_setting(targetRow) {
    // 如果传入的是 id，则通过 this.layers.grid 来查找对应的 row 对象
    if (typeof targetRow !== 'object') {
      // 如果活跃 row 没有变化，则不处理
      if (this.lastHighLightRow && targetRow === this.lastHighLightRow.taskId) {
        return
      }
      targetRow = this.rowMap[targetRow]
    }

    // 如果活跃 row 没有变化，则不处理
    if (
      this.lastHighLightRow &&
      targetRow.taskId === this.lastHighLightRow.taskId
    ) {
      return
    }

    // 撤销上次活跃 row
    this.lastHighLightRow &&
      this.lastHighLightRow.attr({
        style: { fill: theme.background },
        zlevel: zlevel.hidden,
      })

    // 如果在缓存对象中没有找到，则不做处理
    if (!targetRow) {
      return
    }

    // 设置当前 row 活跃
    targetRow.attr({
      style: { fill: theme.rectHighlight, opacity: 0.7 },
      zlevel: zlevel.grid,
    })
    // 缓存当前 row
    this.lastHighLightRow = targetRow

    this.trigger_event('highlight_change', targetRow.taskId)
  }

  // 绑定 bar 事件
  bind_bar_events_canvas() {
    const clickHandler = e => {
      const targetBar = this.get_bar_bygroup(e.target)
      this.trigger_event('taskbar_click', targetBar)
    }
    const mouseoverHandler = e => {
      const targetBar = this.get_bar_bygroup(e.target)
      targetBar.show_popup()
      targetBar.show_resize_handles()
    }
    const mouseoutHandler = e => {
      const targetBar = this.get_bar_bygroup(e.target)
      targetBar.hide_resize_handles()
      this.hide_popup()
    }

    // this.layers.bar.off('mouseover', mouseoverHandler)
    this.layers.bar.on('mouseover', mouseoverHandler)
    // this.layers.bar.off('mouseout', mouseoutHandler)
    this.layers.bar.on('mouseout', mouseoutHandler)
    // this.layers.bar.off('click', clickHandler)
    this.layers.bar.on('click', clickHandler)
  }

  // 绑定 bar 移动事件：整体位移、两端位移
  bind_bar_move_event() {
    let is_dragging = false // 整体拖拽
    let x_on_start = 0 // 在 mousemove 过程中不能改变，始终于 mousedown 是一个相对位移
    // let y_on_start = 0;
    let is_resizing_left = false // 左侧模块拖拽
    let is_resizing_right = false // 右侧模块拖拽
    let targetBar = null // 目标 bar 对象
    this.bar_being_dragged = null
    let finaldx = 0 // 整体 x 位移量

    // 是否是在拖拽过程中
    function action_in_progress() {
      return is_dragging || is_resizing_left || is_resizing_right
    }

    // 鼠标按下
    !this.mousedownHandler &&
      (this.mousedownHandler = e => {
        // 1. 获取 bar 对象
        targetBar = this.get_bar_bygroup(e.target)
        if (!targetBar.task?.dragable) {
          return
        }

        // 2. 判断移动方向
        if (e.target.isLeftHandle) {
          is_resizing_left = true
        } else if (e.target.isRightHandle) {
          is_resizing_right = true
        } else {
          is_dragging = true
        }

        // 3. 记录初始位置
        x_on_start = e.offsetX
        // y_on_start = e.offsetY;

        this.bar_being_dragged = targetBar.task.id
      })
    // 鼠标移动
    !this.mouseMoveHandler &&
      (this.mouseMoveHandler = e => {
        if (!action_in_progress()) return
        this.hide_popup()

        // 计算偏移量
        const dx = e.offsetX - x_on_start
        finaldx = this.get_snap_position(dx)

        if (is_resizing_left) {
          // 这里要保证 bar.js 中 this.x, this.width 不能变
          targetBar.update_bar_position({
            x: targetBar.x + finaldx,
            width: targetBar.width - finaldx,
          })
        } else if (is_resizing_right) {
          targetBar.update_bar_position({
            width: targetBar.width + finaldx,
          })
        } else if (is_dragging) {
          targetBar.update_bar_position({
            x: targetBar.x + finaldx,
          })
        }
      })
    // 鼠标按起
    !this.mouseUpHandler &&
      (this.mouseUpHandler = () => {
        this.bar_being_dragged = null
        is_dragging = false
        is_resizing_left = false
        is_resizing_right = false
        if (!finaldx) return
        finaldx = 0
        targetBar.date_changed()
      })
    this.layers.bar.off('mousedown', this.mousedownHandler)
    this.layers.bar.on('mousedown', this.mousedownHandler)
    this.$canvas.off('mousemove', this.mouseMoveHandler) // mousemove 不能绑在 bar 上面，否则不能检测到
    this.$canvas.on('mousemove', this.mouseMoveHandler)
    this.$canvas.off('mouseup', this.mouseUpHandler)
    this.$canvas.on('mouseup', this.mouseUpHandler)

    // 暂时不处理 document，因为此处内存泄漏不好处理
    // document.removeEventListener('mouseup', mouseUpHandler);
    // document.addEventListener('mouseup', mouseUpHandler);
  }

  // 绑定 window resize 事件
  bind_resize_event() {
    window.removeEventListener('resize', this.resize)
    window.addEventListener('resize', this.resize)
  }

  // 绑定 progress 处理事件 TODO
  bind_bar_progress() {
    // let x_on_start = 0;
    // let y_on_start = 0;
    // let is_resizing = null;
    // let bar = null;
    // let $bar_progress = null;
    // let $bar = null;
    // $.on(this.$svg, 'mousedown', '.handle.progress', (e, handle) => {
    //     is_resizing = true;
    //     x_on_start = e.offsetX;
    //     y_on_start = e.offsetY;
    //     const $bar_wrapper = $.closest('.bar-wrapper', handle);
    //     const id = $bar_wrapper.getAttribute('data-id');
    //     bar = this.get_bar(id);
    //     $bar_progress = bar.$bar_progress;
    //     $bar = bar.$bar;
    //     $bar_progress.finaldx = 0;
    //     $bar_progress.owidth = $bar_progress.getWidth();
    //     $bar_progress.min_dx = -$bar_progress.getWidth();
    //     $bar_progress.max_dx = $bar.getWidth() - $bar_progress.getWidth();
    // });
    // $.on(this.$svg, 'mousemove', e => {
    //     if (!is_resizing) return;
    //     let dx = e.offsetX - x_on_start;
    //     let dy = e.offsetY - y_on_start;
    //     if (dx > $bar_progress.max_dx) {
    //         dx = $bar_progress.max_dx;
    //     }
    //     if (dx < $bar_progress.min_dx) {
    //         dx = $bar_progress.min_dx;
    //     }
    //     const $handle = bar.$handle_progress;
    //     $.attr($bar_progress, 'width', $bar_progress.owidth + dx);
    //     $.attr($handle, 'points', bar.get_progress_polygon_points());
    //     $bar_progress.finaldx = dx;
    // });
    // $.on(this.$svg, 'mouseup', () => {
    //     is_resizing = false;
    //     if (!($bar_progress && $bar_progress.finaldx)) return;
    //     bar.progress_changed();
    //     bar.set_action_completed();
    // });
  }

  get_all_dependent_tasks(task_id) {
    let out = []
    let to_process = [task_id]
    while (to_process.length) {
      const deps = to_process.reduce((acc, curr) => {
        acc = acc.concat(this.dependency_map[curr])
        return acc
      }, [])

      out = out.concat(deps)
      to_process = deps.filter(d => !to_process.includes(d))
    }

    return out.filter(Boolean)
  }

  // 该方法用于取整计算，如果小于半格，则不做位移，如果大于半格，则算一整格，可能返回正负值
  get_snap_position(dx) {
    let odx = dx,
      rem,
      position

    if (this.view_is(VIEW_MODE.WEEK)) {
      rem = dx % (this.options.column_width / 7)
      position =
        odx -
        rem +
        (rem < this.options.column_width / 14
          ? 0
          : this.options.column_width / 7)
    } else if (this.view_is(VIEW_MODE.MONTH)) {
      rem = dx % (this.options.column_width / 30)
      position =
        odx -
        rem +
        (rem < this.options.column_width / 60
          ? 0
          : this.options.column_width / 30)
    } else {
      rem = dx % this.options.column_width
      position =
        odx -
        rem +
        (rem < this.options.column_width / 2 ? 0 : this.options.column_width)
    }
    return position
  }

  unselect_all() {
    ;[...this.$svg.querySelectorAll('.bar-wrapper')].forEach(el => {
      el.classList.remove('active')
    })
  }

  view_is(modes) {
    if (typeof modes === 'string') {
      return this.options.view_mode === modes
    }

    if (Array.isArray(modes)) {
      return modes.some(mode => this.options.view_mode === mode)
    }

    return false
  }

  get_task(id) {
    return this.tasks.find(task => {
      return task.id === id
    })
  }

  // 获取 bar 对象 - 通过 id
  get_bar(id) {
    return this.bars.find(bar => {
      return bar.task.id === id
    })
  }

  // 获取 bar 对象 - 通过 e.target 对象
  get_bar_bygroup(group = {}) {
    let targetBar = null
    let currentObj = group
    while (!targetBar) {
      // NOSONAR
      if (currentObj.parentBar) {
        targetBar = currentObj.parentBar
        break
      } else if (!currentObj.parent) {
        break
      } else {
        currentObj = currentObj.parent
      }
    }
    return targetBar
  }

  // 展示 popup
  show_popup(options) {
    if (!this.popup) {
      this.popup = new Popup(this.popup_wrapper, this.options.custom_popup_html)
    }
    this.popupTargetPosition = options.positionObj || this.popupTargetPosition
    this.popup.show({
      ...options,
      positionObj: {
        ...this.popupTargetPosition,
        x: this.popupTargetPosition.x - this.lastScroll.x,
        y: this.popupTargetPosition.y - this.lastScroll.y,
      },
    })
  }

  // 隐藏 popup
  hide_popup() {
    this.popup && this.popup.hide()
  }

  // resize
  resize() {
    this.$canvas && this.$canvas.resize()
    // 如果初始没有高度或宽度，则需要重新渲染
    if (!this.canvasHeight || !this.canvasWidth) {
      this.change_view_mode()
      this.bind_events()
    } else {
      this.canvasHeight = this.$canvas.getHeight()
      this.canvasWidth = this.$canvas.getWidth()
    }

    this.bind_scroll_event()
  }
}

Gantt.VIEW_MODE = VIEW_MODE
