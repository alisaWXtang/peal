export default class Popup {
    constructor(parent, custom_html) {
        this.parent = parent;
        this.custom_html = custom_html;
        this.isshow = false;
        this.make();
    }

    make() {
        this.parent.innerHTML = `
            <div class="title"></div>
            <div class="subtitle"></div>
            <div class="pointer"></div>
        `;

        this.hide();

        this.title = this.parent.querySelector('.title');
        this.subtitle = this.parent.querySelector('.subtitle');
        this.pointer = this.parent.querySelector('.pointer');
    }

    show(options) {
        if (!options.positionObj) {
            throw new Error('positionObj is required to show popup');
        }

        if (options.custom_html || this.custom_html) {
            const htmlParse = options.custom_html || this.custom_html;
            let html = htmlParse(options.task);
            html += '<div class="pointer"></div>';
            this.parent.innerHTML = html;
            this.pointer = this.parent.querySelector('.pointer');
        } else {
            // set data
            this.title.innerHTML = options.title;
            this.subtitle.innerHTML = options.subtitle;
            this.parent.style.width = this.parent.clientWidth + 'px';
        }

        const position_meta = options.positionObj;
        this.popupRect = this.parent.getBoundingClientRect();
        this.parentRect = this.parent.parentNode.getBoundingClientRect();
        this.refreshPosition(position_meta);

        // show
        // this.parent.style.opacity = 1;
        this.parent.style.visibility = 'visible';
        this.isshow = true;
    }

    // 更新位移，position_meta 表示 target task bar 的几何属性
    // 默认坐对齐，支持 position_meta.center
    refreshPosition(position_meta) {
        const popupRectHeight = this.popupRect.height;
        let parentX = position_meta.x > 0 ? position_meta.x : 0;
        let pointerOffsetX = '10px';

        if (position_meta.center) {
            parentX = parentX + position_meta.width / 2 - this.popupRect.width / 2;
            pointerOffsetX = this.popupRect.width / 2 - 5 + 'px';
        }
        this.parent.style.left = parentX + 'px';

        let y = position_meta.y + position_meta.height + 10; // 10 表示尖角占位
        // 1. 不能超出顶部 header
        y = y < 86 ? 86 : y; // 86 = 76 + 10
        // 2. 如果底部装不下或者明确声明向上，则向上
        if (y + popupRectHeight > this.parentRect.height || position_meta.directionTop) {
            y = position_meta.y - popupRectHeight - 10;
            // 3. 向上时还装不下，则不再偏移
            y = y > (this.parentRect.height - popupRectHeight - 10) ? (this.parentRect.height - popupRectHeight - 10): y;
            this.pointer.style.transform = 'rotateZ(-135deg)';
            this.pointer.style.left = pointerOffsetX;
            this.pointer.style.top = popupRectHeight - 5 + 'px';
        } else {
            this.pointer.style.transform = 'rotateZ(45deg)';
            this.pointer.style.left = pointerOffsetX;
            this.pointer.style.top = '-5px';
        }

        this.parent.style.top = y + 'px';
    }

    hide() {
        // this.parent.style.opacity = 0;
        this.parent.style.visibility = 'hidden';
        this.isshow = false;
    }
}
