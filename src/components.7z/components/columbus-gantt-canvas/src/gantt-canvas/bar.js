import date_utils from './date_utils'
// import { $, createSVG, animateSVG } from './svg_utils';
import zrender from 'zrender'
import { baseConfig, theme, zlevel } from './baseConfig'

export default class Bar {
  constructor(gantt, task) {
    this.set_defaults(gantt, task)
    this.prepare()
    this.draw()
  }

  set_defaults(gantt, task) {
    this.gantt = gantt
    this.task = task
  }

  prepare() {
    this.prepare_values()
  }

  // 设置对象默认值
  prepare_values() {
    this.invalid = this.task.invalid
    this.height = this.gantt.options.bar_height
    this.x = this.compute_x(this.task._start)
    this.y = this.compute_y()
    this.corner_radius = this.gantt.options.bar_corner_radius
    this.duration =
      date_utils.diff(this.task._end, this.task._start, 'hour') /
      this.gantt.options.step
    this.width = this.gantt.options.column_width * this.duration
    this.progress_width =
      this.gantt.options.column_width *
        this.duration *
        (this.task.progress / 100) || 0

    this.group = new zrender.Group()
    this.bar_group = new zrender.Group()
    this.handle_group = new zrender.Group()

    this.group.parentBar = this
    this.bar_group.isBar = true
    this.handle_group.isHandle = true

    this.group.add(this.bar_group)
    this.group.add(this.handle_group)
  }

  // 绘制 - 入口
  draw(force = false) {
    // 如果是 invalid，则需要外界主动调用绘制
    if (this.invalid && !force) {
      return
    }
    this.draw_bar_bg()
    this.draw_bar()
    this.draw_children_bar()
    this.draw_progress_bar()
    this.draw_label()
    this.draw_extra_text()
    this.draw_resize_handles()
  }

  // 绘制 - bar 背景
  draw_bar_bg() {
    if (!this.task.dragable) {
      return
    }
    this.$bar_base = new zrender.Group()
    this.$bar_base_bg = new zrender.Rect({
      shape: {
        x: this.x - 16,
        y: this.y - 4,
        r: 7,
        width: this.width + 32,
        height: this.height + 8,
      },
      style: {
        fill: theme.barBaseBackground,
        stroke: theme.barBaseBorderColor,
      },
      zlevel: zlevel.bar,
    })

    function addLine(x1, y1, x2, y2) {
      return new zrender.Line({
        shape: {
          x1,
          y1,
          x2,
          y2,
        },
        // cursor: 'default',
        style: {
          stroke: theme.barBaseBorderColor,
          lineWidth: 1,
        },
        zlevel: zlevel.bar,
      })
    }

    this.$bar_base_line1 = addLine(
      this.x - 8,
      this.y + 3,
      this.x - 8,
      this.y + 13,
    )
    this.$bar_base_line2 = addLine(
      this.x - 4,
      this.y + 3,
      this.x - 4,
      this.y + 13,
    )
    this.$bar_base_line3 = addLine(
      this.x + this.width + 4,
      this.y + 3,
      this.x + this.width + 4,
      this.y + 13,
    )
    this.$bar_base_line4 = addLine(
      this.x + this.width + 8,
      this.y + 3,
      this.x + this.width + 8,
      this.y + 13,
    )

    this.$bar_base.add(this.$bar_base_bg)
    this.$bar_base.add(this.$bar_base_line1)
    this.$bar_base.add(this.$bar_base_line2)
    this.$bar_base.add(this.$bar_base_line3)
    this.$bar_base.add(this.$bar_base_line4)
    this.$bar_base.hide()

    this.bar_group.add(this.$bar_base)
  }

  // 绘制 - bar
  draw_bar() {
    this.$bar = new zrender.Rect({
      shape: {
        x: this.x,
        y: this.y,
        r: [this.gantt.options.bar_corner_radius],
        // width: 0,
        width: this.width,
        height: this.height,
      },
      style: {
        fill: this.invalid
          ? theme.barInvalidBackground
          : this.task.childrenTasks
          ? theme.transparent
          : this.task.backgroundColor ||
            zrender.color.modifyAlpha(theme.barBackground, 0.3),
        stroke: this.task.childrenTasks
          ? this.task.backgroundColor
            ? this.task.backgroundColor
            : null
          : null,
        lineDash: [1.5],
        text: this.invalid ? '' : this.task.name,
        textPosition: 'right',
        ...baseConfig.fontBase,
        textDistance: 5,
      },
      zlevel: zlevel.bar,
    })

    // this.$bar.animate('shape', false)
    // .when(300, {width: this.width})
    // .start()

    this.bar_group.add(this.$bar)
  }

  // 绘制子集
  draw_children_bar() {
    if (!this.task.childrenTasks) return
    for (let i = 0, len = this.task.childrenTasks.length; i < len; i++) {
      let start = date_utils.parse(this.task.childrenTasks[i].start)
      let end = date_utils.parse(this.task.childrenTasks[i].end)
      let x_position = this.compute_x(start)
      // 如果没有提供时分秒，则增加 24 h，满足结束日当天满天
      // e.g: 2018-09-09 becomes 2018-09-09 23:59:59
      const task_end_values = date_utils.get_date_values(end)
      if (task_end_values.slice(3).every(d => d === 0)) {
        end = date_utils.add(end, 24, 'hour')
      }
      let duration =
        date_utils.diff(end, start, 'hour') / this.gantt.options.step
      let width = this.gantt.options.column_width * duration
      let children_bar = new zrender.Rect({
        shape: {
          x: x_position,
          y: this.y,
          r: [this.gantt.options.bar_corner_radius],
          width,
          height: this.height,
        },
        style: {
          fill:
            this.task.backgroundColor ||
            zrender.color.modifyAlpha(theme.barBackground, 0.3),
          stroke: this.task.backgroundColor || theme.barBackground,
        },
        zlevel: zlevel.bar,
      })
      this.bar_group.add(children_bar)
    }
  }

  // 绘制 - progress
  draw_progress_bar() {
    if (this.invalid || !this.progress_width) return
    this.$bar_progress = new zrender.Rect({
      shape: {
        x: this.x,
        y: this.y,
        r: [this.gantt.options.bar_corner_radius],
        // width: 0,
        width: this.progress_width,
        height: this.height,
      },
      style: {
        fill: theme.progressBackground,
      },
      zlevel: zlevel.bar,
    })

    // this.$bar_progress.animate('shape', false)
    // .when(300, {width: this.progress_width})
    // .start()

    this.bar_group.add(this.$bar_progress)
  }

  // 绘制 - label
  draw_label() {
    if (this.invalid || !this.progress_width) return
    this.$bar_progress_label = new zrender.Text({
      style: {
        // x: this.x,
        x: this.x + this.width - 10,
        y: this.y + this.gantt.options.bar_height / 2,
        text: this.task.progress + '%',
        ...baseConfig.fontBase,
        // textWidth: 40,
        textAlign: 'right',
        textVerticalAlign: 'middle',
      },
      zlevel: zlevel.bar,
    })

    // this.$bar_progress_label.animate('style', false)
    // .when(300, {x: this.x + this.width - 10})
    // .start()
    this.bar_group.add(this.$bar_progress_label)
    // requestAnimationFrame(() => this.bar_group.add(this.$bar_progress_label));
  }

  // 绘制附加文字, 进度和附加文字同时显示时，会有重叠，后期优化。
  draw_extra_text() {
    if (!this.task.extraText) return
    this.$bar_extra_text = new zrender.Text({
      style: {
        x: this.x + this.width - 5,
        y: this.y + this.gantt.options.bar_height / 2,
        text: this.task.extraText,
        ...baseConfig.fontBase,
        textAlign: 'right',
        textVerticalAlign: 'middle',
      },
      zlevel: zlevel.bar,
    })
    this.bar_group.add(this.$bar_extra_text)
  }

  // 绘制 - 拖拽区域
  draw_resize_handles() {
    if (!this.task.dragable) {
      return
    }

    const handle_width = 16

    this.rightHandle = new zrender.Rect({
      invisible: true,
      cursor: 'e-resize',
      shape: {
        x: this.x + this.width,
        y: this.y - 4,
        width: handle_width,
        height: this.height + 8,
      },
      zlevel: zlevel.bar,
    })
    this.rightHandle.isRightHandle = true

    this.handle_group.add(this.rightHandle)

    this.leftHandle = new zrender.Rect({
      invisible: true,
      cursor: 'w-resize',
      shape: {
        x: this.x - handle_width,
        y: this.y - 4,
        width: handle_width,
        height: this.height + 8,
      },
      zlevel: zlevel.bar,
    })
    this.leftHandle.isLeftHandle = true

    this.handle_group.add(this.leftHandle)

    // if (this.task.progress && this.task.progress < 100) {
    //     this.$handle_progress = createSVG('polygon', {
    //         points: this.get_progress_polygon_points().join(','),
    //         class: 'handle progress',
    //         append_to: this.handle_group
    //     });
    // }
  }

  get_progress_polygon_points() {
    const bar_progress = this.$bar_progress
    return [
      bar_progress.getEndX() - 5,
      bar_progress.getY() + bar_progress.getHeight(),
      bar_progress.getEndX() + 5,
      bar_progress.getY() + bar_progress.getHeight(),
      bar_progress.getEndX(),
      bar_progress.getY() + bar_progress.getHeight() - 8.66,
    ]
  }

  // 展示可拖拽区域
  show_resize_handles() {
    if (!this.task.dragable) {
      return
    }
    this.$bar_base && this.$bar_base.show()
    this.$bar &&
      this.$bar.attr({
        style: { textDistance: 21 },
      })
  }

  // 隐藏可拖拽区域
  hide_resize_handles() {
    if (!this.task.dragable) {
      return
    }
    this.$bar_base && this.$bar_base.hide()
    this.$bar &&
      this.$bar.attr({
        style: { textDistance: 5 },
      })
  }

  // 展示 popup
  show_popup() {
    // if (this.gantt.bar_being_dragged) return;
    const start_date = date_utils.format(
      this.task._start,
      'MMM D',
      this.gantt.options.language,
    )
    const end_date = date_utils.format(
      date_utils.add(this.task._end, -1, 'second'),
      'MMM D',
      this.gantt.options.language,
    )
    const subtitle = start_date + ' - ' + end_date

    const obj = {
      positionObj: {
        x: this.x,
        y: this.y,
        height: this.height,
        width: this.width,
      },
      title: this.task.name,
      subtitle: subtitle,
      task: this.task,
    }

    if (this.invalid && this.task.dragable) {
      obj.custom_html = () => {
        return '<p class="subtitle">按住拖动并创建时间</p>'
      }
      obj.positionObj.directionTop = true
      obj.positionObj.center = true
    }

    this.gantt.show_popup(obj)
  }

  // 动态更新 bar 位置及长度
  update_bar_position({ x, width }) {
    x = x || this.x
    width = width || this.width
    width =
      width >= this.gantt.options.column_width
        ? width
        : this.gantt.options.column_width

    this.$bar.attr({ shape: { x, width } })

    this.update_extra_position({ x, width })
    this.update_label_position({ x, width })
    this.update_handle_position({ x, width })
    this.update_progressbar_position({ x, width })
    this.update_bgbase_position({ x, width })
    // this.update_arrow_position();
  }

  // 日期改变时，触发 date_change 事件
  date_changed() {
    let changed = false
    const { new_start_date, new_end_date } = this.compute_start_end_date()

    if (Number(this.task._start) !== Number(new_start_date)) {
      changed = true
      this.task._start = new_start_date
    }

    if (Number(this.task._end) !== Number(new_end_date)) {
      changed = true
      this.task._end = new_end_date
    }

    if (!changed) return

    this.gantt.trigger_event('date_change', [
      this.task,
      new_start_date,
      date_utils.add(new_end_date, -1, 'second'),
    ])
  }

  progress_changed() {
    const new_progress = this.compute_progress()
    this.task.progress = new_progress
    this.gantt.trigger_event('progress_change', [this.task, new_progress])
  }

  // 计算当前 bar 的时间区间
  compute_start_end_date() {
    const { x, width } = this.$bar.getBoundingRect()
    this.x = x
    this.width = width

    const x_in_units = x / this.gantt.options.column_width + 1
    const new_start_date = date_utils.add(
      this.gantt.gantt_start,
      x_in_units * this.gantt.options.step,
      'hour',
    )
    const width_in_units = width / this.gantt.options.column_width - 1
    const new_end_date = date_utils.add(
      new_start_date,
      width_in_units * this.gantt.options.step,
      'hour',
    )

    return { new_start_date, new_end_date }
  }

  compute_progress() {
    const progress =
      (this.$bar_progress.getWidth() / this.$bar.getWidth()) * 100
    return parseInt(progress, 10)
  }

  // 计算 bar x 坐标
  compute_x(start) {
    const { step, column_width } = this.gantt.options
    const task_start = start
    const gantt_start = this.gantt.gantt_start

    const diff = date_utils.diff(task_start, gantt_start, 'hour')
    let x = (diff / step) * column_width
    return x
  }

  // 计算 bar y 坐标
  compute_y() {
    return (
      this.gantt.options.header_height +
      baseConfig.borderWidth +
      this.gantt.options.padding / 2 +
      this.task._index * (this.height + this.gantt.options.padding)
    )
  }

  get_snap_position(dx) {
    let odx = dx,
      rem,
      position

    if (this.gantt.view_is('Week')) {
      rem = dx % (this.gantt.options.column_width / 7)
      position =
        odx -
        rem +
        (rem < this.gantt.options.column_width / 14
          ? 0
          : this.gantt.options.column_width / 7)
    } else if (this.gantt.view_is('Month')) {
      rem = dx % (this.gantt.options.column_width / 30)
      position =
        odx -
        rem +
        (rem < this.gantt.options.column_width / 60
          ? 0
          : this.gantt.options.column_width / 30)
    } else {
      rem = dx % this.gantt.options.column_width
      position =
        odx -
        rem +
        (rem < this.gantt.options.column_width / 2
          ? 0
          : this.gantt.options.column_width)
    }
    return position
  }

  update_attr(element, attr, value) {
    value = +value
    if (!isNaN(value)) {
      element.setAttribute(attr, value)
    }
    return element
  }

  // 动态更新进度信息
  update_progressbar_position({ x, width }) {
    if (this.invalid || !this.progress_width) return
    this.$bar_progress.attr({
      shape: {
        x: x,
        width: width * (this.task.progress / 100),
      },
    })
  }

  // 动态更新 label 位置
  update_label_position({ x, width }) {
    if (this.invalid || !this.progress_width) return
    this.$bar_progress_label.attr({ style: { x: x + width - 10 } })
  }

  // 动态更新附加文字位置
  update_extra_position({ x, width }) {
    if (this.invalid || !this.progress_width) return
    this.$bar_extra_text.attr({ style: { x: x + width - 5 } })
  }

  // 动态更新 handle 位置
  update_handle_position({ x, width }) {
    this.rightHandle.attr({ shape: { x: x + width } })
    this.leftHandle.attr({ shape: { x: x - 16 } })
  }

  // 动态更新 bg base 位置
  update_bgbase_position({ x, width }) {
    this.$bar_base_bg.attr({ shape: { x: x - 16, width: width + 32 } })
    this.$bar_base_line1.attr({ shape: { x1: x - 8, x2: x - 8 } })
    this.$bar_base_line2.attr({ shape: { x1: x - 4, x2: x - 4 } })
    this.$bar_base_line3.attr({
      shape: { x1: x + width + 4, x2: x + width + 4 },
    })
    this.$bar_base_line4.attr({
      shape: { x1: x + width + 8, x2: x + width + 8 },
    })
  }

  update_arrow_position() {
    this.arrows = this.arrows || []
    for (let arrow of this.arrows) {
      arrow.update()
    }
  }
}
