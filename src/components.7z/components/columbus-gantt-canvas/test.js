import Gantt from './index.js';

const div = document.createElement('div');
div.style.height = '500px';
div.style.width = '1000px';
document.body.appendChild(div);

var tasks = [
  {
    start: '2018-10-01',
    end: '2018-10-14',
    name: '',
    id: "Task 0",
    backgroundColor: "#A6B0F5"
  },
  {
    start: '2018-10-03',
    end: '2018-10-06',
    name: '软件商店版本迭代',
    id: "Task 1",
    progress: 5,
    dependencies: 'Task 0',
    projectName: "哥伦布",
    statu: "处理中",
    assignUser: "哈哈(80240000)"
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: "Task 2",
    progress: 10,
    dependencies: 'Task 1'
  },
  {
    start: '2018-10-03',
    end: '2018-10-06',
    name: '软件商店版本迭代',
    id: "Task 1",
    progress: 5,
    dependencies: 'Task 0',
    projectName: "哥伦布",
    statu: "处理中",
    assignUser: "哈哈(80240000)"
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: "Task 2",
    progress: 10,
    dependencies: 'Task 1'
  },
  {
    start: '2018-10-08',
    end: '2018-10-09',
    name: 'Review',
    id: "Task 3",
    progress: 95,
    dependencies: 'Task 2'
  },
  {
    start: '2018-10-08',
    end: '2018-10-10',
    name: 'Deploy',
    id: "Task 4",
    progress: 0,
    dependencies: 'Task 2'
  },
  {
    start: '2018-10-11',
    end: '2019-1-11',
    name: 'Go Live!',
    id: "Task 5",
    progress: 0,
    dependencies: 'Task 4',
    custom_class: 'bar-milestone'
  },
  {
    start: '2018-10-01',
    end: '2018-10-08',
    name: 'Redesign website',
    id: "Task 0",
    progress: 80
  },
  {
    start: '2018-10-03',
    end: '2018-10-06',
    name: 'Write new content',
    id: "Task 1",
    progress: 5,
    dependencies: 'Task 0'
  },
  {
    start: '2018-10-04',
    end: '2018-10-08',
    name: 'Apply new styles',
    id: "Task 2",
    progress: 10,
    dependencies: 'Task 1'
  },
  {
    start: '2018-10-08',
    end: '2018-10-09',
    name: 'Review',
    id: "Task 3",
    progress: 5,
    dependencies: 'Task 2'
  },
  // {
  //   start: '2014-01-05',
  //   end: '2019-10-12',
  //   name: 'Long term task',
  //   id: "Task 6",
  //   progress: 0
  // }
]
var gantt_chart = new Gantt(div, tasks, {
  on_taskbar_click: function (task) {
    console.log('on_taskbar_click', task);
  },
  on_date_change: function(task, start, end) {
    console.log('on_date_change', task, start, end);
  },
  on_progress_change: function(task, progress) {
    console.log('on_progress_changet', task, progress);
  },
  on_view_change: function(mode) {
    console.log('on_view_change', mode);
  },
  stripe: false,
  view_mode: 'Day',
  language: 'zh',
  headerFix: true,
  custom_popup_html(task) {
    return `<p class="title">任务：${task.name}</p>
    <p class="subtitle">项目：${task.projectName}</p>
    <p class="subtitle">状态：${task.statu}</p>
    <p class="subtitle">时间：${task.start} - ${task.end}</p>
    <p class="subtitle">处理人：${task.assignUser}</p>`
  }
});

const btn = document.createElement("button");
btn.innerHTML = "add"
btn.onclick = () => {
  const preLength = tasks.length;
  const newLength = 1000; // 修改此处控制模拟数据条数
  for (let i = preLength; i < newLength; i++) {
    tasks.push({
      start: '2018-10-03',
      end: '2018-10-06',
      name: '软件商店版本迭代',
      // id: "Task 1",
      progress: 5,
      dependencies: 'Task 0',
      projectName: "哥伦布",
      statu: "处理中",
      assignUser: "哈哈(80240000)"
    })
  }
  gantt_chart.refresh(tasks)
}
document.body.appendChild(btn);