# @heytap/columbus-gantt-canvas

time: 2020.7.23  
author: heyunjiang

哥伦布甘特图源组件，是甘特图 canvas 版本的实现，对比 svg 实现，主要是能处理更多数据，性能更强大

## 1 使用方式

`npm i @heytap/columbus-gantt-canvas -S`

```javascript
import gantt from '@heytap/columbus-gantt-canvas'

new gantt(this.$refs.ganttroot, (tasks = []), (this.ganttOptions = {}))
```

[demo](./test.js) 基础使用 gantt demo  
[gantt-vue](./src/gantt-vue/readme.md) gantt vue 版本  
[gantt-table](./src/gantt-table/readme.md) gantt 结合左侧 table 的一种实现

## 2 参数说明

### 2.1 task 配置说明

这里列举一个 task 对象的所有参数说明

|     options     |         说明         |  类型   |       例子       | 是否必须 |
| :-------------: | :------------------: | :-----: | :--------------: | :------: |
|      start      |       开始时间       | String  |   '2018-10-03'   |    是    |
|       end       |       结束时间       | String  |   '2018-10-03'   |    是    |
|      name       |         名称         | String  | '甘特图开发实现' |    是    |
|       id        |          id          | Number  |      100001      |    否    |
|    progress     |       进度(%)        | Number  |        50        |    否    |
|  dependencies   |       版本依赖       | String  | '100001,100002'  |    否    |
|    dragable     |     是否可以拖拽     | Boolean |       true       |    否    |
| backgroundColor |        背景色        | String  |      '#ccc'      |    否    |
|    extraText    |       附加文字       | String  |        --        |    否    |
|    children     | 工作项实际时间段显示 |  Array  |        --        |    否    |

> 另外，自己也可以自由配置其他参数，会在点击、拖拽等其他事件中暴露出来

### 2.2 ganttOptions 配置说明

|       options        |                         说明                          |   类型   |       默认值       |                       单位                        |
| :------------------: | :---------------------------------------------------: | :------: | :----------------: | :-----------------------------------------------: |
|     column_width     |                        列宽度                         |  Number  |         30         |                        px                         |
|  bar_corner_radius   |                     任务条圆角率                      |  Number  |         3          |                        px                         |
|      view_mode       |                       渲染模式                        |  String  |        Day         | (暂时只支持 Day，后续支持 Year, Month, Week, Day) |
|  custom_popup_html   |                     任务提示 html                     | Function | (参数为 task 对象) |
|       language       |                         语言                          |  String  |         en         |                   (支持 en, zh)                   |
|      headerFix       |                     是否固定表头                      | Boolean  |        true        |
|       bg_full        |                   是否背景默认填满                    | Boolean  |        true        |
| browserScrollPrevent |                是否默认阻止浏览器滚动                 | Boolean  |        true        |
|   on_parent_scroll   | 控制父级 dom 滚动事件，搭配 browserScrollPrevent 使用 | Function |                    |
|    on_view_change    |                  切换 view_mode 事件                  | Function |                    |
|   on_before_scroll   |                    钩子 - 滚动开始                    | Function |                    |
|   on_after_scroll    |                    钩子 - 滚动结束                    | Function |                    |
|   on_taskbar_click   |                    点击任务条事件                     | Function |                    |
| on_highlight_change  |                     高亮改变事件                      | Function |                    |

## 3 特殊说明

2. 任务如果不完整时间区间的，则不展示，支持动态点击生成
3. 任务如果没有提供时分秒，则增加 24 h，满足结束日当天满天
4. 日期格式： `2020-7-23 13:24:15`
5. task dependencies 支持格式：id 数组集合，id 字符串以 `,` 分隔
6. 日期刻度支持：年、月、周、日、半天、1/4 天
7. 甘特图整体跨度：取任务最先开始，最后结束时间，日 - 前加 2 天后加 7 天，月 - 前后加一年，年 - 前后加 2 年
8. 拖拽改变时间说明：支持整体拖动区间、改变开始时间、改变结束时间，但是拖动只能在当前可视区域内拖动

## 4 本地开发调试步骤

```javascript
npm i parcel -g

parcel index.html
```

## 5 布局实现思路

1. 分组绘制：表头、表体、bar、detail，方便整体滚动、事件绑定
2. 滚动：滚动对应的 group，背景不需要滚动，需要位移的有表头、表体、bar、detail 等分组
3. 位置计算：由 `日期数 * column_width` 表示整体距离，每条线、文字、bar 都是根据 `date num * column_width` 来计算
4. **canvas 绘制层级（zlevel）说明：头部 3，内容区背景和线 1，bar 为 2**
