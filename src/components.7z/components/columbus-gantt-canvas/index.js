export { default } from './src/index';
 
export {
  ganttCanvas,
  ganttTable,
  ganttVue
}  from './src/index';