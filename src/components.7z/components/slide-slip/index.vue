<template>
  <div
    class="sider-right bug-content-box scrollbal-common work-item-box-slider-box"
    :class="{
      'coteam-slide-right-active': slideShow,
      'sider-right-show': slideShow && !leftSliderEditable,
      [localClass]: true,
      'slider-right__body sub-app-coteam': popperAppendToBody,
    }"
    ref="side"
    :style="{ minHeight: screenHeight }"
    :id="localClass"
  >
    <slot name="task"></slot>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * author: heyunjiang
 * time: 2019.4.3
 */
import { getRootEl } from '@/utils'
export default {
  props: {
    show: {
      type: Boolean,
      default: false,
    },

    beforeClose: {
      type: Function,
      desc:
        '关闭前的钩子，如果要做关闭前的判断，成功时可以调用 callback 来关闭滑块，也可以直接控制 show 来关闭滑块',
      required: false,
    },

    afterClose: {
      type: Function,
      desc: '关闭后的钩子',
      required: false,
    },

    screenHeight: String,
    leftSliderEditable: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否支持左侧内容可以响应',
    },
    popperAppendToBody: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否挂载到body',
    },
  },

  provide() {
    return {
      slide: this,
    }
  },

  data() {
    return {
      localClass: 'coteam-slide-' + this._uid,
      beforeBodyClass: '',
      slideShow: false, // 滑块是否关闭
      bindEventDom: getRootEl() || document.documentElement,
      canCloseSlider: false, // 是否可以关闭 slider ，搭配 click mousedown 使用
    }
  },
  mounted() {
    document.body.className = document.body.className.replace(
      /[modal\-open]/g,
      '',
    )
    if (this.popperAppendToBody) {
      const body = document.querySelector('body')
      body?.appendChild(this.$el)
    }
  },
  watch: {
    // 为什么需要从 show 到 slideShow 的中转，因为一个是 props ，一个是 data
    show: function(newName) {
      this.slideShow = newName
    },
    slideShow: function(newName) {
      this.$nextTick(() => {
        if (newName) {
          this.handlerSileShow()
        } else {
          this.handlerSileHide()
        }
      })
    },
  },

  beforeDestroy() {
    let that = this
    this.bindEventDom.removeEventListener(
      'mousedown',
      that.handerSliderMouseDown,
    )
    document.removeEventListener('keydown', that.handerSliderMouseDown)
    this.bindEventDom.removeEventListener('click', that.handerSliderClose)
    document.removeEventListener('keyup', that.handlerEscSliderClose)

    const slideDom = document.querySelector('#' + this.localClass)

    if (slideDom && this.popperAppendToBody) {
      const body = document.querySelector('body')
      body?.removeChild(slideDom)
    }
  },
  methods: {
    // 展开滑块
    handlerSileShow() {
      // 滚动条
      this.beforeBodyClass = document.body.className.replace(
        /[modal\-open]/g,
        '',
      )
      document.body.className = document.body.className + ' modal-open'
      // 偏移
      this.$refs.side.style.right = '0px'
      // 绑定事件
      let that = this
      this.bindEventDom.removeEventListener(
        'mousedown',
        that.handerSliderMouseDown,
      )
      document.removeEventListener('keydown', that.handerSliderMouseDown)
      this.bindEventDom.removeEventListener('click', that.handerSliderClose)
      document.removeEventListener('keyup', that.handlerEscSliderClose)
      setTimeout(() => {
        this.bindEventDom = getRootEl()
        this.bindEventDom.addEventListener(
          'mousedown',
          that.handerSliderMouseDown,
        )
        document.addEventListener('keydown', that.handerSliderMouseDown)
        this.bindEventDom.addEventListener('click', that.handerSliderClose)
        document.addEventListener('keyup', that.handlerEscSliderClose)
      })
    },
    // 关闭滑块
    handlerSileHide() {
      document.body.className = this.beforeBodyClass
      this.$refs.side.style.right = '-71%'
      // 关闭事件
      let that = this
      this.bindEventDom.removeEventListener(
        'mousedown',
        that.handerSliderMouseDown,
      )
      document.removeEventListener('keydown', that.handerSliderMouseDown)
      this.bindEventDom.removeEventListener('click', that.handerSliderClose)
      document.removeEventListener('keyup', that.handlerEscSliderClose)
      this.$nextTick(() => {
        this.afterCloseSlide()
      })
    },
    // 事件 mousedown handle ，绑定到 documentElement 上的事件，点击任意位置关闭
    handerSliderMouseDown(e) {
      if (
        (this.$refs.side &&
          this.$refs.side.contains(e.target) &&
          !/sider-right-show/.test(e.target.className)) || 
        this.isClickMenu(e) || e.target.className === 'el-link--inner'
      ) {
        this.canCloseSlider = false
      } else {
        !this.leftSliderEditable && e.stopPropagation()
        this.canCloseSlider = true
      }
    },
    // 解决点击menu导航栏无法跳转路由的问题。
    // 点击导航栏时应该跳转路由，直接走destory逻辑，就不再手动改各种状态了。
    // 因为改状态时会改url，在微前端应用中会触发新的路由跳转，把menu的路由跳转覆盖了。
    isClickMenu(e) {
      const eventPathList = e.path || []
      return eventPathList.some(pathTarget => {
        return pathTarget.className?.includes('el-menu-item')
      })
    },
    // 事件 handle ，绑定到 documentElement 上的事件，点击任意位置关闭
    handerSliderClose() {
      if (!this.canCloseSlider) {
        return false
      } else {
        this.canCloseSlider = false
      }
      try {
        if (this.beforeClose) {
          this.beforeClose({
            cb: () => {
              this.slideShow = false
              this.$emit('update:show', false)
            },
          })
        } else {
          this.slideShow = false
          this.$emit('update:show', false)
        }
      } catch (_) {}
    },
    handlerEscSliderClose(e) {
      if (e.keyCode === 27) {
        if (!this.canCloseSlider) {
          return false
        } else {
          this.canCloseSlider = false
        }
        try {
          if (this.beforeClose) {
            this.beforeClose({
              cb: () => {
                this.slideShow = false
                this.$emit('update:show', false)
              },
            })
          } else {
            this.slideShow = false
            this.$emit('update:show', false)
          }
        } catch (_) {}
      }
    },
    // 关闭弹窗后，去除url上的需求id，bugId,taskId
    afterCloseSlide() {
      /**
       * 解决线上问题：解决办法比较hack,没有找到其他更好的办法，通过判断关闭弹窗后是否还有打开的右侧弹窗来实现的
       * 在度量，日历，管理看板页面打开缺陷右侧弹窗，然后点击转需求，在关闭转需求的右侧弹窗会引发两个问题:
       *  1. url地址不应该有变化，但是url地址的projectId和工作项id不见了
       *  2. 在前面的基础上，在点击转需求，所属项目会变为下拉框，可选择的状态，应该是只读状态
       */
      const workItemSliderList = Array.from(
        document.querySelectorAll('.work-item-box-slider-box'),
      )
      const sliderRightValue = workItemSliderList.map(item => item.style.right)
      !sliderRightValue.includes('0px') && this.urlQueryControl()
      this.afterClose && this.afterClose()
    },
    /**
     * 关闭右侧弹窗时，对url参数进行统一管理控制
     * 1、项目下默认有项目id，其他都是默认没有项目id
     * 2、关闭缺陷弹窗时，
     */
    urlQueryControl() {
      let urlQuery = this.$getUrlParams()
      const bugId = urlQuery.bugId
      const requireId = urlQuery.requireId
      const taskId = urlQuery.taskId

      if (this.noShouldExistProjectId()) {
        delete urlQuery.projectId
        delete urlQuery.bugId
        delete urlQuery.requireId
        delete urlQuery.taskId
      }

      if (bugId) {
        urlQuery = this.deleteBugIdOrProjectId(urlQuery)
      }
      if (requireId) {
        urlQuery = this.deleteRequireIdOrProjectId(urlQuery)
      }
      if (taskId) {
        urlQuery = this.deleteTaskIdOrProjectId(urlQuery)
      }

      let search = []
      for (const [key, val] of Object.entries(urlQuery)) {
        search.push(`${key}=${val}`)
      }
      search = search.join('&')
      const location = window.location
      window.history.replaceState(
        null,
        null,
        `${location.origin}${location.pathname}?${search}`,
      )
      // this.$router.replace({
      //   path: this.$route.path,
      //   query: { ...this.$route.query, ...urlQuery },
      // })
    },
    // 项目下原本url上有项目id，不应该去掉项目id，在这里做一个判断
    noShouldExistProjectId() {
      return this.$route.meta?.notUnderProject
    },
    // 在工作台，度量，日历

    // 关闭右侧弹框时，需要去去除缺陷bugId
    deleteBugIdOrProjectId(urlQuery) {
      let { path, meta } = this.$route
      let bugListMode = this.$store.state.bugManage.defectDisplayMode
      //  关闭右侧弹框时，需要去除,1、缺陷的列表模式也需要去掉bugId, 2、其他关闭右侧弹窗需要去除bugId的都可以在路由中配置
      if (
        (path == '/bug/list' && bugListMode) ||
        meta.deleteSlideSlipDugId ||
        path === '/'
      ) {
        delete urlQuery.bugId
      }
      return urlQuery
    },
    // 关闭右侧弹框时，需要去去除需求requireId
    deleteRequireIdOrProjectId(urlQuery) {
      delete urlQuery.requireId
      return urlQuery
    },
    // 关闭右侧弹框时，需要去去除任务taskId
    deleteTaskIdOrProjectId(urlQuery) {
      delete urlQuery.taskId
      return urlQuery
    },
  },
}
</script>
<style lang="scss">
.slider-right__body {
  @import '@/style/project/ProjectCommon';
  .fl {
    float: left;
  }

  .fr {
    float: right;
  }

  .flex-right {
    display: flex;
    justify-content: flex-end;
  }

  .icon {
    width: 1em;
    height: 1em;
    vertical-align: -0.15em;
    fill: currentColor;
    overflow: hidden;
  }

  .ellipsis-pure {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  // 通用-状态盒子-列表
  .statusbox-list-common {
    max-width: 100%;
    @include no-wrap;
    box-sizing: border-box;
    font-size: $font-size-small;
    cursor: pointer;
    color: var(--color);
    border: 1px solid var(--color);
    border-radius: 4px;
    display: inline-block;
    padding: 3px 12px;
    font-size: 12px;
    line-height: 16px;
    &:hover {
      color: #fff;
      background-color: var(--color);
    }
  }

  .filelist-box {
    .filelist-item {
      margin: 0;
      padding: 10px 0;
      overflow: hidden;
      .filelist-item-top {
        font-size: 0;
        height: 18px;
        line-height: 18px;
        padding-left: 35px;
        .filelist-item-top-left {
          display: inline-block;
          width: calc(100% - 90px);
          font-size: 16px;
          color: $color-font-inactive-common;
          cursor: pointer;
        }
        .filelist-item-top-right {
          display: none;
          width: 80px;
          font-size: 14px;
          vertical-align: text-bottom;
          margin-left: 10px;
          margin-bottom: 2px;
          i {
            cursor: pointer;
          }
        }
      }
      .filelist-item-bottom {
        padding-left: 5px;
        color: #797777;
        font-size: 10px;
      }
      &:hover {
        .filelist-item-top-right {
          display: inline-flex;
          justify-content: space-around;
          i:hover {
            color: $color-font-active-common;
          }
        }
      }
    }
  }
}

.cursor-pointer {
  cursor: pointer;
}
</style>
<style rel="stylesheet/css" scoped>
.sider-right {
  width: 68%;

  background-color: #fff;

  position: fixed;
  z-index: 1999;
  right: -71%;
  overflow: hidden;
  transition: all 0.3s cubic-bezier(1, 0.5, 0.8, 1);

  overflow-y: auto;
  box-shadow: 0 1px 3px #ddd, inset 0 0 3px var(--color-white, #fff);
  border-left: 1px solid #dcdee3;
  bottom: 0;
  top: 0;
}
.sider-right-show:before {
  content: '';
  width: 32%;
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 1098;
}
/* .sider-right,.sider-right-show:before {
      z-index: 2222;
    } */
</style>
