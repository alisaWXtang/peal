<template>
  <div>
    <el-dialog
      :title="dialogData.title"
      :visible.sync="dialogData.show"
      :width="dialogData.width ? dialogData.width : '1000px'"
      id="metricDialogSelected"
      :modal-append-to-body="false"
      :modal="false"
    >
      <slot></slot>
    </el-dialog>
    <div class="dialog-metric-bg" v-if="dialogData.show"></div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 公共对话框
 * @desc
 * @author panhui
 * @date
 */
export default {
  name: 'FooterFilter',
  components: {},
  mixins: [],
  props: {
    dialogData: {
      type: Object,
      required: false,
      desc: '弹窗相关操作',
    },
  },

  data() {
    return {
      dialogFormVisible: false,
      title: '',
    }
  },
  computed: {},
  watch: {
    // dialogData:{
    //   handler: function (newVal, oldVal) { /* ... */ },
    //   deep: true
    // }
  },
  created() {},
  methods: {},
}
</script>
<style lang="scss">
.metric-dialog-tr {
  cursor: pointer;
}
#metricDialogSelected {
  z-index: 1090 !important;
}
//  #metricDialogSelected+.v-modal{
//   z-index: 1080 !important;
// }
.dialog-metric-bg {
  width: 100vw;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  z-index: 1080;
  background: rgba(0, 0, 0, 0.5);
}
</style>
