<template>
  <div class="submit-box">
    <el-table
      :data="tableData.list"
      class="tableButton"
      max-height="600"
      border
      style="width: 100%"
    >
      <el-table-column
        prop="commitId"
        label="CommitId"
        show-overflow-tooltip
        width="100"
      >
        <template slot-scope="scope">
          <span
            @click="handleClickl(scope.row.gitCommitUrl)"
            type="text"
            style="color: #409EFF;"
            class="cp"
            >{{ scope.row.shortCommitId }}</span
          >
        </template>
      </el-table-column>
      <el-table-column
        prop="commitMsg"
        :label="$t('提交日志')"
        show-overflow-tooltip
        min-width="80"
      >
      </el-table-column>
      <el-table-column
        prop="commitUserName"
        :label="$t('仓库及分支')"
        show-overflow-tooltip
        min-width="65"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.repoName }} /{{ scope.row.branch }} </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="commitUserName"
        :label="$t('提交者')"
        show-overflow-tooltip
        width="140"
      >
        <template slot-scope="scope">
          <span
            >{{ scope.row.commitUserName }}({{ scope.row.commitUser }})
          </span>
        </template>
      </el-table-column>

      <el-table-column
        prop="commitTime"
        :label="$t('提交时间')"
        width="160"
        show-overflow-tooltip
      >
      </el-table-column>
    </el-table>
    <!-- 分页 -->
    <div class="block" align="center" style="margin-top: 20px;">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="tableData.pageNum"
        :page-sizes="[20, 50, 100]"
        :page-size="tableData.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="tableData.total"
      ></el-pagination>
    </div>
    <!-- <a :href="item.gitCommitUrl" target="_blank" v-for="(item,index) in value" :key="index">
      <div class="submit-recod-line" >
        <div class="submit-recod-top">
            <div class="submit-recod-title submit-recod-ellipsis" :title="item.commitMsg">{{item.commitMsg}}</div>
          <div class="submit-recod-person">{{item.commitUserName}}({{item.commitUser}})</div>
        </div>
        <div class="submit-recod-bottom">
          <div class="submit-recod-branch">{{item.repoName}}/{{item.branch}}</div>
          <div class="submit-recod-time">{{item.commitTime}}</div>
          <div class="submit-recod-version"><i class="iconfont icon-git-commit"></i>&nbsp;{{item.shortCommitId}}</div>
        </div>
      </div>
    </a>
    <div class="load-more" @click="loadMore">{{isMore?'查看更早数据':''}}</div> -->
  </div>
</template>

<script>
import { i18n } from '@/i18n'
export default {
  name: 'SubmitRecod',
  props: {
    tableData: {
      type: [Array, Object],
      required: true,
    },

    loadMoreCallback: Function, // 加载更多
    isMore: {
      type: Boolean, // 是否有更多数据
      default: true,
    },
  },

  data() {
    return {
      filterInfo: {
        pageNum: 1,
        pageSize: 20,
      },

      //分页信息
    }
  },
  computed: {},
  created() {},
  methods: {
    loadMore() {
      this.isMore && this.loadMoreCallback()
    },
    //分页
    handleSizeChange(val) {
      this.filterInfo.pageSize = val
      this.$emit('updata', this.filterInfo)
    },
    handleCurrentChange(val) {
      this.filterInfo.pageNum = val
      this.$emit('updata', this.filterInfo)
    },
    // 点击跳转gitlab
    handleClickl(data) {
      window.open(data, '_blank')
    },
  },
}
</script>

<style lang="scss" scoped>
.submit-comment {
  color: #333;
  display: inline-block;
  padding-top: 15px;
  font-size: 14px;
  font-family: PingFang SC, '\5FAE\8F6F\96C5\9ED1', Arial;
  color: #303030;
  font-weight: 400;
}
.submit-comment-b {
  color: #909090;
  display: inline-block;
  padding-top: 2px;
  font-size: 12px;
}
.submit-box {
  .submit-recod-line {
    width: 100%;
    height: 68px;
    border-bottom: 1px solid #d6d6d6;
    position: relative;
    .submit-recod-top {
      overflow: hidden;
      .submit-recod-title {
        @extend .submit-comment;
        /* position:absolute; */
      }
      .submit-recod-person {
        @extend .submit-comment;
        position: absolute;
        /*left: 78%;*/
        right: 12%;
      }
      .submit-recod-ellipsis {
        //单行文本溢出
        overflow: hidden;
        text-overflow: ellipsis; //文本溢出显示省略号
        white-space: nowrap; //文本不会换行（单行文本溢出）
        width: 500px;
      }
    }
    .submit-recod-bottom {
      overflow: hidden;
      .submit-recod-branch {
        @extend .submit-comment-b;
      }
      .submit-recod-time {
        @extend .submit-comment-b;
        position: absolute;
        /*left: 78%;*/
        right: 12%;
      }
      .submit-recod-version {
        @extend .submit-comment-b;
        position: absolute;
        right: 2%;
      }
    }
  }
  .load-more {
    /* display: inline-block; */
    /* margin-left: 120px; */
    margin-top: 10px;
    text-align: center;
    /* transform: translateX(50%); */
    color: $color-gray-common;
    font-size: $font-size-medium;
    cursor: pointer;
  }
}
.tableButton {
  /deep/ .el-table__empty-block {
    min-height: 90px;
  }
}
</style>
