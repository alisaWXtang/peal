<template>
  <div class="back-top-box" v-show="boxShow" @click="backTop">
    <i class="el-icon-arrow-up"></i>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 一键回到顶端
 * @desc 1. 默认页面滚动向上 2. 支持自定义向上属性
 * @author heyunjiang
 * @date
 */
export default {
  name: 'BackTop',
  components: {},
  mixins: [],
  props: {
    show: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否展示',
    },

    customedDom: {
      type: [HTMLHtmlElement, HTMLSpanElement, HTMLDivElement],
      required: false,
      desc: '自定义目标滚动元素节点',
    },
  },

  data() {
    return {
      targetElementScrollTopEnough: false,
    }
  },
  computed: {
    boxShow() {
      return this.show && this.targetElementScrollTopEnough
    },
    eventTarget() {
      return this.customedDom || document
    },
    domTarget() {
      return this.customedDom || document.documentElement
    },
  },

  watch: {
    customedDom() {
      this.initScrollEvent()
    },
  },

  mounted() {
    this.initScrollEvent()
  },
  beforeDestroy() {
    this.removeScrollEvent()
  },
  methods: {
    // 事件监听初始化
    initScrollEvent() {
      this.removeScrollEvent()
      this.eventTarget.addEventListener('scroll', this.scrollHandle)
    },
    // 移除事件监听
    removeScrollEvent() {
      this.eventTarget.removeEventListener('scroll', this.scrollHandle)
    },
    // 浏览器滚动事件监听，自定义点击则不执行此函数
    scrollHandle() {
      if (this.domTarget.scrollTop > 100) {
        this.targetElementScrollTopEnough = true
      } else {
        this.targetElementScrollTopEnough = false
      }
    },
    // 点击回到顶部按钮
    backTop() {
      this.domTarget.scrollTop = 0
    },
  },
}
</script>
<style lang="scss" scoped>
@keyframes colorChange {
  from {
    color: #ccc;
    // box-shadow: 2px 4px 4px #ccc;
  }
  to {
    color: #307fe2;
    // box-shadow: 1px 1px 4px #ccc;
  }
}
.back-top-box {
  position: fixed;
  display: inline-block;
  box-sizing: border-box;
  bottom: 50px;
  right: 50px;
  height: 50px;
  line-height: 50px;
  width: 50px;
  // border: 1px solid #ccc;
  border-radius: 3px;
  box-shadow: 2px 4px 4px #ccc;
  cursor: pointer;
  z-index: 9999;
  font-size: 30px;
  text-align: center;
  color: #ccc;
  animation: colorChange 2s alternate-reverse infinite;
  &:hover {
    background: #f3f5f2;
  }
}
</style>
