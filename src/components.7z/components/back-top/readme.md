# 一键回到顶端

time: 2019.7.10  
author: heyunjiang

## 说明

通用组件，一键回到顶端

1. 位于网页右下角，采用 fixed 定位
2. 当网页没有滚动条或者 scrollTop 距离大于 100 时，才展示出来
