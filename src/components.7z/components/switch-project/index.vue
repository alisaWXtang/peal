<template>
  <el-dropdown
    size="medium"
    trigger="click"
    @command="changeProjectActive"
    @visible-change="visibleChange"
    placement="bottom-start"
    class="project-dropdown"
  >
    <template v-if="!isLink">
      <co-button
        suffix-icon="co-icon-arrow-down"
        v-show="projectName"
        class="dropdown-button"
      >
        {{ projectName }}
      </co-button>
    </template>
    <template v-else>
      <span v-show="projectName" class="co-dropdown-link">
        <span :title="projectName" class="project-name">{{ projectName }}</span
        ><i class="el-icon-caret-bottom" style="margin-left: 8px"></i>
      </span>
    </template>
    <el-dropdown-menu slot="dropdown" class="dropdown-content">
      <div class="dropdown-box">
        <co-row>
          <co-input
            v-model="filterValue"
            ref="filterInput"
            size="small"
            clearable
            :placeholder="$t('输入项目名称过滤')"
            prefix-icon="co-icon-search"
            class="search-filter-input"
          >
          </co-input>
        </co-row>
        <div class="select-dropdown-container">
          <div
            v-for="(item, key) in ProjectListAllFilter"
            :key="key"
            class="select-dropdown-item"
          >
            <p
              class="project-list-label"
              v-if="item.id === 'uncompleted' || item.id === 'completed'"
            >
              {{ item.name }}
            </p>
            <template v-else>
              <el-dropdown-item
                :command="item.id"
                :class="{
                  'project-select-item': item.id == projectId,
                }"
                class="dropdown-menu-item"
              >
                <span>{{ item.name }}</span>
                <el-tooltip
                  v-if="item.projectType"
                  effect="dark"
                  placement="top-start"
                >
                  <div slot="content">
                    {{ $t('示例项目仅做示例演示') }}，<br />{{
                      $t('里面的数据不会出现在TT每日提醒里')
                    }}。
                  </div>
                  <span class="demoProj">{{ $t('示例') }}</span>
                </el-tooltip>
              </el-dropdown-item>
            </template>
          </div>
        </div>
      </div>
      <div class="all-project-wrap" @click="jumpProjectList">
        <p class="item-divided-text">
          <span>{{ $t('全部项目') }}</span>
          <i class="co-icon-arrow-right"></i>
        </p>
      </div>
    </el-dropdown-menu>
  </el-dropdown>
</template>

<script>
import { windowOpenUrl, getRouterUrl } from '@/utils/sub-app-util'
import { filterStorage } from '@/utils'
export default {
  name: 'SwitchProject',
  props: {
    isLink: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      filterValue: '',
    }
  },
  computed: {
    projectName() {
      return this.$store.state.projectName
    },
    ProjectListAll() {
      return this.$store.state.pf.ProjectListAll
    },
    ProjectListAllFilter() {
      if (this.filterValue.length === 0) {
        return this.getProjectSortList(this.ProjectListAll)
      }
      const projectFilterList = this.ProjectListAll.filter(
        item => item.name.indexOf(this.filterValue) !== -1,
      )
      return this.getProjectSortList(projectFilterList, true)
    },
    projectId() {
      return this.$route.query.projectId
    },
  },
  methods: {
    changeProjectActive(projectId) {
      // 切换项目，切换url
      this.$store.dispatch({
        type: 'clearAssignUserList',
      })
      // 如果是迭代页 跳转至迭代列表
      let path = this.$route.path
      if (path === '/sprint/detail' || path === '/sprint/plan') {
        path = '/sprint/list'
      }
      if (path === '/report/edit') {
        path = '/report'
      }
      if (projectId !== +this.$getUrlParams().projectId) {
        filterStorage.clearAll()
      }
      if (projectId) {
        localStorage.setItem('projectId', projectId)
        this.$router.push({
          path,
          query: {
            projectId: projectId,
          },
        })
      } else {
        this.$router.push({
          path: '/project/list',
        })
      }
    },
    visibleChange(show) {
      if (show) {
        this.$nextTick(() => {
          this.$refs.filterInput.focus()
        })
      }
    },
    jumpProjectList() {
      this.$router.push({
        path: '/project/list',
      })
    },
    // 给项目列表添加分类信息
    getProjectSortList(projectList, filter = false) {
      const activeData = projectList.filter(project => !project.completed) // 进行中
      const inactiveData = projectList.filter(project => project.completed) // 已结束
      let list = []
      // 筛选时有已结束没有进行中判断
      if (!activeData.length && inactiveData.length && filter) {
        list = [
          { name: this.$t('已结束'), id: 'completed', value: 'completed' },
          ...inactiveData,
        ]
      } else {
        list = [
          { name: this.$t('进行中'), id: 'uncompleted', value: 'uncompleted' },
          ...activeData,
        ]
        if (inactiveData.length) {
          list = [
            ...list,
            { name: this.$t('已结束'), id: 'completed', value: 'completed' },
            ...inactiveData,
          ]
        }
      }
      return list
    },
  },
  mounted() {
    if (this.ProjectListAll.length === 0) {
      this.$store.dispatch({ type: 'getProjectListAll' })
    }
  },
}
</script>

<style lang="scss" scoped>
.dropdown-button {
  border: 1px solid #eeeeee;
}
.dropdown-content {
  .dropdown-box {
    position: relative;
    max-height: 500px;
    overflow-y: auto;
    box-sizing: border-box;
  }
  .all-project-wrap {
    border-top: 1px solid #dcdfe6;
    .item-divided-text {
      padding: 8px 23px 0 23px;
      line-height: 28px;
      &:hover {
        cursor: pointer;
      }
    }
  }
  .select-dropdown-item {
    .dropdown-menu-item {
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      .demoProj {
        font-size: 12px;
        color: $demoProListColor;
        background: $demoProBackground;
        padding: 2px 6px;
        border-radius: 4px;
        margin-left: 5px;
        border: $demoProListBor;
      }
    }
  }
}
</style>
