export const latestEditPropKeys = [
  'projectId',
  'workItemId',
  'workItemType',
  'commentsource',
] // PersonEdit 组件 props
export const latestEditInfoKeys = ['comment', 'informant'] // PersonEdit 组件 store 的评论信息
