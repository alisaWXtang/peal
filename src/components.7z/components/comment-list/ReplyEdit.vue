<!--
 * @Description: 回复编辑框
 * @Autor: zhangyun
 * @Date: 2020-07-17 09:26:56
 * @LastEditors: zhangyun
 * @LastEditTime: 2020-08-19 17:01:55
-->
<template>
  <div class="reply-edit">
    <select-filter
      v-model="informant"
      multiple
      :placeholder="$t('通知人')"
      style="width: 400px"
      :is-assign-user="true"
      :select-list="assignUserData"
      @remove-tag="removeTag"
    ></select-filter>
    <div class="top-tiny">
      <tiny-mce
        ref="tinyMce"
        :value="comment"
        :min-heigt="150"
        style="margin-top: 15px;"
        @watch="editComentLister($event)"
      ></tiny-mce>
    </div>
    <div class="mt15">
      <el-button type="primary" @click="onSubmit">{{ $t('回复') }}</el-button>
      <el-button @click="onCloseComment">{{ $t('取消') }}</el-button>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
import { getUserList } from '@/service/project'
import { addReply } from '@/service/comment'

const TinyMce = () => import('@/components/tinymce')

export default {
  name: 'ReplyEdit',
  components: {
    TinyMce,
  },

  props: {
    workItemType: {
      type: [Number, String],
      desc: '类型，需求-1， 任务-2， 缺陷-3',
    },

    workItemId: {
      type: [Number, String],
      desc: 'id',
    },

    projectId: {
      type: [Number, String],
    },

    commentsource: {
      type: String,
      required: false,
      desc: '引用地方来源，工作项详情 -> workItem, 评审 -> review',
    },

    replyPerson: {
      type: [String, Number],
      desc: i18n.t('默认回复人'),
    },

    replyId: {
      type: [String, Number],
      desc: '回复Id',
    },
  },

  data() {
    return {
      assignUserData: [], //项目内所有成员
      informant: [], //通知人
      comment: '', //评论数据
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      await this.getAssignUserList()
      this.informant = [this.replyPerson]
    },
    //  处理人列表
    requestWrokItemAssignUserList() {
      return getUserList({
        projectId: this.projectId,
        workItemType: this.workItemType,
      })
    },
    //获取处理人列表
    async getAssignUserList() {
      this.loading = true
      let result = {}
      try {
        result = await this.requestWrokItemAssignUserList()
      } finally {
        this.loading = false
      }

      if (result.status === 200) {
        this.assignUserData = result.data.map(item => {
          const disabled = item.userId === this.replyPerson
          return {
            ...item,
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
            disabled: disabled,
          }
        })
      }
    },
    // 编辑回复内容
    editComentLister(data) {
      this.comment = data
    },
    // 提交回复
    requestWorkItemSubmitReply() {
      const obj = {
        workItemType: this.workItemType,
        workItemId: this.workItemId,
        comment: this.comment.trim(),
        projectId: this.projectId,
        workNumberIds: this.informant,
        workItemUrl: window.location.href,
        replyId: this.replyId,
      }

      return addReply(obj)
    },
    // 发表
    async onSubmit() {
      if (!this.comment.trim()) {
        this.$message({ type: 'warning', message: i18n.t('内容不能为空') })
        return
      }
      this.loading = true
      let result = { status: 0 }
      try {
        result = await this.requestWorkItemSubmitReply()
      } finally {
        this.loading = false
        this.comment = ''
        this.informant = [this.replyPerson]
      }
      if (result.status === 200) {
        this.$emit('updata')
        this.$emit('closeEdit', false)
      }
    },
    // 取消
    onCloseComment() {
      this.$emit('closeEdit', false)
    },
    removeTag(val) {
      if (val === this.replyPerson) {
        this.informant.unshift(this.replyPerson)
      }
    },
  },
}
</script>
