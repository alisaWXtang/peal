<template>
  <div
    v-loading="loading"
    class="comment-submit"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <div v-if="!visiable">
      <el-button type="primary" plain @click="onShowComment">{{
        $t('发表评论')
      }}</el-button>
    </div>
    <div v-else class="mt15">
      <global-user-select
        v-if="feedback"
        v-model="informant"
        multiple
        :placeholder="$t('通知人')"
        :max-count="50"
      ></global-user-select>
      <select-filter
        v-else
        v-model="informant"
        :is-assign-user="commentsource === 'workItem'"
        :assign-user-choice-focus="false"
        multiple
        :placeholder="$t('通知人')"
        style="width: 400px"
        :select-list="assignUserData"
        @focus="fous"
        @blur="blur"
        @change="informantFunc"
      ></select-filter>
      <div class="top-tiny">
        <el-input
          v-if="feedback && feedback.source == 1"
          v-model.trim="comment"
          type="textarea"
          show-word-limit
          :rows="4"
          :maxlength="200"
          style="margin-top:20px;"
        ></el-input>
        <tiny-mce
          v-else
          :value="comment"
          :min-heigt="150"
          style="margin-top: 15px;"
          @watch="editComentLister($event)"
        ></tiny-mce>
      </div>
      <div id="bottom-tiny" @click="fousClick"></div>
      <div class="mt15">
        <el-button type="primary" @click="onSubmitComment">{{
          $t('发表')
        }}</el-button>
        <el-button @click="onCloseComment">{{ $t('取消') }}</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import GlobalUserSelect from '@/components/global-user-select'
import ACTIONCONSTVARLIABLE from '@/store/action-types'
import { componentsMutation } from '@/store/mutation-types'
import { latestEditPropKeys, latestEditInfoKeys } from './config'
import { getUserList } from '@/service/project'
import { commentAdd } from '@/service/comment'
import { commentCreate } from '@/service/operation'

const TinyMce = () => import('@/components/tinymce')
export default {
  name: 'PersonEdit',
  components: {
    TinyMce,
    GlobalUserSelect,
  },
  props: {
    workItemType: {
      type: [Number, String],
      desc: '类型，需求-1， 任务-2， 缺陷-3',
    },
    workItemId: {
      type: [Number, String],
      desc: 'id',
    },
    projectId: {
      type: [Number, String],
    },
    feedback: {
      type: Object,
      desc: '反馈相关数据',
    },
    commentsource: {
      type: String,
      required: false,
      desc: '引用地方来源，工作项详情 -> workItem, 评审 -> review',
    },
    submitExtraData: {
      type: Object,
      required: false,
      desc: '提交评论额外数据',
    },
    commentUserApi: {
      type: Object,
      required: false,
      desc: '处理人下拉框api',
    },
    commentUserExtraData: {
      type: Object,
      required: false,
      desc: '处理人下拉框额外参数',
    },
  },
  data() {
    return {
      loading: false,
      visiable: false,
      assignUserData: [], //项目内所有成员
      informant: [], //通知人
      comment: '', //评论数据
    }
  },
  watch: {
    workItemId() {
      this.comment = ''
      this.informant = []
    },
    feedback: {
      handler: function() {
        this.comment = ''
        this.informant = this.feedback.defaultNoticePerson || []
      },
      deep: true,
    },
  },
  mounted() {
    !this.feedback && this.assignUsersList()
  },
  methods: {
    getLatestEditStoreInfo() {
      const storeInfo = {}
      for (let prop of latestEditPropKeys.concat(latestEditInfoKeys)) {
        storeInfo[prop] = this[prop]
      }
      return storeInfo
    },
    restoreCommentInfo() {
      const latestEditInfo = this.$store.state.commentList.latestEditInfo
      let canRestore = true
      for (let prop of latestEditPropKeys) {
        if (this[prop] !== latestEditInfo[prop]) {
          canRestore = false
          break
        }
      }
      if (canRestore) {
        for (let prop of latestEditInfoKeys) {
          this[prop] = latestEditInfo[prop]
        }
      }
    },
    fousClick() {
      document.getElementById('bottom-tiny').style.display = 'none'
    },
    fous() {
      document.getElementById('bottom-tiny').style.display = 'block'
    },
    blur() {
      document.getElementById('bottom-tiny').style.display = 'block'
    },
    // 工作项 -> 处理人列表
    requestWrokItemAssignUserList(query) {
      return getUserList({
        projectId: this.projectId,
        query: query ? query : '',
        workItemType: this.workItemType,
      })
    },
    // 评审 -> 处理人列表
    requestReviewAssignUserList() {
      // return window.$http.get(this.commentUserApi, this.commentUserExtraData)
    },
    async assignUsersList(query) {
      this.loading = true
      let result = {}
      try {
        if (this.commentsource === 'workItem') {
          result = await this.requestWrokItemAssignUserList(query)
        } else {
          result = await this.requestReviewAssignUserList()
        }
      } finally {
        this.loading = false
      }

      if (result.status === 200) {
        this.assignUserData = result.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
          }
        })
      }
    },
    // 显示评论编辑内容
    onShowComment() {
      this.countlyLog('project_workItem_publishComment')
      this.visiable = true
      this.feedback &&
        (this.informant = this.feedback.defaultNoticePerson || [])
      if (this.visiable) {
        this.restoreCommentInfo()
      }
    },
    // 隐藏评论编辑内容
    onCloseComment() {
      this.comment = ''
      this.informant = []
      this.visiable = false
      this.$store.commit(
        componentsMutation.UPDATE_COMPONENT_COMMENT_LIST_LATEST_EDIT_INFO,
        this.getLatestEditStoreInfo(),
      )
    },
    //评论通知人搜索
    remoteMethod(query) {
      this.query = query
      this.assignUsersList(query)
    },
    informantFunc() {
      this.$store.commit(
        componentsMutation.UPDATE_COMPONENT_COMMENT_LIST_LATEST_EDIT_INFO,
        this.getLatestEditStoreInfo(),
      )
    },
    //编辑评论tinymce返回数据
    editComentLister(data) {
      this.comment = data
      this.$store.commit(
        componentsMutation.UPDATE_COMPONENT_COMMENT_LIST_LATEST_EDIT_INFO,
        this.getLatestEditStoreInfo(),
      )
    },
    // 工作项详情 提交评论
    requestWorkItemSubmitComment() {
      let obj = {}
      if (this.feedback) {
        const {
          source,
          feedbackId,
          feedbackNumber,
          feedbackInfoUrl,
        } = this.feedback
        obj = {
          source,
          feedbackId,
          feedbackNumber,
          noticeUserIds: this.informant.map(i => i.userId),
          feedbackInfoUrl,
          comment:
            source === 1
              ? this.escapeHtml(this.comment.trim())
              : this.comment.trim(),
        }
        return commentCreate(obj)
      } else {
        obj = {
          workItemType: this.workItemType,
          workItemId: this.workItemId,
          comment: this.comment.trim(),
          projectId: this.projectId,
          workNumberIds: this.informant,
          workItemUrl: window.location.href,
        }
        // url = window.$http.api.comment.add
        return commentAdd(obj)
      }
    },
    // 评审页  提交评论
    requestReviewSubmitComment() {
      return this.$store.dispatch(ACTIONCONSTVARLIABLE.ADD_REVIEW_COMMENT, {
        ...this.submitExtraData,
        recvUserIds: this.informant,
        comment: this.comment.trim(),
      })
    },
    //提交评论
    async onSubmitComment() {
      if (!this.comment.trim()) {
        this.$message({ type: 'warning', message: '内容不能为空' })
        return
      }
      this.loading = true
      let result = { status: 0 }
      try {
        if (this.commentsource === 'workItem') {
          result = await this.requestWorkItemSubmitComment()
        } else {
          result = await this.requestReviewSubmitComment()
        }
      } finally {
        this.loading = false
        this.comment = ''
        this.informant = []
      }
      if (result.status === 200) {
        this.$emit('updata')
        this.onCloseComment()
        this.$store.commit(
          componentsMutation.UPDATE_COMPONENT_COMMENT_LIST_LATEST_EDIT_INFO,
          {},
        )
      }
    },
    /**
     * 转义
     * 对用户输入的数据进行处理，防止输入的脚本执行
     * 进数据库前 || 页面获取数据库数据前 || 直接将用户数据返回到页面 时处理
     */
    escapeHtml(str) {
      if (!str) return ''
      // 转义&,一定要在最前处理，否则会把其它转义符号里的&也处理
      str = str.replace(/&/g, '&amp;')
      // 转义html < > 符号,常用于页面显示录入的文本中包含html
      str = str.replace(/</g, '&lt;')
      str = str.replace(/>/g, '&gt;')
      // 转义 " ' 符号，常用于html属性被"/'提前终止，
      // 如<img src="xxx" onerror="alert(1)"> 用户输入了 xxx" onerror="alert(1)
      str = str.replace(/"/g, '&quot;')
      str = str.replace(/'/g, '&#39;')
      return str
    },
  },
}
</script>
<style lang="scss" scoped>
.tinymce-editor {
  min-height: 200px;
}

.comment-submit {
  position: relative;
  margin-bottom: 10px;
}

#bottom-tiny {
  display: none;
  height: 200px;
  opacity: 0.5;
  height: 200px;
  /* opacity: -0.5; */
  background: #000;
  opacity: 0;
  position: absolute;
  top: 43px;
  z-index: 1300;
  width: 100%;
}
</style>
