<template>
  <div
    v-loading="loading"
    element-loading-text=" "
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <person-edit
      v-if="projectId || feedback"
      :work-item-id="workItemId"
      :work-item-type="workItemType"
      :project-id="projectId"
      v-bind="$attrs"
      :commentsource="commentsource"
      :feedback="feedback"
      @updata="initData"
    ></person-edit>
    <div
      v-for="(item, index) in commentDataList"
      :key="item.id"
      class="comment-box"
    >
      <CommentHeader
        :serial-number="item.rowNum || commentDataList.length - index"
        :data="item"
        @clickReply="reply(item)"
      />
      <reply-edit
        v-if="isReplyEditVisiable && item.id === replyId"
        :key="replyId"
        :work-item-id="workItemId"
        :work-item-type="workItemType"
        :project-id="projectId"
        :commentsource="commentsource"
        :reply-person="replyPersonList"
        :reply-id="replyId"
        @updata="initData"
        @closeEdit="closeReplyEdit"
      />
      <div
        class="comment-box-content"
        @click="onClickCommentContent"
        v-html="commentContent(item.comment, item.receiveUsers)"
      ></div>

      <div
        v-if="showPreviewPicture"
        class="pictrue-preview"
        @click="showPreviewPicture = false"
      >
        <div class="img-box">
          <img :src="previewImg" />
        </div>
      </div>

      <template v-if="item.children && item.children.length > 0">
        <div v-for="child in item.children" :key="child.id" class="comment-box">
          <CommentHeader
            :serial-number="child.rowNum"
            :data="child"
            @clickReply="reply(child)"
          >
            <div class="comment-reply">
              <span class="comment-reply-font">{{ $t('回复') }}</span>
              <span>
                {{ item.createUserName }}&nbsp;({{ item.createUser }})
              </span>
            </div>
          </CommentHeader>
          <reply-edit
            v-if="isReplyEditVisiable && child.id === replyId"
            :key="replyId"
            :work-item-id="workItemId"
            :work-item-type="workItemType"
            :project-id="projectId"
            :commentsource="commentsource"
            :reply-person="replyPersonList"
            :reply-id="replyId"
            @updata="initData"
            @closeEdit="closeReplyEdit"
          />
          <div
            class="comment-box-content"
            @click="onClickCommentContent"
            v-html="commentContent(child.comment, child.receiveUsers)"
          ></div>
        </div>
      </template>
    </div>
    <div class="comment-pagination">
      <el-pagination
        v-if="commentDataList.length > 0"
        class="fr"
        small
        :current-page="paginationInfo.pageNum"
        :page-sizes="[10, 20, 30]"
        :page-size="paginationInfo.pageSize"
        layout="prev, pager, next"
        :total="paginationInfo.total"
        @size-change="handleCommentPageSizeChange"
        @current-change="handleCommentPageNumChange"
      ></el-pagination>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 评论列表组件
 * @author heyunjiang
 * @date 2019.4.11
 */
import PersonEdit from './PersonEdit.vue'
import ReplyEdit from './ReplyEdit.vue'
import CommentHeader from './CommentHeader.vue'
import ACTIONCONSTVARLIABLE from '@/store/action-types'
import { commentList } from '@/service/operation'
import { commentList as _commentList } from '@/service/comment'
import { replaceImgSrc } from '@/utils/img-util'
export default {
  name: 'CommentList',
  components: {
    PersonEdit,
    ReplyEdit,
    CommentHeader,
  },

  props: {
    workItemType: {
      type: [Number, String],
      desc: '类型，需求-1， 任务-2， 缺陷-3',
    },

    workItemId: {
      type: [Number, String],
      desc: 'id',
    },

    update: {
      type: Boolean,
      default: false,
      desc:
        '父组件更新这个值，即可更新列表数据，临时方法，找不到更好的解决方案',
    },

    projectId: {
      type: [Number, String],
    },

    feedback: {
      type: Object,
      desc: i18n.t('反馈相关数据'),
    },

    commentListExtraData: {
      type: Object,
      desc: i18n.t('评论列表的额外参数'),
    },

    commentsource: {
      type: String,
      required: false,
      default: 'workItem',
      desc: '引用地方来源，工作项详情 -> workItem, 评审 -> review',
    },
  },

  data() {
    return {
      previewImg: '',
      showPreviewPicture: false,
      loading: false,
      paginationInfo: {
        pageNum: 1,
        pageSize: 20,
        total: 0,
      },

      commentDataList: [],
      isReplyEditVisiable: false, //回复编辑框
      replyPersonList: [], //回复人列表
      replyId: '', //回复id
    }
  },
  computed: {
    commentContent: function() {
      return function(content, users) {
        content = replaceImgSrc(content)
        // 把用户名及id拼接到最后一个p标签里面
        let usersHtml = ''
        users &&
          users.forEach(element => {
            usersHtml += `<span class='comment-user'> @${element.userName}(${element.userId})</span>`
          })
        //  做兼容，目前不存在没有p标签的情况，以防万一，如果没有p标签，直接返回用户名，试了下直接评论为空字符串不行
        let pElementIndex = content.lastIndexOf('</p>')
        if (pElementIndex !== -1 && pElementIndex + 4 == content.length) {
          let beforeLastPContent = content.substr(
            0,
            content.lastIndexOf('</p>'),
          )

          return beforeLastPContent + usersHtml + '</p>'
        } else {
          return content + usersHtml
        }
      }
    },
  },

  watch: {
    workItemId(newId) {
      if (newId !== -1) {
        this.initData()
      }
    },
    workItemType() {
      this.initData()
    },
    feedback: {
      handler: function(val) {
        val.feedbackId && this.initData()
      },
      deep: true,
    },

    update() {
      this.getCommentList()
    },
  },

  mounted() {
    if (this.feedback) {
      this.feedback.feedbackId && this.initData(false)
    } else {
      this.initData(false)
    }
  },
  methods: {
    // 初始化
    initData(isInit = true) {
      this.paginationInfo = {
        pageNum: 1,
        pageSize: 20,
        total: 0,
      }

      this.getCommentList(isInit)
    },
    // 获取工作项详情 的评论列表
    requestWorkItemCommentList() {
      let obj = {}
      if (this.feedback) {
        const { feedbackId, source } = this.feedback
        obj = {
          feedbackId,
          source,
          pageNum: this.paginationInfo.pageNum,
          pageSize: this.paginationInfo.pageSize,
        }

        return commentList(obj)
      } else {
        // 兼容 this.workItemId === 0 接口报异常
        if (+this.workItemId <= 0) {
          return
        }
        obj = {
          workItemType: +this.workItemType,
          workItemId: +this.workItemId,
          pageNum: this.paginationInfo.pageNum,
          pageSize: this.paginationInfo.pageSize,
          projectId: +this.projectId,
        }

        return _commentList(obj)
      }
    },
    // 获取评审的评论列表
    requestReviewCommentList() {
      return this.$store.dispatch(
        ACTIONCONSTVARLIABLE.GET_REVIEW_COMMENT_LIST,
        {
          ...this.commentListExtraData,
          pageNum: this.paginationInfo.pageNum,
          pageSize: this.paginationInfo.pageSize,
        },
      )
    },
    // 获取评论列表
    async getCommentList(isInit = true) {
      let result = { status: 0 }
      this.loading = true
      try {
        if (this.commentsource === 'workItem') {
          result = await this.requestWorkItemCommentList()
        } else {
          result = await this.requestReviewCommentList()
        }
      } finally {
        this.loading = false
      }
      if (result.status === 200) {
        if (this.feedback || this.commentsource === 'review') {
          this.commentDataList = result.data?.list || []
          this.paginationInfo.total = result.data?.total
        } else {
          this.commentDataList = result.data?.results || []
          this.paginationInfo.total = result.data?.pageInfo?.totalPages
        }
        this.commentDataList.forEach(item => {
          if (item.children.length) {
            item.children.reverse()
          }
        })
        isInit && this.$emit('discussFun', result.data)
      } else {
        this.commentDataList = []
        this.paginationInfo.total = 0
      }
    },
    // 放大评论图片
    onClickCommentContent(item) {
      if (item.target.src) {
        this.previewImg = item.target.src
        this.showPreviewPicture = true
      }
    },
    // 分页变化-pageSize
    handleCommentPageSizeChange(pageSize) {
      this.paginationInfo.pageSize = pageSize
      this.$nextTick(this.getCommentList)
    },
    // 分页变化-pageNum
    handleCommentPageNumChange(pageNum) {
      this.paginationInfo.pageNum = pageNum
      this.$nextTick(this.getCommentList)
    },
    //回复
    reply(val) {
      this.isReplyEditVisiable = !this.isReplyEditVisiable
      this.replyPersonList = val.createUser
      this.replyId = val.id
    },
    //关闭回复编辑框
    closeReplyEdit(val) {
      this.isReplyEditVisiable = val
    },
  },
}
</script>
<style lang="scss" scoped>
.pictrue-preview {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1000;
  //text-align: center;
  //margin: auto;
  background-color: rgba(0, 0, 0, 0.1);
  overflow: scroll;
  display: flex;
  justify-content: center;
  align-items: center;
  img {
    max-width: 100%;
    max-height: 100%;
  }
}

.comment-box {
  padding: 16px 16px 0 16px;
  background-color: rgba(241, 245, 248, 0.7);
  margin-bottom: 16px;
  line-height: 1;
  .comment-box {
    margin-top: 0;
    margin-bottom: 0;
    padding: 0 0 0 15px;
  }
  &:first-of-type {
    margin-top: 0;
  }
  .comment-box-header {
    color: rgb(153, 153, 153);
    div {
      display: inline-block;
    }
  }
  .comment-box-content {
    padding-left: 0;
    word-wrap: break-word;
    overflow-x: auto;
    box-sizing: border-box;
    margin-top: 6px;
    line-height: 16px;
    /deep/ p {
      word-wrap: break-word;
      margin-top: 8px;
      margin-bottom: 16px;
      line-height: 20px;
      img {
        max-width: 200px;
        height: auto;
      }
    }
    /deep/.comment-user {
      margin-right: 5px;
      color: #a2a1a1;
      font-size: 12px;
    }
  }
}
.comment-pagination {
  margin-top: 10px;
  overflow: hidden;
}
.comment-reply {
  margin-top: 10px;
  margin-left: 12px;
  color: $--color-text-secondary;
}
</style>
