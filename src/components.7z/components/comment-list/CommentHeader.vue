<template>
  <div class="comment-box-header">
    <div class="comment-box-header-person">
      {{ data.createUserName }}&nbsp;({{ data.createUser }})
      <slot />
    </div>
    <div v-if="data.remark" class="comment-box-header-remark">
      {{ data.remark }}
    </div>
    <div class="comment-box-header-time">{{ data.createTime }}</div>
    <span v-if="data.replyNum" class="comment-reply-font">
      #{{ data.replyNum }}
    </span>
    <span v-if="isReply" class="reply" @click="reply(data)">
      {{ $t('回复') }}
    </span>
    <div class="comment-box-header-index fr">#{{ serialNumber }}</div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
export default {
  name: 'CommentHeader',
  props: {
    serialNumber: {
      type: Number,
      desc: i18n.t('评论列表序号'),
    },

    data: {
      type: Object,
      desc: i18n.t('评论内容数据'),
    },
  },

  data() {
    return {
      isReply: false, //是否支持回复功能
    }
  },

  mounted() {
    const pathname = this.$route.path
    this.isReply =
      pathname === '/' ||
      /\/requirement|\/task|\/bug|\/sprint|\/mine|\/measure|\/searchPage/.test(
        pathname,
      ) //按需配置需要回复的详情页
  },
  methods: {
    reply(data) {
      this.$emit('clickReply', data)
    },
  },
}
</script>
<style lang="scss" scoped>
.comment-box-header {
  color: $--color-text-secondary;
  font-size: 12px;
  div {
    display: inline-block;
  }
  .comment-box-header-remark,
  .comment-box-header-time {
    margin-left: 12px;
  }
  .reply {
    color: $--color-primary;
    cursor: pointer;
    padding-left: 12px;
  }
}
</style>
