<!--
 * @Descripttion: 
 * @version: 
 * @Author: lili
 * @Date: 2020-05-09 15:13:10
 * @LastEditors: lili
 * @LastEditTime: 2020-05-09 16:50:17
 -->
# global-user-select

> 基于elementUI的select组件开发，在有默认展示的选项列表下支持远程搜索功能

### 安装

``` bash
npm install @columbus/global-user-select
```

### 使用

``` bash
import GlobalUserSelect from '@columbus/global-user-select'
Vue.use(GlobalUserSelect)
```

### 属性

参数|说明|类型|可选值|默认值
:--:|:--:|:--:|:--:|:--:
value / v-model|绑定值| array / object | — | —
class-name|类名| string | — | —
multiple|是否多选| boolean | — | false
bind-key|作为value唯一标识的键名，绑定值为对象类型时必填| string | — | userId
max-count|多选最多选择个数| number | — | 50
multiple|是否多选| boolean | — | false
disabled|是否禁用| boolean | — | false
size|输入框尺寸| string | medium/small/mini | —
clearable|是否可以清空选项| boolean | — | true
collapse-tags|多选时是否将选中值按文字的形式展示| boolean | — | false
placeholder|占位符| string | — | —
allowCustom|在没有搜索结果时，是否允许用户创建新条目| boolean | — | false
defaultUserList|下拉列表默认展示数据| array | — | —
refName|select ref名字| string | — | —
envType|组件的使用环境| string | — | GLOBAL
apiParams|接口查询参数| object | — | {}

### 事件

事件名称|说明|回调参数
:--:|:--:|:--:
change|选中值发生变化时触发|目前的选中值
visibleChange|下拉框出现/隐藏时触发|出现则为 true，隐藏则为 false
remove-tag|多选模式下移除tag时触发|移除的tag值
clear|可清空的单选模式下用户点击清空按钮时触发|—
