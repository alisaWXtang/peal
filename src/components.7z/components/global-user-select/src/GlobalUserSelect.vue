<template>
  <div class="select_box">
    <co-select
      :ref="refName"
      v-model="selectValue"
      width="100%"
      filterable
      remote
      v-bind="$attrs"
      :clearable="clearable"
      :value-key="bindKey"
      :multiple="multiple"
      :multiple-limit="maxCount"
      :disabled="disabled"
      :size="size"
      :collapse-tags="collapseTags"
      :placeholder="placeholder"
      :remote-method="remoteMethod"
      :loading="searchLoading"
      :class="[className]"
      popper-class="global-user-select-popper"
      :allow-create="allowCreate"
      @change="selectHandle"
      v-on="currentListeners"
      @visible-change="selectVisibleChange"
    >
      <template v-for="item in managerList">
        <co-option
          v-if="!(item.status === 0 && filterInvalid)"
          :key="item.userId"
          :style="item.noHeight ? 'height:0' : ''"
          :class="{ 'select-option_invalid': item.status === 0 }"
          :label="
            `${
              item.userId !== item.userName
                ? item.userName + '(' + item.userId + ')'
                : item.userEmail
            }`
          "
          :value="item"
        >
        </co-option>
      </template>
    </co-select>
  </div>
</template>

<script>
/**
 * 支持搜索的select组件，有默认展示的列表
 */
import cloneDeep from 'lodash/cloneDeep'
import { Select, Option } from '@heytap/cook-ui'
import * as manageViewService from '@/service/manageView'
import * as projectService from '@/service/project'
import * as userService from '@/service/common/user'
import { debounce } from 'throttle-debounce'

// 组件使用环境, 关联不同用户查询接口
const envType = ['GLOBAL', 'PROJECT', 'DEFAULT']

export default {
  name: 'GlobalUserSelect',
  components: {
    [Select.name]: Select,
    [Option.name]: Option,
  },

  model: {
    prop: 'value',
    event: 'change',
  },

  props: {
    // eslint-disable-next-line vue/require-prop-types
    value: {
      desc: '双向绑定值',
    },

    className: {
      type: String,
      default: '',
      desc: '外部class',
    },

    multiple: {
      type: Boolean,
      default: false,
      desc: '是否是多选',
    },

    allowCustom: {
      type: Boolean,
      default: false,
      desc: '在没有搜索结果的情况下，是否允许用户创建新条目',
    },

    bindKey: {
      type: String,
      default: 'userId',
      desc: '作为 value 唯一标识的键名，绑定值为对象类型时必填',
    },

    maxCount: {
      type: Number,
      default: 50,
      desc: '多选最多选择个数',
    },

    disabled: {
      type: Boolean,
      default: false,
      desc: '是否禁用',
    },

    size: {
      type: String,
      default: '',
      desc: '输入框尺寸',
    },

    clearable: {
      type: Boolean,
      default: true,
      desc: '是否可以清空选项',
    },

    collapseTags: {
      type: Boolean,
      default: false,
      desc: '多选时是否将选中值按文字的形式展示',
    },

    placeholder: {
      type: String,
      default: '',
      desc: '占位符',
    },

    defaultUserList: {
      type: Array,
      default: () => [],
      desc: '默认下拉框列表',
    },

    refName: {
      type: String,
      default: 'select',
      desc: 'select ref名字',
    },

    envType: {
      type: String,
      default: 'GLOBAL',
      desc: '组件使用环境',
      validator: function(val) {
        return envType.includes(val)
      },
    },

    apiParams: {
      type: Object,
      default: function() {
        return {}
      },
      desc: '接口参数',
    },

    isFocus: {
      type: Boolean,
      default: false,
      desc: '是否挂载的时候聚焦',
    },

    filterInvalid: {
      type: Boolean,
      default: false,
      desc: '是否过滤失效人员',
    },

    defaultProposersList: {
      type: Array,
      default: () => [],
      desc: '反馈人默认下拉框列表',
    },
  },

  data() {
    return {
      selectValue: [],
      defaultList: [],
      managerList: [],
      copyList: [],
      allowCreate: false,
      searchLoading: false,
    }
  },
  computed: {
    // current listeners，去掉 change 事件，因为 $listeners 和自己手写的 change 会同时执行
    currentListeners() {
      const listeners = {}
      this.$listeners &&
        Object.entries(this.$listeners).forEach(([key, handler]) => {
          if (key === 'change') {
            return
          }
          listeners[key] = handler
        })
      return listeners
    },
  },
  watch: {
    value: {
      handler: async function() {
        await this.getDefaultList()
      },
      immediate: true,
      deep: true,
    },

    isFocus: {
      handler: function(val) {
        if (val) {
          this.$nextTick(() => {
            this.$refs[this.refName].focus()
          })
        }
      },
      immediate: true,
    },

    defaultUserList: {
      handler: async function() {
        await this.getDefaultList()
      },
      deep: true,
    },
  },

  created() {
    // 防止多次无用搜索
    this.remoteMethod = debounce(500, this.remoteMethod)
  },

  mounted() {},
  methods: {
    async getDefaultList() {
      let res
      if (this.envType === 'PROJECT') {
        res = await projectService.getUserList(this.apiParams)

        this.defaultList = res.data
      } else if (this.envType === 'DEFAULT') {
        this.defaultList = this.defaultUserList
      } else {
        res = await manageViewService.getUserList()
        this.defaultList = res.data
      }
      this.copyList = cloneDeep(this.defaultList)
      const selectValue = this.genearteSelectValue()
      let list = this.differenceSet(
        this.multiple ? selectValue : [selectValue],
        this.copyList,
      )

      this.copyList =
        this.defaultProposersList && this.defaultProposersList.length > 0
          ? [...this.defaultProposersList, ...this.copyList]
          : [...list, ...this.copyList]
      this.managerList = this.copyList
      // 优化回显效果
      this.$nextTick(() => {
        this.selectValue = selectValue
      })
    },
    async remoteMethod(query) {
      // 存储当前的查询关键字
      this.query = query
      if (query !== '') {
        this.searchLoading = true
        let select = this.multiple ? this.selectValue || [] : [this.selectValue]
        let list = []
        let result

        if (this.envType === 'PROJECT') {
          result = await projectService.getUserList(
            Object.assign({}, this.apiParams, { query }),
          )
        } else {
          result = await userService.userSearch({ keyword: query })
        }

        // 此次数据是最新的数据则使用该数据
        if (this.query === query) {
          this.searchLoading = false
          const res = result.data
          if (result.status === 200) {
            let searchList = res.map(item => ({
              ...item,
              origin: 'remote',
            }))

            if (searchList && searchList.length > 0) {
              list = this.differenceSet(select, searchList)
              this.managerList = [...list, ...searchList]
              this.allowCustom && (this.allowCreate = false)
            } else {
              this.managerList = []
              this.allowCustom && (this.allowCreate = true)
            }
          } else {
            this.managerList = [...list]
          }
        }
      } else {
        this.searchLoading = false
        let select = this.multiple ? this.selectValue || [] : [this.selectValue]
        let list = []
        for (let i = 0; i < select.length; i++) {
          if (select[i].origin === 'remote') {
            select[i].noHeight = true
          }
        }
        list = this.differenceSet(select, this.copyList)
        this.copyList = [...list, ...this.copyList]
        this.managerList = this.copyList
      }
    },
    selectHandle(val) {
      this.$emit('change', val)
    },
    selectVisibleChange(val) {
      !val && (this.managerList = this.copyList)
      this.$emit('visibleChange', val)
    },
    // 重新计算选择条目，保证回显由value计算得出,value传递如 1.['123','124'] 2.[{userId: 123, userName: 'test', status: 1}]
    genearteSelectValue() {
      const { value, multiple, allowCustom } = this
      let selectValue
      if (allowCustom) {
        selectValue = value ? cloneDeep(value) : ''
      } else if (multiple) {
        selectValue = Array.isArray(value)
          ? [...value].map(item => {
              if (Object.prototype.toString.call(item) !== '[object Object]') {
                const data = this.defaultList.find(obj => obj.userId === item)
                return data ? { ...data } : { userId: item }
              }

              return item
            })
          : typeof value === 'object'
          ? [value]
          : []
        selectValue = selectValue.filter(item => item.userId)
      } else {
        if (
          Object.prototype.toString.call(value) !== '[object Object]' &&
          value
        ) {
          const data = this.defaultList.find(obj => obj.userId === value)
          selectValue = cloneDeep(data) || ''
        } else {
          selectValue = value ? cloneDeep(value) : ''
        }
      }
      return selectValue
    },
    /**
     * 2 个数组求差集
     */
    differenceSet(target, origin) {
      !target && (target = [])

      return [...target]
        .filter(x => [...origin].every(y => y.userId !== x.userId))
        .map(item => ({
          ...item,
          noHeight: true,
        }))
    },
  },
}
</script>

<style lang="scss" scoped>
.select_box {
  width: 100%;
}

.select-option_invalid {
  color: #bfbfbf;
  padding-right: 50px !important;
  position: relative;
  display: flex;
  align-items: center;

  &::after {
    content: '已失效';
    position: absolute;
    right: 5px;
    background-color: #eee;
    color: #666666;
    border-radius: 20px;
    border: 1px solid #f5f5f5;
    padding: 0 5px;
    font-size: 12px;
    height: 22px;
    box-sizing: border-box;
    display: flex;
    align-items: center;
  }
}
</style>
<style lang="scss">
.global-user-select-popper {
  &.el-select-dropdown {
    .el-select-dropdown__item::after {
      top: 9px;
    }
  }
  .el-scrollbar__wrap {
    max-height: 274px;
  }
}
</style>
