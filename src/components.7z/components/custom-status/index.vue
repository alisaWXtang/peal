<template>
  <div ref="statusBox" v-loading="showloading" class="custom-statu">
    <div class="custom-statu-left" @click="prevetEvent($event)">
      <div
        v-for="(item, $index) in stausData"
        :key="item.type"
        class="custom-item"
        :style="{ '--color': item.color }"
        :class="{ 'border-class': currentItem === item.statusId }"
        @click="customChoose(item, $index)"
      >
        <span class="title" :title="item.statusName">{{
          item.statusName
        }}</span>
        <i
          v-if="currentItem === item.statusId"
          class="el-icon-circle-check"
          :style="{ color: item.color }"
        ></i>
      </div>
    </div>
    <div class="custom-statu-right" @click="prevetEvent($event)">
      <div class="custom-statu-right-box scrollbal-common">
        <div v-for="ite in editList" ref="form" :key="ite.index" :model="form">
          <div v-show="ite.fieldName == $t('评论')" class="form-type-list">
            <div class="form-type-font">
              <span style="color: #fff">*</span>
              <span>{{ $t('通知人') }}</span>
            </div>
            <div class="form-item__container">
              <select-filter
                v-model="form.messger"
                multiple
                :select-list="assignUserData"
                :is-assign-user="true"
              >
                <el-option slot :label="$t('全部')" value="all"></el-option>
              </select-filter>
            </div>
          </div>
          <div class="form-type-list">
            <div class="form-type-font">
              <span :style="{ color: ite.required ? 'red' : '#fff' }">*</span>
              <span class="form-type-ellipsis" :title="ite.fieldName">{{
                ite.fieldName
              }}</span>
            </div>
            <div
              v-if="ite.fieldName !== $t('评论')"
              class="form-item__container item__containers"
            >
              <expect-hour
                v-if="
                  ite.attrName === 'actualHour' || ite.attrName === 'expectHour'
                "
                :hour.sync="ite.setValue"
              >
              </expect-hour>
              <typed-form-item
                v-else
                v-model="ite.setValue"
                :popper-append-to-body="true"
                :type="ite.attrValue"
                :is-assign-user="
                  ['MEMBER_CHOICE', 'MULTI_MEMBER_CHOICE'].includes(
                    ite.attrValue,
                  )
                "
                :select-list="selectdatatFun(ite)"
                :filter-field="false"
                @focus="getSelectInfo(ite)"
                @input="inputInfo"
              ></typed-form-item>
            </div>
            <tiny-mce
              v-show="ite.fieldName === $t('评论')"
              style="width: 293px"
              :value="form.comment"
              :max-heigt="200"
              :min-heigt="200"
              :toolbar="toolBar"
              @watch="editComentLister($event)"
            ></tiny-mce>
          </div>
        </div>
      </div>
      <div class="btn-footer">
        <el-button type="primary" @click="sendInformation">{{
          $t('确定')
        }}</el-button>
        <el-button @click="$emit('finish')">{{ $t('取消') }}</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
// import FormType from "@/pages/commonComponents/FormTypeList";
import BugCustomFieldsMixin from '@/mixin/BugCustomFieldsMixin.js'
const TinyMce = () => import('@/components/tinymce')
import SelectFilter from '@/components/select-filter'
import ExpectHour from '@/components/expect-hour'
import ACTIONCONSTVARLIABLE from '@/store/action-types'
import {
  queryOptions,
  updateTaskStatus,
  updateRequirementStatus,
  batchUpdateRequirementStatus,
} from '@/service/work-status-flow'
import { commentAdd } from '@/service/comment'
import { getUserList } from '@/service/project'
import { statusUpdatableList } from '@/service/bug'
import { isEmpty } from '@/utils'
export default {
  name: 'CustomStatus',
  components: {
    TinyMce,
    SelectFilter,
    ExpectHour,
  },

  mixins: [BugCustomFieldsMixin],

  props: {
    parentInfo: {
      type: Object,
      required: false,
      default: () => {
        return {}
      },
      desc: '状态对应的整体详细信息，用于拿附加字段的初始值',
    },

    workItemType: {
      type: [String, Number],
      required: false,
    },

    workItemId: {
      type: [String, Number, Array],
      required: false,
      default: null,
    },

    statusId: {
      type: [String, Number],
      required: false,
    },

    projectId: {
      type: [String, Number],
      required: false,
      default: 0,
    },

    updateData: {
      type: Function,
      required: false,
    },
    // 是否为批量修改
    bulk: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      form: {
        user: '',
        messger: [],
        comment: '',
        cause: 1,
      },

      showStatus: false, //展示/隐藏状态流转
      selectList: [{ comment: [] }], //设置对应的下拉选项
      assignUserData: [],
      currentItem: '', //
      stausData: '',
      attachFields: [], // 附件字段，包含评论
      show: false,
      showloading: true,
      // visible:false,
      toolBar:
        'undo redo | bold italic  bullist  numlist  lists  imageCustom  fullscreen',
      editList: [
        { label: '需求分类', type: 'SINGLE_TEXT' },
        { label: '迭代', type: 'MULTI_CHOICE' },
        { label: '优先级', type: 'MULTI_CHOICE' },
      ],

      interimInfo: null,
      infoList: [],
    }
  },
  watch: {
    workItemId() {
      this.getNextStatus()
    },
  },

  mounted() {
    this.getNextStatus()
    this.assignUsersList()
  },
  methods: {
    noop() {},
    // 输入事件 - 暂时注释掉，如果需要实时刷新列表，请判断一下条件，比如在多选框选项变化时，也会触发 input 事件
    inputInfo() {
      // let Obj = {
      //   projectId:this.projectId,
      //   workItemType:this.workItemType,
      //   attrName:this.interimInfo && this.interimInfo.attrName,
      //   searchKey:val
      // };
      // window.$http.post(window.$http.api.work_status_fow.query_options,Obj).then(res => {
      //   if (res.status== 200) {
      //     if (this.interimInfo.attrValue=='MEMBER_CHOICE') {
      //       this.selectList[0][this.interimInfo.attrName] = res.data.map(item=>{
      //         return {value:`${item.label}(${item.value})`,key:item.value}
      //       })
      //     }else{
      //       this.selectList[0][this.interimInfo.attrName] = res.data.map(item=>{
      //         return {value:item.label,key:item.value}
      //       })
      //     }
      //   }
      // })
      // .catch(res => {
      //   // this.assignUserData = res.data;
      // });
    },
    //处理下拉选项
    selectdatatFun(ite) {
      if (
        this.selectList[0][ite.attrName] &&
        this.selectList[0][ite.attrName].length == 0
      ) {
        let arr = []
        if (ite.selectedValue) {
          if (ite.attrValue == 'MEMBER_CHOICE') {
            arr = ite.selectedValue.map(item => {
              return { value: `${item.label}(${item.value})`, key: item.value }
            })
            if (this.bulk && ite.attrName === 'assignUser') {
              arr.unshift({
                key: '',
                value: this.$t('保留原工作项处理人'),
              })
            }
          } else {
            arr = ite.selectedValue.map(item => {
              return { value: item.label, key: item.value }
            })
          }

          return arr
        }
      } else {
        if (this.bulk && ite.attrName === 'assignUser') {
          return [
            {
              key: '',
              value: this.$t('保留原工作项处理人'),
            },
            ...this.selectList[0][ite.attrName],
          ]
        } else {
          return this.selectList[0][ite.attrName]
        }
      }
    },
    //获取下拉选项
    getSelectInfo(val) {
      const { attrValue = 'LITE_DATE_ATTR' } = val
      if (
        ![
          'MEMBER_CHOICE',
          'MULTI_MEMBER_CHOICE',
          'SINGLE_CHOICE',
          'MULTI_CHOICE',
        ].includes(attrValue)
      ) {
        return
      }
      this.interimInfo = val //获取对应的下拉框信息
      let Obj = {
        projectId: this.projectId,
        workItemType: this.workItemType,
        attrName: val.attrName,
      }

      queryOptions(Obj)
        .then(res => {
          if (res.status == 200) {
            if (val.attrValue == 'MEMBER_CHOICE') {
              this.selectList[0][val.attrName] = res.data.map(item => {
                return {
                  value: `${item.label}(${item.value})`,
                  key: item.value,
                }
              })
            } else {
              this.selectList[0][val.attrName] = res.data.map(item => {
                return { value: item.label, key: item.value }
              })
            }
          }
        })
        .catch(() => {
          // this.assignUserData = res.data;
        })
    },
    sendInformation() {
      let info = {},
        arr = this.editList,
        userDefinedAttrs = {}
      for (let i = 0; i < arr.length; i++) {
        if (
          ['INT_ATTR', 'FLOAT_ATTR'].includes(arr[i].attrValue) &&
          arr[i].setValue === ''
        ) {
          arr[i].setValue = null
        }
        if (arr[i].fieldName == i18n.t('评论')) {
          arr[i].setValue = this.form.comment
        }
        if (arr[i].userDefined) {
          userDefinedAttrs[arr[i].attrName] = arr[i].setValue
        } else {
          info[arr[i].attrName] = arr[i].setValue
        }
        if (arr[i].required && isEmpty(arr[i].setValue)) {
          this.$message({
            type: 'error',
            message: `${arr[i].fieldName}${i18n.t('不能为空')}!`,
          })

          return false
        }
      }
      if (JSON.stringify(userDefinedAttrs) !== '{}') {
        info['userDefinedAttrs'] = userDefinedAttrs
      }
      if (this.form.messger.length > 0 && !this.form.comment.trim()) {
        this.$message({
          type: 'error',
          message: i18n.t('填写通知人时评论不能为空'),
        })

        return
      }
      if (this.workItemType === 1) {
        this.updateRequir(info)
      } else if (this.workItemType === 2) {
        this.upDateTask(info)
      } else if (this.workItemType === 3) {
        this.updateDefect(info)
      }
      !this.bulk && this.onSubmitComment()
    },
    onSubmitComment() {
      commentAdd({
        workItemType: this.workItemType,
        workItemId: this.workItemId,
        comment: this.form.comment.trim(),
        projectId: this.projectId,
        workNumberIds: this.form.messger,
        workItemUrl: window.location.href,
      }).then(res => {
        if (res.status === 200) {
          this.$emit('finish')
          this.comment = ''
          this.informant = []
        } else {
          this.$message({ type: 'error', message: res.msg })
        }
      })
    },
    // 更新任务
    async upDateTask(info) {
      const params = {
        projectId: this.projectId,
        assignUser: this.form.user,
        statusId: this.currentItem,
        ...info,
      }
      let res
      if (this.bulk) {
        params.workItemIds = this.workItemId
        params.changeType = this.workItemType
        params.fromStatus = this.statusId
        params.notifyUser = this.form.messger.length ? this.form.messger : null
        res = await batchUpdateRequirementStatus(params)
      } else {
        params.id = this.workItemId
        res = await updateTaskStatus(params)
      }
      if (res.status === 200) {
        this.$message({
          message: res.msg || i18n.t('修改任务成功'),
          type: 'success',
        })
        this.bulk
          ? this.$emit('finish', this.statusInfo)
          : this.updateData(res, 2)
      } else if (res.status === 418) {
        this.$message({
          message: res.msg,
          type: 'error',
        })
      }
    },
    //更新缺陷
    async updateDefect(info) {
      const params = {
        projectId: this.projectId,
        assignUser: this.form.user,
        statusId: this.currentItem,
        ...info,
      }
      let res
      if (this.bulk) {
        params.workItemIds = this.workItemId
        params.changeType = this.workItemType
        params.fromStatus = this.statusId
        params.notifyUser = this.form.messger.length ? this.form.messger : null
        res = await batchUpdateRequirementStatus(params)
      } else {
        params.id = this.workItemId
        res = await this.$store.dispatch(
          ACTIONCONSTVARLIABLE.UPDATE_DEFECT_STATUS,
          params,
        )
      }
      if (res.status === 200) {
        this.bulk
          ? this.$emit('finish', this.statusInfo)
          : this.updateData(res, 3)
      } else if (res.status === 418) {
        this.$message({
          message: res.msg,
          type: 'error',
        })
      }
    },
    //更新需求
    async updateRequir(info) {
      const params = {
        projectId: this.projectId,
        assignUser: this.form.user,
        statusId: this.currentItem,
        ...info,
      }
      let res
      if (this.bulk) {
        params.workItemIds = this.workItemId
        params.changeType = this.workItemType
        params.fromStatus = this.statusId
        params.notifyUser = this.form.messger.length ? this.form.messger : null
        res = await batchUpdateRequirementStatus(params)
      } else {
        params.id = this.workItemId
        res = await updateRequirementStatus(params)
      }
      if (res.status === 200) {
        this.$message({
          message: res.msg || i18n.t('修改需求成功'),
          type: 'success',
        })
        this.bulk
          ? this.$emit('finish', this.statusInfo)
          : this.updateData(null, 1)
      } else if (res.status === 418) {
        this.$message({
          message: res.msg,
          type: 'error',
        })
      }
    },
    fousClick() {
      this.show = false
    },
    fous() {
      this.show = true
    },
    blur() {
      this.show = true
    },
    prevetEvent(e) {
      e.stopPropagation()
    },
    // 字段初始化
    async fieldInit() {
      // 数据初始化
      this.attachFields = []
      this.values = { comment: '' }
      this.loading = true
      let result = await this.getCustomFiledInfo(this.parentInfo.projectId)
      this.loading = false
      if (result.status !== 200 || result.data === null) {
        return false
      }
      result = result.data
      // 封装 this.attachFields 对象
      try {
        const required = this.statusInfo.fields.value.required // 需要展示的字段集合
        const attachFields = []
        required.forEach(item => {
          if (item === 'comment') {
            attachFields.push({
              key: item,
              label: i18n.t('评论'),
            })

            this.$set(this.values, 'comment', '')
          } else {
            if (result.def[item]) {
              attachFields.push({
                key: item,
                label: result.def[item].fieldName,
                choice: result.def[item].choice,
                selectValue: [],
              })

              this.$set(this.values, item, this.parentInfo[item] || '')
            }
          }
        })
        // 获取预加载值
        attachFields
          .filter(item => item.choice)
          .forEach(async item => {
            const innerResult = await this.getPresetDataForSelect(item.key)
            item.selectValue = innerResult.choices.map(jtem => {
              return {
                key: jtem.fieldValue,
                value: jtem.fieldDisplay,
                ...jtem,
              }
            })
            this.$set(this.values, item.key, item.selectValue[0].key)
          })
        this.attachFields = attachFields
        // eslint-disable-next-line no-empty
      } catch (_) {}
    },
    // 获取下拉框 select options 值
    async getPresetDataForSelect(fieldId) {
      const result = await this.getCustomFiledSelectList(
        fieldId,
        this.parentInfo.projectId,
      )

      if (result.status === 200) {
        return result.data
      }
      return []
    },
    customChoose(item, index) {
      this.editList = this.stausData[index].fields.value.fields
      this.editList && this.selectListFun(this.editList)
      this.editList && this.statusList()
      this.currentItem = item.statusId
      this.statusInfo = item
      this.fieldInit()
    },
    getObjectKeys(object) {
      let keys = []
      for (let property in object) keys.push(property)
      return keys
    },
    assignUsersList(query) {
      let projectId = this.projectId
      getUserList({
        projectId,
        query: query ? query : '',
        workItemType: this.workItemType,
      }).then(res => {
        this.assignUserData = res.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: `${item.userName}(${item.userId})`,
          }
        })
      })
    },
    getNextStatus() {
      // 为了解决打开这个状态流转框,当关闭弹窗时会must be positive
      if (!this.statusId || !this.workItemId || this.workItemId === -1) {
        return
      }
      let param = {
        workItemType: this.workItemType,
        workItemId: this.bulk ? this.workItemId[0] : this.workItemId,
        statusId: this.statusId,
        projectId: this.projectId,
      }

      statusUpdatableList(param).then(res => {
        if (res.status !== 200) {
          return false
        }
        this.showloading = false
        // res.data&&res.data.length == 0 ?this.showStatus = false:this.showStatus = true
        if (res.data && res.data.length == 0) {
          this.showStatus = false
          this.$message({
            type: 'warning',
            message: '没有可流转状态',
          })

          this.$emit('getStatus', true)
          return false
        } else {
          this.showStatus = true
        }
        this.stausData = res.data
        this.editList = this.stausData[0].fields.value.fields

        if (this.bulk) {
          const assignUser = this.editList.find(
            item => item.attrName === 'assignUser',
          )

          if (assignUser) {
            assignUser.value = ''
          }
        }

        this.currentItem = res.data[0].statusId
        this.editList && this.selectListFun(this.editList)
        this.editList && this.statusList()
        if (this.currentItem === 81 || this.currentItem === 121 || this.bulk) {
          this.statusInfo = res.data[0]
          this.$nextTick(() => {
            this.fieldInit()
          })
        }
        this.$nextTick(() => {
          this.$emit('getStatus', false)
        })
      })
    },
    //处理下拉列表默认选中数据
    statusList() {
      this.editList.forEach(item => {
        if (item.selectedValue) {
          // 在批量操作以及处理人时，特殊处理
          if (item.attrName === 'assignUser' && this.bulk) {
            item.setValue = ''
          } else if (
            item.selectedValue.length > 0 &&
            ['MULTI_CHOICE', 'MULTI_MEMBER_CHOICE'].includes(item.attrValue)
          ) {
            item.setValue = item.selectedValue.map(innerItem => {
              return innerItem.value
            })
          } else if (
            item.selectedValue.length > 0 &&
            item.attrValue !== 'MULTI_CHOICE'
          ) {
            item.setValue =
              item.attrValue === 'SINGLE_CHOICE'
                ? item.selectedValue[0].value
                : item.value
          } else if (
            item.selectedValue.length == 0 &&
            item.attrValue == 'MULTI_CHOICE'
          ) {
            item.selectedValue = []
            item.setValue = []
          } else {
            item.selectedValue = []
            item.setValue = null
          }
        } else {
          // eslint-disable-next-line no-prototype-builtins
          if (item.hasOwnProperty('value')) {
            item.setValue = item.value
          }
        }
      })
    },

    // 设置下拉选项数据
    selectListFun(arr) {
      let obj = {}
      for (let index = 0; index < arr.length; index++) {
        obj[arr[index].attrName] = []
        // this.selectList
        if (arr[index].attrName == 'comment') {
          this.form.comment = arr[index].defaultValue || ''
        }
      }
      this.selectList = [obj]
    },
    editComentLister(data) {
      this.form.comment = data
    },
    //评论通知人搜索
    remoteMethod(query) {
      this.query = query
      this.assignUsersList(query)
    },
  },
}
</script>
<style lang="scss" scoped>
.form-type-list {
  display: flex;
  margin-bottom: 14px;
  align-items: flex-start;
  line-height: 28px;
}
.form-item__container {
  width: 200px;
}
.form-type-font {
  display: flex;
  width: 110px;
}
.custom-statu {
  display: flex;
  .custom-statu-left {
    border-right: $borderSolid;
    padding-right: 20px;
    .custom-item {
      border: 1px solid var(--color);
      color: var(--color);
      width: 100px;
      height: 28px;
      line-height: 28px;
      cursor: pointer;
      text-align: center;
      border-radius: 4px;
      & + .custom-item {
        margin-top: 14px;
      }

      &:hover {
        background-color: var(--color);
        color: #fff;
      }

      .title {
        display: inline-block;
        width: 100px;
        height: 28px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }

  .custom-statu-right {
    padding-left: 10px;
    .custom-statu-right-box {
      overflow: auto;
      max-height: 660px;
    }
  }
  .btn-footer {
    float: right;
  }
}
.form-type-ellipsis {
  display: inline-block;
  width: 100px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
#bottom-tiny {
  height: 200px;
  width: 404px;
  background: #000;
  opacity: 0;
  position: absolute;
  top: 116px;
  z-index: 1300;
}
.border-class {
  position: relative;
  .el-icon-circle-check {
    position: absolute;
    right: -7px;
    top: -8px;
    z-index: 3000;
    font-size: 16px;
    background-color: white;
    border-radius: 50%;
    line-height: 1;
  }
}
.unstatus {
  margin: 25% 0;
  text-align: center;
  color: #7b7a7a;
}
.select-scroll {
  height: 150px;
  overflow: auto;
}
// 先展示把状态流转框下拉三角去掉,添加到元素中，没有添加到body出现的问题，添加到元素中，主要是为了解决流转时点击任意下拉会关闭弹窗问题
/deep/.popper__arrow {
  display: none !important;
}
</style>
