# select filter

time: 2019.7.23  
author: heyunjiang

## 说明

基于 element-ui select 组件，提供 filter 功能

## 使用方式

```javascript
// template
// assignUserData 数组选项需要保持 key, value 2个字段
<select-filter v-model="createTaskInfo.assignUser" :selectList="assignUserData"></select-filter>
```