/** * @title 基于 elementui select 的 filter 组件, * @desc
支持单选、多选、过滤，人员选择拼音搜索(人员筛选默认过滤失效人员) * @author
heyunjiang,chenxiaolong * @date 2019.7.23 * @update 2020.7.2 */
<template>
  <span>
    <el-select
      ref="select"
      v-model="selectValue"
      :multiple="multiple"
      :disabled="disabled"
      v-bind="$attrs"
      :placeholder="placeholder"
      :popper-append-to-body="popperAppendToBody"
      popper-class="select-filter-popper"
      v-on="$listeners"
      @visible-change="selectvisibleChange"
      @change="setSelected"
    >
      <template>
        <li class="filter-search-container">
          <el-input
            ref="filterHandlePerson"
            v-model.trim="filterString"
            v-focus
            :placeholder="
              projectUserSelect ? $t('输入拼音/工号/姓名') : $t('搜索')
            "
            @input="inputKeyup"
          ></el-input>
        </li>
      </template>
      <div class="select-scroll scrollbal-common">
        <slot></slot>
        <template v-if="multiple && $attrs.clearAll">
          <el-option
            :label="$t('清除选中')"
            value=""
            style="font-size: 12px; height: 30px; line-height: 30px"
            @click.native="onClearAll"
          ></el-option>
        </template>
        <template v-if="multiple && $attrs.pickAll">
          <el-option :label="$t('全部')" value="all"></el-option>
        </template>
        <template v-if="$attrs.group">
          <el-option-group
            v-for="(group, idx) in selectListVo"
            :key="idx"
            :label="group.label"
          >
            <el-option
              v-for="(data, index) in group.children"
              :key="index"
              :class="{ 'hidden-option': data.hidden }"
              :style="{ height: data.noHeight ? '0' : '' }"
              :value="data.key"
              :label="data.value"
            >
              <span
                v-if="data.color"
                class="option_text"
                :style="{ 'background-color': data.color, color: '#fff' }"
                >{{ data.value }}</span
              >
              <template v-else>{{ data.value }}</template>
            </el-option>
          </el-option-group>
        </template>
        <template v-for="(data, index) in selectListVo" v-else>
          <el-option
            v-show="!(isAssignUser && data.status === 0)"
            :key="index"
            :style="{ height: data.noHeight ? '0' : '' }"
            :value="data.key"
            :label="data.value"
            :class="{ 'hidden-option': data.hidden }"
            :disabled="data.disabled"
          >
            <span
              v-if="data.color"
              class="option_text"
              :style="{ 'background-color': data.color, color: '#fff' }"
              >{{ data.value }}</span
            >
            <template v-else>{{ data.value }}</template>
          </el-option>
        </template>
        <template v-if="isEmpty">
          <el-option label="无匹配数据" value="无匹配数据" disabled></el-option>
        </template>
      </div>
    </el-select>
  </span>
</template>
<script>
import { i18n } from '@/i18n'
import { inputFocusPublic } from '@/utils/focusPublicUtil.js'
import cloneDeep from 'lodash/cloneDeep'
import debounce from 'lodash/debounce'
import * as projectService from '@/service/project'
import * as userService from '@/service/common/user'
export default {
  name: 'SelectFilter',
  components: {},

  mixins: [],

  model: {
    prop: 'value',
    event: 'change',
  },

  props: {
    value: {
      validator: function() {
        return true
      },
    },

    disabled: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否禁用',
    },

    multiple: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否多选',
    },

    selectList: {
      type: Array,
      required: true,
      desc: 'select option source data',
    },

    placeholder: String,
    popperAppendToBody: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否渲染到 body',
    },

    isAssignUser: {
      type: Boolean,
      default: false,
      desc: '是否为指派用户类型',
    },

    assignUserChoiceFocus: {
      type: Boolean,
      default: false,
      desc: '指派类型是否默认聚焦',
    },
  },
  data() {
    return {
      selectValue: '',
      filterString: '',
      focusTimer: null, //input聚焦用到定时器
      originSelectList: [], // 源数据
      selectListVo: [], // options
      isEmpty: false,
    }
  },
  computed: {
    projectId() {
      return this.$getUrlParams().projectId
    },
    // 项目中人员使用
    projectUserSelect() {
      return this.projectId && this.isAssignUser
    },
  },

  watch: {
    value: {
      handler: function() {
        const { value, multiple } = this

        if (multiple) {
          this.selectValue = Array.isArray(value)
            ? [...value]
            : value
            ? [value]
            : []
        } else {
          this.selectValue = value
        }
      },
      immediate: true,
    },

    filterString: {
      handler: function(val) {
        // 仅当项目中人员选择使用时，支持拼音搜索
        if (this.projectUserSelect) {
          this.userRemoteSearch(val)
        } else {
          this.localSearch(val)
        }
      },
    },

    assignUserChoiceFocus: {
      handler: function(val) {
        if (val) {
          this.$nextTick(() => {
            this.$refs.select.focus()
            // 解决二次点击不聚焦问题
            this.$refs.select.visible = true
          })
        }
      },
      immediate: true,
    },

    selectList: {
      handler: function(val) {
        this.originSelectList = cloneDeep(val)
        this.selectListVo = cloneDeep(val)
      },
      immediate: true,
    },

    // 在有默认值时切换单选多选会报错
    multiple(multiple) {
      const value = this.value
      if (multiple) {
        this.selectValue = Array.isArray(value)
          ? [...value]
          : value
          ? [value]
          : []
      } else {
        this.selectValue = value
      }
    },
  },

  created() {},
  methods: {
    selectvisibleChange(visible) {
      if (!visible) {
        this.filterString = ''
      } else {
        // 为了保证下拉框样式正确
        setTimeout(() => {
          this.$refs.filterHandlePerson.focus()
        }, 200)
      }

      // 组件自身不显示时，不响应 visibleChange 事件
      // 解决 table fixed 列时，同时渲染多次该组件，由于 v-if 条件显示，隐藏的组件响应该事件，改变了 v-if 的条件，销毁了要显示的组件
      // 比如组件: RequirementDetailTaskDecompose
      if (window.getComputedStyle(this.$el).visibility !== 'hidden') {
        this.$emit('visableChange', visible)
      }
    },
    inputKeyup() {
      this.$emit('input', this.filterString)
    },
    visibleChange(visible) {
      // input聚焦
      inputFocusPublic(visible, 'searchPublicInput', this.focusTimer, this)

      // 项目中人员使用且传递的selectList为空时，获取selectList
      if (visible && this.projectUserSelect && !this.originSelectList.length) {
        this.getUserList()
      }
    },
    // 本地搜索
    localSearch: debounce(function(query) {
      if (!query) {
        this.selectListVo = this.selectList
        return
      }

      if (this.$attrs.group) {
        const data = []
        this.selectList.forEach(item => {
          data.push(...item.children)
        })
        const matches = data.filter(
          item => item.value?.indexOf(this.filterString) > -1,
        )
        this.selectListVo = [
          {
            label: '搜索结果',
            children: matches,
          },
        ]
        this.isEmpty = !matches.length
      } else {
        this.selectListVo = this.selectList.filter(
          item => item.value?.indexOf(this.filterString) > -1,
        )
        this.isEmpty = !this.selectListVo.length
      }
    }, 300),
    // 获取用户
    async getUserList(query) {
      const params = {
        query,
        projectId: this.projectId,
      }

      let res

      // 判断当前是否在项目中
      if (this.projectId) {
        res = await projectService.getUserList(params)
      } else {
        res = await userService.userSearch(params)
      }

      const result = res.data
      let userData = []
      if (res.status === 200) {
        userData = result
          .filter(user => user.status !== 0)
          .map(item => {
            return {
              ...item,
              key: item.userId,
              value: `${item.userName}(${item.userId})`,
            }
          })

        !query && (this.originSelectList = userData)
        this.selectListVo = userData

        return userData
      } else {
        this.$message.error(i18n.t('获取数据出错'))
      }
    },
    // 用户远程搜索
    userRemoteSearch: debounce(
      function(query) {
        const selectValue = []

        if (Array.isArray(this.selectValue)) {
          for (const item of this.selectValue) {
            if (item === 'all' || !item) {
              continue
            }

            const data = this.originSelectList.find(obj => obj.userId === item)
            data && selectValue.push({ ...data, noHeight: true })
          }
        } else if (this.selectValue) {
          const data = this.originSelectList.find(
            obj => obj.userId === this.selectValue,
          )

          data && selectValue.push({ ...data, noHeight: true })
        }

        if (query) {
          this.getUserList(query).then(userData => {
            this.selectListVo = [...selectValue, ...userData]
          })
        } else {
          this.selectListVo = this.originSelectList
        }
      },
      300,
      { leading: true },
    ),
    // 清空选择
    onClearAll() {
      this.selectValue = ['all']
      this.$emit('change', this.selectValue)
    },
    setSelected(val) {
      if ((this.multiple || this.$attrs.multiple) && this.$attrs.pickAll) {
        if (val[val.length - 1] === 'all' || !val.length) {
          this.$nextTick(() => {
            this.selectValue = ['all']
            this.$emit('change', this.selectValue)
          })
        }
        if (val.length > 1 && val[0] === 'all') {
          this.selectValue.splice(0, 1)
        }
      }
    },
  },
}
</script>
<style lang="scss">
@import '@/style/custom-select/index.scss';
</style>
<style lang="scss" scoped>
.select-filter-popper {
  .filter-search-container {
    padding: 0 0 5px;
  }

  &.el-select-dropdown .el-select-dropdown__item::after {
    top: 50%;
    transform: translateY(-50%);
  }
}

.select-scroll {
  height: 180px;
  overflow: auto;
  @include scrollbal-common;
  /deep/ .option_text {
    padding: 2px 5px;
    border-radius: 4px;
    line-height: 1;
  }
}
.filter-search-container {
  padding: 0 30px 5px 20px;
  &::after {
    display: none;
  }
}
.hidden-option {
  height: 0 !important;
  overflow: hidden;
}
</style>
