<template>
  <div class="department-treebox">
    <co-input
      v-if="filter"
      :placeholder="$t('输入关键字进行过滤')"
      v-model="filterText"
    >
    </co-input>

    <co-tree
      v-bind="$attrs"
      v-on="$listeners"
      class="filter-tree scrollbal-common"
      :class="{ 'filter-tree-noicon': !showIcon }"
      node-key="id"
      :data="department"
      :props="defaultProps"
      highlight-current
      :current-node-key="currentNodeKey"
      :expand-on-click-node="false"
      :filter-node-method="filterNode"
      :render-content="renderContent"
      :default-expanded-keys="expandedKeys"
      ref="tree"
    >
    </co-tree>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 部门组件树
 * @desc
 * @author heyunjiang
 * @date
 */

export default {
  name: 'CompanyTree',
  components: {},
  mixins: [],
  props: {
    showStar: {
      type: Boolean,
      required: false,
      desc: i18n.t('是否展示我关注的'),
    },

    starKeyName: {
      type: String,
      default: i18n.t('我关注的'),
    },

    currentNodeKey: {
      type: [String, Number],
      required: false,
      desc: '当前活跃的 key',
    },

    filter: {
      type: Boolean,
      required: false,
      default: false,
      desc: i18n.t('是否支持过滤'),
    },
  },

  data() {
    return {
      filterText: '',
      defaultProps: {
        children: 'children',
        label: 'name',
      },
    }
  },
  computed: {
    department() {
      const originTree = this._flatTree(this.$store.state.gd.department)
      if (this.showStar && originTree?.[0]?.id !== -1) {
        originTree.unshift({
          id: -1,
          name: this.starKeyName,
        })
      }
      return originTree
    },
    // 是否展示 icon 图标，如果只有一层，那么缩进就有问题，则不需要展示 icon
    showIcon() {
      return this.department.find(item => item.children?.length)
    },
    // 默认展开节点数组
    expandedKeys() {
      return [this._treeParentKey(this.department, this.currentNodeKey)]
    },
  },

  watch: {
    filterText(val) {
      this.$refs.tree.filter(val)
    },
    department() {
      // 保证在树渲染成功之后，更新选项，否则会默认选中第一个
      this.$nextTick(() => {
        this.$refs.tree.setCurrentKey(this.currentNodeKey)
      })
    },
    currentNodeKey() {
      this.$refs.tree.setCurrentKey(this.currentNodeKey)
    },
  },

  created() {},
  mounted() {},
  methods: {
    // 查找选中值的父节点 - 设置默认展开
    _treeParentKey(tree, key) {
      if (!Array.isArray(tree) || !tree.length) return
      const result = tree.find(item => item.id === key)
      let parentId
      if (result) {
        parentId = result?.parentId
      } else {
        for (let i = 0; i < tree.length; i++) {
          const current = this._treeParentKey(tree[i].children, key)
          if (current) {
            parentId = current
            break
          }
        }
      }
      return parentId || ''
    },
    // 执行过滤
    filterNode(value, data) {
      if (!value) return true
      return data.name.indexOf(value) !== -1
    },
    renderContent(h, { node, data, store }) {
      const style = this.showIcon
        ? 'width: calc(100% - 24px);'
        : 'width: calc(100% - 19px);'
      return (
        <span class="ellipsis-pure" style={style} title={node.label}>
          {node.label}
        </span>
      )
    },
    _flatTree(tree) {
      if (!Array.isArray(tree) || tree.length === 0) {
        return []
      }
      if (
        !tree[0].data ||
        Object.prototype.toString.call(tree[0].data) !== '[object Object]'
      ) {
        return tree.map(item => ({
          ...item,
          children: this._flatTree(item.children),
        }))
      }
      return tree.map(item => ({
        ...item,
        ...item.data,
        children: this._flatTree(item.children),
      }))
    },
  },
}
</script>
<style lang="scss" scoped>
// 保持全局统一样式
.department-treebox {
  /deep/ .el-tree {
    background-color: $--background-gray;

    .el-tree-node {
      .el-tree-node__content {
        height: 32px;
        line-height: 32px;
        border-radius: 4px;

        &:hover {
          background-color: #e2e9ef;
        }
      }

      &.is-current > .el-tree-node__content {
        color: #fff;
        background-color: $--color-primary;

        .el-tree-node__expand-icon:not(.is-leaf) {
          color: #fff;
        }
      }
    }
  }
}
</style>
