<template>
  <div :class="className">
    <el-popover
      :popperClass="isInPage ? `guide-pop in-page` : 'guide-pop'"
      v-if="!isVisited"
      class="function-guide-tips"
      v-model="isTipsShow"
      trigger="manual"
      :placement="placement"
      ref="pop"
    >
      <div class="pop-content">
        <slot name="tips">{{ tips }}</slot>
      </div>
      <div class="function-guide-tips__footer" @click.stop>
        <el-button type="text" @click="gotoDetailLink">{{
          $t('了解详情')
        }}</el-button>
        <el-button type="text" @click="hide">{{ $t('已知晓') }}</el-button>
      </div>
      <span slot="reference">
        <slot></slot>
      </span>
    </el-popover>
    <slot v-else></slot>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/***
 * 新功能提醒popover封装
 * 监听全局newVersionAlert.isVisited状态决定当前是否显示
 */
export default {
  name: 'FunctionGuideTips',
  props: {
    actionUrl: {
      type: String,
      default:
        'http://columbus.os.adc.com/doc/detail?productId=1&selectedId=2573',
    },

    tips: {
      type: String,
    },

    placement: {
      type: String,
      default: 'right',
    },

    storageVisibleKey: {
      type: String,
      default: '',
    },

    className: {
      type: String,
    },

    isInPage: {
      type: Boolean,
    },
  },

  data() {
    let isShow = false
    const { storageVisibleKey } = this
    if (window.localStorage && storageVisibleKey) {
      // isShow = !window.localStorage.getItem(storageVisibleKey);
      // window.localStorage.setItem(storageVisibleKey, 'shown');
    }
    return {
      isShow,
    }
  },
  created() {
    if (this.isTipsShow && this.storageVisibleKey === 'requirement_tips') {
      this.$store.commit('updateRequireTipsShown', true)
    }
  },
  computed: {
    isVisited() {
      return this.$store.state.newVersionAlert.isVisited
    },
    isTipsShow: {
      get() {
        return !this.isVisited && this.isShow
      },
      set(val) {
        this.isShow = val
      },
    },
  },

  watch: {
    isVisited() {
      this.updatePopper()
    },
  },

  mounted() {
    this.updatePopper()
  },
  methods: {
    updatePopper() {
      !this.isVisited &&
        this.$nextTick(() => {
          this.$refs.pop.updatePopper()
        })
    },
    gotoDetailLink() {
      window.open(this.actionUrl)
      this.isShow = false
    },
    hide() {
      this.isShow = false
      this.$emit('hide')
    },
  },
}
</script>

<style scoped>
.function-guide-tips__footer {
  text-align: right;
}
</style>
<style>
.in-page.el-popover {
  z-index: 1098 !important;
}
.guide-pop {
  border-radius: 6px;
  padding: 10px 20px 4px;
}
.pop-content {
  padding-top: 4px;
  font-size: 12px;
  color: #666;
}
</style>
