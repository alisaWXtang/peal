<template>
  <el-cascader
    v-model="currentSelect"
    :options="options"
    filterable
    collapse-tags
    :placeholder="$t('请选择部门')"
    v-bind="$attrs"
    :filter-method="filterMethod"
    @change="onChange"
    @visible-change="onVisible"
    popper-class="department-cascader__popper--custom"
  ></el-cascader>
</template>
<script>
/**
 * @title 部门级联选择器
 * @author wuqian
 * @date 2020.10.16
 */
export default {
  name: "DepartmentCascader",
  components: {},
  model: {
    prop: "value",
    event: "change",
  },
  props: {
    value: {
      type: [Array, String],
    },
    resetZIndexSelectors: {
      type: Array,
      default: () => [],
    }
  },
  data() {
    return {
      currentSelect: null,
      options: [],
      elementsZIndexMap: null,
      componentSelector: '.department-cascader__popper--custom',
    };
  },
  computed: {
    departmentTree() {
      return this.$store.state.departmentCascader.departmentTree
    }
  },
  watch: {
    value() {
      this.currentSelect = this.value;
    },
    departmentTree: {
      handler: function() {
        this.options = [...this.departmentTree];
      },
      immediate: true,
    }
  },
  created() {
    this.currentSelect = this.value;
  },
  mounted() {
    this.$store.dispatch("getDepartmentTreeForAll")
  },
  methods: {
    onChange() {
      this.$emit("change", this.currentSelect);
    },
    filterMethod(node, keyword) {
      const labels = node.pathLabels
      const isInclude = () => {
        let result = false;
        for(let i = 0; i < labels.length; i++) {
          if(labels[i].includes(keyword)) {
            result = true;
            break;
          }
        }
        return result;
      }
      if (isInclude()) {
        node.text = labels.join('/');
        return true
      }
    },
    onVisible(visible) {
      if (this.resetZIndexSelectors?.length) {
        if (visible) {
          this.$nextTick(() => {
            // 打开弹窗时 根据当前组件popover z-index 动态设置 resetZIndexSelectors 节点元素的 z-index
            this.manageElZIndex()
          })
        } else {
          // 重置被设置元素的 z-index
          this.recoveryElZIndex()
        }
      }
    },
    // 控制弹窗层级
    manageElZIndex() {
      this.elementsZIndexMap = this.getElmentsZIndex(this.resetZIndexSelectors)
      const targetSelector = this.componentSelector
      const targetZIndex = document.querySelector(targetSelector)?.style?.zIndex
      this.resetZIndexSelectors.forEach(selector => {
        if (selector === targetSelector) return
        this.setElementZIndex(selector, Number(targetZIndex) + 1000);
      })
    },
    getElmentsZIndex(selectors = []) {
      const elZIndexMap = {}
      selectors.forEach(selector => {
        const zIndex = document.querySelector(selector)?.style?.zIndex;
        if (zIndex != null) {
          elZIndexMap[selector] = zIndex
        }
      })
      return elZIndexMap
    },
    setElementZIndex(selector, zIndex) {
      const el = document.querySelector(selector)
      if (el && zIndex != null) {
        el.style.zIndex = zIndex
      }
    },
    recoveryElZIndex() {
      const exceptedSelector = this.componentSelector
      this.resetZIndexSelectors.forEach(selector => {
        if (selector === exceptedSelector) return
        this.setElementZIndex(selector, this.elementsZIndexMap[selector]);
      })
    }
  },
};
</script>
<style lang='scss'>
.department-cascader__popper--custom {
  .el-cascader-menu__wrap {
    height: 400px;
  }
}
</style>