<template>
  <div class="left-col-select__container">
    <div class="filter-list" :style="{ 'max-height': toPx(maxHeight) }">
      <template v-for="item in data">
        <div
          class="filter-list__item"
          :class="{ 'filter-list__item--active': item.id === actived }"
          :key="item.id"
          @click.stop="handlerItemClick(item.id)"
        >
          {{ $t(item.title) }}
        </div>
      </template>
    </div>
  </div>
</template>
<script>
/**
 * @title 反馈 - 两栏布局左侧选择器
 * @author wuqian
 * @date 2020.6.15
 * @props
 *    data 选择器列表
 *      id 选项id
 *      title 选项名
 *    default-active 默认选中id
 * @events
 *    change 选中值发生变化时触发
 */
export default {
  name: 'LeftColSelect',
  components: {},
  data() {
    return {
      actived: null,
    }
  },
  props: {
    data: {
      type: Array,
      default: () => [],
    },
    maxHeight: {
      type: [String, Number],
    },
    defaultActive: [String, Number],
  },

  computed: {},
  watch: {
    defaultActive(val) {
      this.actived = val
    },
  },

  created() {
    this.actived = this.defaultActive
  },
  mounted() {},
  methods: {
    toPx(value) {
      if (!value) return 'auto'
      if (!/px$/i.test(value.toString())) {
        value += 'px'
      }
      return value
    },
    handlerItemClick(id) {
      if (this.actived === id) return
      this.actived = id
      this.$emit('change', id)
    },
  },
}
</script>
<style lang="scss" scoped>
.left-col-select__container {
  padding: 12px;
  .filter-list {
    overflow-y: auto;
    .filter-list__item {
      cursor: pointer;
      padding: 16px 10px;
      line-height: 14px;
      font-size: 14px;
      border-radius: 4px;
      &:hover {
        background: #e2e9ef;
        border-radius: 4px;
      }
      &.filter-list__item--active {
        &:hover {
          color: #ffffff;
          background: $--color-primary;
        }
      }
    }
    .filter-list__item--active {
      color: #ffffff;
      background: $--color-primary;
    }
  }
}
</style>
