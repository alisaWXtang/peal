<template>
  <el-dialog
    :visible.sync="isVisible"
    :title="$t('复制项目成员')"
    custom-class="dialog-noanimate"
    width="1200px"
    :modal-append-to-body="false"
    :before-close="closeModal"
  >
    <div class="clone-content-box">
      <div class="left-content">
        <el-input
          v-model="localFilterName"
          :placeholder="$t('请输入项目名称')"
          class="project-filter"
        ></el-input>
        <select-list
          class="select-list"
          :listData="projectList"
          :activeObj="activeProject"
          :clickCallback="setActiveItem"
        ></select-list>
      </div>
      <div class="right-content">
        <div class="right-content-top">
          <el-row type="flex" justify="space-between">
            <el-col
              class="top-content-left"
              :class="{ 'top-content-left-english': $isEnglish() }"
            >
              <el-row>
                <el-col :span="4" class="person-table-title">{{
                  $t('人员预览')
                }}</el-col>
                <el-col :span="8"
                  ><el-input
                    :placeholder="$t('请输入人员')"
                    @input="searchPerson"
                    v-model="searchPersonVal"
                  ></el-input
                ></el-col>
                <el-col :span="10" class="person-role-content">
                  <el-select
                    v-model="searchPersonRole"
                    multiple
                    :placeholder="$t('请选择角色')"
                    collapse-tags
                    @change="handlePersonRoleChange"
                  >
                    <el-option
                      v-for="item in roleOptions"
                      :key="item.roleId"
                      :label="item.roleName"
                      :value="item.roleId"
                    >
                    </el-option>
                  </el-select>
                </el-col>
              </el-row>
            </el-col>
            <el-col
              class="top-content-right"
              :class="{ 'top-content-right-english': $isEnglish() }"
            >
              <span>{{ $t('导入角色') }}</span>
              <el-switch v-model="importRoles"></el-switch>
              <el-button
                type="primary"
                @click="copyProjectPerson"
                :disabled="loadingObject.posting"
                >{{
                  loadingObject.posting ? '导入中...' : $t('导入')
                }}</el-button
              >
            </el-col>
          </el-row>
        </div>

        <div style>
          <el-table
            ref="personTable"
            :border="true"
            :data="personnelManagementData.results"
            style="width: 100%;height: 100%;"
            v-loading="loadingObject.getting"
            @select="handleSelectionChange"
            @select-all="handleSelectionAll"
            :max-height="tableHeight"
          >
            <el-table-column type="selection" width="55"> </el-table-column>
            <el-table-column
              prop="userName"
              :label="$t('人员')"
              min-width="120"
            >
              <template slot-scope="scope">{{
                scope.row.userName + '(' + scope.row.userId + ')'
              }}</template>
            </el-table-column>
            <!-- <el-table-column prop :label="$t('来自服务')" min-width="120">
              <template slot-scope="scope">
                <span>{{ fromBusiness(scope.row) }}</span>
              </template>
            </el-table-column> -->
            <el-table-column :label="$t('角色')" min-width="180">
              <template slot-scope="scope">{{
                arrayJoiner(scope.row.roles)
              }}</template>
            </el-table-column>
          </el-table>
        </div>
      </div>
    </div>
  </el-dialog>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 工作流复制组件
 * @desc 每次打开 modal 时会恢复初始状态
 * @author chenxuecheng,wangling
 * @date 2019.6.24
 * @date 2020/5/21  wangling修改
 */
import { mapState } from 'vuex'
import SelectList from '@/components/select-list'
import {
  projectManagementStaffList,
  projectManagementStaffCopyList,
} from '@/service/project'
import { workStautsFowWithStaff } from '@/service/work-status-flow'
import { authRoleList } from '@/service/auth-custom'

export default {
  name: 'personClone',
  components: {
    SelectList,
  },

  mixins: [],
  props: {
    visible: {
      type: Boolean,
      required: true,
    },

    closeModal: {
      type: Function,
      required: false,
    },

    projectId: {
      type: [String, Number],
      required: false,
      desc: '项目 id',
    },

    type: {
      type: String,
      required: false,
      default: 'Personnel',
      desc:
        '目前有两个地方用到：设置人员管理(personnel), 管理看板成员视图(member)',
    },
  },

  data() {
    return {
      isVisible: false,
      loadingObject: {
        getting: false, //整体弹窗loading
        posting: false, //导出按钮loading
      },
      personnelManagementData: {
        results: [],
        pageInfo: { pageNum: 1, pageSize: 10 },
        total: 0,
        pages: 0,
      },

      localFilterName: '', // 本地过滤
      // 过滤器
      filterInfo: {
        name: '', // 项目名称
        type: 'PROJECT', // 项目类型 PROJECT->我的项目 PUBLIC->公开的项目
      },
      // 项目列表 - 左侧
      workFlowProjectList: [],
      activeProject: { key: -1, value: null },
      importRoles: true, // 是否导入角色信息
      searchPersonVal: '', // 查询人员的值
      requiredPersonInfo: [], // 需要的导入人员信息
      searchPersonRole: [], // 成员角色
      roleOptions: [], // 角色列表
      isSelectAll: true, // 是否选中全选
    }
  },
  computed: {
    projectList() {
      if (!this.localFilterName.trim().length) {
        return this.workFlowProjectList
      }
      return this.workFlowProjectList.filter(
        item => item.value.indexOf(this.localFilterName.trim()) !== -1,
      )
    },
    projectListAll() {
      return this.$store.state.pf.ProjectListAll
    },
    tableHeight() {
      return window.innerHeight - 380
    },
  },

  watch: {
    // 当打开 modal 的时候，需要获取数据 - data cache
    visible(value) {
      this.isVisible = value
      if (value) {
        this.requestProjectList()
        this.activeProject.value && this.queryPersonnelManagement() // 再次弹出导入成员弹框需刷新成员列表
      } else {
        this.resetInfo()
      }
    },
    isVisible(newVal) {
      this.$emit('update:visible', newVal)
    },
    // 当切换 type 的时候，需要清空数据
    workItemType() {
      this.workFlowProjectList = []
    },
    // 当切换 activeProject 时，需要更新右侧数据
    activeProject() {
      this.personnelManagementData.pageInfo.pageNum = 1
      this.queryPersonnelManagement()
    },
    projectListAll(projectList) {
      if (this.type === 'member') {
        this.addAttrsProjectList(projectList)
      }
    },
  },

  mounted() {},
  methods: {
    //得到项目列表
    requestProjectList() {
      switch (this.type) {
        case 'member':
          this.getAllProjectList()
          break
        case 'personnel':
          this.getProjectList()
          break
      }
    },
    //复制项目成员
    queryPersonnelManagement(params) {
      projectManagementStaffList({
        projectId: this.activeProject.id,
        pageInfo: {
          pageNumber: this.personnelManagementData.pageInfo.pageNum,
          pageSize: 100,
        },

        query: params?.query || '',
        roleIds: params?.roleIds || [],
      }).then(res => {
        const data = res.data
        this.personnelManagementData.results = data?.results
        this.personnelManagementData.total = data?.pageInfo.totalRecords
        this.requiredPersonInfo = data?.results.map(data => data.userId)
        this.$nextTick(() => {
          this.$refs.personTable.toggleAllSelection() // 默认全部选中
        })
      })
    },
    // 分页 size变化
    handleOpsSizeChange(val) {
      this.personnelManagementData.pageInfo.pageNum = 1
      this.personnelManagementData.pageInfo.pageSize = val
      this.queryPersonnelManagement()
    },
    // 分页 页数改变
    handleOpsCurrentChange(val) {
      this.personnelManagementData.pageInfo.pageNum = val
      this.queryPersonnelManagement()
    },
    // 设置->人员管理 点击导入
    async requestCopyProjectPersonnel() {
      let isAll = false // 是否全部选中
      if (this.searchPersonRole.length === 0 && this.searchPersonVal === '') {
        const originList = this.personnelManagementData.results.map(
          item => item.userId,
        )

        isAll = this.requiredPersonInfo.length === originList.length
      }

      const ProjectUserQueryCopyRO = {
        projectId: this.projectId,
        fromProjectId: this.activeProject.id,
        importRoles: this.importRoles,
        userIds: this.requiredPersonInfo,
        pageInfo: null,
        query: this.searchPersonVal,
        isAll: isAll || false,
      }

      let result = { status: 0 }
      try {
        result = await projectManagementStaffCopyList(ProjectUserQueryCopyRO)
      } catch (error) {
        console.log(error)
      }
      this.importRoles = true
      return result
    },
    // 管理看板->成员总览 点击导入
    requestCopeProjectMember() {
      return this.$store.dispatch('copeMemberTeam', {
        projectId: this.activeProject.id,
        teamId: this.$store.state.manageViewMember.filterInfo.teamId,
      })
    },
    //点击导入  发送请求 复制项目成员
    async copyProjectPerson() {
      this.loadingObject.posting = true
      let result = {}
      switch (this.type) {
        case 'personnel':
          result = await this.requestCopyProjectPersonnel()
          break
        case 'member':
          result = await this.requestCopeProjectMember()
          break
      }

      if (result.status === 200) {
        this.$message({
          type: 'success',
          message: i18n.t('复制成功'),
        })
        this.closeModal && this.closeModal()
        this.$emit('updatePerson')
        // 关闭弹窗
        this.$emit('update:visible', false)
      }
      this.loadingObject.posting = false
    },
    // 重置基本信息
    resetInfo() {
      this.localFilterName = ''
      this.searchPersonVal = '' // 清空人员信息查询框
      this.searchPersonRole = [] // 清空角色筛选框
    },
    // 为项目列表添加 key,value属性以及设置默认选中的项目列表
    addAttrsProjectList(list = []) {
      this.workFlowProjectList = list.map(item => {
        return {
          key: item.id,
          value: item.name,
          ...item,
        }
      })
      if (this.activeProject.key < 0 && this.workFlowProjectList.length > 0) {
        this.setActiveItem(this.workFlowProjectList[0])
      }
    },
    // 获取全部项目列表
    async getAllProjectList() {
      this.loadingObject.getting = true
      await this.$store.dispatch('getProjectListAll')
      this.loadingObject.getting = false
    },
    // 获取排除当前项目的项目列表数据
    async getProjectList() {
      this.loadingObject.getting = true
      const result = await workStautsFowWithStaff({
        projectId: +this.projectId,
        workItemType: +this.workItemType || 1,
        ...this.filterInfo,
      })

      if (result.status === 200) {
        this.addAttrsProjectList(result?.data)
      } else {
        this.workFlowProjectList = []
      }
      this.loadingObject.getting = false
    },
    // 设置当前活跃工作流
    setActiveItem(item) {
      this.getRoleOptions(item.id)
      this.searchPersonVal = '' // 清空人员信息查询框
      this.searchPersonRole = [] // 清空角色筛选框
      this.activeProject = { ...item }
    },
    arrayJoiner(inputArray = []) {
      return inputArray.map(item => item.roleName).join(',')
    },

    fromBusiness(row) {
      return row.fromBiz ? i18n.t('是') : i18n.t('否')
    },
    //查询结果
    searchPerson(val) {
      this.queryPersonnelManagement({ query: val })
    },
    // 人员选择多选
    handleSelectionChange(val, row) {
      this.isSelectAll = false
      this.requiredPersonInfo = val.map(data => data.userId)
    },
    handleSelectionAll(row) {
      this.isSelectAll = row.length > 0
    },
    //人员角色改变
    handlePersonRoleChange(val) {
      this.queryPersonnelManagement({ roleIds: val })
    },
    //获取成员角色列表
    async getRoleOptions(val) {
      const result = await authRoleList({
        projectId: +val,
      })

      this.roleOptions = result?.data
    },
  },
}
</script>
<style lang="scss" scoped>
.clone-content-box {
  font-size: 0;
  width: 100%;
  background: $color-background-light-common;
  padding: 10px;
  box-sizing: border-box;
}

.left-content,
.right-content {
  display: inline-block;
  vertical-align: top;
  font-size: 14px;
  box-sizing: border-box;
  padding: 10px;
  background: white;
}

.left-content {
  width: 260px;
  .select-list {
    height: 565px;
    overflow-y: auto;
  }
  .filter-type {
    margin: 10px 0;
  }
  .project-filter {
    padding-bottom: 5px;
  }
}

.right-content {
  width: calc(100% - 270px);
  margin-left: 10px;
}

.right-content-top {
  padding-bottom: 5px;
  .top-content-left {
    width: 420px;
    .person-role-content {
      margin-left: 3px;
    }
  }
  .top-content-left-english {
    width: 640px;
  }
  .top-content-right {
    width: 190px;
  }
  .top-content-right-english {
    width: 210px;
  }
  .person-table-title {
    line-height: 28px;
  }
}
</style>
