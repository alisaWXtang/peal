<template>
  <div class="more-dropdown-wrapper">
    <co-dropdown @command="handleCommand">
      <co-button suffix-icon="co-icon-arrow-down"
        >{{ dropDownTitle }}
      </co-button>
      <co-dropdown-menu slot="dropdown">
        <div v-if="dropDownList.length">
          <co-dropdown-item
            v-for="item in dropDownList"
            :key="item.type"
            :command="item.type"
            >{{ item.typeName }}</co-dropdown-item
          >
        </div>
      </co-dropdown-menu>
    </co-dropdown>
  </div>
</template>

<script>
import { i18n } from '@/i18n'
/** 工作项更多下拉菜单
 * @author liufeng
 * @date 2020.04.28
 */
export default {
  name: 'MoreDropdown',
  components: {},
  mixins: [],
  props: {
    dropDownList: {
      type: Array,
      require: true,
      desc: i18n.t('下拉列表项'),
    },

    dropDownTitle: {
      type: String,
      require: false,
      default() {
        return this.$t('更多')
      },
      desc: i18n.t('下拉列表标题'),
    },
  },

  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {
    handleCommand(type) {
      this.$emit('handleMoreCommand', type)
    },
  },
}
</script>

<style lang="scss" scoped>
.more-dropdown-wrapper {
  margin: 0 15px;
  /deep/ .el-button {
    span + .co-icon-arrow-down {
      margin-left: 4px;
    }
  }
}
</style>
