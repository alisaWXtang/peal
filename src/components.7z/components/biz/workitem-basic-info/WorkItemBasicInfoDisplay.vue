<template>
  <div class="workitem-basic-info-box">
    <template v-for="item in fieldList">
      <div
        class="workitem-basic-info-item"
        :key="item.key"
        v-if="item.readonly"
      >
        <ellipsis-block
          class="workitem-basic-info-item-label ellipsis-pure"
          :value="item.fieldName + ':'"
          :class="{
            'workitem-basic-info-item-label-pre': item.required,
            'workitem-basic-info-item-label-english': $isEnglish(),
          }"
        ></ellipsis-block>
        <span
          class="hover-basic-info-item-static workitem-basic-info-item-readonly"
          style="
            width: calc(100% - 123px);
            display: inline-block;
            margin-left: 10px;
          "
          :style="{
            width: $isEnglish() ? 'calc(100% - 158px)' : 'calc(100% - 123px)',
          }"
          >{{ item.fieldEditProps.initName }}</span
        >
      </div>
      <template v-else>
        <!-- 1. 特殊字段处理 - 父需求 -->
        <div
          class="workitem-basic-info-item"
          :key="item.key"
          v-if="item.attrName === 'parentId' || item.attrName === 'requireId'"
        >
          <ellipsis-block
            class="workitem-basic-info-item-label ellipsis-pure"
            :value="`${+workItemType === 3 ? $t('所属需求') : $t('父需求')}:`"
            :class="{
              'workitem-basic-info-item-label-pre': item.required,
              'workitem-basic-info-item-label-english': $isEnglish(),
            }"
          ></ellipsis-block>
          <span
            style="width: calc(100% - 96px);display: inline-block"
            @mouseover="deleteParentRequire = true"
            @mouseout="deleteParentRequire = false"
          >
            <span
              v-if="workItemDetail.display.parentTitle&&workItemDetail.display.parentTitle!=='--'"
              class="workitem-basic-info-item-select-width work-item-hover pRWidth"
              style="display: inline-block; margin-left: 10px;padding: 0 5px;"
            >
              <span
                class="hover-basic-info-item-static hoverColor"
                style="padding: 0 5px;"
                @click="parentRequirement(workItemDetail.rawData.parentId||workItemDetail.rawData.requireId)"
                >{{
                  workItemDetail.display.parentTitle
                }}</span
              >
            </span>
            <span
              v-else
              class="workitem-basic-info-item-select-width work-item-hover pRWidth"
              style="display: inline-block; margin-left: 10px;padding: 0 5px;"
            >
              <span
                class="hover-basic-info-item-static"
                style="padding: 0 5px;"
                @click="ChangeFatherRquireFuc"
                >{{ '--'
                }}</span
              >
            </span>
            <i 
              v-show="
                deleteParentRequire &&
                  (workItemDetail.rawData.parentId > 0 ||
                    workItemDetail.rawData.requireId > 0) &&
                  !item.required
              "
              class="el-icon-search link-common ml10"
              style="position: relative; top: 5px"
              @click="ChangeFatherRquireFuc"
            ></i>
            <i
              v-show="
                deleteParentRequire &&
                  (workItemDetail.rawData.parentId > 0 ||
                    workItemDetail.rawData.requireId > 0) &&
                  !item.required
              "
              class="el-icon-delete link-common ml10"
              @click.stop="deleteParentRequireFuc"
              style="position: relative; top: 5px"
            ></i>
          </span>
        </div>
        <!-- 2. 特殊字段处理 - 状态 -->
        <div
          class="workitem-basic-info-item"
          :key="item.key"
          v-else-if="item.attrName === 'statusId'"
        >
          <ellipsis-block
            class="workitem-basic-info-item-label ellipsis-pure"
            :value="$t('状态') + ':'"
            :class="{
              'workitem-basic-info-item-label-pre': item.required,
              'workitem-basic-info-item-label-english': $isEnglish(),
            }"
          ></ellipsis-block>
          <div
            class="workitem-basic-info-item-select-width"
            style="display: inline-flex"
            :class="{
              'workitem-basic-info-item-select-width-english': $isEnglish(),
            }"
          >
            <state-flow
              :current-index="0"
              :projectId="projectId || $getUrlParams().projectId"
              :statusId="workItemDetail.rawData.statusId"
              :workItemType="workItemType"
              :workItemId="workItemDetail.detail.id"
              :updateData="refreshData"
            >
              <span
                class="bug-basic-info-item-static editable-field cursor-pointer status_name"
                v-html="
                  initNameStatus(
                    workItemDetail.detail && workItemDetail.detail.status.color,
                    workItemDetail.display.status,
                  )
                "
              >
              </span>
            </state-flow>
            <work-flow-chart :transfers="statusChartTransfers">
              <i
                class="iconfont icon-jurassic_process view-workflow"
                :title="$t('查看工作流')"
                @click="getWorkFlow"
              ></i>
            </work-flow-chart>
          </div>
        </div>
        <!-- 3. 特殊字段处理 - 优先级 -->
        <div
          class="workitem-basic-info-item"
          :key="item.key"
          v-else-if="item.attrName === 'priority'"
        >
          <ellipsis-block
            class="workitem-basic-info-item-label ellipsis-pure"
            :value="item.fieldName + ':'"
            :class="{
              'workitem-basic-info-item-label-pre': item.required,
              'workitem-basic-info-item-label-english': $isEnglish(),
            }"
          ></ellipsis-block>
          <field-edit
            v-bind="item.fieldEditProps"
            :showOuterBorder="false"
            :initName="
              initNameStatus(
                workItemDetail.detail.priority.color,
                workItemDetail.display.priority,
              )
            "
            class="workitem-basic-info-item-select-width"
            :class="{
              'workitem-basic-info-item-select-width-english': $isEnglish(),
            }"
            @FieldEditFieldClick="getSelectOptionList(item)"
            :onChange="
              value => {
                updateInfoWhenShow(item, value)
              }
            "
            colorType="bg"
          ></field-edit>
        </div>
        <!-- 4. 特殊字段处理 - 需求分类  -->
        <div
          class="workitem-basic-info-item"
          :key="item.key"
          v-else-if="item.attrName === 'categoryId'"
        >
          <ellipsis-block
            class="workitem-basic-info-item-label ellipsis-pure"
            :value="item.fieldName + ':'"
            :class="{
              'workitem-basic-info-item-label-pre': item.required,
              'workitem-basic-info-item-label-english': $isEnglish(),
            }"
          ></ellipsis-block>
          <div
            v-if="categoryChoice.isShow"
            @click.capture="changeRequireCategory($event)"
            class="current-category-hover"
          >
            <span>{{
              requierCategoryValue
                ? requierCategoryValue
                : item.fieldEditProps.initName
            }}</span>
          </div>
          <el-cascader
            v-if="!categoryChoice.isShow"
            :options="options"
            class="category-cascader workitem-basic-info-item-select-width"
            ref="cascader"
            :value="
              requierCategoryValue
                ? String(requierCategoryId)
                : String(item.fieldEditProps.initValue)
            "
            @visible-change="cancelCategoryChange"
            :props="{ checkStrictly: true, emitPath: false }"
            :show-all-levels="false"
            @change="handleChange"
          >
          </el-cascader>
        </div>
        <div class="workitem-basic-info-item" :key="item.key" v-else>
          <ellipsis-block
            class="workitem-basic-info-item-label ellipsis-pure"
            :value="item.fieldName + ':'"
            :class="{
              'workitem-basic-info-item-label-pre': item.required,
              'workitem-basic-info-item-label-english': $isEnglish(),
            }"
          ></ellipsis-block>
          <field-edit
            v-bind="item.fieldEditProps"
            style="max-width: calc(100% - 105px)"
            class="workitem-basic-info-item-select-width"
            :class="{
              'workitem-basic-info-item-select-width-english': $isEnglish(),
            }"
            @FieldEditFieldClick="getSelectOptionList(item)"
            :onChange="
              value => {
                if (item.fieldEditProps.multiple) {
                  return
                }
                updateInfoWhenShow(item, value)
              }
            "
            @inactive="
              value => {
                if (!item.fieldEditProps.multiple) {
                  return
                }
                updateInfoWhenShow(item, value)
              }
            "
          ></field-edit>
        </div>
      </template>
    </template>
    <slot name="footer"></slot>
    <div
      class="workitem-basic-info-item"
      v-if="fieldListAll.length > currentFieldCount"
    >
      <el-button
        type="text"
        @click="customHandle"
        style="padding-left: 0 !important"
        >{{ fieldShowAll ? $t('收起') : $t('更多字段') }}</el-button
      >
    </div>
    <slide
      :show="parentrequirementShow"
      :after-close="contextmenuNone"
    >
      <div slot="task" class="silder-box">
        <RequirementDetail
          :showBack="true"
          ref="requrire"
          :show="parentrequirementShow"
          :projectId="projectId||$getUrlParams().projectId"
          :workItemId="requiredId"          
          @HandleSide="contextmenuNone"
        ></RequirementDetail>
      </div>
    </slide>    
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 工作项基本信息组件 - 新建
 * @desc 需求、任务、缺陷基本信息通用，新建时基于模板新建，编辑时，根据基本信息详情 + 全局缓存字段信息
 * @function 1. 支持新建时 v-model 双向更新
 * @function 2. 支持过长收起
 * @function 3. 支持 slot 嵌入
 * @author heyunjiang
 * @date 2020.3.24
 */
import FieldEdit from '@/components/field-edit'
import StateFlow from '@/components/state-flow'
import workFlowChart from '@/components/project/WorkFlowChart'
import StatusChartCommonMixin from '@/mixin/statusChartCommonMixin'
import { isEmpty } from '@/utils'
import { queryOptions } from '@/service/work-status-flow'
import { getUserList } from '@/service/project'
import { priorityList } from '@/service/bug'
import * as requirementCategoryService from '@/service/requirement-category'
import * as requirementService from '@/service/requirement'
import slide from '@/components/slide-slip'
import { RequirementDetail } from '@/components/columbus-workitem-display'

// import GlobalUserSelect from '@/components/global-user-select/src/GlobalUserSelect';
const attrValueToInputTypeMap = {
  SINGLE_TEXT: 'text',
  MULTI_TEXT: 'textarea',
  MEMBER_CHOICE: 'select',
  MULTI_MEMBER_CHOICE: 'select',
  LITE_DATE_ATTR: 'date',
  BOOLEAN_ATTR: 'select',
  INT_ATTR: 'number',
  FLOAT_ATTR: 'number',
  SINGLE_CHOICE: 'select',
  MULTI_CHOICE: 'select',
}

// 工作项类型对象
const WorkItemTypeObj = {
  requirement: 1,
  task: 2,
  bug: 3,
}

export default {
  name: 'WorkItemBasicInfoDisplay',
  components: {
    FieldEdit,
    StateFlow,
    workFlowChart,
    slide,
    RequirementDetail
  },

  mixins: [StatusChartCommonMixin],
  props: {
    projectId: {
      type: [String, Number],
      required: true,
    },

    workItemType: {
      type: [String, Number],
      required: true,
      desc: i18n.t('工作项类型'),
    },

    workItemDetail: {
      type: Object,
      required: true,
      desc: i18n.t('工作项详情'),
    },
  },

  data() {
    return {
      requierCategoryValue: '',
      requierCategoryId: '',
      categoryChoice: {
        value: '',
        isShow: true,
      },
      requiredId:'',
      parentrequirementShow:false,
      options: [],
      currentFieldCount: 17, // 当前展示的字段个数
      fieldShowAll: false,
      fieldListAll: [], // 基本信息所有字段
      deleteParentRequire: false, // 是否展示删除父需求字段
      lastUpdateField: null, // 最近一次更新的字段信息
      assignUserChoice: {
        value: '',
        isShow: false,
      },
      isTemplateUpdate: false,
    }
  },
  created() {},
  computed: {
    // 当前展示的基本信息列表
    fieldList() {
      if (this.fieldShowAll) {
        return this.fieldListAll
      } else {
        return this.fieldListAll.slice(0, this.currentFieldCount)
      }
    },
    // 当前基本信息的所有字段描述信息
    workItemAllBasicAttrList() {
      return this.$store.state.pf.workItemAllBasicAttrList[
        this.$store.state.pf.workItemTypeMap[this.workItemType]
      ]
    },
  },

  watch: {
    workItemAllBasicAttrList() {
      this.initList()
    },
    workItemDetail() {
      this.initList()
    },
    projectId() {
      this.initList(true)
    },
    'assignUserChoice.isShow': {
      handler: function(newVal) {
        if (newVal) {
          this.$nextTick(() => {
            this.$refs.globalUserSelect[0].$children[0].focus()
            // 解决选择后点击不可聚焦问题
            this.$refs.globalUserSelect[0].$children[0].visible = true
          })
        }
      },
    },
  },

  mounted() {
    this.initList()
  },
  methods: {
    // 获取工作项基本信息字段列表
    async initList(forceupdate = false) {
      if (
        +this.projectId !== +this.$store.state.pf.ProjectId ||
        Object.keys(this.workItemAllBasicAttrList.systemAttrs).length === 0 ||
        forceupdate && !this.isTemplateUpdate
      ) {
        await this.$store.dispatch({
          type: 'initProjectWorkItemAllBasicAttrs',
          payload: {
            projectId: this.projectId,
            workItemType: this.workItemType,
          },
        })

        this.isTemplateUpdate = true

        return
      }
      this.fieldListAll = this.setFieldInitData()
      this.$forceUpdate()
      this.getRequirementCategory()
    },
    changeRequireCategory($event) {
      this.categoryChoice.isShow = false
      this.$nextTick(() => {
        document.elementFromPoint($event.clientX, $event.clientY).click()
      })
    },
    cancelCategoryChange(isVisibleChange) {
      if (!isVisibleChange) {
        this.categoryChoice.isShow = true
      }
    },
    async handleChange() {
      let categoryData = this.$refs['cascader'][0].getCheckedNodes()[0].data
      await requirementService.update({
        id: this.workItemDetail.detail.id,
        categoryId: categoryData.categoryId,
      })
      this.$message({
        message: i18n.t('更新成功'),
        type: 'success',
      })
      this.categoryChoice.isShow = true
      this.requierCategoryValue = categoryData.label
      this.requierCategoryId = categoryData.value //绑定id唯一值显示cascader
      this.refreshData()
    },
    parentRequirement(val){
      this.parentrequirementShow = true
      this.requiredId = val
    },
    contextmenuNone(){
      this.parentrequirementShow = false
    },
    transferHandler(){

    },
    getRequirementCategory() {
      let projectId = this.$getUrlParams().projectId || this.projectId
      requirementCategoryService.tree({ projectId }).then(res => {
        if (!res.data) {
          return
        }
        this.options = (function f(list) {
          return list.map(({ label, children, id }) => ({
            label,
            value: String(id),
            categoryId: id,
            children: children.length === 0 ? null : f(children),
          }))
        })(res.data)
      })
    },
    // 将 workItemDetail 转换成 list
    _generateBasicList() {
      const { rawData, display, meta = {} } = this.workItemDetail
      const {
        systemAttrs = {},
        userDefinedAttrs = {},
      } = this.workItemAllBasicAttrList
      const attrsObj = {
        ...systemAttrs,
        ...userDefinedAttrs,
      }

      const fields = meta.fields || []
      let isAttrPoorUpdate = false // 是否模板更新了字段
      const result =
        fields.map(({ attrName, required, fieldName }) => {
          const item = attrName
          // 如果缺少字段，表示模板更新了
          if (!attrsObj[item]) {
            isAttrPoorUpdate = true
            attrsObj[item] = {}
          }
          let initName = display[attrsObj[item].displayAttrName || item]
          initName = isEmpty(initName) ? '' : initName
          initName = Array.isArray(initName) ? initName.join(',') : initName
          initName = ['actualHour', 'expectHour'].includes(item)
            ? String(initName) + 'h'
            : String(initName)
          return {
            ...attrsObj[item],
            fieldName,
            required,
            key: attrsObj[item].attrName,
            initValue:
              rawData[item] === null
                ? this.$store.state.cm.customFieldInitTypeMap[
                    attrsObj[item].attrValue
                  ]
                : rawData[item],
            initName,
          }
        }) || []
      if (isAttrPoorUpdate && !this.isTemplateUpdate) {
        this.initList(true)
        return []
      }
      return result
    },
    // 根据模板设置字段 fieldEditProps 属性 - 展示
    setFieldInitData() {
      // 自定义字段可清空的类型
      const needClearableAttr = [
        'SINGLE_CHOICE',
        'INT_ATTR',
        'FLOAT_ATTR',
        'BOOLEAN_ATTR',
        'MEMBER_CHOICE',
        'SINGLE_TEXT',
      ]

      // 任务默认模板中“预计工时、实际工时、进度”需做清空功能
      const needClearableFunInTaskTemp = [
        'expectHour',
        'actualHour',
        'progress',
      ]

      const fieldListAll = this._generateBasicList()
      const result = []
      fieldListAll.forEach(item => {
        const fieldEditProps = {}
        const ismultiple = ['MULTI_CHOICE', 'MULTI_MEMBER_CHOICE'].includes(
          item.attrValue,
        )
        const surportLocalSearch = [
          'MEMBER_CHOICE',
          'MULTI_MEMBER_CHOICE',
          'SINGLE_CHOICE',
        ].includes(item.attrValue)

        fieldEditProps.initValue = item.initValue
        fieldEditProps.initName = item.initName
        fieldEditProps.inputType =
          item.attrName === 'progress'
            ? 'progress'
            : attrValueToInputTypeMap[item.attrValue]
        fieldEditProps.attrValueType = item.attrValue
        fieldEditProps.selectValue = []
        fieldEditProps.multiple = ismultiple
        fieldEditProps.localSearch = surportLocalSearch
        fieldEditProps.isClearable =
          (needClearableAttr.includes(item.attrValue) && item.userDefined) ||
          (this.workItemType === WorkItemTypeObj.task &&
            needClearableFunInTaskTemp.includes(item.attrName))
        fieldEditProps.attrName = item.attrName
        item.fieldEditProps = fieldEditProps
        result.push(item)
      })
      return result
    },
    // 获取字段可选择值列表列表 - 在 for 循环里面执行 async 的一个场景
    async getSelectOptionList(field) {
      // 1. 如果不是 select 类型的，则跳过
      if (attrValueToInputTypeMap[field.attrValue] !== 'select') {
        return
      }
      // 2. 如果是人员选择，则去拿人员选择数据
      if (['MEMBER_CHOICE', 'MULTI_MEMBER_CHOICE'].includes(field.attrValue)) {
        this.getAssignUsersList(field)
        return
      }
      // 3. 如果是布尔
      if (field.attrValue === 'BOOLEAN_ATTR') {
        const list = [
          { key: true, value: i18n.t('是') },
          { key: false, value: i18n.t('否') },
        ]

        const fieldEditProps = {
          selectValue: list,
        }

        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps,
        }

        this.$forceUpdate()
        return
      }
      // 4. 如果是优先级列表
      if (field.attrName === 'priority') {
        this.getPriorityList(field)
        return
      }
      // 5. 如果是预计工时
      if (field.attrName === 'expectHour' || field.attrName === 'actualHour') {
        field.fieldEditProps.customInput = true
        field.fieldEditProps.selectValue = this.$store.state.pf.expectHourList
        field.fieldEditProps.customInputPlaceHolder = '自定义工时(h)'
        field.fieldEditProps.customInputChange = value => {
          this.taskInputChange(field, value)
        }
        this.$forceUpdate()
        return
      }
      // 6. 其他类型
      let result = {}
      let addtionalParams = {}
      if (field.attrName === 'sprintId') {
        addtionalParams = {
          includeUnplanned: true,
          appendUnplannedBefore: true,
        }
      }
      try {
        result = await queryOptions({
          projectId: this.projectId,
          workItemType: this.workItemType,
          attrName: field.attrName,
          ...addtionalParams,
        })
      } catch (_) {
        result.status = 0
      }
      if (result.status === 200) {
        const list = result.data.map(item => {
          let obj = {
            ...item,
            key: item.value,
            value: item.label,
          }

          delete obj.label
          return obj
        })
        const fieldEditProps = {
          selectValue: list,
        }

        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps,
        }

        this.$forceUpdate()
      }
      return true
    },
    // 获取人员列表
    async getAssignUsersList(field) {
      // 减少发起的请求，增加效率
      if (field.fieldEditProps.selectValue.length > 0) {
        return
      }
      const result = await getUserList({
        projectId: this.projectId,
        query: '',
        workItemType: this.workItemType,
      })

      if (result.status && result.status === 200) {
        const list = result.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
          }
        })
        const fieldEditProps = {
          selectValue: list,
        }

        // if(!field.fieldEditProps.initValue && list.length > 0 && this.detailType==='editable') {
        //   fieldEditProps.initValue = field.fieldEditProps.multiple ? [list[0].key] : list[0].key;
        // }
        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps,
        }

        this.$forceUpdate()
      }
    },
    // 恢复最近一次操作字段的状态
    lastFieldReset() {
      if (!this.lastUpdateField) {
        return
      }
      this.lastUpdateField.key += 's'
      this.lastUpdateField = null
      this.$forceUpdate()
    },
    // 更新字段值
    updateInfoWhenShow(item, value) {
      item && (this.lastUpdateField = item)
      if (item.required && isEmpty(value)) {
        this.$message({
          message: i18n.t('必填项不能清空'),
          type: 'warning',
        })

        item.key += 's'
        this.$forceUpdate()
        return
      }
      const obj = item.userDefined
        ? {
            userDefinedAttrs: {
              [item.attrName]: value,
            },
          }
        : {
            [item.attrName]: value,
          }

      item.attrName === 'sprintId' && (obj.updateSubSprint = true) // lili 2020-4-21 父需求更新迭代，子需求也一起更新
      // 日期特殊处理
      if (['startTime', 'endTime'].includes(item.attrName) && value === '') {
        obj[item.attrName] = '2001-01-01'
      }
      // 清空自定义字段值处理
      if (item.userDefined && value === null) {
        obj.clearFields = [item.attrName]
      }
      obj.workItemId = obj.id = this.workItemDetail.detail.id
      this.$emit('updateField', obj)
    },
    // 展开/收起自定义字段
    customHandle() {
      this.fieldShowAll = !this.fieldShowAll
    },
    // 特殊字段处理 - 改变副需求
    ChangeFatherRquireFuc() {
      this.$emit('ChangeFatherRquireFuc')
    },
    // 特殊字段处理 - 删除父需求
    deleteParentRequireFuc() {
      this.$emit('deleteParentRequireFuc')
    },
    // 特殊字段处理 - 更新工作项数据
    refreshData(value) {
      this.$emit('refreshData', value)
    },
    // 特殊字段处理 - 全局修改table-优先级,严重程度,状态的样式
    initNameStatus(color, item) {
      color = color || 'black'
      return `<span class="statusbox-list-common" style="--color: ${color}" title="${item}">${item}</span>`
    },
    // 特殊字段处理 - 查看工作流
    getWorkFlow() {
      this.getWorkFlowInfo(this.projectId, this.workItemType)
    },
    // 特殊字段处理 - 获取优先级
    getPriorityList(field) {
      let projectId = this.projectId || this.$getUrlParams().projectId
      priorityList({
        projectId,
        workItemType: this.workItemType,
      }).then(res => {
        const list = res.data.map(item => {
          return {
            value: item.literal,
            key: item.priority,
            color: item.color,
            ...item,
          }
        })
        const fieldEditProps = {
          selectValue: list,
        }

        // if(!field.fieldEditProps.initValue && list.length > 0 && this.detailType==='editable') {
        //   fieldEditProps.initValue = field.fieldEditProps.multiple ? [list[0].key] : list[0].key;
        // }
        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps,
        }

        this.$forceUpdate()
      })
    },
    // 特殊字段处理 - 任务工时自定义输入
    taskInputChange(field, value) {
      var expectHour = Number(value)
      if (!/^\d+$/.test(expectHour)) {
        this.$message({
          showClose: true,
          message: i18n.t('工时必须是正整数'),
          type: 'warning',
        })

        return false
      }
      if (expectHour <= 0) {
        this.$message({
          showClose: true,
          message: i18n.t('工时必须大于0'),
          type: 'warning',
        })

        return false
      }
      if (expectHour >= 10000) {
        this.$message({
          showClose: true,
          message: i18n.t('工时必须小于10000'),
          type: 'warning',
        })

        return false
      }
      this.updateInfoWhenShow(field, expectHour)
    },
    // 选择用户数据改变
    selectUserChange(item, val) {
      if (val && val.userId) {
        this.updateInfoWhenShow(item, val.userId)
      }

      this.assignUserChoice.isShow = false
    },
    // 选择用户失去焦点时触发事件
    selectUserVisibleChange(val) {
      !val && (this.assignUserChoice.isShow = false)
    },
  },
}
</script>
<style lang="scss" scoped>
.select-user-container {
  max-width: calc(100% - 105px);
  height: 26px;
  line-height: 26px;
  box-sizing: border-box;
  display: inline-block;
  vertical-align: top;
  position: relative;
  padding: 0 5px;
  margin-left: 10px;
  border: 1px solid transparent;

  &__hover:hover {
    border: 1px solid #eee;
  }

  .select-user {
    width: 100%;
    display: inline-block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 0 5px;
    cursor: pointer;
  }
}

.workitem-basic-info-item {
  padding: 0;
  font-size: $font-size-medium;
  margin-bottom: 10px;
  // &.workitem-basic-info-item-select-multiple {
  //   padding: 5px 0 0;
  //   margin-bottom: -5px;
  //   height: auto;
  //   line-height: 26px;
  // }
  // lable
  .workitem-basic-info-item-label {
    height: 26px;
    line-height: 26px;
    display: inline-block;
    width: 90px;
    overflow: hidden;
    padding-left: 7px;
    vertical-align: top;
    box-sizing: border-box;
  }
  .workitem-basic-info-item-label-pre {
    position: relative;
    &:before {
      content: '*';
      color: red;
      position: absolute;
      top: 2px;
      left: 0;
    }
  }
  .workitem-basic-info-item-label-english {
    width: 130px;
  }
  .workitem-basic-info-item-select-width {
    max-width: calc(100% - 43px);
    height: 26px;
    line-height: 26px;
    box-sizing: border-box;
    display: inline-block;
    vertical-align: top;
    margin-left: 10px;
  }
  .work-item-hover {
    &:hover {
      box-shadow: 0 0 0 1px #eee;
    }
  }
  .pRWidth{
     max-width: calc(100% - 63px)!important;
  }
  .workitem-basic-info-item-select-width-english {
    max-width: calc(100% - 146px);
  }
  .hover-basic-info-item-static {
    display: inline-block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 100%;
    padding-left: 10px;
    cursor: pointer;
  }
  .hoverColor:hover{
    color: $--color-primary;
  }
  .workitem-basic-info-item-readonly {
    position: relative;
    top: 3px;
    cursor: unset;
  }
  .status_name {
    max-width: 80px;
    height: 26px;
    line-height: 26px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    border-radius: 4px;
    color: #fff;
  }
}
.view-workflow {
  color: $--color-primary;
  font-size: 18px;
}

.category-cascader {
  width: calc(100% - 105px);
  padding: 0 5px;
}

.current-category-hover {
  max-width: calc(100% - 105px);
  height: 26px;
  line-height: 26px;
  box-sizing: border-box;
  display: inline-block;
  vertical-align: top;
  padding: 0 5px;
  margin-left: 10px;

  &:hover {
    box-shadow: 0 0 0 1px #eee;
  }

  span {
    width: 100%;
    display: inline-block;
    @include no-wrap;
    padding: 0 5px;
    height: 100%;
    cursor: pointer;
  }
}
</style>
