<template>
  <div class="workitem-basic-info-box">
    <template v-for="item in fieldListAll">
      <div
        :id="item.attrName === 'sprintId' ? 'sprintIdDom': ''" 
        class="workitem-basic-info-item"
        :data-key="item.attrName"
        :key="item.attrName"
      >
        <ellipsis-block
          class="workitem-basic-info-item-label ellipsis-pure"
          :class="{ 'workitem-basic-info-item-label-pre': item.required }"
          :value="item.fieldName + ':'"
        ></ellipsis-block>
        <!-- <field-edit v-if="detailType==='show'" v-bind="item.fieldEditProps"
            @FieldEditFieldClick="getSelectOptionList(item)"
            :onChange="(value)=>{updateInfoWhenShow(item.key, value)}"
        ></field-edit> -->
        <div
          class="workitem-basic-info-item-select-width workitem-basic-info-item-readonly"
          v-if="item.fieldEditProps.readonly"
        >
          {{ item.fieldEditProps.initName }}
        </div>
        <div
          v-else-if="item.attrName === 'requireId'"
          class="workitem-basic-info-item-select-width-required"
          @mouseover="deleteParentRequire = true"
          @mouseout="deleteParentRequire = false"
        >
          <!-- <span
            :class="[
              'mock-input',
              'cursor-pointer',
              { 'placeholder-text': !item.fieldEditProps.initName },
            ]"
            @click="ChangeFatherRquireFuc"
            @mouseover="deleteParentRequire = true"
            @mouseout="deleteParentRequire = false"
          >
            <span class="hover-basic-info-item-static mock-input-text">
              {{
                item.fieldEditProps.initName
                  ? item.fieldEditProps.initName
                  : $t('请选择所属需求')
              }}
            </span>
            <i
              v-show="deleteParentRequire && item.fieldEditProps.initName"
              class="el-icon-delete link-common ml10"
              @click.stop="deleteParentRequireFuc"
            />
          </span> -->
        <el-input
          v-model="item.fieldEditProps.initName"
          class="input-typeed-class"
          @click.native="ChangeFatherRquireFuc"
          readonly
          clearable
          :placeholder="$t('请选择所属需求')"
        >
        </el-input>
          <i
            v-show="deleteParentRequire &&item.fieldEditProps.initName" 
            class="el-icon-delete vertical link-common"
            @click.stop="deleteParentRequireFuc"
          ></i>        
        </div>
        <co-tooltip
          v-else
          :content="$t('必填项不能为空')"
          placement="top"
          :manual="true"
          :value="item.fieldEditProps.showEmptyNotice"
          popper-class="workitem-basic-info-item-tooltip"
        >
          <expect-hour
            v-bind:hour.sync="item.fieldEditProps.initValue"
            v-if="
              (workItemType === WorkItemTypeObj.requirement ||
                workItemType === WorkItemTypeObj.task) &&
                ['expectHour', 'actualHour'].includes(item.attrName)
            "
            class="workitem-basic-info-item-select-width"
            :changeCallback="
              value => {
                handleChange(item, value)
                fieldValidCheck(item)
              }
            "
            @focus="getSelectOptionList(item)"
            @blur="fieldValidCheck(item)"
            :isClearable="item.isClearable"
          >
          </expect-hour>
          <typed-form-item
            v-else
            popperAppendToBody
            :isAssignUser="
              ['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(item.attrValue)
            "
            class="workitem-basic-info-item-select-width"
            @change="
              value => {
                handleChange(item, value)
                fieldValidCheck(item, 2)
              }
            "
            @focus="getSelectOptionList(item)"
            @blur="fieldValidCheck(item)"
            v-model="item.fieldEditProps.initValue"
            :initName="item.fieldEditProps.initName"
            :type="item.attrValue"
            :selectList="item.fieldEditProps.selectValue"
            :isClearable="item.isClearable"
            :filterField="false"
            :filterable="['SINGLE_CHOICE'].includes(item.attrValue)"
          ></typed-form-item>
        </co-tooltip>
      </div>
    </template>
    <slot name="footer"></slot>
    <ChangeBugFatherRequire
      @onChange="changeRequireId"
      :cloneRquireModalStatus="cloneRquireModalStatus"
      :projectId="projectId"
      :requireId="requireId"
      :closeModal="closeModal"
    />
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 工作项基本信息组件 - 新建
 * @desc 需求、任务、缺陷基本信息通用，新建时基于模板新建，编辑时，根据基本信息详情 + 全局缓存字段信息
 * @function 1. 支持新建时 v-model 双向更新
 * @function 2. 支持过长收起
 * @function 3. 支持 slot 嵌入
 * @author heyunjiang
 * @date 2020.3.24
 */
// import FieldEdit from "@/pages/tool/FieldEdit";
import ExpectHour from '@/components/expect-hour'
import { saveStorage, getStorage, isEmpty, calcWorkHoursParam } from '@/utils'
import { USER_INFO } from '@/utils/constant'
import { queryOptions } from '@/service/work-status-flow'
import { getUserList } from '@/service/project'
import { parentAble } from '@/service/requirement'
import { timeLinkageCalculate } from '@/service/task'
import * as requirementCategoryService from '@/service/requirement-category'
import ChangeBugFatherRequire from '@/views/bug/ChangeBugFatherRquire'

const attrValueToInputTypeMap = {
  SINGLE_TEXT: 'text',
  MULTI_TEXT: 'textarea',
  MEMBER_CHOICE: 'select',
  MULTI_MEMBER_CHOICE: 'select',
  LITE_DATE_ATTR: 'date',
  BOOLEAN_ATTR: 'select',
  INT_ATTR: 'number',
  FLOAT_ATTR: 'number',
  SINGLE_CHOICE: 'select',
  MULTI_CHOICE: 'select',
  CASCADER_CHOICE: 'select',
}

// 项目类型对象
const WorkItemTypeObj = {
  requirement: 1,
  task: 2,
  bug: 3,
}

export default {
  name: 'WorkItemBasicInfoCreate',
  components: {
    ExpectHour,
    ChangeBugFatherRequire,
    // FieldEdit
  },
  model: {
    prop: 'value',
    event: 'change',
  },

  mixins: [],
  props: {
    projectId: {
      type: [String, Number],
      required: false,
      desc: i18n.t('因为可能从非项目模块创建工作项'),
    },

    workItemType: {
      type: [String, Number],
      required: true,
      desc: i18n.t('工作项类型'),
    },

    value: {
      type: Object,
      required: true,
      desc: 'v-model 绑定的值',
    },

    workItemCreateBasicTemplateArray: {
      type: Array,
      required: true,
      desc: '新建时，传入的模板基本信息列表',
    },

    // 基本信息数据源
    currentCategoryId: {
      type: [String, Number],
      desc: i18n.t('需求分类选中值'),
    },
  },

  data() {
    return {
      // fieldPermission: 0,
      // fieldShowAll: false,
      fieldListAll: [], // 基本信息所有字段
      currentModelValue: {}, // 新建时，表单缓存数据，用于和 v-model 判断是否是外部主动更新
      currentProjectId: null, // 用于保存基本信息选中的项目 id
      lastPriority: null, // 防抖
      lastEventHandle: null, // 防抖事件句柄
      deleteParentRequire: false,
      cloneRquireModalStatus: false, // 所属需求弹窗
      requireId: null, // 所属需求id
      WorkItemTypeObj,
    }
  },
  created() {},
  computed: {
    ProjectListAll() {
      return this.$store.state.pf.ProjectListAll
    },
  },

  watch: {
    // 当工作项模板变化时，更新字段列表
    workItemCreateBasicTemplateArray() {
      this.initList()
    },
    // 如果外部主动更新(比如缓存恢复)，则更新当前基本信息展示数据
    value() {
      // 去除更新死循环
      if (this.value !== this.currentModelValue) {
        this.initList()
      }
    },
  },

  mounted() {
    this.initList()
  },
  methods: {
    handleChange(field, value) {
      const selectList = field.fieldEditProps.selectValue
      // 特殊字段处理 1 - 项目
      if (field.attrName === 'projectId') {
        this.$emit('handleProjectChange', value)
        const assignUser = this.fieldListAll.find(item => item.attrName === 'assignUser')

        // 重置处理人信息
        if (assignUser) {
          const { userName, userId } = this.$store.state.gd.userInfo
          assignUser.fieldEditProps.initValue = userId;
          assignUser.fieldEditProps.initName = userName + '(' + userId + ')';
        }
      }
      // 特殊字段处理 2-迭代 创建缺陷时选择的迭代需进行缓存处理
      if (
        field.attrName === 'sprintId' &&
        WorkItemTypeObj.bug === this.workItemType
      ) {
        const sprintPresetValue = selectList.find(item => item.key === value)
        saveStorage('createBugSprintPresetValue', sprintPresetValue)
        sessionStorage.setItem('isFirstSelectSprintInBug', 'false')
      }
      this.updateModel()
    },
    // 获取工作项基本信息字段列表
    async initList() {
      // 新建和编辑时，注意区分
      this.fieldListAll = this.setFieldInitData(
        this.workItemCreateBasicTemplateArray,
      )

      // 新建的时候，才触发更新 v-model
      this.updateModel()
    },
    // 根据模板设置字段 fieldEditProps 属性 - 新建
    setFieldInitData(fieldListAll) {
      const result = []
      // 需要显示删除功能图标的类型
      const needClearableFun = [
        'SINGLE_CHOICE',
        'INT_ATTR',
        'FLOAT_ATTR',
        'BOOLEAN_ATTR',
        'MEMBER_CHOICE',
        'SINGLE_TEXT',
      ]

      // 任务默认模板中“预计工时、实际工时、进度”需做清空功能
      const needClearableFunInTaskTemp = [
        'expectHour',
        'actualHour',
        'progress',
      ]

      fieldListAll.forEach(item => {
        const fieldEditProps = {}
        const ismultiple = ['MULTI_CHOICE', 'MULTI_MEMBER_CHOICE'].includes(
          item.attrValue,
        )
        const surportLocalSearch = [
          'MEMBER_CHOICE',
          'MULTI_MEMBER_CHOICE',
          'SINGLE_CHOICE',
        ].includes(item.attrValue)

        let presetValue = {}
        try {
          presetValue = JSON.parse(item.presetValue) || {}
        } catch (_) {}
        try {
          fieldEditProps.initValue =
            (item.userDefined
              ? this.value.userDefinedAttrs &&
                this.value.userDefinedAttrs[item.attrName]
              : this.value[item.attrName]) ||
            (presetValue.key === null
              ? this.$store.state.cm.customFieldInitTypeMap[item.attrValue]
              : presetValue.key)
          fieldEditProps.initName = presetValue.value
          if (item.attrName === 'categoryId') {
            fieldEditProps.initName = String(presetValue.key)
          }
        } catch (_) {}

        fieldEditProps.attrValueType = item.attrValue
        fieldEditProps.inputType = attrValueToInputTypeMap[item.attrValue]
        fieldEditProps.selectValue = []
        fieldEditProps.multiple = ismultiple
        fieldEditProps.localSearch = surportLocalSearch
        fieldEditProps.showEmptyNotice = item.fieldEditProps
          ? item.fieldEditProps.showEmptyNotice
          : false
        // 特殊处理1: 如果是在非项目模块创建工作项
        if (item.attrName === 'projectId') {
          if (this.$getUrlParams().projectId && item.readonly) {
            fieldEditProps.readonly = true
          }
          this.$set(item, 'fieldEditProps', fieldEditProps)
          // 获取项目列表，并更新 currentProjectId
          this.getProjectList(
            item,
            this.projectId ||
              this.$getUrlParams().projectId ||
              this.value.projectId,
          )
        } else if (item.hiddenWhenCreate) {
          // 如果是在新建时不需要的字段，则不展示
          return
        } else if (item.readonly) {
          // 如果是非项目字段，并且只读
          fieldEditProps.readonly = true
        }
        // 特殊处理2: 需求和任务在创建时，处理人默认为创建人
        if (
          item.attrName === 'assignUser' &&
          [1, 2].includes(+this.workItemType) &&
          !this.value.assignUser
        ) {
          const { userName, userId } = this.$store.state.gd.userInfo

          fieldEditProps.initValue = userId
          fieldEditProps.initName = userName + '(' + userId + ')'
        }
        // 特殊处理3: 进度
        if (item.attrName === 'progress') {
          item.attrValue = 'INT_ATTR'
          fieldEditProps.attrValueType = item.attrValue
        }

        // 特殊处理父需求
        if (item.attrName === 'requireId') {
          fieldEditProps.initName = item.initName
        }

        this.$set(item, 'fieldEditProps', fieldEditProps)
        // 特殊处理4: 迭代 如果不是每次登陆后第一次创建缺陷,则需要选择缓存中的迭代
        if (
          item.attrName === 'sprintId' &&
          WorkItemTypeObj.bug === this.workItemType
        ) {
          if (sessionStorage.getItem('isFirstSelectSprintInBug') === 'false') {
            this.getSelectOptionList(item)
          }
        }

        // 特殊处理，父需求
        if (item.attrName === 'requireId') {
          this.requireId = item.initValue
        }

        // 特殊处理5 需求分类
        if (item.attrName === 'categoryId') {
          item.attrValue = 'CASCADER_CHOICE'
          fieldEditProps.inputType = 'CASCADER_CHOICE'
          fieldEditProps.attrValue = 'CASCADER_CHOICE'
          fieldEditProps.attrValueType = 'CASCADER_CHOICE'
          fieldEditProps.initValue += ''
          fieldEditProps.initName = fieldEditProps.initValue
        }
        // 特殊处理5: 自定义字段类型为“成员单选框、布尔值选择、数字输入框、单选框、文本输入框”，选择后可删除 任务中的预计工时、实际工时、进度需做清空功能
        item.isClearable =
          (item.userDefined && needClearableFun.includes(item.attrValue)) ||
          (this.workItemType === WorkItemTypeObj.task &&
            needClearableFunInTaskTemp.includes(item.attrName))

        result.push(item)
        // 如果外部主动更新 v-model ，则需要主动获取对应下拉列表的展示值
        if (
          this.value[item.attrName] &&
          this.value[item.attrName] !== presetValue.key
        ) {
          this.getSelectOptionList(item)
        }
        // 特殊处理字段2 ： 需求分类
        if (
          item.attrName === 'categoryId' &&
          this.currentCategoryId !== undefined &&
          !this.value.categoryId
        ) {
          this.getSelectOptionList(item)
        }
      })
      return result
    },
    // 获取缓存中的迭代值,并判断是否是第一次创建
    getSprintCachePresetValue(editProps = {}) {
      // 如果不是第一次登陆则使用缓存，否则为默认最新迭代
      const presetValueCache = getStorage('createBugSprintPresetValue')
      const sprintList = editProps.selectValue || []
      return sprintList.find(item => item.key == presetValueCache.key)
        ? presetValueCache
        : false
    },
    // 获取字段可选择值列表列表 - 在 for 循环里面执行 async 的一个场景
    async getSelectOptionList(field) {
      // 1. 如果不是 select 类型的,不是父需求，则跳过
      if (
        attrValueToInputTypeMap[field.attrValue] !== 'select' ||
        field.attrName === 'requireId' ||
        field.attrName === 'parentId'
      ) {
        return
      }
      // 特殊字段处理 - 如果是选择项目
      if (field.attrName === 'projectId') {
        if (!this.currentProjectId) {
          this.getProjectList(field)
        }
        return false
      }
      // 特殊字段处理 - 如果是选择父需求
      if (field.attrName === 'parentId') {
        this.getParentRequirementList(field)
        return false
      }

      // 特殊字段处理 - 如果是需求分类
      if (field.attrName === 'categoryId') {
        this.getCategoryList(field)
        return false
      }

      if (!this.$getUrlParams().projectId && !this.currentProjectId) {
        this.$message({
          message: i18n.t('请先选择项目'),
          type: 'warning',
        })

        return false
      }
      // 2. 如果是人员选择，则去拿人员选择数据
      if (['MEMBER_CHOICE', 'MULTI_MEMBER_CHOICE'].includes(field.attrValue)) {
        this.getAssignUsersList(field)
        return
      }
      // 3. 如果是布尔
      if (['BOOLEAN_ATTR'].includes(field.attrValue)) {
        const list = [
          { key: true, value: i18n.t('是') },
          { key: false, value: i18n.t('否') },
        ]

        const fieldEditProps = {
          selectValue: list,
        }

        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps,
        }

        this.$forceUpdate()
        return
      }
      // 4. 其他类型
      let result = {}
      let addtionalParams = {}
      if (field.attrName === 'sprintId') {
        addtionalParams = {
          includeUnplanned: true,
          appendUnplannedBefore: true,
        }
      }
      try {
        result = await queryOptions({
          projectId: this.projectId || this.currentProjectId,
          workItemType: this.workItemType,
          attrName: field.attrName,
          ...addtionalParams,
        })
      } catch (_) {
        result.status = 0
      }
      if (result.status === 200) {
        const list = result.data.map(item => {
          return {
            ...item,
            key: item.value,
            value: item.label,
          }
        })
        const fieldEditProps = {
          selectValue: list,
        }

        // 特殊字段处理 1 - 需求分类
        if (field.attrName === 'categoryId' && this.currentCategoryId) {
          fieldEditProps.initValue = this.currentCategoryId
        }
        // 特殊字段处理 2 - 如果是创建缺陷时需要选择缓存中的迭代
        if (
          field.attrName === 'sprintId' &&
          WorkItemTypeObj.bug === this.workItemType &&
          sessionStorage.getItem('isFirstSelectSprintInBug') === 'false'
        ) {
          const presetValue = this.getSprintCachePresetValue(fieldEditProps)
          if (presetValue) {
            field.presetValue = presetValue
            fieldEditProps.initValue = presetValue.key
            fieldEditProps.initName = presetValue.value
          }
        }
        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps,
        }

        this.$forceUpdate()
        this.updateModel()
      }
      return true
    },
    // 获取需求分类
    async getCategoryList(field) {
      const projectId = this.$getUrlParams().projectId || this.projectId
      const result = await requirementCategoryService.tree({ projectId })
      if (result.status === 200) {
        function getAllCategoryList(list) {
          return list.map(({ label, id, children }) => ({
            label,
            value: String(id),
            key: id,
            children:
              children.length === 0 ? null : getAllCategoryList(children),
          }))
        }
        field.fieldEditProps.selectValue = getAllCategoryList(result.data)
      }
      this.$forceUpdate()
      this.updateModel()
    },
    // 获取人员列表
    async getAssignUsersList(field) {
      // 减少发起的请求，增加效率
      if (field.fieldEditProps.selectValue.length > 0) {
        return
      }
      const result = await getUserList({
        projectId: this.projectId || this.currentProjectId,
        query: '',
        workItemType: this.workItemType,
      })

      if (result.status && result.status === 200) {
        const list = result.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
          }
        })
        field.fieldEditProps.selectValue = list
        // 为什么必须 forceUpdate: 在 for 循环内部，相当于通过下标访问数组，这里 vue 不监听响应式数据的变更
        this.$forceUpdate()
      }
    },
    // 获取项目列表 - 在非项目模块时访问
    async getProjectList(field, projectId) {
      let result = this.ProjectListAll
      if (result.length === 0) {
        result = await this.$store.dispatch({ type: 'getProjectListAll' })
      }
      this.currentProjectId = projectId || result[0].id
      field.fieldEditProps.initValue = this.currentProjectId
      field.fieldEditProps.selectValue = result.map(item => {
        return {
          key: item.id,
          value: item.name,
        }
      })
      // 如果是在项目内新建，则增加展示值
      if (this.$getUrlParams().projectId && field.readonly) {
        field.fieldEditProps.initName = result.find(
          item => item.id + '' === this.currentProjectId + '',
        ).name
      }
      this.$forceUpdate()
      this.updateModel()
    },
    // 特殊字段处理 - 获取父需求列表
    async getParentRequirementList(field) {
      const result = await parentAble({
        title: '',
        pageInfo: {
          pageNumber: 1,
          pageSize: 1000,
        },

        projectId: this.projectId || this.currentProjectId,
      })

      if (result.status && result.status === 200 && result.data.result) {
        const list = result.data.result.map(item => {
          return {
            key: item.id,
            value: item.label,
          }
        })
        field.fieldEditProps.selectValue = list
        // 为什么必须 forceUpdate: 在 for 循环内部，相当于通过下标访问数组，这里 vue 不监听响应式数据的变更
        this.$forceUpdate()
      }
    },
    // 字段检测，必填项提示、progress ; @param priority 表示优先级，采用防抖实现
    fieldValidCheck(field, priority = 1) {
      // 第二次调用，但是优先级低了
      if (this.lastPriority && this.lastPriority > priority) {
        return false
      }
      // 第一次调用，或者优先级一样
      if (!this.lastPriority || priority <= this.lastPriority) {
        this.lastPriority = priority
      }
      this.lastEventHandle && clearTimeout(this.lastEventHandle)
      this.lastEventHandle = setTimeout(() => {
        let current = field.fieldEditProps.initValue
        // 1. 非空检测
        if (field.required && isEmpty(current)) {
          // 如果需要提示，则清除其他所有提示
          const listLength = this.fieldListAll.length
          for (let i = 0; i < listLength; i++) {
            const currentfield = this.fieldListAll[i]
            currentfield.fieldEditProps.showEmptyNotice =
              currentfield.attrName === field.attrName
          }
        } else if (field.required && !isEmpty(current)) {
          field.fieldEditProps.showEmptyNotice = false
        }
        // 特殊字段处理 1 progress 检测
        if (field.attrName === 'progress') {
          const tofixed = /^(\d{1,2}(\.\d{1})?|100)$/ // 匹配最多一位小数
          if (!tofixed.test(current) && !isEmpty(current)) {
            current = Number(current).toFixed(1)
            this.$message({
              showClose: true,
              message: i18n.t('进度只能在0到100之间且只保留一位小数'),
              type: 'warning',
            })

            this.$nextTick(() => {
              field.fieldEditProps.initValue =
                current > 100 ? 100 : current < 0 ? 0 : current
              // 第二次：是为了改变 v-model 绑定的值，对其他地方没有影响
              this.$forceUpdate()
            })
          }
        }
        // 特殊字段处理 2 -自动计算工时
        if (
          (+this.workItemType === WorkItemTypeObj.task ||
            +this.workItemType === WorkItemTypeObj.requirement) &&
          ['expectHour', 'startTime', 'endTime'].includes(field.attrName)
        ) {
          this.taskTimeChange(field.attrName)
        }
        // 第一次：是为了更新 v-model 绑定的值
        this.$forceUpdate()
        this.lastEventHandle && clearTimeout(this.lastEventHandle)
        this.lastPriority = null
      }, 300)
    },
    // 校验必填项 - 用于全部字段校验，可以通过 $ref 访问
    checkFields() {
      let creatable = true
      const listLength = this.fieldListAll.length
      let dataKey = ''
      // 1. 保证提示第一个 2. 节约性能
      for (let i = 0; i < listLength; i++) {
        const field = this.fieldListAll[i]
        if (field.required && isEmpty(field.fieldEditProps.initValue)) {
          creatable && (field.fieldEditProps.showEmptyNotice = true)
          dataKey = field.attrName
          creatable = false
          break
        }
      }
      if (!creatable) {
        this.$forceUpdate()
        // 滚动到屏幕可以看见的区域
        try {
          let scrolltarget = this.$el.querySelector(
            '.workitem-basic-info-item[data-key="' + dataKey + '"]',
          )

          scrolltarget.previousElementSibling &&
            (scrolltarget = scrolltarget.previousElementSibling)
          scrolltarget.previousElementSibling &&
            (scrolltarget = scrolltarget.previousElementSibling)
          scrolltarget.previousElementSibling.scrollIntoView()
        } catch (_) {}
      }
      return creatable
    },
    // 获取当前表单数据 - 注意区分固有字段和自定义字段
    getModelObj() {
      const systemAttrs = {},
        userDefinedAttrs = {}
      this.fieldListAll.forEach(item => {
        if (item.userDefined) {
          userDefinedAttrs[item.attrName] = item.fieldEditProps.initValue
        } else {
          systemAttrs[item.attrName] = item.fieldEditProps.initValue
        }
      })
      return {
        ...systemAttrs,
        userDefinedAttrs,
      }
    },
    // 更新 v-model 值
    updateModel() {
      this.currentModelValue = this.getModelObj()
      this.$emit('change', this.currentModelValue)
    },
    // 打开所属需求弹窗
    ChangeFatherRquireFuc() {
      this.cloneRquireModalStatus = true
    },
    // 设置所属需求
    changeRequireId(obj) {
      const idx = this.fieldListAll.findIndex(i => i.attrName === 'requireId')
      if (idx > -1) {
        this.fieldListAll[idx].fieldEditProps.initName = obj.label
        this.fieldListAll[idx].fieldEditProps.initValue = obj.id
        this.requireId = obj.id
        this.updateModel()
      }
    },
    // 删除所属需求
    deleteParentRequireFuc() {
      this.changeRequireId({})
    },
    // 关闭父需求的弹窗
    closeModal() {
      this.cloneRquireModalStatus = false
    },
    // 展开/收起自定义字段
    // customHandle() {
    //   this.fieldShowAll = !this.fieldShowAll;
    // }
    // 特殊处理 - 任务工时联动 - 只有当任务工时为空，修改了预计结束时间和预计开始时间，才发请求计算
    async taskTimeChange(modifyName) {
      const resultObj = calcWorkHoursParam(
        this.currentModelValue,
        this.fieldListAll,
      )

      if (!resultObj) {
        return
      }
      const { options, modifyField } = resultObj
      if (!modifyField) {
        return
      }
      let result = {}
      try {
        result = await timeLinkageCalculate({
          ...options,
          modifiedFiled: modifyName,
        })
      } catch (_) {}
      if (result.status && result.status === 200) {
        const {
          expectHour,
          startTime,
          endTime,
        } = result.data.timeCalculateResult
        !options.expectHour &&
          (modifyField.fieldEditProps.initValue = expectHour)
        !options.startTime && (modifyField.fieldEditProps.initValue = startTime)
        !options.endTime && (modifyField.fieldEditProps.initValue = endTime)
        this.$forceUpdate()
        this.updateModel()
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.workitem-basic-info-item {
  // line-height: 28px;
  // height: 26px;
  height: auto;
  line-height: 22px;
  padding: 0;
  margin-bottom: 10px;
  font-size: $font-size-medium;

  // &.workitem-basic-info-item-select-multiple {
  //   padding: 5px 0 0;
  //   margin-bottom: -5px;
  //   height: auto;
  //   line-height: 26px;
  // }
  // lable
  .workitem-basic-info-item-label {
    height: 29px;
    line-height: 29px;
    display: inline-block;
    width: 90px;
    overflow: hidden;
    padding-left: 6px;
  }
  .workitem-basic-info-item-label-pre {
    position: relative;
    &:before {
      content: '*';
      color: red;
      position: absolute;
      top: 2px;
      left: -1px;
    }
  }
  .workitem-basic-info-item-select-width {
    max-width: calc(100% - 105px);
    overflow: hidden;
    box-sizing: border-box;
    padding-right: 1px;
    display: inline-block;
  }
  .workitem-basic-info-item-select-width-required{
    max-width: calc(100% - 105px);
    overflow: hidden;
    box-sizing: border-box;
    position: relative;
    display: inline-block;
    /deep/.el-input__inner{
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
      padding-right: 30px;
    }
    .vertical{
      position: absolute;
      top: 6px;
      right: 8px;
      width: 20px;
      height: 20px;
      text-align: center;
      line-height: 20px;
    }
  }  
  .workitem-basic-info-item-readonly {
    height: 29px;
    line-height: 29px;
  }
  .mock-input {
    background-color: #fff;
    border-radius: 2px;
    border: 1px solid #dde5ef;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    color: #606266;
    display: flex;
    font-size: 14px;
    padding: 0 7px;
    width: 176px;
    height: 28px;
    line-height: 28px;
    justify-content: space-between;
    align-items: center;

    &.placeholder-text {
      color: #bfbfbf;
    }

    .mock-input-text {
      display: block;
      max-width: 124px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }
}
.input-typeed-class{
  width: 100%;
  max-width: 100%;
}
</style>
