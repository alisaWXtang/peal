<template>
  <co-dialog
    :title="$t('设置反馈对接人')"
    width="600px"
    :visible.sync="isVisible"
    @closed="$refs.form.resetFields()"
    :append-to-body="false"
  >
    <co-form ref="form" :model="settingForm" :rules="rules" label-width="100px">
      <co-form-item :label="$t('反馈对接人')" prop="interfaceManList">
        <GlobalUserSelect
          :placeholder="$t('请选择反馈对接人')"
          v-model="settingForm.interfaceManList"
          multiple
          size="mini"
          :popper-append-to-body="true"
        />
      </co-form-item>
    </co-form>
    <span slot="footer" class="dialog-footer">
      <co-button @click="isVisible = false">{{ $t('取消') }}</co-button>
      <co-button
        type="primary"
        @click="confirmSetting"
        :loading="updateLoading"
        >{{ $t('确定') }}</co-button
      >
    </span>
  </co-dialog>
</template>

<script>
import { i18n } from '@/i18n'
/**
 * 设置反馈对接人弹窗
 * settingType 设置类型：'inner'表示内部反馈，'400'表示400工单反馈
 * visible 控制弹窗显示隐藏
 * productId 当前设置的产品id
 * defaultInterfaceManList 默认选中的对接人列表
 */
import cloneDeep from 'lodash/cloneDeep'
import GlobalUserSelect from '@/components/global-user-select'
import { operationActionTypes } from '@/store/action-types'

export default {
  name: 'FeedbackManSetting',
  props: {
    // 设置类型：'inner'表示内部反馈，'400'表示400工单反馈
    settingType: {
      type: String,
      required: true,
    },

    visible: {
      type: Boolean,
      default: false,
    },

    productId: {
      type: [Number, String],
      required: true,
    },

    defaultInterfaceManList: {
      type: Array,
      default() {
        return []
      },
    },
  },

  watch: {
    visible: {
      handler(newVal) {
        this.isVisible = newVal
        this.settingForm.interfaceManList = cloneDeep(
          this.defaultInterfaceManList,
        )
      },
      immediate: true,
    },

    isVisible(newVal) {
      this.$emit('update:visible', newVal)
    },
  },

  data() {
    return {
      rules: {
        interfaceManList: [
          { required: true, message: i18n.t('操作失败，至少需设置一个对接人') },
        ],
      },

      settingForm: {
        interfaceManList: [],
      },

      updateLoading: false,
      isVisible: false,
    }
  },
  components: {
    GlobalUserSelect,
  },

  methods: {
    confirmSetting() {
      this.$refs.form.validate(valid => {
        if (valid) {
          const { interfaceManList } = this.settingForm
          this.updateLoading = true
          this.$store
            .dispatch({
              type: operationActionTypes.UPDATE_INTERFACE_MAN,
              payload: {
                list: interfaceManList.map(item => item?.userId),
                productId: this.productId,
                type: this.settingType,
              },
            })
            .then(() => {
              this.isVisible = false
            })
            .finally(() => {
              this.updateLoading = false
            })
        }
      })
    },
  },
}
</script>

<style scoped></style>
