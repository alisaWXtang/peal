<template>
  <FunctionGuideTips
    is-in-page
    v-bind="$attrs"
    tips="管理员可以在这里创建/编辑过滤器，将过滤器分享给项目所有成员。"
  >
    <slot></slot>
  </FunctionGuideTips>
</template>

<script>
import { i18n } from '@/i18n'
import FunctionGuideTips from '../function-guide-tips'
export default {
  name: 'FilterFunctionTips',
  components: {
    FunctionGuideTips,
  },
}
</script>
