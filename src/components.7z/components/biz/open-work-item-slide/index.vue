<template>
  <!-- 工作项滑窗 -->
  <slide
    v-loading="loading"
    :show="visible"
    :afterClose="sliderClose"
    v-bind="$attrs"
    :beforeClose="
      ({ cb }) =>
        beforeSliderClose({
          id: sliderWorkItemInfo.info.id,
          cb: () => {
            !loading && cb()
          },
        })
    "
    :element-loading-text="$t('拼命加载中')"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgb(255,255,255)"
  >
    <div slot="task" :key="id" class="taslinfo">
      <BugDetail
        v-if="sliderWorkItemInfo.type === 'bug'"
        ref="bug"
        :workItemId="sliderWorkItemInfo.info.id"
        :projectId="sliderWorkItemInfo.projectId"
        :show="visible"
        @HandleSide="sliderClose"
        @updateInfoSuccess="updateWorkInfoSuccess"
        @deleteSuccess="updateWorkInfoSuccess"
      ></BugDetail>
      <TaskDetail
        v-if="sliderWorkItemInfo.type === 'task'"
        ref="task"
        :projectId="sliderWorkItemInfo.projectId"
        :workItemId="sliderWorkItemInfo.info.id"
        :show="visible"
        @HandleSide="sliderClose"
        @updateInfoSuccess="updateWorkInfoSuccess"
        @deleteSuccess="updateWorkInfoSuccess"
      ></TaskDetail>
      <RequirementDetail
        v-if="sliderWorkItemInfo.type === 'requirement'"
        ref="requrire"
        :projectId="sliderWorkItemInfo.projectId"
        :workItemId="sliderWorkItemInfo.info.id"
        :show="visible"
        @HandleSide="sliderClose"
        @updateInfoSuccess="updateWorkInfoSuccess"
        @deleteSuccess="updateWorkInfoSuccess"
      ></RequirementDetail>
    </div>
  </slide>
</template>
<script>
import slide from '@/components/slide-slip'
// import TaskDetail from "@/pages/project/task/taskDetail";
// import RequireDetail from "@/pages/project/requirement/requirementView";
// import BugDetail from "@/pages/project/bugManagement/BugDetail";
import {
  BugDetail,
  TaskDetail,
  RequirementDetail,
} from '@/components/columbus-workitem-display'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import TinymceSaveMixin from '@/mixin/tinymce-save-mixin'
import CopeUrlOpenSliderMixin from './CopeUrlOpenSliderMixin'
import { seeDemand } from '@/service/requirement'

export default {
  name: '',
  components: {
    TaskDetail,
    RequirementDetail,
    BugDetail,
    slide,
  },

  mixins: [TinymceSaveMixin, ProjectCommonMixin, CopeUrlOpenSliderMixin],
  props: {
    sliderStatus: {
      type: Boolean,
      required: false,
      default: false,
    },

    id: {
      type: [String, Number],
      required: false,
      desc: '工作项id',
    },

    workItemType: {
      type: [String, Number],
      required: false,
      desc: '工作项类型，需求1,任务2，缺陷3',
    },

    projectId: {
      type: [String, Number],
      required: false,
      desc: '项目id',
    },
  },

  data() {
    return {
      loading: false,
      workItemMenu: {
        1: 'requirement',
        2: 'task',
        3: 'bug',
      },

      // 通用滑块-滑块信息-需求详情、任务详情、缺陷详情
      sliderWorkItemInfo: {
        projectId: null,
        type: '', // 工作项类型
        info: {
          id: null,
        },

        // 工作项信息
      },
      visible: false,
    }
  },
  computed: {},
  watch: {
    id(id) {
      // 内容切换
      if (id) {
        this.openSlide()
      }
    },
    sliderStatus(status) {
      if (status && this.id) {
        this.openSlide()
      }
      this.visible = status
    },
  },

  created() {},
  mounted() {
    this.visible = this.sliderStatus
  },
  methods: {
    // 通用滑块 - 关闭滑块
    sliderClose() {
      this.sliderWorkItemInfo = {
        projectId: null,
        type: '', // 工作项类型
        info: {
          id: null,
        },

        // 工作项信息
      }
      this.visible = false
      this.$emit('update:sliderStatus', false)
      this.$emit('close')
    },
    //  打开弹窗
    openSlide() {
      if (this.loading) {
        return
      }
      this.loading = true
      setTimeout(() => {
        this.loading = false
      }, 500)

      const type = this.workItemMenu[+this.workItemType]
      if (type === 'requirement') {
        this.checkRequirementInfo({
          id: this.id,
          type,
          projectId: this.projectId,
        })
      } else {
        this.sliderWorkItemInfo = {
          projectId: this.projectId,
          type, // 工作项类型
          info: {
            id: this.id,
          },

          // 工作项信息
        }
      }
    },
    // 需求详情鉴权接口
    checkRequirementInfo(info) {
      seeDemand({ id: info.id }).then((res = {}) => {
        if (res.status === 200) {
          this.sliderWorkItemInfo = {
            projectId: info.projectId,
            type: info.type, // 工作项类型
            info: {
              id: info.id,
            },

            // 工作项信息
          }
        } else {
          this.sliderClose()
        }
      })
    },
    // 更新成功回调函数
    updateWorkInfoSuccess(result) {
      this.$emit('updateWorkInfoSuccess', result)
    },
  },
}
</script>
<style lang="scss" scoped></style>
