## 功能

1. 点击工作项打开右侧弹窗
2. 复制 url 打开右侧弹窗

## 使用

### router.js 配置

考虑到项目下的会默认带上一个 projectId,所有不是在项目下的需要配置一下 router,比如工作台，日历，评审等，需要在 meta 下配置`notUnderProject: true`

```js
   {
    path: '/calendar',
    name: 'calendar',
    component: calendar,
    meta: {
      notUnderProject: true // 主要用于关闭右侧弹窗时,是否需要取消url上的projectId
    }
  }

```

### 点击工作项打开右侧弹窗使用

> 就引入下面就可以了，不需要在 data 里面定义变量，都定义在 mixin 里面

- id: 为工作项 id
- projectId: 项目 id
- workItemType: 工作项类型 1：需求 2：任务 3、缺陷
- sliderStatus：是否打开右侧弹窗
- updateWorkInfoSuccess：更新工作项信息成功的回调函数

```html
<OpenWorkItemSlide
  :id="sliderWorkItemInfo.id"
  :projectId="sliderWorkItemInfo.projectId"
  :workItemType="sliderWorkItemInfo.workItemType"
  :sliderStatus.sync="sliderWorkItemVisible"
  @updateWorkInfoSuccess="updateWorkInfoSuccess"
/>
```

```js
import OpenWorkItemSlide from "@/components/bizComponents/OpenWorkItemSlide";
components: {
  OpenWorkItemSlide
},
```

### 复制链接打开右侧弹窗

为了方便，我把变量都定义在 mixin 里面

```js
import CopeUrlOpenSliderMixin from "@/components/bizComponents/OpenWorkItemSlide/CopeUrlOpenSliderMixin"
mixins: [ CopeUrlOpenSliderMixin ],

```

### 注意点

描述：比如管理视图->成员总览->点击任务（预计总工时/待排期任务数）等这些蓝色数字，会出来一个详情表弹窗 A，在点击详情表里面的标题会打开另外一个弹窗 B(工作项详情右侧弹窗 B)

- 问题 1：
  弹窗 A 的遮罩层会覆盖弹窗 B
- 问题 2
  部分场景下会出现蒙层（描述图片预览、删除附件/取消删除、查看修改记录）

```css
// 解决在一个弹窗中打开slide工作项弹框时，slider弹窗被覆盖问题,比如在管理视图->成员视图->点击任意一个蓝色数字(会出来一个弹窗A)->在点击标题（在弹窗上面打开工作项详情的弹窗B），这时候A弹窗遮罩层会覆盖B弹窗，也就是说看不到工作项详情弹窗
.detail-dialog-wrap {
  .slide-change-dialog-zindex {
    z-index: 1090 !important;
  }
  .v-modal {
    z-index: 1080 !important;
  }
  // 解决部分场景下会出现蒙层（描述图片预览、删除附件/取消删除、查看修改记录）,建议参考src\pages\tool\PopList\index.vue
  .modal-dialog-bg {
    width: 100vw;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    z-index: 1080;
    background: rgba(0, 0, 0, 0.5);
  }
}
```
