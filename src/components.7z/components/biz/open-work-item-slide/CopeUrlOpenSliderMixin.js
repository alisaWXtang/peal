/*
 *@Description: 该文件主要是实现通过复制链接打开工作项右侧弹窗,具体用法在readme.md文件
 *@Author:  wangling
 *@Date: 2020-05-29 15:37:08
 */

export default {
  data() {
    return {
      sliderWorkItemInfo: {
        //右侧弹窗信息,通过props传递给slider组件
        id: '', //工作项id
        projectId: '', //项目id
        workItemType: '', //工作项类型 1-需求，2-任务，3-缺陷
      },
      sliderWorkItemVisible: false, //是否打开slider右侧弹窗
    }
  },
  mounted() {
    this.isNeedcopeLinkOpenSlider()
  },
  methods: {
    // 复制工作项链接,是否需要打开右侧弹窗
    copeLinkOpenSlide() {
      const { projectId, bugId, requireId, taskId } = this.$route.query
      let id = bugId || requireId || taskId
      //  通过url打开弹窗
      if (!id) {
        return false
      }
      let info = {
        id,
        projectId,
      }

      if (bugId) {
        info.workItemType = 3
      }
      if (taskId) {
        info.workItemType = 2
      }
      if (requireId) {
        info.workItemType = 1
      }
      return info
    },
    //打开右侧弹窗具体操作
    isNeedcopeLinkOpenSlider() {
      const sliderInfo = this.copeLinkOpenSlide()
      if (sliderInfo) {
        this.sliderWorkItemInfo = sliderInfo
        this.sliderWorkItemVisible = true
      }
    },
  },
}
