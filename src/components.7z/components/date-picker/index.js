import { i18n } from '@/i18n'
import DatePicker from './src/picker/date-picker'
import ElementLocale from '@heytap/cook-ui/src/locale'

ElementLocale.i18n((key, value) => i18n.t(key, value))

DatePicker.install = function install(Vue) {
  Vue.component(DatePicker.name, DatePicker)
}

export default DatePicker
