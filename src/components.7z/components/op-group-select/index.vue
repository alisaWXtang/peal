<template>
  <div class="custom-select-wrap">
    <div
      v-if="mode === 'text'"
      class="select-title"
      :class="{
        hidden: mode !== 'text',
        'select-title__active': propverVisible,
        pr24: pr24,
      }"
      @click="handleTitleClick"
    >
      <span class="content" :style="{ 'max-width': width - 24 + 'px' }">{{
        selectedTitle
      }}</span>
      <!--      <i-->
      <!--        v-if="canClearAll && selected.length && selected[0] !== 'all'"-->
      <!--        class="select-title__icon el-icon-close"-->
      <!--        :class="{ 'icon-arrow-close__canClearAll': canClearAll }"-->
      <!--        @click.stop="handleClearAllClick"-->
      <!--      ></i>-->
      <i class="select-title__icon el-icon-arrow-down"></i>
    </div>
    <el-select
      ref="select"
      v-model="selected"
      style="width: 220px"
      placeholder
      :class="{ 'el-select-wrap': mode === 'text' }"
      multiple
      collapse-tags
      :popper-class="customClass"
      @change="onSelectChange"
      @visible-change="onVisibleChange"
      @remove-tag="onRemove"
    >
      <li class="search-input">
        <el-input
          ref="sprintSearchInput"
          v-model.trim="filterString"
          v-focus
          :placeholder="$t('搜索')"
        ></el-input>
      </li>
      <div
        class="select-scroll scrollbal-common"
        :class="{ 'has-group': sprintData.length }"
      >
        <el-option
          :label="$t('清除选中')"
          value=""
          style="font-size: 12px;height: 30px;line-height: 30px;"
          @click.native="onClearAll"
        ></el-option>
        <el-option :label="allLabel" value="all"></el-option>
        <el-option-group
          v-for="group in sprintData"
          :key="group[valueAttr]"
          :label="group[labelAttr]"
        >
          <el-option
            v-for="item in group.children"
            :key="item[valueAttr]"
            :label="item[labelAttr]"
            :value="item[valueAttr]"
          ></el-option>
        </el-option-group>
        <el-option
          v-if="!sprintData.length"
          :label="$t('无数据')"
          :value="$t('无数据')"
          disabled
        ></el-option>
      </div>
    </el-select>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 项目 迭代多选
 * @desc 使用 el-select 组件
 * @author wuqian
 * @date 2019.12.5
 */
import { inputFocusPublic } from '@/utils/focusPublicUtil.js'
export default {
  name: 'OpGroupSelect',
  components: {},
  model: {
    prop: 'defaultSelected',
    event: 'change',
  },

  props: {
    // 选择器模式: text input
    mode: {
      type: String,
      default() {
        return 'text'
      },
    },

    // 默认选中值
    defaultSelected: {
      type: [String, Array],
      default() {
        return ''
      },
    },

    // 选择器标记
    selectedLabel: {
      type: String,
      default() {
        return ''
      },
    },

    customClass: {
      type: String,
      desc: '自定义 Select 下拉框的类名',
    },

    // 选择器宽度
    width: {
      type: String,
      default() {
        return '150'
      },
    },

    allValue: {
      type: String,
      default() {
        return 'all'
      },
    },

    data: {
      type: Array,
      default() {
        return []
      },
    },

    labelAttr: {
      type: String,
      default() {
        return 'name'
      },
    },

    valueAttr: {
      type: String,
      default() {
        return 'value'
      },
    },

    allLabel: {
      type: String,
      default() {
        return i18n.t('全部')
      },
    },

    // 清除所选项
    canClearAll: {
      type: Boolean,
      default() {
        return true
      },
    },

    projectId: {
      type: [Number, String],
      desc: '项目id',
    },
  },

  data() {
    return {
      // selected: [101577, 101578, 1015771],
      selected: ['all'], // 选中后的 value 值
      selectedCopy: [],
      search: '',
      filterString: '', // 过滤字段
      sprintData: [], // 组件下拉列表数据
      sprintDataCopy: [], // 原始数据
      selectedTitle: '', // 选中后显示的标题
      propverVisible: false, // 下拉框显隐
      focusTimer: null, //input聚焦用到定时器
    }
  },

  computed: {
    pr24() {
      return (
        !this.canCancel && (!this.selected.length || this.selected[0] === 'all')
      )
    },
  },
  watch: {
    // 监听用户过滤操作
    filterString(val) {
      // 回退到原始数据
      this.sprintData = this._deepClone(this.sprintDataCopy)
      // 过滤子节点 name 属性包含 val 的数据
      this.sprintData = this.filterSprintData(this.sprintData, val)
    },
    defaultSelected(val) {
      this.selected = this.filterSelectedValue(val)
      this.setSelected(this.selected)
      this.$emit(
        'setFilterDataLabel',
        this.selected,
        this.selectedTitle,
        this.handleClearAllClick,
      )
    },
    data: {
      handler: function(val) {
        this.sprintData = this._deepClone(val)
        // 拷贝原始数据
        this.sprintDataCopy = this._deepClone(this.sprintData)
      },
      immediate: true,
    },
  },

  mounted() {
    if (this.selectedLabel) {
      this.setSelectedTitle(this.selected)
    } else {
      this.selectedTitle = ''
    }
  },
  methods: {
    onClearAll() {
      this.selected = []
      this.setSelectedTitle(this.selected)
    },
    handleClearAllClick() {
      this.$emit('change', [])
      this.$emit(
        'setFilterDataLabel',
        [],
        this.selectedTitle,
        this.handleClearAllClick,
      )
    },
    onRemove(val) {
      this.selected.forEach((item, index) => {
        if (val === item) {
          this.selected.splice(index, 1)
        }
      })
      this.$emit('change', this.selected[0] === 'all' ? [] : this.selected)
    },
    // 点击标题区域触发
    handleTitleClick() {
      // 打开下拉框
      this.$refs.select.$el.click()
      this.$emit('click')
    },
    // 选中下拉列表值触发
    onSelectChange(val) {
      this.setSelected(val)
      this.$emit(
        'change',
        !this.selected.length ||
          this.selected[0] === 'all' ||
          this.selected[this.selected.length - 1] === ''
          ? []
          : this.selected,
      )
      this.$emit(
        'setFilterDataLabel',
        !this.selected.length ||
          this.selected[0] === 'all' ||
          this.selected[this.selected.length - 1] === ''
          ? []
          : this.selected,
        this.selectedTitle,
        this.handleClearAllClick,
      )
    },
    // 下拉框出现/隐藏时触发
    onVisibleChange(show) {
      // 当下拉框出现时，聚焦
      inputFocusPublic(show, 'sprintSearchInput', this.focusTimer, this)
      // this.propverVisible = !this.propverVisible
      if (!this.propverVisible) {
        this.filterString = ''
        // 选中为空的场景 标题部分为全部
        if (!this.selected.length) {
          this.setSelected(['all'])
        }
      }
    },
    // 过滤选中项 解决初始值不在列表的问题
    filterSelectedValue(val) {
      if (!val.length || !this.sprintDataCopy.length) return [this.allValue]
      if (val[val.length - 1] === this.allValue) return val
      // 暂存所有子数据项value，优化搜索最大时间复杂度O(n3)
      const dataValues = []
      // 分组模式
      // 降维
      this.sprintDataCopy.forEach(group => {
        const children = group.children
        children &&
          children.forEach(item => {
            // 兼容id = 0
            if (item[this.valueAttr] || item[this.valueAttr] === 0) {
              dataValues.push(item[this.valueAttr])
            }
          })
      })
      // 过滤
      return (
        val.filter(item => {
          return dataValues.includes(item)
        }) || []
      )
    },
    // 将选中的 value 暂存到 this.selected
    setSelected(val) {
      // 全选操作
      if (this.isHandleAll(val)) {
        this.selected = [this.allValue]
      }
      // 非全选操作移除全部
      if (this.isHandleItem(val)) {
        this.selected.splice(0, 1)
      }
      // text 模式动态改变 select-title 区域选中项内容
      if (this.mode === 'text') {
        this.setSelectedTitle()
      }
    },
    isHandleAll(val) {
      return (val && val[val.length - 1] === this.allValue) || !val.length
    },
    isHandleItem(val) {
      return val && val[0] === this.allValue && val.length > 1
    },
    // 显示选中项内容
    setSelectedTitle() {
      const label = this.selectedLabel ? `${this.selectedLabel}: ` : ''
      let title = ''
      if (Array.isArray(this.selected) && this.selected.length) {
        title = this.searchSprintLabel(this.selected).join(', ')
      }
      // 选中项内容
      this.selectedTitle = label + title
      // this.$emit('setTags', label + this.selectedTitle)
      // this.selectedTitle = title
    },
    // 遍历原始数据, 由选中的 value 查找选中项 label（注：遍历过程中需要注意选中顺序，以队列方式查找）
    searchSprintLabel(values) {
      const labels = []
      if (!values.length) return labels
      if (values[0] === 'all') return [this.allLabel]
      this.sprintDataCopy.forEach(group => {
        const children = group.children
        children.forEach(item => {
          const indexOf = values.indexOf(item[this.valueAttr])
          if (indexOf !== -1) {
            // 模拟队列 保证选中项 label 在页面的显示顺序
            labels[indexOf] = item[this.labelAttr]
          }
        })
      })
      // 数组去假值
      return labels.filter(Boolean)
    },
    // 从‘迭代’树 children 子节点的 this.labelAttr 属性中 过滤所有包含 val 的数据项
    filterSprintData(source, val) {
      if (!source || !source.length) return []
      const hasValList = []
      source.forEach((group, i) => {
        const children = group.children
        const nGroup = this._deepClone(group)
        nGroup.children = []
        hasValList.push(nGroup)
        if (children) {
          children.forEach(item => {
            if (item[this.labelAttr] && item[this.labelAttr].includes(val)) {
              if (hasValList[i].children) {
                hasValList[i].children.push(item)
              }
            }
          })
        }
      })
      // 剔除 children 子树中为列表为空的数据项 避免界面只显示分组的组名 但是没有数据项
      const noEmptyList = []
      hasValList.forEach(item => {
        if (item.children.length) {
          noEmptyList.push(item)
        }
      })
      return noEmptyList
    },
    // 深拷贝
    _deepClone(source) {
      if (!source && typeof source !== 'object') {
        throw new Error('error arguments', 'shallowClone')
      }
      const targetObj = source?.constructor === Array ? [] : {}
      Object.keys(source).forEach(keys => {
        if (source[keys] && typeof source[keys] === 'object') {
          targetObj[keys] = source[keys].constructor === Array ? [] : {}
          targetObj[keys] = this._deepClone(source[keys])
        } else {
          targetObj[keys] = source[keys]
        }
      })
      return targetObj
    },
  },
}
</script>
<style lang="scss">
@import '@/style/custom-select/index.scss';
</style>
<style lang="scss" scoped>
.custom-select-wrap {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  box-sizing: border-box;
  .select-title__icon {
    color: #bfbfbf;
  }
  .select-title {
    padding: 0 12px;
    &:hover {
      border-color: $--color-primary;
      color: #666666;
      background: #ffffff;
    }
  }
}
.search-input {
  padding: 0 10px;
}

.el-select-group__wrap:not(:last-of-type) {
  padding-bottom: 13px;
}

.el-select-group__wrap:not(:last-of-type)::after {
  bottom: 6px;
}

/deep/ .el-select__tags-text {
  max-width: 105px !important;
}
</style>
