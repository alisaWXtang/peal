# coteam项目业务组件 迭代列表、项目列表 分组展示

time: 2019.12.5
author: wuqian

## 说明

使用 el-select 组件
组件内部通过 http 请求获取迭代列表数据
外部可传入列表数据