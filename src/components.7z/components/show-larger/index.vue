<template>
  <div id="show-larger-content" class="show-larger-content">
    <div
      ref="textEditShow"
      class="edit-box-bug-inactive scrollbal-common"
      @click="clickImg($event)"
      @copy="handleCopy"
      v-html="contentHTML"
    ></div>
    <!--    <el-dialog-->
    <!--      :visible.sync="imgDialog"-->
    <!--      class="el-dialog-img"-->
    <!--      :fullscreen="true"-->
    <!--      :modal-append-to-body="modaltobody"-->
    <!--      :close-on-click-modal="shadeBtn"-->
    <!--      :show-close="false"-->
    <!--    >-->
    <!--      <img-->
    <!--        v-if="imgDialog"-->
    <!--        style="width: 100%"-->
    <!--        :src="imgPath"-->
    <!--        @click="closeImgDialog()"-->
    <!--      />-->
    <!--    </el-dialog>-->
    <div v-if="imgDialog" class="pictrue-preview" @click="closeImgDialog()">
      <img :src="imgPath" />
    </div>
  </div>
</template>
<script>
import { urlToHtmlElA } from '@/utils'
import { replaceImgSrc } from '@/utils/img-util'
export default {
  props: {
    value: {
      type: String,
      require: true,
    },

    mathRomId: {
      //工作项的详情Id
      type: [String, Number],
    },
  },
  data() {
    return {
      modaltobody: false,
      shadeBtn: true,
      imgPath: '',
      imgDialog: false,
    }
  },

  computed: {
    contentHTML: function() {
      // 将 p 替换为 span，解决复制换行问题
      let value = this.value ? this.value.replace(/\r\n/g, '<br />') : ''
      // value = value.replace(/\<p\>/g, '<span>');
      // value = value.replace(/\<\/p\>/g, '</span>' + String.fromCharCode(10));

      // 解决链接不能跳转的问题
      let valueReplaceUrl = value.replace(
        // eslint-disable-next-line
        /(?<=[^\'\"\=\]])((https?:\/\/)[A-Za-z0-9]+\.[A-Za-z0-9]+[\/=\?%\-&_~`@[\]\':+!]*([^<>\"\"\s])*)(?=[^\'\"])/gis,
        function(w) {
          return w + ' '
        },
      )
      return replaceImgSrc(valueReplaceUrl)
    },
  },

  watch: {
    mathRomId() {
      setTimeout(() => {
        this.setHref()
      }, 500)
    },
    value() {
      this.$nextTick(() => {
        this.urlToA()
      })
    },
  },

  mounted() {
    setTimeout(() => {
      this.setHref()
    }, 500)
    this.$nextTick(() => {
      this.urlToA()
    })
  },
  methods: {
    setHref() {
      const { textEditShow } = this.$refs
      if (textEditShow) {
        const textEditShowATag = textEditShow.getElementsByTagName('a')
        for (let i = 0; i < textEditShowATag.length; i++) {
          textEditShowATag[i].target = '_blank'
        }
      }
    },
    // 将组件dom中所有的url转成a标签
    urlToA() {
      // eslint-disable-next-line no-useless-escape
      const URL_REG = /https?:\/\/[\w\-_]+(\.[\w\-_]+)+([\w\-\.,@?^=%&amp;:/~\+#]*[\w\-\@?^=%&amp;/~\+#])?/
      const { textEditShow } = this.$refs
      // dom 中 #text 节点替换成 p 元素
      textEditShow.childNodes.forEach(item => {
        if (item.nodeName !== '#text' || !item.nodeValue) {
          return
        }
        const el = document.createElement('p')
        el.innerHTML = item.nodeValue
        item.replaceWith(el)
      })
      textEditShow.childNodes.forEach(item => {
        if (!item.innerHTML) {
          return
        }
        // 兼容文本编辑器换行符替换成 <br> 的场景 思路：将字符串分割成包含br部分和不包含br的部分 将不包含br的url转a再拼接
        const brIndex = item.innerHTML.indexOf('<br>')
        let urlStr = item.innerHTML
        let hasBrStr = ''
        if (brIndex !== -1) {
          urlStr = item.innerHTML.substr(0, brIndex)
          hasBrStr = item.innerHTML.substr(brIndex)
        }
        // !item.innerHTML.includes('↵')：加这个判断主要是为了性能优化，每个换行的html元素都会生成 "'↵ '文本" 表示换行
        // 不匹配a标签、img标签, 因为有可能自带链接 造成二次替换
        if (
          urlStr &&
          URL_REG.test(urlStr) &&
          !/<img/.test(urlStr) &&
          !urlStr.includes('↵')
        ) {
          const results = /<a .*">(.*)<\/a>/.exec(urlStr)
          if (/<\/a>/.test(urlStr) && results) {
            // 如果是已经存在的 a 标签，则替换链接内容
            item.innerHTML = urlStr.replace(
              /href=".*">/,
              `href="${results[1]}">`,
            )
          } else {
            item.innerHTML = `${urlToHtmlElA(urlStr)}${hasBrStr}`
          }
        }
      })
    },
    closeImgDialog() {
      this.imgDialog = false
      this.imgPath = ''
    },
    clickImg(event) {
      if (event.target.nodeName == 'IMG') {
        this.imgPath = event.target.src
        // let imgDialog = document
        //   .getElementsByClassName('el-dialog-img')[0]
        //   .getElementsByClassName('el-dialog')[0]
        // imgDialog.setAttribute(
        //   'style',
        //   'width: ' +
        //     (event.target.naturalWidth + 65) +
        //     'px;height: ' +
        //     (event.target.naturalHeight + 25 + 60) +
        //     'px',
        // )

        this.imgDialog = true
      }
    },
    // 复制信息
    handleCopy(e) {
      const clipboardData = e.clipboardData || window.clipboardData
      let text = window.getSelection().toString()
      if (!clipboardData) return

      if (text) {
        e.preventDefault()
        const formatText = this.copyFormatText(text)
        clipboardData.setData('text/plain', formatText)
      }
    },
    // 处理复制文本信息
    copyFormatText(text) {
      // 将信息中\n\r 替换成 ''
      let value = text
        ? text.replace(/(\r|\n|\r\n)+/g, String.fromCharCode(10))
        : ''
      return value
    },
  },
}
</script>
<style scoped lang="scss">
@import '@/style/project/ProjectCommon.scss';
.pictrue-preview {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1000;
  //text-align: center;
  //margin: auto;
  background-color: rgba(0, 0, 0, 0.1);
  overflow: scroll;
  display: flex;
  justify-content: center;
  align-items: center;
  img {
    max-width: 100%;
    max-height: 100%;
  }
}
</style>
