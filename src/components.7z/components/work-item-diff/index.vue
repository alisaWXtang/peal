<template>
  <ColumbusDiff
    class="diff-box"
    :data-empty-text="$t('暂无数据')"
    :pre-content="preContent"
    :next-content="nextContent"
  ></ColumbusDiff>
</template>
<script>
/**
 * @title 工作项内容 diff
 * @desc
 * @author heyunjiang
 * @date 2019.12.13
 */
import ColumbusDiff from '@/components/columbus-diff'
import { htmlDiff } from '@/service/diff'

export default {
  name: 'WorkItemDiff',
  components: {
    ColumbusDiff,
  },

  mixins: [],
  props: {
    apiParams: {
      type: Object,
      default: function() {
        return {}
      },
    },
  },

  data() {
    return {
      preContent: '',
      nextContent: '',
    }
  },
  computed: {
    query() {
      const keys = [
        'workItemType',
        'workItemId',
        'rightContentId',
        'leftContentId',
      ]

      const params = Object.assign({}, this.$getUrlParams(), this.apiParams)
      const query = {}
      Object.entries(params).forEach(([key, val]) => {
        if (keys.includes(key)) {
          query[key] = val
        }
      })

      return query
    },
  },

  watch: {},
  created() {},
  mounted() {
    this.getDiffValue()
  },
  methods: {
    async getDiffValue() {
      const result = await htmlDiff(this.query)
      if (result.status === 200 && result.data) {
        this.preContent = result.data.left.content
        this.nextContent = result.data.right.content
      }
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/work-diff/index.scss';
</style>
