<template>
  <div class="custom-input__container">
    <co-input
      class="custom-input"
      v-model.trim="value_"
      v-bind="$attrs"
      v-on="$listeners"
      @keyup.native.enter="handleSearchThrottle"
    >
      <template v-slot:suffix>
        <div class="custom-input__icon">
          <i
            v-if="value_"
            class="el-input__icon el-icon-close"
            @click="handleClear"
          ></i>
          <i v-if="value_" class="line"></i>
          <i
            class="el-input__icon el-icon-search"
            @click="handleSearchThrottle"
          ></i>
        </div>
      </template>
    </co-input>
  </div>
</template>
<script>
/**
 * @title 项目通用input组件
 * @desc 基于co-input、增加自定义清除图标、过滤图标
 * @author wuqian
 * @date 2020.5.11
 *
 * event
 *   search：回车键、搜索图标触发的事件
 *
 */
import { debounce } from 'lodash'
export default {
  name: 'CustomInput',
  model: {
    prop: 'value',
    event: 'search',
  },

  props: {
    value: {
      type: String,
      required: true,
    },
  },

  data() {
    return {
      value_: '',
    }
  },
  watch: {
    value: {
      handler: function(val) {
        this.value_ = val
      },
      immediate: true,
    },
  },

  created() {
    this.handleSearchThrottle = debounce(this.handleSearch, 300)
  },
  mounted() {},
  methods: {
    handleClear() {
      this.value_ = ''
      this.$emit('search', this.value_)
    },
    handleSearch() {
      this.$emit('search', this.value_)
    },
  },
}
</script>
<style lang="scss" scoped>
.custom-input__container {
  .custom-input {
    /deep/ .el-input__inner {
      padding-right: 50px !important;
    }
    .el-input__icon {
      cursor: pointer;
      width: 20px;
    }
    .custom-input__icon {
      display: flex;
      .el-icon-close {
        font-size: 12px;
      }
      .line {
        margin: 6px 4px 6px 2px;
        display: inline-block;
        width: 1px;
        height: 16px;
        background-color: #bfbfbf;
      }
    }
  }
}
</style>
