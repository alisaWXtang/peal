# 通用选择器组件

time: 2019.12.6 
author: wuqian

## 说明

使用 el-select 组件