/**
 * @title 用于组件js化
 * @author chenxiaolong
 * @date 2021.3.29
 */

import Vue from "vue";
import ExportBox from "./exportBox.vue";
const exportBoxClass = Vue.extend(ExportBox);

ExportBox.install = (vm, props) => {
  const instance = new exportBoxClass({ propsData: {...props, vm} }).$mount();
  if (process.env.NODE_ENV === "development") {
    vm.$root.$children.push(instance);
  }

  return instance
};

export default ExportBox;
