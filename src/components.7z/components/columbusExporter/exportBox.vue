<template>
  <custom-box :title="title" :can-close="canClose" @close="handleClose">
    <div class="box-progress">
      <el-progress
        :text-inside="true"
        :stroke-width="20"
        :color="color"
        :percentage="exporter.percentage"
      ></el-progress>
    </div>
    <div class="box-info">
      <div class="info-container">
        <template v-if="!errorMsg">
          <template v-if="exporter.percentage === 100">
            <span class="active-color">
              <i class="el-icon-circle-check"></i> {{ vm.$t('导出成功') }}</span>
          </template>
          <template v-else>
            {{ vm.$t('导出中') }}...，{{ vm.$t('总共') }}
            <span class="active-color">{{ dataTotal }}</span> {{ vm.$t('条')
            }}{{ vm.$t('数据') }}，{{ vm.$t('正在导出第') }}
            <span class="active-color"
              >{{ exporter.range[0] }}-{{ exporter.range[1] }}</span
            >
            {{ vm.$t('条') }}{{ vm.$t('数据') }}
          </template>
        </template>
        <div v-else class="danger-color">
          {{ vm.$t('导出失败') }}：{{ errorMsg }}
        </div>
      </div>
    </div>
  </custom-box>
</template>

<script>
/**
 * @title 自定义box盒子，支持拖动
 * @author chenxiaolong
 * @date 2021.3.29
 */
import CustomBox from '../dragBox/index.vue'
import ExportWorker from './export.worker'
import { exportSnippetLen, eventMaps } from './constant'
import EventBus from '../columbusImporter/eventBus'
import { getRealUrl } from '@/utils/sub-app-util'
import { parseResponse } from '@/utils/http'
export default {
  name: 'ExportBox',
  components: {
    CustomBox,
  },
  props: {
    title: {
      type: String,
      required: true,
      desc: '标题',
    },
    vm: {
      type: Object,
      required: true,
    },
    exportUrl: {
      type: String,
      required: true,
      desc: '导出地址',
    },
    requestPayload: {
      type: Object,
      desc: '请求参数',
    },
    headers: {
      type: Array,
      desc: '导出表头',
    },
    formatDataFn: {
      type: Function,
      desc: '处理数据函数',
    },
    pageInfo: {
      type: Object,
      default: () => {
        return {
          pageNumber: 1,
          pageSize: 20,
          totalRecords: 0,
        }
      },
      desc: '分页信息',
    },
  },
  data() {
    return {
      canClose: false,
      worker: null,
      dataTotal: this.pageInfo.totalRecords,
      exporter: {
        percentage: 0,
        range: [
          0,
          this.pageInfo.totalRecords <= exportSnippetLen
            ? this.pageInfo.totalRecords
            : exportSnippetLen,
        ],
        loading: false,
      },
      eventBus: new EventBus(),
      color: '#05b570',
      errorMsg: '',
    }
  },
  computed: {
    localExportUrl() {
      return getRealUrl(this.exportUrl, { ssoToken: true })
    },
  },
  created() {
    this.worker = new ExportWorker()
    this.worker.onmessage = e => {
      const { res, event } = e.data

      parseResponse(
        { data: e.data.res },
        function() {},
        function() {},
      )

      if (res?.status === 200 && event === eventMaps.EXPORT_DATA) {
        this.exportProgress(res)
      } else if (res.status === 200 && event === eventMaps.EXPORT_FILE) {
        this.exportFile(res)
      } else {
        this.color = '#ea3447'
        this.canClose = true
        this.errorMsg = e.data.res?.error?.message || e.data.res.msg
      }
    }
  },
  mounted() {
    this.$once('hook:beforeDestroy', () => {
      // 关闭worker线程
      this.worker && this.worker.terminate()
    })
    this.exportAction()
  },
  methods: {
    on(event, fn) {
      this.eventBus.on(event, fn)
    },
    once(event, fn) {
      this.eventBus.once(event, fn)
    },
    // 关闭
    handleClose() {
      this.$emit('close')
      this.$destroy()
      this.$emit('closed')
    },
    exportAction() {
      this.worker.postMessage({
        event: eventMaps.EXPORT_DATA,
        props: {
          headers: this.headers,
          url: this.localExportUrl,
          payload: this.requestPayload,
          method: 'post',
          pageInfo: this.pageInfo,
        },
      })
    },
    exportProgress(res) {
      this.exporter.percentage = res.data.percentage
      this.exporter.range = res.data.range

      if (this.exporter.percentage === 100) {
        this.canClose = true
      }
    },
    exportFile(res) {
      if (res.status === 200) {
        let data = new Blob([res.data], {
          type: 'application/octet-stream',
        })
        data = URL.createObjectURL(data)
        const a = document.createElement('a')
        a.hidden = true
        a.href = data
        a.download = `${this.vm.$t('跨项目查询导出数据')}.xlsx`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(data)
      }

      this.exportLoading = false
    },
  },
}
</script>

<style lang="scss" scoped>
.active-color {
  color: $--color-primary;
}

.danger-color {
  color: $--color-danger;
}

.import-button,
.validate-button {
  cursor: pointer;
}

.box-progress {
  margin-bottom: 8px;
}

.box-info {
  .validated-text {
    color: $--color-success;
  }
}
</style>
