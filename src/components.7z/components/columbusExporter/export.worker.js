/**
 * @title 导出worker
 * @author chenxiaolong
 * @date 2020.3.29
 */

import axios from 'axios'
import Excel from 'exceljs'
import moment from 'dayjs'
import { eventMaps, exportSnippetLen } from './constant'

/**
 * @title 导出数据
 * @author chenxiaolong
 * @date 2021.4.19
 */
class ExportData {
  constructor(props) {
    this.header = props.headers
    this.url = props.url
    this.method = props.method
    this.payload = props.payload
    this.pageInfo = props.pageInfo
    this.workbook = new Excel.Workbook()
    this.workbook.creator = 'gsdp-columbus'
    this.workbook.lastModifiedBy = 'gsdp-columbus'
    this.workbook.created = new Date()
    this.workbook.modified = new Date()
    this.pageInfo.pageSize = exportSnippetLen
    this.payload.pageInfo.pageSize = exportSnippetLen
    this.pages = Math.ceil(this.pageInfo.totalRecords / this.pageInfo.pageSize)
    this.success = true
  }

  async writeData() {
    const sheet = this.workbook.addWorksheet('导出数据')
    sheet.getRow(1).values = this.header.map(item => item.header)
    sheet.columns = this.header
    let index = 0
    const pages = this.pages
    while (this.pages > 0) {
      --this.pages
      ++index
      const start = (index - 1) * this.pageInfo.pageSize
      let end = start + this.pageInfo.pageSize
      end > this.pageInfo.totalRecords && (end = this.pageInfo.totalRecords)
      try {
        this.payload.pageInfo.pageNum = index
        const res = await httpReq(this.url, this.method, this.payload)

        if (res.data.status === 200 && res.data.data) {
          const pageInfo = res.data.data.pageInfo

          if (pageInfo.totalRecords > 50000) {
            postMessage({
              event: eventMaps.EXPORT_DATA,
              res: {
                status: 0,
                msg: '导出结果超过50000条导出限制，请缩小查询范围再导出',
              },
            })
            this.success = false
            break
          }

          const data = res.data.data.workItemExtends.map(item => {
            return {
              ...item.workItem,
              ...item.workItem.display,
              createTime: moment(item.workItem.createTime).format(
                'YYYY-MM-DD HH:mm:ss',
              ),
              relevantUsers: item.workItem.display.relevantUsers.join(',')
            }
          })
          sheet.addRows(data)
          const percentage = Math.floor((index / pages) * 100)
          postMessage({
            event: eventMaps.EXPORT_DATA,
            res: {
              status: 200,
              data: {
                percentage,
                range: [start, end],
                pageInfo
              },
            },
          })
        } else {
          this.success = false
          postMessage({
            event: eventMaps.EXPORT_DATA,
            res: res.data,
          })
          break
        }
      } catch (error) {
        let data = error
        if (error.response && error.response.data) {
          data = error.response.data
        }
        postMessage({
          event: eventMaps.EXPORT_DATA,
          res: Object.assign({ status: 0 }, data),
        })
        this.success = false
        break
      }
    }
  }

  async exportData() {
    await this.writeData()
    this.success && this.workbook.xlsx.writeBuffer().then(data => {
      postMessage({
        event: eventMaps.EXPORT_FILE,
        res: { status: 200, data },
      })
    })
  }
}

const messageEventMaps = {
  [eventMaps.EXPORT_DATA]: exportData,
}

addEventListener('message', e => {
  const { props, event } = e.data
  messageEventMaps[event] && messageEventMaps[event](props, event)
})

async function httpReq(url, method, payload = {}, ...otherConfig) {
  const config = {
    url,
    method,
    ...otherConfig,
  }

  if (method.toUpperCase() === 'GET') {
    config.params = payload
  } else {
    config.data = payload
  }

  return await axios(config)
}

/**
 * @title 导出数据
 * @param {*} data
 * @param {*} event
 */
function exportData(data, event) {
  try {
    new ExportData(data).exportData()
  } catch (error) {
    postMessage({ event, res: { status: 0, error } })
  }
}
