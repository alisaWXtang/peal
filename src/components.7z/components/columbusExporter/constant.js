/**
 * @title 导出常量
 * @author chenxiaolong
 * @date 2021.3.29
 */

export const eventMaps = {
  EXPORT_DATA: 'EXPORT_DATA',
  EXPORT_FILE: 'EXPORT_FILE'
}

// 导出类型
export const exportTypes = {
  EXPORT_REQUIREMENT: 'EXPORT_REQUIREMENT',
  EXPORT_TASK: 'EXPORT_TASK',
  EXPORT_DEFECT: 'EXPORT_DEFECT',
  EXPORT_CROSS_PROJECT_DATA: 'EXPORT_CROSS_PROJECT_DATA',
}

// 导出长度
export const exportSnippetLen = 1000

// 缓存导出队列名称
export const exportQueueName = 'columbus-export-queue'
