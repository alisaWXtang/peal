<template>
  <date-picker
    ref="datepickercustom"
    v-model="dateValue"
    :popper-class="popperClass"
    v-bind="$attrs"
    prefix-icon="clean-icon"
    :value-format="valueFormat"
    :placeholder="$t('选择日期')"
    :picker-options="_pickerOptions"
    v-on="$listeners"
    @change="selectChange"
  >
  </date-picker>
</template>
<script>
/**
 * @title 全局日期组件
 * @function1 日期增加今天、明天、可清空等功能
 * @function2 日期做周末、节假日标注功能
 * @author chengxuecheng、heyunjiang
 * @date 2019.8.20
 */
import DatePicker from '../date-picker/src/picker/date-picker'
import { i18n } from '@/i18n'

export default {
  name: 'CustomDate',
  components: {
    DatePicker,
  },
  model: {
    prop: 'value',
    event: 'model-event',
  },
  props: {
    value: [String, Date, Array],
    disabledDate: {
      type: Function,
      required: false,
    },
    popperClass: {
      type: String,
      default: 'el-date-default-popper-class',
    },
    pickerOptions: {
      type: Object,
      default: null,
    },
    valueFormat: {
      type: String,
      default: 'yyyy-MM-dd',
    },
  },
  data() {
    return {
      dateValue: this.value,
    }
  },
  computed: {
    _pickerOptions() {
      // 支持自定义
      if (this.pickerOptions) {
        return this.pickerOptions
      }
      let obj = {
        shortcuts: [
          {
            text: i18n.t('最近一周'),
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: i18n.t('最近一个月'),
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: i18n.t('最近三个月'),
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      }
      if (this.disabledDate) {
        obj.disabledDate = this.disabledDate
      }
      return obj
    },
  },
  watch: {
    value() {
      this.dateValue = this.value
    },
  },
  methods: {
    focus() {
      this.$refs.datepickercustom.focus()
    },
    // 支持v-model
    selectChange(value) {
      this.$emit('model-event', value)
    },
  },
}
</script>
<style lang="scss">
@import '@/style/project/ProjectCommon';
</style>
