<template>
  <div
    class="select-wrap cascader-select-wrap"
    :class="{ block: width == '100%' }"
  >
    <div
      v-if="mode === options.textMode"
      class="select-title"
      :class="{
        hidden: mode !== options.textMode,
        'select-title__active': propverVisible,
      }"
      @click="handleTitleClick"
    >
      <span
        class="content"
        :style="{ 'max-width': width + 'px' }"
        :title="selectedTitle"
        >{{ selectedTitle }}</span
      >
      <i
        v-if="canClearAll"
        class="select-title__icon el-icon-close"
        :class="{ 'icon-arrow-close__canClearAll': canClearAll }"
        @click.stop="handleClearAllClick"
      ></i>
      <i
        class="select-title__icon el-icon-arrow-down"
        :class="{ 'icon-arrow-down__canClearAll': canClearAll }"
      ></i>
      <CoCascader
        ref="cascader"
        v-model="value_"
        :class="{ 'el-select-wrap': mode === options.textMode }"
        v-bind="$attrs"
        clearable
        emit-path
        @change="onChange"
        @visible-change="onVisibleChange"
      >
      </CoCascader>
    </div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 项目自定义级联选择器
 * @desc 基于co-cascader
 * @author wuqian
 * @date 2020.5.15
 */
import cloneDeep from 'lodash/cloneDeep'
export default {
  name: 'OpCascader',
  model: {
    prop: 'value',
    event: 'change',
  },

  props: {
    value: {
      type: Array,
    },

    clearable: {
      type: Boolean,
      default: true,
    },

    isNeedLabel: {
      type: Boolean,
      default: false,
    },

    mode: {
      type: String,
      default: 'text',
    },

    // 选择器宽度
    width: {
      type: [String, Number],
      default() {
        return '200'
      },
    },
  },

  data() {
    return {
      value_: [],
      propverVisible: false,
      selectedTitle: '',
      options: {
        elMode: 'element', // element样式
        textMode: 'text', // 哥伦布自定义样式
      },
      data: [],
    }
  },
  computed: {
    canClearAll() {
      return this.clearable && this.value_ && this.value_.length
    },
  },

  watch: {
    value: {
      handler: function(val) {
        if (!val?.length) {
          this.defaultSelectedTitle()
        }
        this.value_ = cloneDeep(val)
      },
      immediate: true,
    },
  },

  created() {},
  mounted() {
    this.setSelectTitle()
  },
  methods: {
    // 清除按钮事件
    handleClearAllClick() {
      this.value_ = []
      this.$emit('change', this.value_)
      this.defaultSelectedTitle()
    },
    defaultSelectedTitle() {
      this.selectedTitle = this.$i18n.t('全部')
    },
    // 点击标题区域触发
    handleTitleClick() {
      // 打开下拉框
      this.$refs.cascader.$el.click()
    },
    // 选中事件
    onChange(val) {
      console.log('----', val)
      this.value_ = val
      if (this.isNeedLabel) {
        this.$nextTick(() => {
          const presentTags = this.$refs.cascader?.presentTags
          this.$emit(
            'change',
            presentTags.map(presentTag => {
              return {
                value: presentTag.node.value,
                label: presentTag.node.label,
              }
            }),
          )
        })
      } else {
        this.$emit('change', this.value_)
      }
      this.$nextTick(() => {
        this.setSelectTitle()
      })
    },
    // 选中后自定义标题
    setSelectTitle() {
      const presentTags = this.$refs.cascader?.presentTags
      let selectedTitle = ''
      if (presentTags?.length) {
        presentTags.forEach(item => {
          selectedTitle = `${selectedTitle} ${item.text}, `
        })
        selectedTitle = selectedTitle.slice(0, -2)
      } else {
        selectedTitle = i18n.t('全部')
      }
      this.selectedTitle = selectedTitle
    },
    // 下拉框显示隐藏事件
    onVisibleChange(val) {
      this.propverVisible = val
    },
  },
}
</script>
<style lang="scss" scoped>
@import '@/style/ele-variables';
@mixin ellipsis {
  overflow: hidden !important;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.select-wrap {
  position: relative;
  display: inline-block;
  line-height: 0;
  vertical-align: middle;
  width: 100%;
}
.cascader-select-wrap {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  box-sizing: border-box;
}
.icon-arrow-down__canClearAll {
  right: 5px;
}
.icon-arrow-close__canClearAll {
  right: 22px;
}
@mixin active {
  border: 1px solid $--color-primary;
  .el-icon-close {
    color: $--color-primary;
    border: 1px solid $--color-primary;
    background: $--color-primary-light-9;
  }
}
.select-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px;
  border-radius: 3px;
  box-sizing: border-box;
  height: 30px;
  line-height: 28px;
  transition: all 0.2s;
  cursor: pointer;
  border: 1px solid transparent;
  &:hover {
    @include active;
  }
  .content {
    @include ellipsis;
    line-height: 1;
    font-size: 14px;
  }
  .el-icon-close {
    border-radius: 50%;
    background-color: #999;
    border: 1px solid #999;
    color: #fff;
    padding: 2px;
    transform: scale(0.7);
  }
}
.select-title__icon {
  margin-left: 10px;
}
.select-title__active {
  @include active;
}
/deep/ .el-select-wrap {
  position: absolute;
  top: 0;
  visibility: hidden;
  width: 0;
  /deep/ .el-cascader__tags {
    display: none;
  }
}
.block {
  display: block;
}
</style>
