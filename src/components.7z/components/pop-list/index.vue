<template>
  <div :class="{ 'pop-list': popListType }" class="detail-dialog-wrap">
    <el-dialog
      :visible="ifShowDialog"
      :title="dialogTitle"
      :close-on-click-modal="false"
      :width="dialogWidth || '1000px'"
      class="slide-change-dialog-zindex"
      :modal-append-to-body="false"
      :modal="false"
      @close="handleClosePopList"
    >
      <div v-if="popList.length" v-loading="loading">
        <el-table
          :data="popList"
          :cell-style="addFirstColumnStyle"
          :max-height="maxHeight"
          border
          :highlight-current-row="currentRowShow"
          @cell-click="firstCellClick"
          @sort-change="sortChangeHandle"
        >
          <el-table-column
            v-for="colConfig in colConfigs"
            :key="colConfig.prop"
            :prop="colConfig.prop"
            :label="colConfig.label"
            :width="colConfig.width ? colConfig.width : ''"
            :show-overflow-tooltip="showOverTip"
            :sortable="colConfig.sortable"
          >
            <template #default="scope">
              <span
                :class="{
                  'title-gray':
                    colConfig.prop == 'title' && !scope.row.hasPermission,
                }"
                >{{ scope.row[colConfig.prop] || '--' }}</span
              >
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div v-else-if="!loading">{{ $t('暂无相关数据') }}</div>
      <el-pagination
        v-if="ifShowPopListPagination"
        class="poplist-pagination"
        :current-page="popListPageInfo.pageNumber"
        :page-size="popListPageInfo.pageSize"
        :total="popListPageInfo.totalRecords"
        :layout="pagination.layout"
        @current-change="currentChange"
      ></el-pagination>
    </el-dialog>
    <div v-if="ifShowDialog" class="modal-dialog-bg"></div>
  </div>
</template>
<script>
/**
 * @title 弹窗列表组件
 * @desc 支持dialog标题和列表header的配置，支持首列点击跳转事件
 * @author liufeng
 * @date 2020.4.14
 */

// 根据跳转工作项类型所要跳转的页面
const JumpToNewpage = {
  sprintPop: '/sprint/detail',
  require: '/requirement/list',
  task: '/task/view',
  bug: '/bug/list',
}

import CONSTVARLIABLE from '@/store/mutation-types'
import { mapState } from 'vuex'
export default {
  name: 'PopList',
  props: {
    popListType: {
      type: String,
      require: false,
      default: '',
      desc: '首列跳转工作项类型',
    },

    showOverTip: {
      type: Boolean,
      require: false,
      default: true,
      desc: '内容过长是否隐藏',
    },
  },

  data() {
    return {
      maxHeight: 420, // 设置表格的最大高度
      pagination: {
        layout: 'total, prev, pager, next',
      },

      currentRowShow: false, // 是否高亮当前行
    }
  },
  computed: {
    ...mapState({
      loading: state => state.manageViewPopList.loading,
      popList: state => state.manageViewPopList.popList,
      dialogTitle: state => state.manageViewPopList.dialogTitle,
      colConfigs: state => state.manageViewPopList.colConfigs,
      addColumnStyle: state => state.manageViewPopList.addFirstColumnStyle,
      popListPageInfo: state => state.manageViewPopList.pageInfo,
      dialogWidth: state => state.manageViewPopList.dialogWidth,
    }),

    // 用于dialog与列表信息同步显示
    ifShowDialog() {
      return !!this.colConfigs.length
    },
    // 是否显示分页信息
    ifShowPopListPagination() {
      return this.popListPageInfo.totalPages
    },
  },

  methods: {
    // 关闭弹窗 并初始化弹窗的state
    handleClosePopList() {
      this.$store.commit(CONSTVARLIABLE.UPDATE_MANAGEVIEW_INIT_POP_LIST)
    },
    // 给第一列元素添加样式
    addFirstColumnStyle({ columnIndex }) {
      if (this.addColumnStyle && columnIndex == 0) {
        return 'color:#3081F2cursor:pointer;'
      }
    },
    // 点击第一列时的跳转事件
    firstCellClick(row, column) {
      if (!row.hasPermission) {
        return
      }

      // 通过判断是否需要给第一列增加可点击的样式来判断是否可点击
      if (
        this.addColumnStyle &&
        (column.property == 'title' || column.property == 'name')
      ) {
        this.currentRowShow = true
        if (this.popListType == 'sprintPop') {
          const projectId = this.$store.state.manageViewPopList.projectId
          window.open(
            `${
              JumpToNewpage[this.popListType]
            }?projectId=${projectId}&sprintId=${row.id}`,
          )
        } else {
          const sliderWorkItemInfo = {
            id: row.id,
            projectId: row.projectId,
            workItemType: row.workItemType,
          }

          this.$emit('openSlider', sliderWorkItemInfo)
        }
      }
    },
    // 排序规则变化
    sortChangeHandle({ column, prop, order }) {
      this.$emit('popListSortChange', { column, prop, order })
    },
    // 分页跳转
    currentChange(num) {
      this.$emit('popListCurrentChange', num)
    },
    // 改变pageSize
    handleSizeChange(pageSize) {
      this.$emit('popListSizeChange', pageSize)
    },
  },
}
</script>

<style lang="scss" scoped>
.title-gray {
  color: #666666;
}
.pop-list {
  top: -40vh;
}
.poplist-pagination {
  display: flex;
  justify-content: flex-end;
  margin-top: 4px;
}
.pop-list-dialog-bg {
  width: 100vw;
  height: 100vh;
  position: fixed;
  left: 0;
  top: 0;
  z-index: 1080;
  background: rgba(0, 0, 0, 0.5);
}
/deep/ .el-dialog__body {
  padding: 0;
}
</style>
