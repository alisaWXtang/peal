<template>
  <div ref="tooltip" class="tooltip">
    <template v-if="closeClickStop">
      <div class="text-pointer">
        <span v-if="!isHtml" v-show="!showToolTip" ref="tooltipItem">{{
          value
        }}</span>
        <span
          v-else
          v-show="!showToolTip"
          ref="tooltipItem"
          v-html="value"
        ></span>
      </div>
      <span
        v-if="!isHtml"
        v-show="showToolTip"
        ref="tooltipInnerItem"
        class="text-pointer template-text"
        >{{ value }}</span
      >
      <span
        v-else
        v-show="showToolTip"
        ref="tooltipInnerItem"
        class="text-pointer template-text"
        v-html="value"
      ></span>
    </template>
    <template v-else>
      <div class="text-pointer" @click.stop="spanClick">
        <span v-if="!isHtml" v-show="!showToolTip" ref="tooltipItem">{{
          value
        }}</span>
        <span
          v-else
          v-show="!showToolTip"
          ref="tooltipItem"
          v-html="value"
        ></span>
      </div>
      <span
        v-if="!isHtml"
        v-show="showToolTip"
        ref="tooltipInnerItem"
        class="text-pointer template-text"
        @click.stop="spanClick"
        >{{ value }}</span
      >
      <span
        v-else
        v-show="showToolTip"
        ref="tooltipInnerItem"
        class="text-pointer template-text"
        @click.stop="spanClick"
        v-html="value"
      ></span>
    </template>

    <el-tooltip
      v-show="showToolTip"
      :popper-class="popperClass"
      effect="dark"
      :placement="placement"
    >
      <template v-if="!isHtml">
        <span slot="content" class="tooltip-slot">{{ value }}</span>
        <span v-if="closeClickStop" class="text-pointer tooltip-content-bake">{{
          value
        }}</span>
        <span
          v-else
          class="text-pointer tooltip-content-bake"
          @click.stop="spanClick"
          >{{ value }}</span
        >
      </template>
      <template v-else>
        <span slot="content" class="tooltip-slot" v-html="value"></span>
        <span
          v-if="closeClickStop"
          class="text-pointer tooltip-content-bake"
          v-html="value"
        ></span>
        <span
          v-else
          class="text-pointer tooltip-content-bake"
          @click.stop="spanClick"
          v-html="value"
        ></span>
      </template>
    </el-tooltip>
  </div>
</template>
<script>
/**
 * @title 文字省略组件
 * @desc 用于需求分类树、滑窗工作项title
 * @author heyunjiang
 * @date 2019.6.17
 */
export default {
  name: 'EllipsisBlock',
  components: {},
  mixins: [],
  props: {
    value: {
      type: String,
      required: true,
    },

    popperClass: String,
    placement: {
      type: String,
      default: 'top-start',
    },
    closeClickStop: {
      type: Boolean,
      default: false,
    },
    isHtml: {
      type: Boolean,
      default: false,
    },
  },

  data() {
    return {
      showToolTip: false,
    }
  },
  computed: {},
  watch: {
    value() {
      this.$nextTick(this.computedshowToolTip)
    },
  },

  mounted() {
    this.computedshowToolTip()
  },
  methods: {
    spanClick(e) {
      this.$emit('click', e)
    },
    computedshowToolTip() {
      const parentwidth = this.$refs.tooltip.getBoundingClientRect().width
      let childWidth = 0
      if (this.showToolTip) {
        childWidth = this.$refs.tooltipInnerItem.getBoundingClientRect().width
      } else {
        childWidth = this.$refs.tooltipItem.getBoundingClientRect().width
      }
      if (parentwidth < childWidth) {
        this.showToolTip = true
      } else {
        this.showToolTip = false
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.tooltip {
  display: inline-block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  position: relative;
}
.tooltip-slot {
  display: inline-block;
  max-width: 100vw;
  box-sizing: border-box;
  padding: 0 10px;
}
.tooltip-content-bake {
  display: inline-block;
  max-width: 100%;
  @include no-wrap;
}
.text-pointer {
  cursor: pointer;
}

.template-text {
  position: absolute;
  color: transparent;
  z-index: -1;
}
</style>
