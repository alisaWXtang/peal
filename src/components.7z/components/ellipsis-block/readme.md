# 文字省略组件

time: 2019.6.17  
author: heyunjiang

## 说明

当文字超出模块，则省略，并且鼠标悬浮有 tooptip 提示；如果不超出，则正常显示，没有 tooltip 提示。
