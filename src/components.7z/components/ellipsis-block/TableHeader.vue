<template>
  <span
    ref="tooltip"
    class="tooltip tool-table-header"
    :class="{ 'tool-table-header-sortable': sortable }"
  >
    <span @click="spanClick"
      ><span v-show="!showToolTip" ref="tooltipItem">{{ value }}</span></span
    >
    <span v-show="showToolTip" ref="tooltipInnerItem" @click="spanClick">{{
      value
    }}</span>
    <!--    <el-tooltip v-show="showToolTip" effect="dark" placement="top-start">-->
    <!--      <span slot="content" class="tooltip-slot">{{ value }}</span>-->
    <!--      <span class="tooltip-content-bake" @click="spanClick">{{ value }}</span>-->
    <!--    </el-tooltip>-->
  </span>
</template>
<script>
/**
 * @title 文字省略组件 - 只用于表格头部
 * @desc 用于需求分类树、滑窗工作项title；
 * @desc 与 index 不同的是 1. 将所有 div 换成了 span; 2. 去掉了 class="cursor-pointer" 3. 设置了宽度 4. 去掉了 click.stop
 * @author heyunjiang
 * @date 2020.1.20
 */
export default {
  name: 'TableHeader',
  components: {},
  mixins: [],
  props: {
    value: {
      type: String,
      required: true,
    },

    sortable: {
      type: Boolean,
      required: false,
      default: false,
    },
  },

  data() {
    return {
      showToolTip: false,
    }
  },
  computed: {},
  watch: {
    value() {
      this.$nextTick(this.computedshowToolTip)
    },
  },

  mounted() {
    this.$nextTick(this.computedshowToolTip)
  },
  methods: {
    spanClick() {
      this.$emit('click')
    },
    computedshowToolTip() {
      const parentwidth = this.$refs.tooltip.getBoundingClientRect().width
      let childWidth = 0
      if (this.showToolTip) {
        childWidth = this.$refs.tooltipInnerItem.getBoundingClientRect().width
      } else {
        childWidth = this.$refs.tooltipItem.getBoundingClientRect().width
      }
      if (parentwidth < childWidth) {
        this.showToolTip = true
      } else {
        this.showToolTip = false
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.tooltip {
  display: inline-block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  position: relative;
  &.tool-table-header {
    vertical-align: middle;
    top: -1px;
    max-width: 100%;
  }
  &.tool-table-header-sortable {
    max-width: calc(100% - 25px);
  }
}
.tooltip-slot {
  display: inline-block;
  max-width: 100vw;
  box-sizing: border-box;
  padding: 0 10px;
}
.tooltip-content-bake {
  display: inline-block;
  max-width: 100%;
  position: absolute;
  left: 0;
  overflow: hidden;
  color: transparent;
}
</style>
