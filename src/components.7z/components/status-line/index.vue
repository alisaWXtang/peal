<template>
  <div class="time-box">
    <template v-if="useType === 'feedbackProcess'">
      <div class="time-item" v-for="item in timeArray" :key="item.id">
        <div class="time-item-time" :title="$t(item.statusName)">
          <span class="ellipsis">{{ $t(item.statusName) }}</span>
        </div>
        <span class="time-item-light">{{ item.changeTime }}</span>
        <span
          class="time-item-user ellipsis"
          :title="`${item.opUserName}(${item.opUser})`"
          >{{ item.opUserName }}({{ item.opUser }})</span
        >
        <span class="time-item-light"
          >{{ $t(item.actionName) }}&nbsp;
          <el-link
            v-if="item.statusName === '转需求'"
            :href="
              `${urlPrefix}/requirement/list?projectId=${extra.projectId}&requireId=${extra.workItemId}`
            "
            target="_blank"
            type="primary"
            >(ID为#{{ extra.workItemId }})</el-link
          >
          <el-link
            v-if="item.statusName === '转缺陷'"
            :href="
              `${urlPrefix}/bugList/list?projectId=${extra.projectId}&bugId=${extra.workItemId}`
            "
            target="_blank"
            type="primary"
            >(ID为#{{ extra.workItemId }})</el-link
          >
          <span v-if="item.actionName === '转交'">{{ item.curVal }}</span>
        </span>
      </div>
    </template>
    <template v-else-if="useType === 'workItemProcess'">
      <div class="time-item" v-for="(item, index) in timeArray" :key="item.id">
        <div class="time-item-time" :title="item.statusName">
          <span class="ellipsis">{{ item.statusName }}</span>
        </div>
        <span class="time-item-light">{{ item.changeTime }}</span>
        <template v-if="index === timeArray.length - 1">
          <span
            class="time-item-user ellipsis"
            :title="`${item.opUserName}(${item.opUser})`"
            >{{ item.opUserName }}({{ item.opUser }})</span
          >
          <span class="time-item-light ellipsis" :title="item.statusName">{{
            item.statusName
          }}</span>
          <template v-if="extra.startTime">
            <span class="time-item-user">{{ $t('开始时间') }}</span
            >&nbsp;{{ $t('为') }}
            <span class="time-item-user">{{ extra.startTime }}</span>
          </template>
          <template v-if="extra.endTime">
            <span class="time-item-user">{{ $t('结束时间') }}</span
            >&nbsp;{{ $t('为') }}
            <span class="time-item-user">{{ extra.endTime }}</span>
          </template>
        </template>
        <template v-else>
          <span class="time-item-user">{{
            +item.workItemType === 1 ? $t('需求状态') : $t('缺陷状态')
          }}</span
          >{{ $t('更新为') }}
          <span class="time-item-user ellipsis" :title="item.statusName">{{
            item.statusName
          }}</span>
          <span v-for="(field, index) in item.fields" :key="index"
            >{{ field.fieldName }}:{{ field.displayValue }}</span
          >
        </template>
      </div>
    </template>
  </div>
</template>

<script>
/**
 * @title 状态流转组件
 * @author lili
 * @date 2020-05-14
 */
import { COTEAM_SUBAPP_KEY } from '@/utils/constant'
export default {
  name: 'StatusLine',
  props: {
    useType: {
      type: String,
      required: true,
      desc: '组件使用场景',
    },

    data: {
      type: Array,
      required: true,
      desc: '要展示的数据列表',
    },

    extra: {
      desc: '要展示的额外数据',
    },
  },

  data() {
    return {
      urlPrefix:`/micro-app/${COTEAM_SUBAPP_KEY}`
    }
  },
  computed: {
    timeArray() {
      return this.data
    },
  },

  methods: {},
}
</script>

<style lang="scss" scoped>
@import '@/style/common';
$timeLineWidth: 40px; // 连接线宽度
.time-box {
  // padding: 10px;
  .time-item {
    padding: 10px 10px 10px 0px;
    font-size: $font-size-medium;
    display: flex;
    align-items: center;
    font-size: $font-size-small-x;
    .time-item-time {
      flex-shrink: 0;
      display: inline-block;
      width: 60px;
      padding-right: 30px;
      text-align: right;
      font-size: $font-size-medium;
      font-weight: 600;
      color: $color-font-inactive-common;
      position: relative;
      vertical-align: middle;
      span {
        display: inline-block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        width: 100%;
        vertical-align: middle;
      }
      &:before {
        content: '';
        position: absolute;
        top: 50%;
        right: 1px;
        display: inline-block;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background-color: $color-gray-common;
        transform: translate(-50%, -50%);
      }
    }
    &:first-child {
      .time-item-time {
        color: $color-font-active-common;
        &:before {
          width: 8px;
          height: 8px;
          right: -1px;
          background-color: $color-font-active-common;
        }
      }
    }
    &:not(:first-child) {
      .time-item-time {
        &:after {
          content: '';
          position: absolute;
          bottom: 18px;
          right: 6px;
          width: 2px;
          height: 20px;
          background-color: $color-gray-common;
        }
      }
    }
    .time-item-light {
      flex-shrink: 0;
      color: $color-font-inactive-common;
      display: flex;
      white-space: nowrap;
      &:first-of-type {
        padding-left: 20px;
      }
    }
    .time-item-user {
      flex-shrink: 0;
      display: inline-block;
      white-space: nowrap;
      max-width: 130px;
      color: $color-font-active-common;
      padding: 0 6px;
    }
  }
}
.ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
