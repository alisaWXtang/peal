<template>
  <div class="file-update-history-view" :class="active ? 'active' : ''">
    <img
      class="button-toggle"
      src="@/assets/icon-toggle.png"
      @click="active = !active"
    />
    <div class="title">{{ $t('更新历史') }}</div>
    <div class="list">
      <div
        class="item"
        v-for="(item, index) in historyList"
        :key="index + ''"
        @click="handleChange(item, index)"
        :class="item.id === activeId ? 'active' : ''"
      >
        <div>V.{{ item.index + 1 }}</div>
        <div>
          {{ item.operationUserName }} {{ item.operationTime }}
          {{ item.operatorName }}({{ item.operator }})
          {{ item.operation }}
          “{{ item.origName }}”
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { updateHistory } from '@/service/file'
import { i18n } from '@/i18n'

export default {
  name: 'FileUpdateHistory',
  props: {
    isDocument: {
      type: Boolean,
      default: false,
    },
    documentId: {
      type: [Number, String],
      default: null,
    },
    value: {
      type: [Number, String],
      default: null,
    },
    storageName: {
      type: [Number, String],
      default: null,
    },
  },
  data() {
    return {
      activeIndex: 0,
      activeId: null,
      active: false,
      historyList: [],
    }
  },
  watch: {
    active(val) {
      if (val) {
        this.initUpdateHistory()
      }
      this.$emit('historyVsibleChange', val)
    },
  },
  mounted() {
    this.active = true
  },
  methods: {
    handleChange(item, index) {
      this.$emit('changePreview', {
        item: item,
        index: index,
      })
      this.activeId = item.id
      this.$emit('input', item.id)
    },
    initUpdateHistory(type) {
      updateHistory({
        documentId: this.documentId,
        documentType: this.isDocument ? 1 : 2,
      }).then(res => {
        res.data.forEach((item, index) => {
          item.index = index
        })
        res.data.reverse()
        if (type === 'update') {
          this.activeId = res.data[0].id
        } else {
          this.activeId = this.activeId || res.data[0].id
        }
        res.data.forEach((item, index) => {
          if (decodeURIComponent(this.storageName) === item.storageName) {
            this.activeId = item.id
            this.$emit('input', item.id)
            if (index !== 0) {
              this.$emit('changeCandelete')
            }
          }
        })
        this.historyList = res.data
      })
    },
  },
}
</script>

<style lang="scss">
@import '@/style/common';
.file-update-history-view {
  width: 400px;
  height: calc(100vh - 64px);
  position: absolute;
  right: 0;
  top: 64px;
  border-left: 1px solid #e5e5e5;
  box-sizing: border-box;
  padding: 24px 16px;
  background-color: $color-font-white-common;
  transform: translateX(100%);
  transition: 0.2s transform ease-in-out;
  &.active {
    transform: translateX(0);
  }
  .button-toggle {
    position: absolute;
    left: -16px;
    top: 50%;
    transform: translateY(-50%);
    width: 21px;
    cursor: pointer;
  }
  .title {
    font-size: 14px;
    color: $color-font-title-common;
    line-height: 19px;
    padding-bottom: 8px;
    border-bottom: 1px solid #e5e5e5;
  }
  .list {
    padding-bottom: 24px;
    max-height: calc(100vh - 155px);
    overflow-y: auto;
  }
  .item {
    margin-top: 24px;
    display: flex;
    cursor: pointer;
    & > div {
      font-size: 14px;
      color: #666666;
      line-height: 19px;
      &:first-child {
        margin-right: 15px;
        white-space: nowrap;
        position: relative;
        padding-left: 15px;
        &::before {
          content: '';
          width: 6px;
          height: 6px;
          border-radius: 50%;
          position: absolute;
          background-color: #666666;
          left: 0;
          top: 6px;
        }
      }
    }
    &.active {
      div {
        color: $color-font-active-common;
        &:first-child::before {
          background-color: $color-font-active-common;
        }
      }
    }
  }
}
</style>
