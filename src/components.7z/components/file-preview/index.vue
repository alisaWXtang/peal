<template>
  <el-dialog
    :visible.sync="dialogVisible"
    custom-class="file-review-dialog"
    ref="fileReviewDialog"
    :modal-append-to-body="true"
    :append-to-body="true"
    :modal="false"
  >
    <div class="file-reivew-title" slot="title">
      <el-tooltip
        class="item"
        effect="dark"
        :content="fileInfo.name"
        placement="bottom-start"
      >
        <span>{{ fileInfo.name }}</span>
      </el-tooltip>
    </div>
    <div class="button-div">
      <div>
        <el-upload
          action="/"
          :show-file-list="false"
          :on-change="fileUpload"
          :auto-upload="false"
          v-if="
            $authFunction(
              'FUNC_COOP_DOCUMENT_UPDATE',
              3,
              $getUrlParams().projectId,
            )
          "
        >
          <el-button type="primary" style="margin-right:15px;">{{
            $t('更新')
          }}</el-button>
        </el-upload>
      </div>
      <el-dropdown trigger="hover" placement="bottom-start">
        <span class="el-dropdown-link button-down">
          {{ $t('更多操作') }}<i class="el-icon-arrow-down el-icon--right"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>
            <span @click="handleFileDownload"
              ><i class="el-icon-bottom" />{{ $t('下载') }}</span
            >
          </el-dropdown-item>
          <template v-if="isDocument">
            <el-dropdown-item
              v-if="
                canDelete &&
                  $authFunction(
                    'FUNC_COOP_DOCUMENT_DELETE',
                    3,
                    $getUrlParams().projectId,
                  )
              "
            >
              <span @click="handleFileDelete"
                ><i class="el-icon-delete" />{{ $t('删除') }}</span
              >
            </el-dropdown-item>
          </template>
          <el-dropdown-item v-else-if="canDelete">
            <span @click="handleFileDelete"
              ><i class="el-icon-delete" />{{ $t('删除') }}</span
            >
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
    <div class="content-div" :class="historyVisible ? 'history-active' : ''">
      <video-player
        v-if="isVideo && videoUrl"
        autoplay
        preload
        controls
        :src="videoUrl"
      ></video-player>
      <iframe
        class="file-review-iframe"
        :src="iSrc"
        v-if="loaded && suppot && !isVideo"
      />
      <div class="not-suppot-div" v-if="!suppot && !loading">
        <svg class="icon" aria-hidden="true" style="font-size: 55px;">
          <use
            :xlink:href="
              iconClass[fileInfo.typeName]
                ? iconClass[fileInfo.typeName]
                : '#icon-TET'
            "
          ></use>
        </svg>
        <div class="name">{{ fileInfo.name }}</div>
        <div class="size">{{ fileInfo.size | filterFileSize }}</div>
        <el-button
          type="primary"
          icon="el-icon-download"
          @click="handleFileDownload"
        >
          {{ $t('下载') }}
        </el-button>
      </div>
    </div>
    <History
      v-model="nowFileHistrotyId"
      @historyVsibleChange="historyVsibleChange"
      :documentId="fileInfo.id"
      :is-document="isDocument"
      :storageName="storageName"
      ref="history"
      @changePreview="changePreview"
      @changeCandelete="canDelete = false"
    />
  </el-dialog>
</template>

<script>
import { i18n } from '@/i18n'
import History from './history.vue'
import { mapState } from 'vuex'
import { preview, documentUpdate, attachmentUpdate } from '@/service/file'
import { downloadFile } from '@/utils/index'
import { getRealUrl } from '@/utils/sub-app-util'
import api from '@/api/file'
import VideoPlayer from '@/components/video-player/index.vue'

/**
 * @title 文件预览
 * @desc 支持doc、 docx、 xls、 xlsx、 ppt、pptx、txt、pdf、png、jpg、jpeg的在线预览功能
 * @author wangshuju
 * @date 2021-03-12
 */
export default {
  name: 'FileReview',
  props: {
    isDocument: {
      type: Boolean,
      default: false,
    },
    fileInfo: {
      type: Object,
      default() {
        return {
          url: null, //文件url
          typeName: null, //文件类型
          id: null, //文件ID
          size: null, //文件尺寸
          name: null, //文件名
          downHistoryUrl: null, // 用于切换历史的下载
          workItemId: null,
          workItemType: null,
        }
      },
    },
  },
  components: {
    History,
    VideoPlayer,
  },
  watch: {
    iSrc(val) {
      this.loaded = false
      setTimeout(() => {
        this.loaded = true
      }, 0)
    },
    dialogVisible(val) {
      if (!val) {
        this.$emit('close')
        // 文件名回归最新版本的
        this.fileInfo.name = this.$refs.history.historyList[0].origName
      } else {
        this.$nextTick(() => {
          if (!this.isVideo) {
            this.init()
          }
        })
      }
    },
  },
  data() {
    return {
      iconClass: {
        xlsx: '#icon-ECEL',
        xls: '#icon-ECEL',
        json: '#icon-zonghewendang',
        ppt: '#icon-PPT',
        txt: '#icon-TET',
        png: '#icon-PNG',
        gif: '#icon-GIF',
        jpge: '#icon-JPG',
        zip: '#icon-ZIP',
        mp4: '#icon-VIDEO',
        pdf: '#icon-PDF',
        doc: '#icon-WORD',
        docx: '#icon-WORD',
      },
      uploadLoading: null,
      historyVisible: true,
      dialogVisible: false,
      iSrc: null,
      suppot: true,
      loaded: true,
      canDelete: true,
      nowFileHistrotyId: null,
    }
  },
  filters: {
    filterFileSize(val) {
      if (val < 1024) {
        return val + 'kb'
      }
      if (val >= 1024) {
        return Math.round((val / 1024) * 100) / 100 + 'MB'
      }
    },
  },
  computed: {
    ...mapState({
      filePreviewAuthList: state => state.pf.filePreviewAuthList,
    }),
    videoUrl() {
      if (this.isVideo && this.nowFileHistrotyId) {
        console.log(this.nowFileHistrotyId)
        return (
          getRealUrl(api.realFileUrl.url, { ssoToken: true }) +
          `&id=${this.nowFileHistrotyId}&projectId=${
            this.$getUrlParams().projectId
          }`
        )
      }
      return null
    },
    isVideo() {
      return this.videoSet.has(this.fileInfo.typeName)
    },
    videoSet() {
      return new Set(['mp4', 'MP4', 'webm', 'ogg', 'Ogg', 'WebM'])
    },
    storageName() {
      return this.fileInfo.url.split('/').pop()
    },
  },
  beforeDestroy(a) {
    this.uploadLoading && this.uploadLoading.close()
  },
  methods: {
    historyVsibleChange(val) {
      this.historyVisible = val
    },
    changePreview(obj) {
      let item = obj.item
      this.canDelete = obj.index === 0
      // 重新构建预览文件对象
      let fileInfo = {
        typeName: item.storageName.split('.').pop(),
        id: item.documentId,
        url: '/' + item.storageName, // 统一处理， 所以拼接个 “/”
        size: item.size,
        name: item.origName,
      }
      this.fileInfo.typeName = fileInfo.typeName
      this.fileInfo.name = item.origName
      let urlArr = this.fileInfo.url.split('/')
      urlArr.pop()
      urlArr.push(obj.item.storageName)
      this.fileInfo.downHistoryUrl = urlArr.join('/')
      if (!this.isVideo) {
        this.init(fileInfo)
      }
    },
    init(item) {
      let fileInfo = item || this.fileInfo
      this.loading = true
      this.suppot = this.filePreviewAuthList.includes(fileInfo.typeName)
      if (!this.suppot) {
        this.loading = false
        return
      }
      let fileName = fileInfo.url.split('/').pop()
      fileName = decodeURIComponent(fileName)
      this.fileInfo.downHistoryUrl = this.fileInfo.url
      preview({
        documentId: fileInfo.id,
        workItemId: this.fileInfo.workItemId,
        workItemType: this.fileInfo.workItemType,
        documentType: this.isDocument ? 1 : 2,
        fileName: fileName,
        originalFileName: fileInfo.name,
        fileSize: fileInfo.size,
      })
        .then(res => {
          if (res.status === 200) {
            this.iSrc = res.data
            this.loading = false
          } else {
            this.dialogVisible = false
          }
        })
        .catch(() => {
          this.dialogVisible = false
        })
    },
    async fileUpload(file) {
      file = file.raw
      if (file.size > 1024 * 1024 * 256) {
        this.$message({
          message: i18n.t('允许上传文件的大小上限为 256 M'),
          type: 'error',
        })
        return
      }
      this.uploadLoading = this.$loading({
        target: this.$refs.fileReviewDialog.$el,
        lock: true,
        text: i18n.t('文件上传中，请耐心等待'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.2)',
        customClass: 'file-preview-loading',
      })
      let data = new FormData()
      let res
      try {
        if (this.isDocument) {
          data.append('file', file)
          data.append('documentId ', this.fileInfo.id)
          data.append('documentFolderId', this.fileInfo.documentFolderId)
          res = await documentUpdate(data)
        } else {
          // 如果为文档页面的工作项附件预览， 这里的workItemType,workItemId在fileInfo里面是有值的
          data.append('file', file)
          data.append('workItemType', this.fileInfo.workItemType)
          data.append('workItemId', this.fileInfo.workItemId)
          data.append('attachmentId', this.fileInfo.id)
          res = await attachmentUpdate(data)
        }
        this.fileInfo.name = res.data.origName
        this.fileInfo.typeName = res.data.origName.split('.').pop()
        this.fileInfo.url = res.data.url
        this.fileInfo.size = res.data.size
        this.fileInfo.downHistoryUrl = res.data.url
        // 更新历史记录
        this.$refs.history.initUpdateHistory('update')
        this.uploadLoading.close()
        if (!this.isVideo) {
          this.init()
        }
        this.$message({
          type: 'success',
          message: i18n.t('文档更新成功') + '!',
        })
      } catch (error) {
        this.uploadLoading.close()
      }
      return false
    },
    // 文件上传 - 文件下载
    handleFileDownload() {
      downloadFile(this.fileInfo.downHistoryUrl, this.fileInfo.name)
    },
    handleFileDelete() {
      // this.dialogVisible = false;
      this.$emit('delete')
    },
  },
}
</script>

<style lang="scss">
@import '@/style/common';
.file-preview-loading {
  z-index: 2100;
}
.el-dialog.file-review-dialog {
  width: 100%;
  height: 100%;
  margin: 0 !important;
  padding: 0;
  border-radius: 0;
  background-color: $color-background-light-common;
  overflow: hidden;
  z-index: 2100 !important;
  .icon {
    width: 1em;
    height: 1em;
    vertical-align: -0.15em;
    fill: currentColor;
    overflow: hidden;
  }
  .file-reivew-title {
    width: 500px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-size: 16px;
    color: #333330;
    line-height: 64px;
    padding-left: 24px;
    font-weight: 600;
  }
  .el-dropdown {
    display: flex;
    align-items: center;
  }
  .content-div {
    transition: 0.2s all ease-in-out;
    overflow-x: auto;
    box-sizing: border-box;
    padding-bottom: 40px;
    &.history-active {
      width: calc(100% - 400px);
    }
  }
  .not-suppot-div {
    width: 340px;
    margin: 20vh auto 0;
    padding: 32px;
    text-align: center;
    background-color: $color-font-white-common;
    box-sizing: border-box;
    box-shadow: 0 3px 12px 0 rgba(102, 102, 102, 0.15);
    border-radius: 8px;
    border-radius: 8px;
    & > i {
      font-size: 55px;
      display: block;
      margin-bottom: 8px;
      color: #f4c446;
    }
    .name {
      font-size: 16px;
      color: $color-font-title-common;
      line-height: 24px;
      padding-bottom: 8px;
    }
    .size {
      font-size: 14px;
      color: #999999;
      line-height: 24px;
      padding-bottom: 24px;
    }
    button {
      width: 180px;
    }
  }
  .button-down {
    font-size: 14px;
    color: $color-font-active-common;
  }
  .el-dialog__headerbtn {
    top: 26px;
    i {
      color: #999;
    }
  }
  .button-div {
    position: absolute;
    z-index: 1;
    right: 56px;
    padding-right: 19px;
    top: 20px;
    display: flex;
    & > div:first-child {
      margin-right: 15px;
    }
    &::before {
      content: '';
      height: 24px;
      width: 1px;
      position: absolute;
      right: 0;
      top: 50%;
      transform: translateY(-50%);
      background: #dcdfe6;
    }
  }
  .file-review-iframe {
    width: 900px;
    height: calc(100vh - 112px);
    border: 1px solid #e5e5e5;
    box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.15);
    border-radius: 4px;
    border-radius: 4px;
    margin: 0 auto;
    display: block;
    background-color: $color-font-white-common;
  }
  .el-dialog__header {
    padding-bottom: 0;
    height: 64px;
    background-color: $color-font-white-common;
    box-shadow: 0 1px 5px 0 rgba(0, 0, 0, 0.1), inset 0 -1px 0 0 #e5e5e5;
    .el-dialog__title {
    }
  }
}
</style>
