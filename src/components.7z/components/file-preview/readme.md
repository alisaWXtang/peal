# 文件上传组件

time: 2021.03.12  
author: wangshuju

## 说明

文件预览功能

## 使用方式
