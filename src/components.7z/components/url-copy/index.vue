<template>
  <span>
    <span v-if="customSlot" @click="urlcopy">
      <slot></slot>
    </span>

    <i
      class="iconfont icon-url-copy"
      :title="config.title"
      v-else
      @click="urlcopy"
    ></i>
  </span>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 内容复制组件
 * @desc 复制内容到剪切板
 * @author heyunjiang
 * @date 2019.12.12
 */
export default {
  name: 'UrlCopy',
  components: {},
  mixins: [],
  props: {
    customSlot: {
      type: Boolean,
      required: false,
      default: false,
    },

    value: {
      type: String,
    },

    config: {
      type: Object,
      default: () => {
        return {
          successMessage: i18n.t('复制链接成功'),
          title: i18n.t('复制链接'),
        }
      },
    },
  },

  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  mounted() {},
  methods: {
    urlcopy() {
      const input = document.createElement('input')
      input.value = this.value || window.location.href
      input.style = 'position: fixed;top: 0;z-index: -1'
      document.body.appendChild(input)
      input.focus()
      input.setSelectionRange(0, input.value.length)
      const bool = document.execCommand('copy')
      document.body.removeChild(input)
      if (bool) {
        this.$message({
          type: 'success',
          message: this.config.successMessage,
          customClass: 'el-date-default-popper-class',
        })
      }
    },
  },
}
</script>
<style lang="scss" scoped>
.icon-url-copy {
  position: relative;
  top: -1px;
  cursor: pointer;
  &:hover {
    background-color: #ebf2f9;
  }
}
</style>
