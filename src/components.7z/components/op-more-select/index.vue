<template>
  <div class="custom-select-wrap">
    <div
      v-if="mode === options.textMode"
      class="select-title"
      :class="{
        hidden: mode !== options.textMode,
        'select-title__active': propverVisible,
      }"
      :style="{ 'max-width': width + 'px' }"
      @click="handleTitleClick"
    >
      <span class="content" :style="{ 'max-width': width - 24 + 'px' }">{{
        selectedLabel
      }}</span>
      <i class="select-title__icon el-icon-arrow-down"></i>
    </div>
    <el-select
      ref="select"
      v-model="selected"
      placeholder
      :class="{ 'el-select-wrap': mode === options.textMode }"
      :style="{ 'max-width': width + 'px', 'min-width': '150px' }"
      :multiple="multiple"
      :popper-class="customClass"
      @change="onSelectChange"
      @visible-change="onVisibleChange"
    >
      <!-- 过滤 -->
      <li class="select-search-input">
        <el-input
          ref="moreFilter"
          v-model.trim="filterString"
          v-focus
          :placeholder="$t('搜索')"
        ></el-input>
      </li>
      <div
        v-if="listLength"
        class="select-scroll scrollbal-common"
        :class="{ 'has-group': dynamicData.length }"
      >
        <!-- 固定过滤项 -->
        <template v-for="item in fixedData">
          <el-option
            v-if="item.owner && item.owner.includes(owner)"
            :key="item[labelAttr]"
            :value="item[valueAttr]"
            :label="item[labelAttr]"
            @click.native="onChangeValue(item[valueAttr])"
          ></el-option>
        </template>

        <!-- 静态过滤项 -->
        <template v-for="item in staticData">
          <el-option
            v-if="item.owner && item.owner.includes(owner)"
            :key="item[labelAttr]"
            :value="item[valueAttr]"
            :label="setLable(item[labelAttr])"
            @click.native="onChangeValue(item[valueAttr])"
          ></el-option>
        </template>

        <!-- 动态（自定义）过滤项 -->
        <el-option-group
          v-if="dynamicData.length"
          class="el-option-group"
          :label="$t('自定义字段')"
        >
          <template v-for="item in dynamicData">
            <el-option
              v-if="item.enabled"
              :key="item.id"
              :label="item[labelAttr]"
              :value="item[valueAttr]"
              @click.native="onChangeValue(item[valueAttr])"
            ></el-option>
          </template>
        </el-option-group>
      </div>
      <el-option v-else value="" disabled>{{ $t('无数据') }}</el-option>
    </el-select>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 更多过滤条件选择器组件
 * @desc 使用 el-select 组件
 * @author wuqian
 * @date 2019.12.9
 */
import { inputFocusPublic } from '@/utils/focusPublicUtil.js'
export default {
  name: 'OpMoreSelect',
  components: {},
  model: {
    prop: 'defaultSelected',
    event: 'change',
  },

  props: {
    owner: String,
    data: Object,
    // 选择器模式: text input
    mode: {
      type: String,
      default() {
        return 'text'
      },
    },

    // 是否多选
    multiple: {
      type: Boolean,
      default() {
        return false
      },
    },

    // 是否分组
    group: {
      type: Boolean,
      default() {
        return false
      },
    },

    // 选择器标记
    selectedLabel: {
      type: String,
      default() {
        return i18n.t('已选项')
      },
    },

    // 选择器宽度
    width: {
      type: [String, Number],
      default() {
        return '200'
      },
    },

    customClass: {
      type: String,
      desc: '自定义 Select 下拉框的类名',
    },

    // 默认选中值
    defaultSelected: {
      type: [String, Array],
      default() {
        return ''
      },
    },

    // 数据项 label 属性
    labelAttr: {
      type: String,
      default() {
        return 'fieldName'
      },
    },

    // 数据项 value属性
    valueAttr: {
      type: String,
      default() {
        return 'attrName'
      },
    },

    // 全选项的 value
    allValue: {
      type: String,
      default() {
        return 'all'
      },
    },

    // 全选项的 label
    allLabel: {
      type: String,
      default() {
        return i18n.t('全部')
      },
    },

    // 是否可过滤
    filterable: {
      type: Boolean,
      default() {
        return true
      },
    },

    // 过滤框 placeholder
    filterPlaceholder: {
      type: String,
      default() {
        return i18n.t('搜索')
      },
    },

    // 无数据提示信息
    noDataLabel: {
      type: String,
      default() {
        return i18n.t('无数据')
      },
    },

    // 静态选项
    staticFieldList: {
      type: Array,
      default() {
        return []
      },
    },

    // 自定义选项
    customFieldList: {
      type: Array,
      default() {
        return []
      },
    },

    // 固定选项（缺陷列表）
    fixedFieldList: {
      type: Array,
      default() {
        return []
      },
    },
  },

  data() {
    return {
      // 组件默认配置
      options: {
        inputMode: 'input',
        textMode: 'text',
      },

      fixedData: [],
      fixedDataCopy: [],
      staticData: [],
      staticDataCopy: [],
      dynamicData: [],
      dynamicDataCopy: [],
      search: '',
      selected: [],
      filterString: '', // 过滤字段
      propverVisible: false, // 下拉框显隐
      focusTimer: null, //input聚焦用到定时器
    }
  },
  computed: {
    listLength() {
      return (
        this.fixedData.length + this.staticData.length + this.dynamicData.length
      )
    },
  },

  watch: {
    // 监听过滤操作
    filterString(val) {
      this.staticData = [...this.staticDataCopy]
      this.dynamicData = [...this.dynamicDataCopy]
      this.fixedData = [...this.fixedDataCopy]
      // 原始数据中过滤包含 val 的数据子项（分组模式时不过滤组名）
      if (val) {
        this.staticData = this.filterData(
          this._deepClone(this.staticDataCopy),
          val,
        )

        this.dynamicData = this.filterData(
          this._deepClone(this.dynamicDataCopy),
          val,
        )

        this.fixedData = this.filterData(
          this._deepClone(this.fixedDataCopy),
          val,
        )
      }
    },
    staticFieldList: {
      handler: function(val) {
        this.staticData = [...val]
        this.staticDataCopy = [...val]
      },
    },

    customFieldList: {
      handler: function(val) {
        this.dynamicData = [...val]
        this.dynamicDataCopy = [...val]
      },
    },

    fixedFieldList: {
      handler: function(val) {
        this.fixedData = [...val]
        this.fixedDataCopy = [...val]
      },
    },

    defaultSelected: {
      handler: function(val) {
        // 设置默认选中
        this.selected = this.filterValues(val)
      },
    },
  },

  mounted() {
    this.selected = this.filterValues(this.defaultSelected)
  },
  methods: {
    //设置label
    setLable(val) {
      return this.owner === 'bug' && val === i18n.t('实际完成时间')
        ? i18n.t('实际关闭时间')
        : val
    },
    // 下拉框出现/隐藏时触发
    onVisibleChange(isVisible) {
      inputFocusPublic(isVisible, 'moreFilter', this.focusTimer, this)
      this.propverVisible = !this.propverVisible
      if (!this.propverVisible) {
        this.filterString = ''
      }
    },
    // 点击标题区域触发
    handleTitleClick() {
      // 打开下拉框
      this.$refs.select.$el.click()
    },
    // 选中下拉列表值触发
    onSelectChange() {
      this.$emit('change', this.multiple ? this.selected : [])
    },
    // 改变某项的选中状态
    onChangeValue(val) {
      if (!this.selected.includes(val)) {
        // 取消选中项 emit 事件
        this.$emit('cancelValue', val)
      }
    },
    filterValues(value) {
      const vals = []
      value.forEach(item => {
        if (item.key && !vals.includes(item.key)) {
          vals.push(item.key)
        } else if (typeof item === 'string' && !vals.includes(item)) {
          vals.push(item)
        }
      })
      return vals
    },
    // 过滤
    filterData(source, val) {
      const filteredList = []
      if (this.group) {
        // 分组过滤
        source.forEach((group, i) => {
          const children = group[this.groupChildAttr]
          if (children) {
            const nGroup = this._deepClone(group)
            nGroup[this.groupChildAttr] = []
            filteredList.push(nGroup)
          }
          children.forEach(item => {
            if (item[this.labelAttr] && item[this.labelAttr].includes(val)) {
              filteredList[i][this.groupChildAttr].push(item)
            }
          })
        })
        // 剔除子树中列表为空的数据项 避免界面只显示分组的组名 但是没有数据项
        const noEmptyList = []
        filteredList.forEach(item => {
          if (item[this.groupChildAttr].length) {
            noEmptyList.push(item)
          }
        })
        return noEmptyList
      } else {
        // 不分组过滤
        source.forEach(item => {
          if (item[this.labelAttr] && item[this.labelAttr].includes(val)) {
            filteredList.push(item)
          }
        })
        return filteredList
      }
    },
    _deepClone(source) {
      if (!source && typeof source !== 'object') {
        throw new Error('error arguments', 'shallowClone')
      }
      const targetObj = source?.constructor === Array ? [] : {}
      Object.keys(source).forEach(keys => {
        if (source[keys] && typeof source[keys] === 'object') {
          targetObj[keys] = source[keys].constructor === Array ? [] : {}
          targetObj[keys] = this._deepClone(source[keys])
        } else {
          targetObj[keys] = source[keys]
        }
      })
      return targetObj
    },
  },
}
</script>
<style lang="scss">
@import '@/style/custom-select/index.scss';
</style>
<style lang="scss" scoped>
.el-option-group {
  padding-top: 13px;
  &::before {
    content: '';
    position: absolute;
    display: block;
    left: 20px;
    right: 20px;
    top: 6px;
    height: 1px;
    background: #e4e7ed;
  }
}

.select-wrap {
  position: relative;
  display: inline-block;
  line-height: 0;
  vertical-align: middle;
}

.search-input {
  padding: 0 10px;
}
</style>
