# coteam项目业务组件 需求、任务、缺陷列表过滤器 更多过滤条件

time: 2019.12.10  
author: wuqian

## 说明

index.vue 父组件-更多过滤条件下拉列表控制相关过滤项相关功能
formItem.vue node组件-更多过滤条件下拉列表每项对应的node组件