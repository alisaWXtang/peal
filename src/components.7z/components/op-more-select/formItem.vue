<template>
  <div>
    <!-- 严重程度 -->
    <op-select
      v-if="type === 'priorities'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="literal"
      value-attr="priority"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 延期 -->
    <op-select
      v-if="type === 'delayTypes'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="delaySelectList"
      label-attr="label"
      value-attr="value"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>

    <!-- 原因 -->
    <op-select
      v-if="type === 'types'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 缺陷来源 -->
    <op-select
      v-if="type === 'sources'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 打回原因 -->
    <op-select
      v-if="type === 'refuseCauses'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 重打开原因 -->
    <op-select
      v-if="type === 'reopenCauses'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 所属业务端 -->
    <op-select
      v-if="type === 'businessEnds'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 期望解决阶段 -->
    <op-select
      v-if="type === 'expectedSolutionPhases'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 功能特性 -->
    <op-select
      v-if="type === 'functionCharacters'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 复现概率 -->
    <op-select
      v-if="type === 'reproduceProbabilitys'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 是否用例发现 -->
    <op-select
      v-if="type === 'whetherUseCaseDiscoverys'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 发现阶段 -->
    <op-select
      v-if="type === 'findStages'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="fieldDisplay"
      value-attr="fieldValue"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 创建时间 -->
    <custom-date
      v-if="type === 'createTimes'"
      v-model="componentValue"
      mode="text"
      value-format="yyyy-MM-dd"
      cancelable
      :selected-label="selectedLabel"
      type="daterange"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('createTimes')"
    ></custom-date>
    <!-- 开始时间 -->
    <custom-date
      v-if="type === 'startTimes'"
      v-model="componentValue"
      mode="text"
      value-format="yyyy-MM-dd"
      cancelable
      :selected-label="selectedLabel"
      type="daterange"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('startTimes')"
    ></custom-date>
    <!-- 结束时间 -->
    <custom-date
      v-if="type === 'endTimes'"
      v-model="componentValue"
      mode="text"
      value-format="yyyy-MM-dd"
      cancelable
      :selected-label="selectedLabel"
      type="daterange"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('endTimes')"
    ></custom-date>
    <!-- 更新时间 -->
    <custom-date
      v-if="type === 'updateTimes'"
      v-model="componentValue"
      mode="text"
      value-format="yyyy-MM-dd"
      cancelable
      :selected-label="selectedLabel"
      type="daterange"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('updateTimes')"
    ></custom-date>
    <!-- 实际完成时间 -->
    <custom-date
      v-if="type === 'finishTimes'"
      v-model="componentValue"
      mode="text"
      value-format="yyyy-MM-dd"
      cancelable
      :selected-label="finishTimesName"
      type="daterange"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('finishTimes')"
    ></custom-date>
    <!-- 父需求 -->
    <op-select
      v-if="type === 'parentRequireIds'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="title"
      value-attr="id"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('parentRequireIds')"
    ></op-select>
    <!-- 需求筛选 -->
    <op-select
      v-if="type === 'requireIds'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="selectList"
      label-attr="title"
      value-attr="id"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('requireIds')"
    ></op-select>
    <!-- 相关人 -->
    <op-select
      v-if="type === 'relevantUsers'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :is-user-select="true"
      :filter-placeholder="$t('输入拼音/工号/姓名')"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      mode="text"
      :data="assignUserFilterList"
      label-attr="value"
      value-attr="userId"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel('relevantUsers')"
    ></op-select>
    <!-- 是否漏测 -->
    <op-select
      v-if="type === 'missTests'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :can-cancel="true"
      :can-clear-all="false"
      :selected-label="$t('是否漏测')"
      mode="text"
      :data="selectList"
      label-attr="label"
      value-attr="value"
      :multiple="true"
      :group="false"
      @change="updateModel"
      @cancel="onCancel(type)"
    ></op-select>
    <!-- 自定义过滤框区域 start -->
    <!-- 简单时间框 -->
    <custom-date
      v-if="type === 'LITE_DATE_ATTR' && !showFilterField"
      v-model="componentValue"
      value-format="yyyy-MM-dd"
      mode="text"
      cancelable
      :selected-label="selectedLabel"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun, dataType.CUSTOM)
        }
      "
      @change="updateModel"
      @cancel="onCancel(item.key)"
    ></custom-date>
    <!-- 时间区间框 -->
    <custom-date
      v-if="type === 'LITE_DATE_RANGE_ATTR' && !showFilterField"
      v-model="componentValue"
      value-format="yyyy-MM-dd"
      mode="text"
      cancelable
      :selected-label="selectedLabel"
      type="daterange"
      class="input-typeed-class"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun, dataType.CUSTOM)
        }
      "
      @change="updateModel"
      @cancel="onCancel(item.key)"
    ></custom-date>
    <el-popover
      v-if="showPopover"
      v-model="propverVisible"
      placement="bottom"
      trigger="click"
    >
      <div slot="reference" class="data-wrap">
        <div
          class="select-title"
          :class="{ 'select-title__active': propverVisible }"
        >
          <span class="content">{{ inputValue }}</span>
          <i class="select-title__icon el-icon-arrow-down"></i>
          <i
            class="select-title__icon el-icon-close delete-item"
            @click.stop="onCancel(item.key)"
          ></i>
        </div>
      </div>
      <!-- 单行文本框 -->
      <el-input
        v-if="type === 'SINGLE_TEXT' && !showFilterField"
        v-model="componentValue"
        class="input-typeed-class"
        @change="updateModel"
      ></el-input>
      <!-- 多行富文本框 -->
      <el-input
        v-if="type === 'MULTI_TEXT' && !showFilterField"
        v-model="componentValue"
        type="textarea"
        class="input-typeed-class"
        v-bind="$attrs"
        @change="updateModel"
        @blur="blurHandler"
      ></el-input>
      <!-- 布尔值选择框 -->
      <el-radio-group
        v-if="type === 'BOOLEAN_ATTR' && !showFilterField"
        v-model="componentValue"
        class="input-typeed-class"
        @change="updateModel"
      >
        <el-radio :label="true">{{ $t('是') }}</el-radio>
        <el-radio :label="false">{{ $t('否') }}</el-radio>
      </el-radio-group>
      <!-- 整数输入框, 浮点数输入框 -->
      <el-input
        v-if="
          (type === 'INT_ATTR' || type === 'FLOAT_ATTR') && !showFilterField
        "
        v-model.number="componentValue"
        type="number"
        class="input-typeed-class"
        @change="updateModel"
      ></el-input>
    </el-popover>
    <op-select
      v-if="type === 'MEMBER_CHOICE'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      :is-user-select="true"
      :filter-placeholder="$t('输入拼音/工号/姓名')"
      :can-cancel="true"
      :can-clear-all="false"
      mode="text"
      :data="selectList"
      label-attr="value"
      value-attr="userId"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(item.key)"
    ></op-select>
    <!-- 成员多选框 -->
    <op-select
      v-if="type === 'MULTI_MEMBER_CHOICE'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      :can-cancel="true"
      :can-clear-all="false"
      :is-user-select="true"
      :filter-placeholder="$t('输入拼音/工号/姓名')"
      mode="text"
      :data="selectList"
      label-attr="value"
      value-attr="userId"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(item.key)"
    ></op-select>
    <!-- 单选框 -->
    <op-select
      v-if="type === 'SINGLE_CHOICE'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      :can-cancel="true"
      :can-clear-all="false"
      mode="text"
      :data="selectList"
      label-attr="value"
      value-attr="key"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(item.key)"
    ></op-select>
    <!-- 多选框 -->
    <op-select
      v-if="type === 'MULTI_CHOICE'"
      v-model="componentValue"
      custom-class="custom_select_popper"
      :selected-label="selectedLabel"
      :popper-append-to-body="popperAppendToBody"
      :can-cancel="true"
      :can-clear-all="false"
      mode="text"
      :data="selectList"
      label-attr="value"
      value-attr="key"
      :multiple="true"
      :group="false"
      @setFilterDataLabel="
        (value, label, clearFun) => {
          itemSetTags(value, label, clearFun)
        }
      "
      @change="updateModel"
      @cancel="onCancel(item.key)"
    ></op-select>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 更多过滤条件选择组件node
 * @desc
 * @author wuqian
 * @date 2019.12.9
 */
import OpSelect from '@/components/op-select'
import CustomDate from '@/components/columbus-custom-date'
import { HEADER_FILTER_DATA_TYPE } from '@/utils/constant.js'

export default {
  name: 'MoreFormItem',
  components: { OpSelect, CustomDate },

  mixins: [],
  model: {
    prop: 'value',
    event: 'change',
  },
  props: {
    value: {
      validator: () => {
        return true
      },
    },

    // 父组件node类型
    type: {
      type: String,
      required: false,
      default: 'SINGLE_TEXT',
      desc: '字段类型，默认普通 input 框',
    },

    selectList: {
      type: Array,
      default: () => {
        return []
      },
    },

    popperAppendToBody: {
      type: Boolean,
      default: false,
      desc: '是否填充到body元素中',
    },

    filterField: {
      type: Boolean,
      required: false,
      default: false,
      desc:
        '是否应用在过滤器中，过滤器中就需要全部是多选，并且拥有过全部这个 option',
    },

    assignUserFilterList: {
      type: Array,
      default() {
        return []
      },
    },

    delaySelectList: {
      type: Array,
      default() {
        return []
      },
    },

    selectedLabel: {
      type: String,
      default() {
        return ''
      },
    },

    item: {
      type: Object,
      default() {
        return {}
      },
    },

    finishTimesName: {
      type: String,
      default: i18n.t('实际完成时间'),
      desc: '实际完成时间或实际关闭时间',
    },
  },

  data() {
    return {
      propverVisible: false,
      componentValue: '',
      originalValue: '',
      finishTimeType: '',
      dataType: HEADER_FILTER_DATA_TYPE,
    }
  },
  computed: {
    // 是否在过滤器中展示的字段
    showFilterField() {
      return (
        [
          'MEMBER_CHOICE',
          'MULTI_MEMBER_CHOICE',
          'SINGLE_CHOICE',
          'MULTI_CHOICE',
        ].includes(this.type) && this.filterField
      )
    },
    showCustomFilterField() {
      return (
        ['LITE_DATE_ATTR', 'LITE_DATE_RANGE_ATTR'].includes(this.type) &&
        this.filterField
      )
    },
    showPopover() {
      return [
        'SINGLE_TEXT',
        'MULTI_TEXT',
        'BOOLEAN_ATTR',
        'INT_ATTR',
        'FLOAT_ATTR',
      ].includes(this.type)
    },
    inputValue() {
      if (typeof this.componentValue === 'boolean') {
        return this.componentValue ? i18n.t('是') : i18n.t('否')
      } else if (!this.componentValue) {
        return i18n.t('全部')
      } else {
        return this.componentValue
      }
    },
  },

  watch: {
    value() {
      this.generateValue()
    },
    inputValue() {
      this.itemSetTags(this.componentValue, this.inputValue, this.onClear)
    },
  },

  mounted() {
    this.generateValue()
  },
  methods: {
    onCancel(type) {
      this.$emit('cancel', type)
      this.itemSetTags([], '', this.onClear)
    },
    onClear() {
      this.componentValue = ''
      if (this.showPopover) {
        this.$emit(
          'setCustomTags',
          this.componentValue,
          this.inputValue,
          this.onClear,
        )
      }
    },
    inputFun(value) {
      this.$emit('input', value)
    },
    //获取到的事件信息传递到父组件
    focusFun() {
      this.$emit('focus')
    },
    generateValue() {
      this.componentValue =
        typeof this.value === 'undefined'
          ? this.$store.state.cm.customFieldInitTypeMap[this.type]
          : this.value
      this.originalValue = this.componentValue
    },
    // 失去焦点时触发事件
    blurHandler() {
      this.$emit('blur')
      if (this.originalValue !== this.componentValue) {
        this.$emit('change', this.componentValue)
      }
    },
    updateModel(value) {
      this.$emit('change', value)
      // this.itemSetTags(value, this.inputValue, this.onClear)
    },
    // 控制全选 select
    handleSelectChange(value) {
      // 如果最后一个选中了全部
      if (value[value.length - 1] === 'all') {
        this.componentValue = ['all']
      }
      // 如果不是最后一个选中了全部
      if (
        this.componentValue.includes('all') &&
        this.componentValue.length > 1
      ) {
        this.componentValue = this.componentValue.filter(item => item !== 'all')
      }
      this.$emit('change', this.componentValue)
    },
    itemSetTags(value, label, clearFun = null) {
      // console.log(4444, value, label)
      if (
        this.showCustomFilterField ||
        this.showPopover ||
        this.showFilterField
      ) {
        this.$emit('setCustomTags', value, label, clearFun)
      } else {
        this.$emit('setFilterDataLabel', value, label, clearFun)
      }
    },
  },
}
</script>
<style lang="scss" scoped>
@mixin ellipsis {
  overflow: hidden !important;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.input-typeed-class {
  max-width: 100%;
}
@mixin active {
  color: $--color-primary;
  border: 1px solid $--color-primary;
  background: $--color-primary-light-9;
  .el-icon-close {
    color: $--color-primary;
    border: 1px solid $--color-primary;
    background: $--color-primary-light-9;
  }
}
.data-wrap {
  position: relative;
  line-height: 0;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  box-sizing: border-box;
}
.select-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10px;
  border-radius: 3px;
  box-sizing: border-box;
  height: 32px;
  line-height: 32px;
  transition: all 0.2s;
  cursor: pointer;
  border: 1px solid transparent;
  &:hover {
    border-color: $--color-primary;
    color: #666666;
  }
  .content {
    @include ellipsis;
    line-height: 1;
  }
  .el-icon-close {
    border-radius: 50%;
    background-color: #d8d8d8;
    color: #fff;
    padding: 2px;
    transform: scale(0.7);
  }
  .delete-item {
    position: absolute;
    right: -3px;
    top: -24px;
    display: none;
  }
}
.select-title__icon {
  margin-left: 10px;
}
.content {
  @include ellipsis;
}
.select-filter-wrap {
  position: relative;
  .el-icon-arrow-down {
    top: 8px;
  }
  .el-icon-close {
    top: 5px;
  }
  .el-select {
    position: absolute;
    top: 0;
    visibility: hidden;
    width: 0;
    .el-select__tags {
      display: none;
      background-color: transparent;
    }
  }
}
</style>
