<template>
  <video
    class="video-dom"
    controls
    v-bind="$attrs"
    ref="video"
    :src="src"
  ></video>
</template>

<script>
export default {
  name: 'VideoPlayer',
  props: {
    src: {
      type: String,
      required: true,
    },
  },
  data() {
    return {}
  },
}
</script>

<style lang="scss" scoped>
.video-dom {
  width: 80%;
  margin: 100px auto 0;
  display: block;
  height: 65vh;
  border: 1px solid #e5e5e5;
  box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.15);
  border-radius: 4px;
  border-radius: 4px;
}
</style>

<style lang="scss">
.video-player-dialog {
  /deep/ .el-dialog__body {
    padding: 0;
  }
}
</style>
