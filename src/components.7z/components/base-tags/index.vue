<template>
  <div class="tags-wrap">
    <template v-for="tag in tags">
      <div
        v-if="
          tag.value &&
            ((Array.isArray(tag.value) &&
              tag.value.length > 0 &&
              tag.value[0] !== 'all') ||
              (typeof tag.value === 'string' && tag.value !== '') ||
              typeof tag.value === 'boolean')
        "
        :key="tag.type"
        :style="{ backgroundColor: color }"
      >
        <Tag
          :text="tag.name + '：' + tag.label"
          :type="tag.type"
          @handleCloseTag="type => handleCloseTag(type)"
        />
      </div>
    </template>
  </div>
</template>

<script>
import Tag from './tag'
export default {
  name: 'BaseTags',
  props: {
    tags: {
      type: [Object, Array],
      default: () => {},
    },
    // 背景颜色
    color: {
      type: String,
      default: 'rgba(5, 181, 112, 0.1)',
    },
  },
  components: {
    Tag,
  },
  methods: {
    handleCloseTag(type) {
      this.$emit('handleCloseTag', type)
    },
  },
}
</script>

<style lang="scss" scoped>
.header-base-filter-box {
  padding-top: 16px;
  height: calc(100% - 60px);
  overflow-y: auto;
  .checked-tag-box {
    div {
      line-height: 0;
    }
  }
  .filter-item-wrap {
    margin-bottom: 8px;
    &:hover {
      /deep/ .el-icon-close {
        display: block;
      }
    }
  }
  .select-filter-item-box {
    width: 100%;
    /deep/ .el-input__inner {
      border: 1px solid #dcdfe6;
      border-radius: 4px;
      height: 30px;
      padding: 0 12px;
      &:hover {
        border-color: $--color-primary;
        color: #666666;
      }
    }
    /deep/ .el-input__suffix {
      color: #bfbfbf;
      right: 9px;
    }
  }
  .footer-button-box {
    position: absolute;
    right: 24px;
    bottom: 16px;
  }
  .more-filter {
    color: $--color-primary;
  }
  .select-wrap_focus {
    //border-color: $--color-primary;
    color: #666666;
  }
}
.tag-tooltip {
  max-width: 750px;
  max-height: 312px;
  line-height: 17px;
}
</style>
