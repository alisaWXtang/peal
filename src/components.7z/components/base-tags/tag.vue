<template>
  <div class="tag-box" ref="tabBox">
    <el-tooltip
      :enterable="false"
      placement="top"
      ref="tooltipItem"
      :disabled="showToolTip"
    >
      <div class="tag-tooltip" slot="content">
        {{ text }}
      </div>
      <span class="tag-content">
        {{ text }}
        <i
          class="tag-close co-icon-close"
          @click.stop="handleCloseTag(type)"
        ></i>
      </span>
    </el-tooltip>
  </div>
</template>

<script>
export default {
  name: 'tag',
  props: {
    text: {
      type: String,
      default: '',
    },
    type: {
      type: [String, Number],
      default: '',
    },
  },
  data() {
    return {
      showToolTip: true,
    }
  },
  mounted() {
    this.$nextTick(this.computedShowToolTip)
  },
  watch: {
    text() {
      this.$nextTick(this.computedShowToolTip)
    },
  },
  methods: {
    handleCloseTag(type) {
      this.$emit('handleCloseTag', type)
    },
    computedShowToolTip() {
      const tagBoxW = this.$refs.tabBox.getBoundingClientRect().width
      const childWidth = this.$refs.tooltipItem.$el.getBoundingClientRect()
        .width
      if (tagBoxW > childWidth) {
        this.showToolTip = true
      } else {
        this.showToolTip = false
      }
    },
  },
}
</script>

<style lang="scss" scoped>
.tag-box {
  margin-bottom: 8px;
  position: relative;
  padding: 0 12px;
  background-color: $--color-primary-light-9;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.tag-content {
  height: 28px;
  line-height: 28px;
  color: $--color-primary;
  font-size: 12px;
  border-radius: 4px;
  box-sizing: border-box;

  i {
    position: absolute;
    right: 5px;
    top: 7px;
    cursor: pointer;
  }
}
</style>
