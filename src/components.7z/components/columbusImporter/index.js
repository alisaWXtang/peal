/**
 * @title 用于组件js化
 * @date 2021.3.24
 * @author chenxiaolong
 */

import Vue from "vue";
import ImportBox from "./ImportBox.vue";
const importBoxClass = Vue.extend(ImportBox);

ImportBox.install = (vm, props) => {
  // 注入vm 内部组件可以使用store 以及 i18n
  const instance = new importBoxClass({ propsData: {...props, vm} }).$mount();
  if (process.env.NODE_ENV === "development") {
    vm.$root.$children.push(instance);
  }

  return instance
};

export default ImportBox;
