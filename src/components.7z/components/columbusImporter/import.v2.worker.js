/**
 * @title 导入相关 worker
 * @date 2021.3.24
 * @author chenxiaolong
 */

import axios from "axios";
import XLSX from "xlsx";
import Excel from "exceljs";
import {
  eventMaps as EventMaps,
  importSnippetLen,
  excelTitleRow,
  errorMsgName
} from "./constant";

/**
 * @title 导入数据, 分片段
 */
class Importer {
  /**
   *
   * @param {Array} props | 表格数据
   */
  constructor(props) {
    this.url = props.url;
    // 表头提取
    this.header = props.header[excelTitleRow - 1].fieldValue;
    // 真实数据
    this.data = props.excelData;
    this.requestPayload = props.payload;
    this.pageSize = importSnippetLen;
    this.pages = 0;
    this.computedPages();
    // 使用WeakMap，优化大循环内存回收问题
    this.map = new WeakMap();
  }

  computedPages() {
    this.pages = Math.ceil(this.data.length / this.pageSize);
  }

  async runProgress(index) {
    const start = index * this.pageSize;
    let end = start + this.pageSize;
    end > this.data.length && (end = this.data.length);
    let dataMapKey = { key: "data" + index };
    let remainDataMapKey = { key: "remainData" + index };
    let resMapKey = { key: "res" + index };
    let payloadMapKey = { key: "payload" + index };
    this.map.set(dataMapKey, this.data.slice(start, end));
    // 组装表头以及数据
    this.map.set(payloadMapKey, {
      ...this.requestPayload,
      fieldNameList: this.header,
      fieldValueList: this.map.get(dataMapKey)
    });
    this.map.set(remainDataMapKey, this.data.slice(end, this.data.length));
    const percentage = Math.floor((end / this.data.length) * 100);

    try {
      this.map.set(
        resMapKey,
        await httpReq(this.url, "post", this.map.get(payloadMapKey))
      );

      if (
        this.map.get(resMapKey).data.status === 200 &&
        this.map.get(resMapKey).data.data
      ) {
        postMessage({
          event: EventMaps.IMPORT_DATA,
          res: {
            status: 200,
            data: {
              ...this.map.get(resMapKey).data.data,
              range: [start, end],
              percentage,
              remainData: this.map.get(remainDataMapKey)
            }
          }
        });
        dataMapKey = null;
        remainDataMapKey = null;
        resMapKey = null;
        payloadMapKey = null;
        return true;
      } else {
        postMessage({
          event: EventMaps.IMPORT_DATA,
          res: this.map.get(resMapKey).data
        });
        return false;
      }
    } catch (error) {
      let data = error
      if (error.response && error.response.data) {
        data = error.response.data
      }
      postMessage({
        event: EventMaps.IMPORT_DATA,
        res: Object.assign({ status: 0 }, data)
      });
      return false;
    }
  }

  async importData() {
    for (const index of Object.keys([...new Array(this.pages)])) {
      const res = await this.runProgress(index);
      if (!res) {
        break;
      }
    }
  }
}

/**
 * @title 导入数据错误下载
 * @desc 使用exceljs  将会加速导出速度，且导出文件大小将会有所下降
 */
class ErrorDataDownloadUtil {
  constructor(props) {
    this.data = props.data.map(item => [...item.fieldValue, item._error]);
    this.config = props.config;
    this.workbook = new Excel.Workbook();
    props.header[excelTitleRow - 1].fieldValue.push(errorMsgName);
    this.header = props.header.map(item => item.fieldValue);
  }

  // 写入数据
  writeData() {
    this.workbook.creator = "columbus";
    this.workbook.lastModifiedBy = "columbus";
    this.workbook.created = new Date();
    this.workbook.modified = new Date();
    const headerFirst = this.header.shift();

    // 全部加入制表符
    const excelData = [...this.header, ...this.data].map(item => {
      for (let index = 0; index < item.length; index++) {
        const element = item[index];
        if (!element) {
          item[index] = "";
        } else {
          item[index] = element + "\t";
        }
      }

      return item;
    });
    const sheet = this.workbook.addWorksheet("sheet1");
    sheet.mergeCells("A1:J1");
    sheet.getRow(1).height = 100;
    sheet.getCell("A1").value = headerFirst.toString();
    sheet.getCell("A1").alignment = {
      vertical: "middle",
      horizontal: "left",
      wrapText: true
    };
    sheet.addRows(excelData);
    const configSheet = this.workbook.addWorksheet("metaDataConfig");
    configSheet.state = "hidden";
    configSheet.addRows(this.config);
  }

  /**
   * @title 导出数据
   */
  exportData() {
    this.writeData();
    this.workbook.xlsx.writeBuffer().then(data => {
      postMessage({
        event: EventMaps.EXPORT_ERROR_DATA,
        res: { status: 200, data }
      });
    });
  }
}

const eventMaps = {
  PARSE_FILE: parseFile,
  IMPORT_DATA: importData,
  EXPORT_ERROR_DATA: exportErrorData
};

self.addEventListener("message", e => {
  const { event, props } = e.data;
  eventMaps[event] && eventMaps[event](props, event);
});

async function httpReq(url, method, payload = {}, ...otherConfig) {
  const config = {
    url,
    method,
    ...otherConfig
  };

  if (method.toUpperCase() === "GET") {
    config.params = payload;
  } else {
    config.data = payload;
  }

  return await axios(config);
}

// 解析文件数据
function parseFile(data, event) {
  try {
    const workbook = XLSX.read(data, {
      type: "binary"
    });
    const activeSheet = workbook.SheetNames[0]; //取第一张表
    //生成json表格内容, 从第一行开始读取
    let column = 0;
    let hasErrorMsg = false;
    let hasErrorIndex = 0;
    const parseData = XLSX.utils
      .sheet_to_json(workbook.Sheets[activeSheet], {
        header: 1,
        // raw: false
      })
      .map((item, index) => {
        if (index === 1) {
          column = item.length;
          const index = item.findIndex(
            field => field && String(field).indexOf(errorMsgName) > -1
          );
          // 错误信息校验
          if (index > -1) {
            hasErrorMsg = true;
            hasErrorIndex = index;
          }
        }

        if (item.length < column) {
          Object.keys([...new Array(column - item.length)]).forEach(() => {
            item.push(null);
          });
        }

        // 删除错误提示
        if (hasErrorMsg) {
          item.splice(hasErrorIndex, 1);
        }

        return {
          fieldValue: item,
          _row: index + 1
        };
      });
    // 定义配置参数在第二个sheet
    const configData = XLSX.utils.sheet_to_json(
      workbook.Sheets[workbook.SheetNames[1]],
      { header: 1 }
    );
    postMessage({
      event,
      res: {
        status: 200,
        data: {
          excelData: parseData,
          config: configData
        }
      }
    });
  } catch (error) {
    postMessage({ event, res: { status: 0, error } });
  }
}

// 导入数据
function importData(props, event) {
  try {
    let importer = new Importer(props);
    importer.importData();
  } catch (error) {
    postMessage({ event, res: { status: 0, error } });
  }
}

// 导出错误数据
function exportErrorData(props, event) {
  try {
    new ErrorDataDownloadUtil(props).exportData();
  } catch (error) {
    postMessage({ event, res: { status: 0, error } });
  }
}
