/**
 * @title 常量
 * @date 2021.3.24
 * @author chenxiaolong
 */

// 事件类型
export const eventMaps = {
  PARSE_FILE: "PARSE_FILE",
  VALIDATE_FILE_DATA: "VALIDATE_FILE_DATA",
  IMPORT_DATA: "IMPORT_DATA",
  EXPORT_ERROR_DATA: "EXPORT_ERROR_DATA"
};

// 导入长度
export const importSnippetLen = 30;

// 校验长度
export const validateSnippetLen = 300;

// 缓存导入队列名称
export const importQueueName = "columbus-import-queue";

// 表格标题行
export const excelTitleRow = 2;

// 表格数据起始行
export const excelDataStartRow = 4;

// 错误信息名称
export const errorMsgName = "错误信息（请勿修改此名称）";

export const importTypes = {
  IMPORT_REQUIREMENT: "IMPORT_REQUIREMENT",
  IMPORT_DEFECT: "IMPORT_DEFECT",
  IMPORT_TASK: "IMPORT_TASK"
};
