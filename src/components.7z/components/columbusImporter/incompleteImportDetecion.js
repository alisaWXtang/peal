/**
 * @title 断点导入监控
 * @date 2021.3.25
 * @author chenxiaolong
 */

import { importQueueName } from './constant'
import MessageBox from '@heytap/cook-ui/packages/message-box'

export default function importRun(vm) {
  const localforage = vm.$localforage
  localforage.getItem(importQueueName).then(async val => {
    if (val && val.length) {
      // 异步加载，减少打包体积
      const ImportBox = (await import('./index.js')).default
      const importCache = {}
      const dataList = {}
      let title = `${vm.$t('检测到')}`
      for (const queueName of val) {
        const data = await localforage.getItem(queueName)

        if (!data) continue

        const projectId = data.config[0][0]
        dataList[queueName] = data

        if (importCache[projectId]) {
          importCache[projectId].push(data)
        } else {
          importCache[projectId] = []
          importCache[projectId].push(data)
        }
      }

      for (const [key, data] of Object.entries(importCache)) {
        title += `《${data[0].projectName}》${vm.$t('有')}${data.length}${vm.$t(
          '个未完成的导入任务',
        )}，`
      }

      title += `${vm.$t(
        '是否继续完成未完成的导入任务？取消将会清空任务队列。',
      )}`

      MessageBox({
        title: vm.$t('导入提示'),
        type: 'warning',
        showCancelButton: true,
        cancelButtonText: vm.$t('取消'),
        closeOnClickModal: false,
        closeOnPressEscape: false,
        message: title,
        beforeClose: (action, instance, done) => {
          if (action === 'confirm') {
            for (const [key, data] of Object.entries(dataList)) {
              ImportBox.install(vm, { ...data, cacheKey: key })
            }
            done()
          } else {
            for (let index = 0; index < val.length; index++) {
              const queueName = val[index]
              ;(function(key) {
                localforage.removeItem(key)
              })(queueName)
            }
            localforage.removeItem(importQueueName)
            done()
          }
        },
      }).catch(_)
    }
  })
}
