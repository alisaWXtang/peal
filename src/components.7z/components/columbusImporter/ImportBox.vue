<template>
  <custom-box
    ref="drag"
    :title="localTitle"
    :canClose="canClose"
    @close="handleClose"
  >
    <div class="file-info">
      <div class="file-name" :title="file.name">
        {{ file.name }}
        <el-button
          type="text"
          class="validate-button"
          v-if="step === 'beforeParse'"
          size="mini"
          :loading="parseFileLoading"
          @click="validateFile"
          >{{
            parseFileLoading ? vm.$t('解析文件中...') : vm.$t('解析文件')
          }}</el-button
        >
      </div>
    </div>
    <div class="box-progress" v-if="step === 'importing'">
      <el-progress
        v-if="importer.loading && step === 'importing'"
        :text-inside="true"
        :stroke-width="20"
        :color="color"
        :percentage="importer.percentage"
      ></el-progress>
    </div>
    <div class="box-info">
      <div v-if="step === 'beforeImport'" class="info-container validated-info">
        <template v-if="parseFileError">
          <div class="danger-color">
            {{ vm.$t('解析文件失败') }}, {{ parseFileError }}
          </div>
        </template>
        <template v-else>
          <span class="validated-text"
            >{{ vm.$t('总共') }} {{ excelData.length }} {{ vm.$t('条')
            }}{{ vm.$t('数据') }}</span
          >
          <el-button type="text" class="import-button" @click="importAction">
            {{ isBreakpointImport ? '继续导入' : '开始导入' }}</el-button
          >
        </template>
      </div>

      <div v-if="step === 'importing'" class="info-container import-info">
        <span v-if="importer.status === 'fail'" class="danger-color"
          >{{ vm.$t('导入异常') }}, {{ importer.errorMsg }}</span
        >
        <span v-else class="import-text"
          >{{ vm.$t('导入中') }}..., {{ vm.$t('总共') }}
          <span class="active-color">{{ excelData.length }}</span>
          {{ vm.$t('条') }}{{ vm.$t('数据') }}, {{ vm.$t('正在导入第')
          }}<span class="active-color"
            >{{ importer.range[0] }} - {{ importer.range[1] }}</span
          >{{ vm.$t('条') }}{{ vm.$t('数据') }}</span
        >
      </div>

      <div v-if="step === 'imported'" class="info-container imported-info">
        {{ vm.$t('成功导入') }}
        <span class="active-color">{{ successSize }}</span> {{ vm.$t('条')
        }}{{ vm.$t('数据') }}, {{ vm.$t('失败') }}
        <span class="danger-color">{{ errorSize }}</span> {{ vm.$t('条')
        }}{{ vm.$t('数据') }}。
        <el-button
          type="text"
          v-if="errorSize"
          :loading="exportLoading"
          @click="exportErrorData"
          >{{
            exportLoading ? vm.$t('导出文件中...') : vm.$t('下载错误数据')
          }}</el-button
        >
      </div>
    </div>
  </custom-box>
</template>

<script>
/**
 * @title 导入盒子
 * @desc 页面支持多个导入盒子的出现,该导入支持分片校验，以及分片导入，
 * @date 2021.3.24
 * @author chenxiaolong
 */
import CustomBox from '../dragBox/index.vue'
import ImportWorker from './import.v2.worker'
import { importActions } from '@/store/action-types'
import EventBus from './eventBus'
import { getRealUrl } from '@/utils/sub-app-util'
import { parseResponse } from '@/utils/http'
import {
  eventMaps,
  excelDataStartRow,
  importSnippetLen,
  importQueueName,
} from './constant'
export default {
  name: 'ImportBox',
  components: {
    CustomBox,
  },
  props: {
    title: {
      type: String,
      required: true,
      desc: '标题',
    },
    vm: {
      type: Object,
      required: true,
    },
    importUrl: {
      type: String,
      required: true,
      desc: '导入地址',
    },
    file: {
      type: [Object, File],
      required: true,
      desc: '导入文件',
    },
    data: {
      type: Array,
      default: () => [],
      desc: '断点导入的时候传递的数据，如果数据不会空，那就是断点导入',
    },
    cacheKey: {
      type: String,
      desc: '缓存键值',
    },
    header: {
      type: [Array, Object],
      desc: '标题',
    },
    config: {
      type: [Array, Object],
      desc: '配置参数',
    },
    projectName: {
      type: String,
      desc: '项目名称',
    },
  },
  data() {
    return {
      id: 'columbus-import-box-' + this._uid,
      worker: null,
      validFile: false,
      excelData: [], // 表格原始数据
      excelHeader: [], // 定义中的表格标题
      step: 'beforeParse', // beforeParse  beforeImport importing imported
      canClose: true,
      parseFileLoading: false,
      parseFileError: '', // 解析文件错误信息
      localConfig: {}, // 导入文件的配置信息
      importer: {
        loading: false,
        status: 'success',
        percentage: 0,
        range: [0, importSnippetLen],
        errors: [],
        successes: [],
        errorMsg: '',
      },
      exportLoading: false,
      errorSize: 0,
      successSize: 0,
      projectId: null,
      templateId: null,
      workItemType: null,
      color: '#3081F2',
      eventBus: new EventBus(),
      currentProjectId: this.$getUrlParams().projectId,
      localProjectName: this.vm.$store.state.projectName,
    }
  },
  computed: {
    localFile() {
      return {
        name: this.file.name,
        size: this.file.size,
        type: this.file.type,
      }
    },
    // 导入地址计算
    localImportUrl() {
      if (this.isBreakpointImport) {
        return (
          getRealUrl(this.importUrl, { ssoToken: true }) +
          `&projectId=${this.projectId}`
        )
      }

      return (
        getRealUrl(this.importUrl, { ssoToken: true }) +
        `&projectId=${this.currentProjectId}`
      )
    },
    // 判断是否是断点导入
    isBreakpointImport() {
      return this.data.length
    },
    fileQueue() {
      return this.vm.$store.state.importer.fileQueue
    },
    localTitle() {
      return this.vm.$t(this.title)
    },
  },
  watch: {
    localConfig: {
      handler: function(val) {
        if (val[0]) {
          this.projectId = val[0][0]
          this.templateId = val[0][1]
          this.workItemType = val[0][2]
        }
      },
      deep: true,
    },
    // 监听步骤变化
    step(val) {
      this.eventBus.emit('stepChange', val)
    },
  },
  created() {
    this.worker = new ImportWorker()
    this.worker.onmessage = e => {
      const { event } = e.data

      parseResponse(
        { data: e.data.res },
        function() {},
        function() {},
      )

      if (e.data.res?.status === 200) {
        if (event === eventMaps.PARSE_FILE) {
          this.parsedFileAction(e.data.res)
        } else if (event === eventMaps.IMPORT_DATA) {
          this.importProgress(e.data.res)
        } else if (event === eventMaps.EXPORT_ERROR_DATA) {
          this.exportAction(e.data.res)
        }
      } else {
        // this.$message.error(e.data.res?.error?.message || e.data.res.msg);
        this.canClose = true

        if (event === eventMaps.IMPORT_DATA) {
          this.importer.errorMsg = e.data.res?.error?.message || e.data.res.msg
          this.importer.status = 'fail'
          this.color = '#ea3447'
        }
      }
    }

    this.errorMapKey = { key: 'error' }
    this.remainDataMapKey = { key: 'remainData' }
    // weakMap 解决内存溢出问题
    this.weakMap = new WeakMap()
    this.weakMap.set(this.errorMapKey, [])
    this.weakMap.set(this.remainDataMapKey, [])

    if (this.isBreakpointImport) {
      this.step = 'beforeImport'
      this.excelData = this.data
      this.id = this.cacheKey
      this.localConfig = this.config
      if (this.localConfig[0]) {
        this.projectId = this.localConfig[0][0]
        this.templateId = this.localConfig[0][1]
        this.workItemType = this.localConfig[0][2]
      }
      this.excelHeader = this.header
      this.weakMap.set(this.remainDataMapKey, this.data)
      this.localProjectName = this.projectName
    }
  },
  mounted() {
    if (this.fileQueue.includes(this.file.name)) {
      this.$message.error(this.vm.$t('已存在该文件的导入任务'))
      this.$refs.drag.componentDestroy()
      return
    }

    this.vm.$store.dispatch(importActions.UPDATE_IMPORT_FILE_QUEUE, {
      data: this.file.name,
      type: 'add',
    })
    window.addEventListener('beforeunload', this.unload)
    this.$once('hook:beforeDestroy', () => {
      // 关闭worker线程
      this.worker && this.worker.terminate()
      this.vm.$store.dispatch(importActions.UPDATE_IMPORT_FILE_QUEUE, {
        data: this.file.name,
        type: 'remove',
      })
      this.removeCache()
      window.removeEventListener('beforeunload', this.unload)
    })

    if (!this.isBreakpointImport) {
      // 开始校验数据
      this.validateFile()
    } else {
      this.importAction()
    }
  },
  methods: {
    /**
     * 关闭浏览器以及刷新浏览器处理
     * TODO 此方法在后端接口不出错的前提下可以解决部分边界问题，不是最终解决方案
     */
    unload(e) {
      if (this.canClose) return
      this.weakMap.get(this.remainDataMapKey).splice(0, importSnippetLen)

      if (!this.weakMap.get(this.remainDataMapKey).length) {
        this.removeCache()
        return
      }

      this.$localforage.setItem(this.id, {
        ...this.$props,
        vm: null,
        file: this.localFile,
        data: this.weakMap.get(this.remainDataMapKey),
        header: this.excelHeader,
        config: this.localConfig,
        projectName: this.localProjectName,
      })
    },
    on(event, fn) {
      this.eventBus.on(event, fn)
    },
    once(event, fn) {
      this.eventBus.once(event, fn)
    },
    // 关闭
    handleClose() {
      this.eventBus.emit('close')
      this.$destroy()
      this.eventBus.emit('closed')
    },
    // 校验文件
    validateFile() {
      if (
        !this.file ||
        !this.file.name.length ||
        !/(\.xls||.xlsx)/.test(this.file.name.toLowerCase())
      ) {
        this.validFile = false
        this.canClose = true
        this.$message({
          message: this.vm.$t('导入的文件不符合规范'),
          duration: 5000,
          type: 'error',
        })
      } else {
        this.validFile = true
        this.parseFileLoading = true
        this.parseFile()
      }
    },
    // 校验文件
    parseFile() {
      const fileReader = new FileReader()
      fileReader.onload = e => {
        const data = e.target.result
        this.worker.postMessage({ event: eventMaps.PARSE_FILE, props: data })
      }
      fileReader.readAsBinaryString(this.file)
    },
    // 获取解析后的文件数据
    parsedFileAction(res) {
      this.excelData = res.data.excelData.slice(
        excelDataStartRow - 1,
        res.data.excelData.length,
      )
      this.weakMap.set(this.remainDataMapKey, this.excelData)
      this.excelHeader = res.data.excelData.slice(0, excelDataStartRow - 1)
      this.localConfig = res.data.config

      if (this.localConfig[0]) {
        this.projectId = this.localConfig[0][0]
        this.templateId = this.localConfig[0][1]
        this.workItemType = this.localConfig[0][2]
      }

      this.paseFileLoading = false
      this.step = 'beforeImport'

      if (
        res.data.excelData.length < excelDataStartRow ||
        !this.projectId ||
        !this.templateId ||
        !this.workItemType
      ) {
        const msg = this.vm.$t(
          '导入表格不符合导入模板规则，请检查导入表格内容。',
        )
        this.$message.error(msg)
        this.parseFileError = msg
        return
      }
      this.importAction()
    },
    // 导入
    importAction() {
      this.step = 'importing'
      // 保存当前校验后数据，方便断点导入
      try {
        this.$localforage.getItem(importQueueName).then(queue => {
          queue = queue || []
          this.$localforage.setItem(importQueueName, [
            ...new Set([...queue, this.id]),
          ])
        })
        this.$localforage.setItem(this.id, {
          ...this.$props,
          vm: null,
          file: this.localFile,
          data: this.excelData,
          header: this.excelHeader,
          config: this.localConfig,
          projectName: this.localProjectName,
        })
        this.worker.postMessage({
          event: eventMaps.IMPORT_DATA,
          props: {
            url: this.localImportUrl,
            header: this.excelHeader,
            excelData: this.excelData,
            payload: {
              projectId: this.projectId,
              templateId: this.templateId,
              workItemType: this.workItemType,
            },
          },
        })
        this.canClose = false
      } catch (error) {
        this.$message.error(this.vm.$t('导入失败'))
        this.canClose = true
      }
    },
    // 导入进度
    importProgress(res) {
      if (res.status === 200) {
        this.importer.loading = true
        this.importer.range = res.data.range
        this.importer.percentage = res.data.percentage

        if (res.data?.errorRowDataList?.length) {
          this.weakMap.get(this.errorMapKey).push(...res.data.errorRowDataList)
        }

        this.errorSize += res.data.errorSize
        this.successSize += res.data.successSize
        this.weakMap.set(this.remainDataMapKey, res.data.remainData)

        // 触发事件
        this.eventBus.emit('importing', {
          importer: this.importer,
          res,
        })

        if (res.data.percentage === 100) {
          this.step = 'imported'
          this.removeCache()
          this.canClose = true
        } else {
          // 更新缓存
          this.$localforage.setItem(this.id, {
            ...this.$props,
            vm: null,
            file: this.localFile,
            data: this.weakMap.get(this.remainDataMapKey),
            header: this.excelHeader,
            config: this.localConfig,
            projectName: this.localProjectName,
          })
        }
      } else {
        this.importer.status = 'fail'
        this.color = '#ea3447'
      }
    },
    // 移除缓存
    removeCache() {
      this.$localforage.removeItem(this.id)
      this.$localforage.getItem(importQueueName).then(queue => {
        if (queue) {
          const index = queue.findIndex(item => item === this.id)
          index > -1 && queue.splice(index, 1)
          this.$localforage.setItem(importQueueName, queue)
        }
      })
    },
    // 重新导入
    reimport() {
      this.worker.postMessage({
        event: eventMaps.IMPORT_DATA,
        props: {
          url: this.localImportUrl,
          excelData: this.weakMap.get(this.remainDataMapKey),
          payload: {
            projectId: this.projectId,
            templateId: this.templateId,
            workItemType: this.workItemType,
          },
        },
      })
    },
    // 导出错误数据
    exportErrorData() {
      this.exportLoading = true
      this.worker.postMessage({
        event: eventMaps.EXPORT_ERROR_DATA,
        props: {
          header: this.excelHeader,
          data: this.weakMap.get(this.errorMapKey),
          config: this.localConfig,
        },
      })
    },
    // 导出文件
    exportAction(res) {
      if (res.status === 200) {
        let data = new Blob([res.data], {
          type: 'application/octet-stream',
        })
        data = URL.createObjectURL(data)
        const a = document.createElement('a')
        a.hidden = true
        a.href = data
        a.download = this.localTitle + `_${this.vm.$t('错误数据')}.xlsx`
        document.body.appendChild(a)
        a.click()
        document.body.removeChild(a)
        URL.revokeObjectURL(data)
      }

      this.exportLoading = false
    },
  },
}
</script>

<style lang="scss" scoped>
.active-color {
  color: $--color-primary;
}

.danger-color {
  color: $--color-danger;
}

.import-button,
.validate-button {
  cursor: pointer;
}

.box-progress {
  margin-bottom: 8px;
}

.file-info {
  margin-bottom: 10px;
  display: flex;
  align-items: center;

  button {
    margin-left: 8px;
  }
}

.box-info {
  .validated-text {
    color: $--color-success;
  }
}
</style>
