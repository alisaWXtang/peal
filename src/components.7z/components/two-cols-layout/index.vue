<template>
  <div class="two-cols-layout" :class="isExpand ? '' : 'left--hidden'">
    <div class="two-cols-layout__left">
      <slot name="left">left</slot>
    </div>
    <div class="switch-btn" @click="toggleExpand">
      <i class="icon el-icon-arrow-left"></i>
    </div>
    <div class="two-cols-layout__content">
      <slot name="right">content</slot>
    </div>
  </div>
</template>

<script>
/**
 * 左右布局+展开收起功能
 */
export default {
  name: 'index',
  data() {
    return {
      isExpand: true,
    }
  },
  methods: {
    toggleExpand() {
      this.isExpand = !this.isExpand
    },
  },
}
</script>

<style scoped lang="scss">
.two-cols-layout {
  display: flex;
  align-items: stretch;
}
.switch-btn {
  align-self: center;
}
.two-cols-layout__left {
  position: relative;
  width: 200px;
  background: #fff;
}
.two-cols-layout__content {
  width: 0;
  flex: 1;
  background: #fff;
}
.left--hidden {
  .two-cols-layout__left {
    width: 0 !important;
    overflow: hidden;
  }
  .two-cols-layout__content {
    margin-left: -10px;
  }
  .icon {
    transform: rotate(180deg);
  }
}

.switch-btn {
  width: 12px;
  height: 90px;
  line-height: 90px;
  z-index: 3;
  box-sizing: border-box;
  background-color: $--background-gray;
  cursor: pointer;
  border-top-right-radius: 4px;
  border-bottom-right-radius: 4px;
  .icon {
    font-size: 10px;
    color: #999990;
    width: 10px;
  }
}
</style>
