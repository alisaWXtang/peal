<template>
  <div
    class="tinymce-editor"
    :style="{ 'min-height': minHeigt && minHeigt + 'px' }"
  >
    <editor
      ref="editor"
      v-model="myValue"
      class="tinymce-editor-111"
      :init="init"
      :disabled="disabled"
      @onKeyUp="editorChange"
    >
    </editor>
    <el-upload
      ref="elUploadUd"
      style="display:none"
      :action="uploadActionUrl"
      :data="upoladID"
      :headers="uploadHeaders"
      :show-file-list="false"
      :on-success="uploadSuccess"
      :before-upload="beforeUpload"
      class="elUploadUd"
    >
    </el-upload>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
import { debounce } from 'throttle-debounce'
import 'tinymce/tinymce.min'
import 'tinymce/themes/silver'

import Editor from '@tinymce/tinymce-vue'
// import 'tinymce/skins/content/default/content.css'

import ReportTableCSS from '!!raw-loader!@/style/global-box/ReportTable.scss'
import CustomContentCss from '!!raw-loader!./content-custom.scss'
import attachmentApi from '@/api/attachment'
import { pictureUpload } from '@/service/attachment'
import { getRealUrl } from '@/utils/sub-app-util'
import { getUploadHeaders } from '@/utils'
import { replaceImgSrc } from '@/utils/img-util'
let isImage = false
export default {
  components: {
    Editor,
  },

  props: {
    //传入一个value，使组件支持v-model绑定
    value: {
      type: String,
      default: '',
    },

    disabled: {
      type: Boolean,
      default: false,
    },

    plugins: {
      type: [String, Array],
      default: 'lists image paste autoresize fullscreen table importcss',
    },

    toolbar: {
      type: [String, Array],
      default:
        'undo redo | bold italic forecolor backcolor bullist  numlist  lists  imageCustom table',
    },

    minHeigt: {
      type: [String, Number, Boolean],
      default: 400,
    },

    maxHeigt: {
      type: [String, Number, Boolean],
      default: null,
    },
  },

  data() {
    return {
      //初始化配置
      // uploadActionUrl: window.$http.api.attachment.upload.url,
      // 更换图片上传接口 解决邮件图片加载不出来的问题
      uploadActionUrl: getRealUrl(attachmentApi.pictureUpload.url),
      upoladID: {
        workItemType: 16,
        workItemId: 0,
      },
      uploadHeaders: getUploadHeaders(),
      init: {
        language_url:
          (window.__INJECTED_PUBLIC_PATH_BY_QIANKUN__ || '/') +
          'tinymce/langs/zh_CN.js',
        language: i18n.locale === 'en' ? 'en_US' : 'zh_CN',
        skin_url:
          (window.__INJECTED_PUBLIC_PATH_BY_QIANKUN__ || '/') +
          'tinymce/skins/ui/oxide',
        min_height: this.minHeigt ? this.minHeigt : 400,
        plugins: this.plugins,
        toolbar: this.toolbar,
        paste_data_images: true,
        branding: false,
        font: 14,
        menubar: false,
        convert_urls: false,
        // 引入自定义content样式
        content_css: false,
        content_style: ReportTableCSS + CustomContentCss,
        setup: this.editorSetup,
        max_height: this.maxHeigt ? this.maxHeigt : null,
        //此处为图片上传处理函数
        // images_upload_handler: (blobInfo, success, failure) => {
        // var formData = new FormData();
        // formData.append('file', blobInfo.blob(), blobInfo.filename());
        // formData.append("workItemType", this.upoladID.workItemType);
        // formData.append("workItemId", this.upoladID.workItemId);
        // let config = { 'Content-Type': 'multipart/form-data' };
        // window.$http.post(window.$http.api.attachment.pictureUpload, formData, config).then(res => {
        //   success(res.data.url)
        // }).catch(e => {
        //   this.$message.error('上传失败');
        // })
        // },
        paste_preprocess(plugin, args) {
          // 这里在chromium内核上粘贴一次图片会触发两次，一次内容是文件名，一次是下面插入的img标签
          // 所以利用一个isImage标志位，在插入图片标签前去掉前一次的文件名粘贴
          if (window.chrome && isImage) {
            args.content = ''
            isImage = false
          }
        },
        init_instance_callback: editor => {
          // 判断chromium内核浏览器，才需要这样处理本地图片粘贴
          if (window.chrome) {
            editor.on('paste', event => {
              const clipboardData =
                event.clipboardData || event.originalEvent.clipboardData
              const items = clipboardData.items
              ;[...items].forEach(item => {
                if (item.kind === 'file') {
                  isImage = true
                  var formData = new FormData()
                  formData.append('file', item.getAsFile(), item.filename)
                  formData.append('workItemType', this.upoladID.workItemType)
                  formData.append('workItemId', this.upoladID.workItemId)
                  let config = { 'Content-Type': 'multipart/form-data' }
                  pictureUpload(formData, config).then(res => {
                    editor.execCommand('mceInsertClipboardContent', false, {
                      content: `<img src="${res.data.url}">`,
                    })
                  })

                  // const blob = item.getAsFile();
                  // const reader = new FileReader();
                  // reader.onload = function(event) {
                  //   editor.execCommand('mceInsertClipboardContent', false, {
                  //     content: `<img src="${event.target.result}">`
                  //   });
                  // };
                  // blob && reader.readAsDataURL(blob);
                }
              })
            })
          }
        },
      },

      myValue: this.value,
      editor: null,
    }
  },
  watch: {
    value() {
      this.setMyValue()
    },
    myValue: {
      handler(newName, oldName) {
        if (oldName !== newName) {
          this.$emit('watch', this.myValue)
        }
      },
    },
  },
  created() {
    /**
     * @desc 加载插件js，由外部使用决定启用相关自定义插件，用于解决外部启用插件内部未引用js文件
     */
    const plugins = this.plugins.split(' ').filter(item => !!item)
    plugins.forEach(plugin => {
      if (plugin === 'image') {
        require('./image')
      } else {
        require('tinymce/plugins/' + plugin)
      }
    })
  },
  mounted() {
    // window.tinymce.init({})
    this.setMyValue()
  },
  methods: {
    editorChange() {
      this.$emit('edit', this.myValue)
    },
    // 设置 tinymce value，用于替换特定内容处理
    setMyValue() {
      const tableReg = /<table\s{1}style/g
      let myValue = this.value
      if (tableReg.test(myValue)) {
        myValue = myValue.replace(tableReg, '<table class="tinymceTable" style')
      }
      this.myValue = replaceImgSrc(myValue) || ''
    },
    // 编辑器 setup
    editorSetup(editor) {
      this.registerShortcut(editor)
      this.registerBtn(editor)
    },
    // setup - 注册命令
    registerShortcut(editor) {
      const saveHandle = debounce(300, true, () => this.$emit('save'))
      editor.shortcuts.add('ctrl+s', i18n.t('保存'), saveHandle)
      editor.shortcuts.add('meta+s', i18n.t('保存'), saveHandle)
    },
    // setup - 注册按钮
    registerBtn(editor) {
      !this.editor && (this.editor = editor)
      editor.ui.registry.addButton('imageCustom', {
        icon: 'image',
        onAction: () => {
          this.imageHandlerCallback(editor)
        },
      })
    },
    // img 图标点击回调处理函数，用于触发 element-ui 的 upload 方法
    imageHandlerCallback() {
      this.$refs.elUploadUd.$el.querySelector('.elUploadUd input').click()
    },
    // 图片上传前的格式检测
    beforeUpload(file) {
      const isJPG = file.type === 'image/jpeg' || file.type === 'image/png'
      const isLt2M = file.size / 1024 / 1024 < 2
      if (!isJPG) {
        this.$message.error('上传图片只能是 JPG或PNG 格式!')
      }
      if (!isLt2M) {
        this.$message.error('上传图片大小不能超过 2MB!')
      }
      return isJPG && isLt2M
    },
    //上传图片成功回调
    uploadSuccess(response) {
      if (response.status === 200) {
        this.editor.execCommand(
          'mceInsertContent',
          false,
          '<img alt="img" src="' + response.data.url + '"/>',
        )
      } else {
        this.$message.error(response.msg || i18n.t('上传图片失败'))
      }
    },
    customUpload(file) {
      pictureUpload({ ...file.data, file: file.file }).then(res => {
        if (res.status === 200) {
          this.editor.execCommand(
            'mceInsertContent',
            false,
            '<img alt="img" src="' + res.data.url + '"/>',
          )
        }
      })
    },
    //可以添加一些自己的自定义事件，如清空内容
    clear() {
      this.myValue = ''
    },
  },
}
</script>

<style lang="scss">
// popper样式修复
@import '@/style/global-box/tinymce.scss';
</style>
