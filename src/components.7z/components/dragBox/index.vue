<template>
  <div
    ref="importBox"
    class="columbus-custom-box columbus-import-box slide-left"
    :id="id"
    :style="style"
    v-bind="$attrs"
  >
    <div class="box-header drag-element">
      <div class="header-title" :title="title">{{ title }}</div>
      <div class="header-operation">
        <div class="close" v-if="canClose" @click="handleClose">
          <i class="el-icon-close"></i>
        </div>
      </div>
    </div>
    <div class="box-content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import DragUtil from "./drag";
export default {
  name: "CustomBox",
  props: {
    title: {
      type: String,
      required: true,
      desc: "标题"
    },
    canClose: {
      type: Boolean,
      desc: "是否可以关闭"
    }
  },
  data() {
    return {
      id: "columbus-import-box-" + this._uid,
      style: {}
    };
  },
  created() {
    this.styleComputed();
  },
  mounted() {
    document.body.appendChild(this.$el);
    // 注册拖动事件
    const dragUtil = new DragUtil(this.$el);
    dragUtil.initEvent();
    this.$once("hook:beforeDestroy", () => {
      this.$el.removeEventListener("animationend", this.componentDestroy);
      // 移除拖动事件
      dragUtil.removeEvent();
    });

    this.$once("hook:destroyed", () => {
      const el = document.querySelector("#" + this.id);
      el && document.body.removeChild(el);
    });
  },
  methods: {
    // 样式计算
    styleComputed() {
      let top = 0;
      const boxes = document.querySelectorAll(
        '.columbus-custom-box:not([class*="dragged-element"])'
      );
      if (boxes?.length) {
        const lastNode = boxes[boxes.length - 1];
        top = lastNode.offsetTop + lastNode.offsetHeight + 20;
        this.style = { top: top + "px" };
      }
    },
    // 关闭
    handleClose() {
      this.$el.classList.remove("slide-left");
      this.$el.classList.add("slide-right");
      this.$el.addEventListener("animationend", this.componentDestroy);
    },
    // 组件销毁
    componentDestroy() {
      this.$emit("close");
      this.$destroy();
      this.$emit("closed");
    }
  }
};
</script>

<style lang="scss" scoped>
.active-color {
  color: $--color-primary;
}

.drag-element {
  cursor: move;
}

.import-button,
.validate-button {
  cursor: pointer;
}

.columbus-import-box {
  background-color: #fff;
  border-radius: 6px;
  width: 360px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.15);
  z-index: 5000;
  right: 20px;
  top: 20px;
  position: fixed;

  .box-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #ebeef5;
    padding: 15px;

    .header-title {
      @include no-wrap;
      font-weight: bold;
      color: #666666;
    }

    .header-operation {
      flex: 0 0 auto;
      color: #bfbfbf;

      > div {
        cursor: pointer;

        &:hover {
          color: $--color-primary;
        }
      }
    }
  }

  .box-content {
    padding: 15px 15px 20px 15px;

    .box-progress {
      margin-bottom: 8px;
    }

    .file-info {
      margin-bottom: 10px;
      display: flex;
      align-items: center;

      button {
        margin-left: 8px;
      }
    }

    .box-info {
      .validated-text {
        color: $--color-success;
      }
    }
  }
}

.slide-left {
  animation: slide-left 0.3s ease both;
}

.slide-right {
  animation: slide-right 0.3s ease both;
}

/**
 * ----------------------------------------
 * animation slide-left
 * ----------------------------------------
 */
@keyframes slide-left {
  0% {
    transform: translateX(320px);
  }
  100% {
    transform: translateX(0);
  }
}

@keyframes slide-right {
  0% {
    transform: translateX(0);
  }

  80% {
    opacity: 0.8;
  }

  100% {
    transform: translateX(320px);
    opacity: 0;
  }
}
</style>
