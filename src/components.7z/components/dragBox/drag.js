/**
 * @title 拖动工具
 * @author chenxiaolong
 * @date 2021.3.29
 */

export default class DragUtil {
  /**
   *
   * @param {Element} dom
   */
  constructor(dom) {
    this.dom = dom;
    this.x = 0;
    this.y = 0;
    this.l = 0;
    this.t = 0;
    this.isOnDrag = false;
    this.placeholderLeft = this.dom.offsetLeft - this.dom.offsetWidth;
    this.isUpdateLayout = false
  }

  dragRangeRect() {
    const domRect = this.dom.getBoundingClientRect();
    const topMax = window.innerHeight - domRect.height;
    const leftMax = window.innerWidth - domRect.width;

    this.topMax = topMax;
    this.leftMax = leftMax;
  }

  // 初始化事件
  initEvent() {
    this.dom.addEventListener("mousedown", this.handleMouseDown.bind(this));
    this.dom.addEventListener("mouseup", this.handleMouseUp.bind(this));
    window.addEventListener("mousemove", this.handleMousemove.bind(this));
  }

  // 移除事件
  removeEvent() {
    this.dom.removeEventListener("mousedown", this.handleMouseDown.bind(this));
    this.dom.removeEventListener("mouseup", this.handleMouseUp.bind(this));
    window.removeEventListener("mousemove", this.handleMousemove.bind(this));
  }

  /**
   *
   * @param {EventListenerObject} e
   */
  handleMouseDown(e) {
    if (e.target.classList.contains("drag-element")) {
      // x y 坐标
      this.x = e.clientX;
      this.y = e.clientY;
      // 获取偏移量
      this.l = this.dom.offsetLeft;
      this.t = this.dom.offsetTop;

      this.dragRangeRect();

      this.isOnDrag = true;
    }
  }

  handleMousemove(e) {
    if (!this.isOnDrag) {
      return;
    }

    //获取x和y
    const nx = e.clientX;
    const ny = e.clientY;
    //计算移动后的左偏移量和顶部的偏移量
    let nl = nx - (this.x - this.l);
    let nt = ny - (this.y - this.t);

    if (nl > this.leftMax) {
      nl = this.leftMax;
    } else if (nl < 0) {
      nl = 0;
    }

    if (nt > this.topMax) {
      nt = this.topMax;
    } else if (nt < 0) {
      nt = 0;
    }

    this.dom.style.left = nl + "px";
    this.dom.style.top = nt + "px";
    this.dom.style.position = "fixed";
    this.dom.classList.add("dragged-element");

    if (this.placeholderLeft > this.dom.offsetLeft && !this.isUpdateLayout) {
      this.updateLayout()
    }
  }

  handleMouseUp(e) {
    this.isOnDrag = false;
  }

  // 更新布局
  updateLayout() {
    const boxes = document.querySelectorAll(
      '.columbus-custom-box:not([class*="dragged-element"])'
    );
    let top = 20;
    for (let index = 0; index < boxes.length; index++) {
      const element = boxes[index];
      element.style.top = top + 'px';
      top += element.offsetHeight + 20;
    }

    this.isUpdateLayout = true
  }
}
