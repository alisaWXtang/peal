<template>
  <div>
    <el-popover
      v-model="showPopper"
      popperClass="filter-guide-pop"
      @after-enter="updateFunctionGuide"
      ref="pop"
      placement="right"
      trigger="manual"
    >
      <div class="pop-content">{{ $t('这里可设置默认过滤器') }}。</div>
      <div class="function-guide-tips__footer" @click.stop>
        <el-button type="text" @click="gotoDetailLink">{{
          $t('了解详情')
        }}</el-button>
        <el-button type="text" @click="showGuide = false">{{
          $t('已知晓')
        }}</el-button>
      </div>
    </el-popover>
    <div
      class="select-title"
      @click="onClickTitle"
      :class="{ 'select-title__active': visible }"
      :style="{ 'max-width': '200px', 'min-width': '120px' }"
    >
      <template v-if="selectorLabel">
        <span class="content">{{ selectorLabel }}</span>
        <i class="select-title__icon el-icon-arrow-down"></i>
      </template>
    </div>
    <el-select
      class="selecter"
      v-model="defaultValue"
      @change="onChange"
      @visible-change="onVisibleChange"
      :placeholder="$t('请选择过滤器')"
      :popper-class="customClass"
      :ref="elSelectRefKey"
    >
      <li class="select-search-input">
        <el-input
          :placeholder="$t('搜索')"
          v-model.trim="filterString"
          v-focus
          :ref="searchInputRefKey"
        ></el-input>
      </li>
      <div
        class="select-scroll-common scrollbal-common"
        v-if="!isFilterListEmpty"
        v-popover:pop
      >
        <el-option-group
          v-for="group in filterList"
          :key="group.label"
          :label="group.label"
        >
          <el-option
            v-for="item in group.options"
            :key="item.key"
            :label="item.value"
            :value="item.key"
          >
            <div
              class="select-item-box"
              :class="{ 'select-item-box-english': $isEnglish() }"
              @mouseenter="onHover(item.key, true)"
              @mouseleave="onHover(item.key, false)"
            >
              <span :class="{ 'filter-label': group.itemDetable }">{{
                item.value
              }}</span>
              <span
                class="defaulted-icon"
                v-show="item.isDefault"
                @click.stop
                >{{ defaultedLebal }}</span
              >
              <span
                class="default-icon"
                v-show="!item.isDefault && visibleIconItemId === item.key"
                @click.stop="onDefaultItem(item)"
              >
                <span class="box">
                  <i class="circul"></i>{{ $t('默认') }}
                </span>
              </span>
              <span
                class="delete-icon cursor-pointer"
                v-show="
                  group.key === 'user' &&
                    item.deletable &&
                    visibleIconItemId === item.key
                "
              >
                <i class="el-icon-delete" @click.stop="onDeleteItem(item)"></i>
              </span>
            </div>
          </el-option>
        </el-option-group>
      </div>
      <el-option v-show="isFilterListEmpty" value="" disabled>{{
        $t('无数据')
      }}</el-option>
    </el-select>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
import { inputFocusPublic } from '@/utils/focusPublicUtil.js'
import cloneDeep from 'lodash/cloneDeep'
// import FunctionGuideTips from '@/components/biz/function-guide-tips';

export default {
  name: 'FilterSelect',
  data() {
    let showGuide = false
    const { storageVisibleKey } = this
    if (window.localStorage && storageVisibleKey) {
      // showGuide = !window.localStorage.getItem(storageVisibleKey);
      // window.localStorage.setItem(storageVisibleKey, 'shown');
    }
    return {
      defaultValue: '',
      visible: false,
      filterString: '',
      elSelectRefKey: 'filterSelect',
      searchInputRefKey: 'search',
      defaultedLebal: 'default',
      filterList: [],
      filterListCopy: [],
      visibleIconItemId: null, // 显示图标的过滤器项 id
      focusTimer: null, //input聚焦用到定时器
      optionsLoaded: false,
      showGuide,
      selectorLabel: '',
    }
  },
  model: {
    prop: 'value',
    event: 'change',
  },

  props: {
    value: {
      default: '',
    },

    data: {
      type: Array,
      default() {
        return []
      },
    },

    customClass: {
      type: String,
      desc: '自定义 Select 下拉框的类名',
    },

    storageVisibleKey: {
      type: String,
      default: '',
    },
  },

  components: {
    // FunctionGuideTips,
  },

  computed: {
    isFilterListEmpty() {
      return (
        this.filterList[0] &&
        this.filterList[1] &&
        !this.filterList[0].options.length &&
        !this.filterList[1].options.length
      )
    },
    isFirstVisit() {
      return !this.$store.state.newVersionAlert.isVisited
    },
    showPopper: {
      get() {
        const { isFirstVisit, visible, showGuide } = this
        return isFirstVisit && visible && showGuide
      },
      set() {},
    },

    isNewAlertShown() {
      return this.$store.state.newVersionAlert.isNewVersionModalShown
    },
  },

  watch: {
    isNewAlertShown(newVal) {
      newVal && this.dealOptionsDefaultExpand()
    },
    // 初始化组件数据
    data: {
      handler: 'initData',
    },

    // 监听用户过滤操作
    filterString(val) {
      // 过滤子列表数据
      this.filterList = this.filterData(val)
    },
    value(val) {
      this.defaultValue = val
      this.selectorLabel = this.getSelectorLabel()
    },
  },

  mounted() {
    this.defaultValue = this.value
  },
  methods: {
    getSelectorLabel() {
      const LabelEnum = {
        '/requirement/list': i18n.t('全部需求'),
        '/task/view': i18n.t('全部任务'),
        '/bug/list': i18n.t('全部缺陷'),
      }
      const { filterList } = this
      if (!filterList.length || !this.defaultValue) {
        return LabelEnum[this.$route.path]
      }
      let label
      for (let group of filterList) {
        const { options } = group
        if (Array.isArray(options)) {
          for (let item of options) {
            if (item.key === this.defaultValue) {
              label = item.value
              break
            }
          }
        }
        if (label) break
      }
      return label || LabelEnum[this.$route.path]
    },
    gotoDetailLink() {
      window.open(
        'http://columbus.os.adc.com/doc/detail?productId=1&selectedId=2573',
      )

      this.showGuide = false
    },
    updateFunctionGuide() {
      this.$refs.pop.updatePopper()
    },
    // 初始化数据
    initData(val) {
      this.filterList = cloneDeep(val)
      this.optionsLoaded = true
      this.isNewAlertShown && this.dealOptionsDefaultExpand()
      this.filterListCopy = cloneDeep(val)
      this.selectorLabel = this.getSelectorLabel()
    },
    // 处理首次访问时，下拉选项默认展开逻辑
    dealOptionsDefaultExpand() {
      this.isFirstVisit && this.showGuide && this.onClickTitle()
    },
    // 点击外部元素 触发打开下拉框
    onClickTitle() {
      this.$refs[this.elSelectRefKey].$el.click()
    },
    // el-select change 回调事件
    onChange() {
      this.$emit('change', this.defaultValue)
    },
    // 下拉框显隐方法
    onVisibleChange(show) {
      this.visible = !this.visible
      if (!this.visible) {
        this.showGuide = false
      }
      // this.visible && this.$refs.
      inputFocusPublic(show, this.searchInputRefKey, this.focusTimer, this)
      if (!this.visible) {
        this.filterString = ''
        // this.$emit("change");
      }
    },
    // 删除某个过滤器
    onDeleteItem(filterId) {
      this.$emit('deleteItem', filterId)
    },
    // 设置某个过滤器为默认过滤器
    onDefaultItem(filterId) {
      this.$emit('defaultItem', filterId)
    },
    // 过滤
    filterData(val) {
      this.filterList = cloneDeep(this.filterListCopy)
      if (!val) return this.filterList
      // 回退数据
      this.filterList.forEach(filterGroup => {
        filterGroup.options = filterGroup.options.filter(filterItem => {
          return filterItem.filterName && filterItem.filterName.includes(val)
        })
      })
      return this.filterList
    },
    // 暂存显示图标过滤器的id
    onHover(filterId, visible) {
      this.visibleIconItemId = visible ? filterId : null
    },
  },
}
</script>
<style lang="scss" scoped>
@mixin active {
  border-color: $--color-primary;
}
@mixin ellipsis {
  overflow: hidden !important;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.function-guide-tips__footer {
  text-align: right;
}
.el-select-dropdown__item {
  padding-right: 20px !important;
}
.el-select-dropdown__item > span {
  padding-right: 0;
}
/deep/ .el-radio__label {
  padding-left: 5px;
}
.select-scroll-common {
  /deep/ .el-select-group__title {
    color: $--color-primary;
  }
}
.select-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px 10px;
  border-radius: 3px;
  box-sizing: border-box;
  height: 32px;
  transition: all 0.2s;
  cursor: pointer;
  max-width: 150px;
  border: 1px solid #e5e5e5;
  width: 196px;
  &:hover {
    @include active;
  }
  .content {
    @include ellipsis;
    width: 176px;
  }
  .el-icon-close {
    border-radius: 50%;
    background-color: #6b778c;
    color: #fff;
    padding: 2px;
    transform: scale(0.7);
    &:hover {
      background-color: #344563;
    }
  }
}
.select-title__icon {
  margin-left: 10px;
}
/deep/ .selecter {
  position: absolute;
  top: 0;
  visibility: hidden;
  width: 0;
  .el-select__tags {
    display: none;
    background-color: transparent;
  }
}
.fr {
  float: right;
}
.filter-label {
  margin-right: 15px;
}
.icon-box {
  position: absolute;
  right: 0;
}
.default-icon {
  position: absolute;
  right: 40px;
  padding-left: 20px;
  &:hover {
    color: $color-text-hover;
  }
  .box {
    position: relative;
    padding-left: 20px;
    display: flex;
    align-items: center;
  }
  .circul {
    margin-right: 5px;
    display: inline-block;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    border: 1px solid #bfbfbf;
  }
}
.defaulted-icon {
  color: #fff;
  font-size: 12px;
  border-radius: 5px;
  background-color: rgb(102, 102, 102);
  padding: 2px 4px !important;
  line-height: 16px;
  margin: 7px 0;
  font-weight: 500 !important;
  cursor: text;
  position: absolute;
  right: 40px;
}
.delete-icon {
  position: absolute;
  right: 15px;
  &:hover {
    color: $color-text-hover;
  }
}
.select-item-box {
  padding-right: 70px;
}
.select-item-box-english {
  padding-right: 100px;
}
</style>
<style>
.filter-guide-pop {
  width: 200px;
  border-radius: 6px;
  padding: 10px 20px 4px;
}
.pop-content {
  padding-top: 4px;
  font-size: 12px;
}
.el-select-dropdown {
  box-shadow: 0 3px 12px 0 rgba(102, 102, 102, 0.15);
}
</style>
