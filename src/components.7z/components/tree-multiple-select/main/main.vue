<template>
  <div>
    <div :class="{ showBizIdTab: collapseTags }">
      <el-popover trigger="click">
        <div
          slot="reference"
          class="select-input"
          :style="{ width: Width ? Width + 'px' : '100%' }"
        >
          <span
            v-for="(item, index) in selectList"
            v-show="!collapseTags"
            :key="index"
            class="el-tag el-tag--mini el-select select-tag"
          >
            <span class="el-select__tags-text">{{
              item[checkChlidInfo.label] ? item[checkChlidInfo.label] : 'label'
            }}</span>
            <i
              class="el-tag__close el-icon-close"
              @click.stop="removeTag(item)"
            ></i>
          </span>
          <span
            v-show="collapseTags"
            class="el-tag el-tag--mini el-select select-tag"
          >
            <span class="el-select__tags-text">+{{ selectList.length }}</span>
            <i
              class="el-tag__close el-icon-close"
              @click.stop="removeTag('')"
            ></i>
          </span>
          <span
            v-show="selectAllInit && selectList.length == 0"
            class="el-tag el-tag--mini el-select select-tag"
          >
            <span class="el-select__tags-text">{{ $t('全部') }}</span>
            <i
              class="el-tag__close el-icon-close"
              @click.stop="removeTag('')"
            ></i>
          </span>
          <i class="el-icon-arrow-down select-icon"></i>
        </div>
        <el-input v-model="filterText" :placeholder="$t('搜索')"></el-input>
        <!-- v-loading="!treeList" -->
        <div class="tree-style scrollbal-common">
          <el-tree
            ref="tree"
            :data="treeList"
            size="medium"
            show-checkbox
            :default-expanded-keys="defaultKey"
            :default-checked-keys="defaultCheckedKeys"
            :filter-node-method="filterNode"
            node-key="id"
            highlight-current
            :props="defaultProps"
            @check-change="checkChange"
          >
          </el-tree>
        </div>
      </el-popover>
    </div>
  </div>
</template>
<script>
/**
 * @title 树形下拉列表selectAllInit
 * @desc
 * @author panhui
 * @date 2019/10/11
 */
import { props } from './utils'
export default {
  name: 'TreeMultipleSelect',
  components: {},
  mixins: [],
  props,
  // props,
  data() {
    return {
      selectList: [],
      filterText: '',
      collapseTags: false,
      defaultProps: {
        children: 'children',
        label: this.checkChlidInfo.label ? this.checkChlidInfo.label : 'label',
      },

      treePopover: false,
      selectData: { data: [] },
    }
  },
  computed: {},
  watch: {
    checkChlidInfo: {
      handler(newVal) {
        this.selectList = newVal.tag
        this.setEndValue()
        this.selectList.length > 4
          ? (this.collapseTags = true)
          : (this.collapseTags = false)
      },
      deep: true,
    },

    selectInit: {
      handler(newVal) {
        this.$refs.tree.setCheckedKeys(newVal)
        this.selectList = this.checkChlidInfo.tag
      },
      deep: true,
    },

    filterText(val) {
      this.$refs.tree.filter(val)
    },
  },

  created() {},
  mounted() {},
  methods: {
    //节点选中事件
    checkChange() {
      this.setParentsValue()
    },
    //过滤节点
    filterNode(value, data) {
      if (!value) return true
      // 修复关联迭代过滤不到数据的问题
      const currentValue = data.label || data.name
      return currentValue.indexOf(value) !== -1
    },
    //tag移除
    removeTag(value) {
      let select = this.checkChlidInfo.tag
      select = value
        ? select.filter(item => {
            return item.id !== value.id
          })
        : []
      this.$refs.tree.setCheckedNodes(select)
      this.setParentsValue()
    },
    //设置最终传输值
    setParentsValue() {
      if (this.$refs.tree) {
        let select = this.$refs.tree.getCheckedNodes(true)
        this.$emit('update:checkParentsInfo', { data: select })
        this.setEndValue()
      }
    },
    //设置最终输出值
    setEndValue() {
      let key = ''
      this.checkChlidInfo['id']
        ? (key = this.checkChlidInfo['id'])
        : (key = 'id')
      this.$emit(
        'exportValue',
        this.checkChlidInfo.tag.map(item => {
          return item[key]
        }),
      )
    },
  },
}
</script>
<style lang="scss" scoped>
.select-input {
  position: relative;
  background-color: #fff;
  border-radius: 2px;
  border: 1px solid #dde5ef;
  padding: 0 25px 0 7px;
  min-height: 28px;
}
.select-tag {
  margin: 2px 0;
}
.select-icon {
  position: absolute;
  right: 5px;
  top: 50%;
  margin-top: -7px;
  font-size: 14px;
  color: #c5c4c4;
}
.tree-style {
  height: 200px;
  overflow-y: auto;
}
</style>
