// 所有选项
export const props = {
  checkChlidInfo: {
    type: Object,
    required: false,
    desc:
      '子的tag和checkbox选中信息 备注:label为显示tag标签字段,id为最终输出字段',
  },

  treeList: Array,
  selectInit: {
    type: Array,
    required: false,
    desc: '获取初始值',
  },

  Width: {
    type: [String, Number],
  },

  selectAllInit: {
    type: Boolean,
    required: false,
    default: false,
    desc: '是否初始选中全部',
  },

  defaultKey: {
    type: Array,
    required: false,
    desc: '设置默认展开值',
  },

  defaultCheckedKeys: {
    type: Array,
    required: false,
    desc: '设置默认选中值',
  },
}
