# 迭代多选

time: 2019.8.9  
author: heyunjiang

## 设计

迭代多选，用于需求、任务、缺陷

扩展 element-select
