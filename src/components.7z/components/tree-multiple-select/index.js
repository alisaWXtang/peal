import TreeMultipleSelect from './main/main.vue'
/**
 * @title 树形多选下拉组件
 * @author panhui
 * @date 2019.8.20
 */
export default {
  install(Vue) {
    const name = TreeMultipleSelect.name
    Vue.component(name, TreeMultipleSelect)
  },
}
