<template>
  <div class="filelist-box" ref="fileUploadBox">
    <div
      class="filelist-item"
      v-show="fileList.length"
      v-for="item in fileList"
      :key="item.id"
    >
      <div class="fl">
        <svg class="icon" aria-hidden="true" style="font-size: 30px;">
          <use
            :xlink:href="
              iconClass[item.typeName] ? iconClass[item.typeName] : '#icon-TET'
            "
          ></use>
        </svg>
      </div>
      <div>
        <div class="filelist-item-top">
          <span
            class="filelist-item-top-left ellipsis-pure"
            :title="item.name"
            @click="handleFileNameClick(item)"
            >{{ item.name }}</span
          >
          <span class="filelist-item-top-right">
            <i
              class="el-icon-view"
              :title="$t('预览文件')"
              @click.stop="handleFilePreview(item)"
              v-if="abledPreview(item)"
            ></i>
            <i
              class="el-icon-download"
              :title="$t('下载文件')"
              @click.stop="handleFileDownload(item)"
            ></i>
            <i
              class="el-icon-delete"
              :title="$t('删除文件')"
              @click.stop="handleFileBeforeRemove(item)"
              v-if="supportDelect"
            ></i>
          </span>
        </div>
        <div
          class="filelist-item-bottom ellipsis-pure"
          :title="item.createUser + ' ' + item.createTime"
        >
          {{ item.createUser }}&nbsp;{{ item.createTime }}
        </div>
      </div>
    </div>
    <div class="fileList" v-if="fileList.length <= 0">{{ $t('暂无附件') }}</div>
  </div>
</template>
<script>
import { i18n } from '@/i18n'
import { getRealUrl, windowOpenUrl } from '@/utils/sub-app-util'
/**
 * @title 媒体文件展示组件
 * @desc 支持媒体文件的预览和下载
 * @author lili
 * @date 2020-05-09
 */
export default {
  name: 'MediaFileList',
  props: {
    uploadedFileList: {
      type: Array,
      required: true,
      default: () => {
        return []
      },
      desc: '已经上传的文件列表',
    },

    supportDelect: {
      type: Boolean,
      default: true,
      desc: '媒体文件是否支持删除',
    },

    handleFileDelete: {
      type: Function,
      required: false,
      desc: '删除文件的回调',
    },
  },

  data() {
    return {
      iconClass: {
        xlsx: '#icon-ECEL',
        xls: '#icon-ECEL',
        json: '#icon-zonghewendang',
        ppt: '#icon-PPT',
        txt: '#icon-TET',
        png: '#icon-PNG',
        gif: '#icon-GIF',
        jpge: '#icon-JPG',
        zip: '#icon-ZIP',
        mp4: '#icon-VIDEO',
        pdf: '#icon-PDF',
        doc: '#icon-WORD',
        docx: '#icon-WORD',
      },
    }
  },
  computed: {
    filePreviewAuthList: function() {
      return this.$store.state.pf.filePreviewAuthList
    },
    fileList: function() {
      return this.uploadedFileList.map(item => {
        return {
          ...item,
          name: item.name || item.origName,
          typeName: item.name
            ? item.name.substring(
                item.name.lastIndexOf('.') + 1,
                item.name.length,
              )
            : item.origName.substring(
                item.origName.lastIndexOf('.') + 1,
                item.origName.length,
              ),
        }
      })
    },
  },

  created() {},
  methods: {
    // 是否支持预览
    abledPreview(item) {
      return this.filePreviewAuthList.includes(
        item.typeName && item.typeName.toLowerCase(),
      )
    },
    // 文件上传 - 标题点击
    handleFileNameClick(file) {
      if (
        !this.filePreviewAuthList.includes(
          file.typeName && file.typeName.toLowerCase(),
        )
      ) {
        this.handleFileDownload(file)
      } else {
        this.handleFilePreview(file)
      }
    },
    // 文件上传 - 文件预览
    handleFilePreview({ typeName, url }) {
      if (
        !this.filePreviewAuthList.includes(typeName && typeName.toLowerCase())
      ) {
        this.$message({
          type: 'warning',
          message: i18n.t('当前文档格式暂时不支持预览'),
        })

        return
      }
      windowOpenUrl(url + '?preview=true', '_blank', {
        ssoToken: true,
      })
    },
    // 文件上传 - 文件删除之前判断
    handleFileBeforeRemove(file) {
      let that = this
      this.$confirm(`${i18n.t('确定移除')} ${file.name}？`)
        .then(function() {
          that.handleFileDelete(file)
        })
        .catch(_ => _)
    },
    // 文件上传 - 文件下载
    handleFileDownload(file) {
      const url = getRealUrl(file.url, {
        ssoToken: true,
      })
      const targetElement = this.$refs.fileUploadBox
      if (
        !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) &&
        document.body.clientWidth < 769
      ) {
        window.location.href = url
      }
      let tempLink = document.createElement('a')
      tempLink.style.display = 'none'
      tempLink.href = url
      tempLink.setAttribute('download', '')
      if (typeof tempLink.download === 'undefined') {
        tempLink.setAttribute('target', '_blank')
      }
      targetElement.appendChild(tempLink)
      tempLink.click()
      targetElement.removeChild(tempLink)
    },
  },
}
</script>
<style lang="scss" scoped>
.filelist-box {
  .fileList {
    padding-left: 15px;
    padding-top: 15px;
  }
  .filelist-item {
    margin: 0;
    padding: 10px 0;
    overflow: hidden;
    .filelist-item-top {
      font-size: 0;
      height: 18px;
      line-height: 18px;
      padding-left: 35px;
      .filelist-item-top-left {
        display: inline-block;
        width: calc(100% - 70px);
        font-size: 16px;
        color: $color-font-inactive-common;
        cursor: pointer;
      }
      .filelist-item-top-right {
        display: none;
        width: 60px;
        font-size: 14px;
        vertical-align: text-bottom;
        margin-left: 10px;
        margin-bottom: 2px;
        i {
          cursor: pointer;
        }
      }
    }
    .filelist-item-bottom {
      padding-left: 5px;
      color: #797777;
      font-size: 10px;
    }
    &:hover {
      .filelist-item-top-right {
        display: inline-flex;
        justify-content: space-around;
        i:hover {
          color: $color-font-active-common;
        }
      }
    }
  }
}
</style>
