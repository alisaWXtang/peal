<template>
  <!-- 文件上传框 -->
  <div class="doc-upload">
    <div ref="fileUploadBox">
      <el-popover
        v-if="isNeedRelatedFile"
        v-model="visible"
        placement="bottom"
        popper-class="coteam file-popper"
        trigger="click"
      >
        <div class="file-plus-hover" @click="docVisible = true">
          {{ $t('关联文档') }}
        </div>
        <el-upload
          v-if="!uploading.type"
          :class="{ 'el-upload-hidden': !fileUpdaloadBoxStatus }"
          multiple
          drag
          :show-file-list="false"
          list-type="text"
          :action="uploadInfo.uploadActionUrl"
          :data="extraData || uploadInfo.upoladID"
          :headers="uploadHeaders"
          :on-progress="fileuploadprocess"
          :on-success="handleUploadSuccess"
          :on-error="handleUploadError"
          :before-upload="fileValidCheck"
        >
          <template>
            <div class="cursor-pointer file-plus-hover" @click="uploadDocFun">
              {{ $t('上传文档') }}
            </div>
          </template>
        </el-upload>
        <div v-else class="disable-btn">
          {{ $t('上传文档') }}
        </div>
        <el-button
          v-if="addFileText"
          slot="reference"
          v-clickoutside="handleClosePopover"
          type="primary"
          plain
          style="vertical-align: top"
          >{{ $t('添加附件') }}</el-button
        >
        <el-button
          v-if="!addFileText"
          slot="reference"
          v-clickoutside="handleClosePopover"
          type="primary"
          style="vertical-align: top"
          plain
          >{{ $t('附件上传') }}</el-button
        >
      </el-popover>
      <el-upload
        :style="{
          display: 'inline-block',
          width: isNeedRelatedFile ? '' : '100%',
        }"
        class="bug-attachment-upload-box fileUploadBoxMini"
        :class="{ 'el-upload-hidden': !fileUpdaloadBoxStatus }"
        multiple
        drag
        :show-file-list="false"
        :action="uploadInfo.uploadActionUrl"
        :data="extraData || uploadInfo.upoladID"
        :headers="uploadHeaders"
        :on-progress="fileuploadprocess"
        :on-success="handleUploadSuccess"
        :on-error="handleUploadError"
        :before-upload="fileValidCheck"
      >
        <el-button v-if="!isNeedRelatedFile" type="primary" plain>
          {{ $t('添加附件') }}
        </el-button>
        <div class="el-upload__text">
          <div>
            {{ $t('点击添加附件或拖拽文件到此处上传') }}({{
              $t('大小限制为')
            }}256M)
          </div>
        </div>
      </el-upload>
      <el-progress
        v-if="uploading.type"
        class="file-upload-process"
        :percentage="uploading.process"
      ></el-progress>
      <div class="filelist-box">
        <div
          v-for="(item, index) in fileList"
          :key="item.id"
          class="filelist-item"
        >
          <div class="fl">
            <svg class="icon" aria-hidden="true" style="font-size: 30px">
              <use
                :xlink:href="
                  iconClass[item.typeName]
                    ? iconClass[item.typeName]
                    : '#icon-TET'
                "
              ></use>
            </svg>
          </div>
          <div>
            <div class="filelist-item-top">
              <span
                class="filelist-item-top-left ellipsis-pure no-cursor"
                :title="item.name"
                >{{ item.name }}</span
              >
              <span class="filelist-item-top-right">
                <template v-if="needPreviewAndUpdate">
                  <i
                    class="el-icon-view"
                    :title="$t('预览')"
                    v-if="
                      (!isCreate &&
                        canPreviewAndUpdate &&
                        filePreviewAuthList.includes(
                          item.typeName && item.typeName.toLowerCase(),
                        ))
                    "
                    @click.stop="handleShowFilePreview(item)"
                  ></i>
                  <el-upload
                    action="/"
                    :show-file-list="false"
                    :before-upload="file => fileUpdate(file, index)"
                    v-if="
                      !isCreate &&
                        canPreviewAndUpdate &&
                        $authFunction(
                          'FUNC_COOP_DOCUMENT_UPDATE',
                          3,
                          $getUrlParams().projectId,
                        )
                    "
                  >
                    <i class="el-icon-refresh" :title="$t('更新文件')"></i>
                  </el-upload>
                </template>
                <i
                  class="el-icon-download"
                  :title="$t('下载文件')"
                  @click.stop="handleFileDownload(item)"
                ></i>
                <i
                  class="el-icon-delete"
                  :title="$t('删除文件')"
                  @click.stop="handleFileBeforeRemove(item)"
                ></i>
              </span>
            </div>
            <div
              class="filelist-item-bottom ellipsis-pure"
              :title="
                item.createUser + ' ' + (item.updateTime || item.createTime)
              "
            >
              {{ item.createUser }}&nbsp;{{
                item.updateTime || item.createTime
              }}
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 关联文档弹窗 -->
    <el-dialog
      :title="$t('关联文档')"
      :visible.sync="docVisible"
      :modal-append-to-body="false"
      width="500px"
    >
      <el-input
        v-model="docSearch"
        placeholder=""
        suffix-icon="el-icon-search"
      ></el-input>
      <div style="height: 300px; overflow: auto" class="scrollbal-common">
        <el-tree
          ref="docTree"
          v-loading="loading"
          :data="docTreeData"
          :props="defaultProps"
          node-key="key"
          :check-strictly="true"
          default-expand-all
          :filter-node-method="filterNode"
          show-checkbox
          @check-change="checkChange"
        >
          <div slot-scope="scope" class="iconmorebox">
            <i v-if="scope.data.nodeType" class="iconfont icon-folder"></i>
            <i v-else class="iconfont icon-wenjian"></i>
            <span>{{ scope.node.label }}</span>
          </div>
        </el-tree>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="docVisible = false">{{ $t('取消') }}</el-button>
        <el-button type="primary" @click="docSuerBtn">{{
          $t('确定')
        }}</el-button>
      </span>
    </el-dialog>
    <FilePreview
      :fileInfo="activeItem"
      ref="filePreview"
      v-if="showFileVisble"
      :icon-class="iconClass"
      @delete="handleFileBeforeRemove(activeItem)"
      @close="showFileVisble = false"
    />
  </div>
</template>

<script>
import { i18n } from '@/i18n'
/**
 * @title 关联工作项
 * @desc 缺陷：只能关联一种类型、选择一页的数据关联
 * @desc 2019-8-21修改上传附件并添加button
 * @author heyunjiang
 * @date 2019-3-28
 */
import { mapState } from 'vuex'
import Clickoutside from 'cook-ui/src/utils/clickoutside'
import attachmentApi from '@/api/attachment'
import * as documentService from '@/service/document'
import { getUploadHeaders } from '@/utils'
import { getRealUrl, windowOpenUrl } from '@/utils/sub-app-util'
import FilePreview from '../file-preview/index.vue'
import { attachmentUpdate } from '@/service/file'
import { downloadFile } from '@/utils/index'
import { WORKITEMCONST } from '@/utils/constant'

const isNormalFile = file => {
  return new Promise(resolve => {
    const reader = new FileReader()
    reader.onload = () => {
      resolve(true)
    }
    reader.onerror = () => {
      resolve(false)
    }
    reader.readAsText(file)
  })
}
export default {
  name: 'FileUpload',
  directives: { Clickoutside },
  components: {
    FilePreview,
  },
  props: {
    isCreate: {
      type: Boolean,
      default: false,
      desc: '当前弹窗是为新建',
    },

    projectId: {
      type: [Number, String],
      desc: '用于不再项目下创建时',
    },

    addFileText: {
      type: [Number, String],
    },

    fileUpdaloadBoxStatus: {
      type: Boolean,
      required: false,
      default: true,
      desc: '缺陷上传框是否展示',
    },

    uploadedFileList: {
      type: Array,
      required: true,
      desc: '已经上传的文件列表',
    },

    handleFileDelete: {
      type: Function,
      required: true,
      desc: '删除文件的回调',
    },

    handleUploadSuccess: {
      type: Function,
      required: true,
      desc: '上传文件成功的回调',
    },

    detailInfoId: {
      type: [Number, String],
      required: false,
      default: 0,
      desc:
        '当前文件上传框所属需求/任务/缺陷/其他 的 id，可不传，默认为0，则为新建',
    },

    workItemType: {
      type: [Number, String],
      required: true,
      desc: '当前文件上传框所属需求/任务/缺陷/其他 的 类型，分别对应 0,1,2',
    },

    isNeedRelatedFile: {
      type: Boolean,
      default: true,
      desc: '是否需要关联文档',
    },

    uploadUrl: {
      type: String,
      default: attachmentApi.upload.url,
      desc: '上传的地址',
    },

    extraData: {
      type: Object,
      desc: '上传时附带的额外参数',
    },
  },

  data() {
    return {
      showFileVisble: false,
      activeItem: null,
      uploadHeaders: getUploadHeaders(),
      visible: false,
      uploading: {
        type: false,
        process: 0,
      },
      docSearch: '',
      docVisible: false,
      defaultProps: {},
      docTreeData: [],
      loading: false,
      docPucbli: {}, //临时存储关联文档公共数据
      iconClass: {
        xlsx: '#icon-ECEL',
        xls: '#icon-ECEL',
        json: '#icon-zonghewendang',
        ppt: '#icon-PPT',
        txt: '#icon-TET',
        png: '#icon-PNG',
        gif: '#icon-GIF',
        jpge: '#icon-JPG',
        zip: '#icon-ZIP',
        mp4: '#icon-VIDEO',
        pdf: '#icon-PDF',
        doc: '#icon-WORD',
        docx: '#icon-WORD',
      },
      showPlayer: false,
    }
  },

  computed: {
    // 是否打开预览更新按钮
    needPreviewAndUpdate() {
      return [
        WORKITEMCONST.workItemTypeMap.requirement, // 需求
        WORKITEMCONST.workItemTypeMap.task, // 任务
        WORKITEMCONST.workItemTypeMap.bug, // 缺陷
      ].includes(this.workItemType)
    },
    // 文件上传 - 附带信息 (当切换缺陷时，保证上传信息也更新)
    uploadInfo: function() {
      const url = this.uploadUrl || attachmentApi.upload.url
      const config = {
        uploadActionUrl: getRealUrl(url),
        upoladID: {
          workItemType: +this.workItemType,
          workItemId: +this.detailInfoId,
        },
      }
      return config
    },
    fileList: function() {
      return this.uploadedFileList.map(item => {
        const typeName = item.name
          ? item.name.substring(
              item.name.lastIndexOf('.') + 1,
              item.name.length,
            )
          : item.origName.substring(
              item.origName.lastIndexOf('.') + 1,
              item.origName.length,
            )
        return {
          ...item,
          name: item.name || item.origName,
          typeName,
        }
      })
    },
    ...mapState({
      filePreviewAuthList: state => state.pf.filePreviewAuthList,
    }),
    canPreviewAndUpdate() {
      let query = this.$route.query
      return !!(query.requireId || query.taskId || query.bugId)
    },
  },

  watch: {
    docVisible: function(newVal) {
      if (newVal) {
        this.getDocTreeQuery()
        this.hideTips()
        // this.docTreeData[0].children.push([]);
        // this.$nextTick(()=>{
        //   this.$refs.docTree.setCheckedKeys([]);
        // })
      }
    },
    docSearch: function(newVal) {
      this.$refs.docTree.filter(newVal)
    },
  },

  methods: {
    fileUpdate(file, index) {
      if (file.size > 1024 * 1024 * 256) {
        this.$message({
          message: i18n.t('允许上传文件的大小上限为 256 M'),
          type: 'error',
        })
        return
      }
      this.uploadLoading = this.$loading({
        lock: true,
        text: i18n.t('文件上传中，请耐心等待'),
        spinner: 'el-icon-loading',
        background: 'rgba(0, 0, 0, 0.2)',
      })
      let data = new FormData()
      data.append('file', file)
      data.append('workItemType', this.workItemType)
      data.append('workItemId', this.detailInfoId)
      data.append('attachmentId', this.uploadedFileList[index].id)

      attachmentUpdate(data)
        .then(res => {
          this.uploadedFileList[index].name = res.data.origName
          this.uploadedFileList[index].typeName = res.data.origName
            .split('.')
            .pop()
          this.uploadedFileList[index].url = res.data.url
          this.uploadedFileList[index].size = res.data.size
          this.uploadedFileList[index].updateTime = res.data.updateTime
          this.uploadedFileList[index].createUser = res.data.display.createUser
          this.uploadLoading.close()
          this.handleUpdateSuccess()
          if (res.status === 200) {
            this.$message({
              type: 'success',
              message: i18n.t('文档更新成功') + '!',
            })
          }
        })
        .catch(err => {
          this.uploadLoading.close()
        })

      return false
    },

    async handleShowFilePreview(item) {
      item.workItemId = this.detailInfoId
      item.workItemType = this.workItemType
      this.activeItem = item
      this.showFileVisble = true
      this.$nextTick(() => {
        this.$refs.filePreview.dialogVisible = true
      })
    },
    handleClosePopover() {
      this.visible = false
    },
    // 文件上传 - 标题点击
    handleFileNameClick(file) {
      if (
        !this.filePreviewAuthList.includes(
          file.typeName && file.typeName.toLowerCase(),
        )
      ) {
        this.handleFileDownload(file)
      } else {
        this.handleFilePreview(file)
      }
    },
    // 文件上传 - 文件预览
    handleFilePreview({ typeName, url }) {
      if (
        !this.filePreviewAuthList.includes(typeName && typeName.toLowerCase())
      ) {
        this.$message({
          type: 'warning',
          message: i18n.t('当前文档格式暂时不支持预览'),
        })

        return
      }
      windowOpenUrl(url + '?preview=true', '_blank', {
        ssoToken: true,
      })
    },
    // 文件上传 - 文件删除之前判断
    handleFileBeforeRemove(file) {
      let that = this
      this.$confirm(`${i18n.t('确定移除')} ${file.name}？`)
        .then(function() {
          that.handleFileDelete(file)
          that.showFileVisble = false
          that.$refs.fileReview.dialogVisible = false
        })
        .catch(_ => _)
    },
    // 文件上传 - 文件下载
    handleFileDownload(file) {
      downloadFile(file.url, file.name)
    },
    // 文件上传，错误处理
    handleUploadError() {},
    // 文件上传 - 上传进度控制
    fileuploadprocess(process) {
      if (process && process.percent && process.percent < 100) {
        this.uploading = {
          type: true,
          process: +process.percent.toFixed(0),
        }
      } else {
        this.uploading = {
          type: false,
          process: 0,
        }
      }
    },
    // 文件上传 - 大小控制 256m
    async fileValidCheck(file) {
      // 新增文件名长度控制
      if (file.name && file.name.length > 230) {
        this.$message({
          message: i18n.t('文件名过长'),
          type: 'error',
        })

        throw false
      }
      const isFile = await isNormalFile(file)
      if (isFile && file.size < 256 * 1024 * 1024) {
        return true
      }
      if (!isFile) {
        this.$message({
          message: i18n.t('暂不支持上传文件夹'),
          type: 'error',
        })

        throw false
      }
      if (file.size === 0) {
        this.$message({
          message: i18n.t('暂不支持上传空文件'),
          type: 'error',
        })

        throw false
      }
      this.$message({
        message: i18n.t('允许上传文件的大小上限为 256 M'),
        type: 'error',
      })

      throw false
    },
    //获取关联文档信息
    getDocTreeQuery() {
      this.loading = true
      documentService
        .docTreeQuery({
          projectId: this.$getUrlParams().projectId || this.projectId,
        })
        .then(res => {
          if (res.status == 200) {
            this.docTreeData = [
              {
                id: -32,
                key: 'e',
                projectId: 100001,
                nodeType: 1,
                disabled: true,
                name: i18n.t('全部文件'),
                label: i18n.t('全部文件'),
                parentId: 0,
                children: [...res.data],
              },
            ]

            this.loading = false
          }
        })
        .catch(() => {})
    },
    //搜索关联文档
    filterNode(value, data) {
      if (!value) return true
      return data.label.indexOf(value) !== -1
    },
    //关联文档多选只能单选
    checkChange(data, checked) {
      if (checked) {
        let arr = [data.id]
        this.docPucbli = data
        this.$refs.docTree.setCheckedKeys([])
        this.$refs.docTree.setCheckedKeys(arr)
      }
    },
    //点击上传文档时隐藏tips
    uploadDocFun() {
      this.hideTips()
    },
    //隐藏tips
    hideTips() {
      let classList = [...document.getElementsByClassName('file-popper')]
      classList.forEach(el => {
        el.style.display = 'none'
      })
    },
    //关联文档
    // associatedDocFun(data){
    //   this.docPucbli = data;
    //   this.hideTips();
    // },
    //确认关联文档
    docSuerBtn() {
      let data = this.docPucbli
      if (!data.id) {
        this.$message({
          type: 'info',
          message: i18n.t('请选择关联的文档'),
        })

        return false
      }
      let obj = {
        projectId: data.projectId,
        documentId: data.id,
        workItemType: parseInt(this.workItemType),
        workItemId: parseInt(this.detailInfoId),
      }

      documentService
        .docAssociation(obj, { type: 'form' })
        .then(res => {
          if (res.status == 200) {
            let typeName = res.data.origName.split('.')[1]
            this.uploadedFileList.push({
              ...res.data,
              name: res.data.origName,
              createUser: res.data.display.createUser,
              typeName,
            })
            this.$message({
              type: 'success',
              message: i18n.t('关联文档成功') + '!',
            })

            this.$emit('upDataUpload')
            this.docVisible = false
            this.docPucbli = {}
            this.$refs.docTree.setCheckedKeys([])
          }
        })
        .catch(() => {})
    },
  },
}
</script>

<style lang="scss">
.coteam.file-popper {
  padding: 12px;
  text-align: center;
  width: auto;
  min-width: 100px;

  .el-upload {
    display: block;
  }

  .el-upload-dragger {
    background-color: transparent;
    height: 36px;
    width: 100%;
    // display: inline-block;
    border: none;
    border-radius: 0;
  }
}
</style>

<style lang="scss" scoped>
.doc-upload {
  margin: 24px 15px;
}
.file-upload-process {
  margin: 10px 0;
}
.file-plus-hover {
  cursor: pointer;
  // display: inline-block;
  border-radius: 4px;
  padding: 5px 10px !important;
  height: 26px;
  line-height: 26px;
  // width: 100px;
  &:hover {
    background: $--color-primary-light-9;
    color: $--color-primary;
  }
}
.disable-btn {
  color: #bfbfbf;
  border-radius: 4px;
  padding: 5px 10px !important;
  height: 26px;
  line-height: 26px;
  cursor: no-drop;
}
.docellipsis {
  padding: 0 3px !important;
}
.filelist-box {
  margin-top: 8px;
  .filelist-item {
    margin: 0;
    padding: 10px 0;
    overflow: hidden;
    .filelist-item-top {
      font-size: 0;
      height: 18px;
      line-height: 18px;
      padding-left: 35px;
      position: relative;
      .filelist-item-top-left {
        display: inline-block;
        width: calc(100% - 90px);
        font-size: 14px;
        color: $color-font-inactive-common;
        &.no-cursor {
          cursor: auto;
        }
      }
      .filelist-item-top-right {
        display: none;
        width: 80px;
        font-size: 14px;
        margin-left: 10px;
        justify-content: flex-end;
        align-items: center;
        position: absolute;
        right: 0;
        top: 0;
        z-index: 1;
        i {
          cursor: pointer;
          margin-left: 6px;
        }
      }
    }
    .filelist-item-bottom {
      padding-left: 5px;
      color: #797777;
      font-size: 10px;
    }
    &:hover {
      .filelist-item-top-right {
        display: flex;
        i:hover {
          color: $color-font-active-common;
        }
      }
    }
  }
}
//icon
.bule {
  color: red;
}
.upload-btn {
  display: inline-block;
  vertical-align: top;
  padding: 5px 10px;
  background: #20a0ff;
  color: #ffffff;
  border-radius: 4px;
  cursor: pointer;
  &:hover {
    background: #038fec;
  }
}

// 控制 upload 框大小
/deep/ .fileUploadBoxMini {
  .el-upload {
    width: 100%;
    text-align: left;
    .el-upload-dragger {
      height: 100%;
      width: 100%;
      display: flex;
      align-items: flex-start;
      border: none;
      border-radius: 0px;
      overflow: visible;
      .el-icon-upload {
        margin-top: 8px;
      }
    }
  }
}
</style>
