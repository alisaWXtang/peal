<template>
  <el-select
    v-model="value"
    ref="hourSelect"
    @change="onchange"
    v-bind="$attrs"
    v-on="$listeners"
    :clearable="isClearable"
  >
    <el-option
      v-for="item in expectHourListResult"
      :key="item.key"
      :value="item.key"
      :label="item.label"
    >
      <span style="float: left;margin-right:20px;">{{ item.value }}</span>
      <span style="float: right; color: #8492a6; font-size: 14px;"
        >{{ item.key }}h</span
      >
    </el-option>
    <div v-if="$attrs.multiple" class="multiple-more-display">
      <el-input
        :placeholder="$t('自定义工时(h)')"
        type="number"
        v-model="customDays"
        @change="customInputChange"
      ></el-input>
      <div class="showmore" @click="showmoreClick">
        {{ showMore ? $t('收起') : $t('更多') }}
      </div>
    </div>
    <template v-else>
      <el-option value="search" v-show="customInput" disabled>
        <el-input
          :placeholder="$t('自定义工时(h)')"
          type="number"
          v-model="customDays"
          @change="customInputChange"
        ></el-input>
      </el-option>
      <el-option value="0" disabled>
        <div class="showmore" @click="showmoreClick">
          {{ showMore ? $t('收起') : $t('更多') }}
        </div>
      </el-option>
    </template>
  </el-select>
</template>
<script>
import { i18n } from '@/i18n'
/**
 * @title 预计工时组件
 * @desc 用于分解任务、创建任务
 * @author heyunjiang
 * @date 2019.6.12
 */
import { mapState } from 'vuex'
import uniqBy from 'lodash/uniqBy'
export default {
  name: 'ExpectHour',
  components: {},
  model: {
    data: 'value',
    event: 'change',
  },
  mixins: [],
  props: {
    hour: {
      validator: value => {
        return true
      },
    },

    changeCallback: {
      type: Function,
      required: false,
      default: () => {},
    },

    customInput: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否允许自定义输入',
    },

    isClearable: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否可以清空',
    },
  },

  data() {
    return {
      value: '',
      showMore: false,
      customDays: null,
      customSelect: [],
    }
  },
  computed: {
    expectHourListResult() {
      const defaultSelect = this.expectHourList.filter(item => {
        if (!this.showMore) {
          return !item.showMore
        } else {
          return true
        }
      })
      return uniqBy([...defaultSelect, ...this.customSelect], 'key')
    },
    ...mapState({
      expectHourList: state => state.pf.expectHourList,
    }),
  },

  watch: {
    hour() {
      this.value = this.hour ? this.hour + 'h' : ''
    },
  },

  created() {},
  methods: {
    onchange(value) {
      this.$emit('update:hour', value)
      this.$emit('change', value)
      this.changeCallback && this.changeCallback(value)
      this.$nextTick(() => {
        this.$parent.$forceUpdate()
      })
    },
    showmoreClick() {
      this.showMore = !this.showMore
    },
    // 自定义天数回调
    customInputChange() {
      var expectHour = Number(this.customDays)
      if (!/^\d+$/.test(expectHour)) {
        this.$message({
          showClose: true,
          message: i18n.t('工时必须是正整数'),
          type: 'warning',
        })

        this.customDays = null
        return false
      }
      if (expectHour <= 0) {
        this.$message({
          showClose: true,
          message: i18n.t('工时必须大于0'),
          type: 'warning',
        })

        this.customDays = null
        return false
      }
      if (expectHour >= 10000) {
        this.$message({
          showClose: true,
          message: i18n.t('工时必须小于10000'),
          type: 'warning',
        })

        this.customDays = null
        return false
      }

      if (this.$attrs.multiple) {
        const valueSet = new Set(this.value)
        if (!valueSet.has(expectHour)) {
          this.value.push(expectHour)
          const data = {
            key: expectHour,
            label: expectHour + 'h',
            value: expectHour + 'h',
          }
          this.expectHourListResult.push(data)
          this.customSelect.push(data)
        } else {
          this.$message.warning(this.$t('已存在自定义工时'))
          return
        }
      } else {
        this.$emit('update:hour', expectHour)
        this.$refs.hourSelect.blur()
      }

      this.$emit('change', this.value)
      this.changeCallback && this.changeCallback(expectHour)
      this.$nextTick(() => {
        this.$parent.$forceUpdate()
      })
      this.customDays = null
    },
  },
}
</script>
<style lang="scss" scoped>
.showmore {
  cursor: pointer;
  text-align: center;
}

.multiple-more-display {
  padding-top: 5px;
  .showmore {
    padding: 10px 0;
    color: $--color-text-secondary;
  }
}
</style>
