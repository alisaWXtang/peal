<template>
  <div class="annotation-box">
    <div class="annotation-content">
      <div class="text">
        <slot></slot>
      </div>
      <div class="suffix-icon" v-if="icon">
        <co-tooltip
          class="item"
          popper-class="tooltip-item"
          :content="content"
          :effect="effect"
          :placement="placement"
        >
          <div slot="content" v-if="$slots.toolContent">
            <slot name="toolContent"></slot>
          </div>
          <i :class="icon"></i>
        </co-tooltip>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AnnotationTooltip",
  props: {
    icon: {
      type: String,
      default: null,
      desc: '图标'
    },
    content: {
      type: String,
      default: null,
      desc: '提示内容'
    },
    placement: {
      type: String,
      default: 'right',
      desc: 'top/top-start/top-end/bottom/bottom-start/bottom-end/left/left-start/left-end/right/right-start/right-end'
    },
    effect: {
      type: String,
      default: 'dark',
    }
  }
}
</script>

<style lang="scss" scoped>
.annotation-box {
  display: inline-block;
  .annotation-content {
    display: flex;
    .suffix-icon {
      margin-left: 5px;
    }
  }
}
</style>