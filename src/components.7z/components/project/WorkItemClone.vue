<template>
  <el-dialog
    :visible="cloneModalStatus"
    :title="cloneTitle"
    :show-close="false"
    width="550px"
    :modal-append-to-body="false"
  >
    <div>
      <el-form label-width="34%" class="modal-form">
        <el-form-item
          :label="
            `${$t(
              '复制',
            )}${$isEnglishDisplaySpace()}${workItemTypeName}${$isEnglishDisplaySpace()}${$t(
              '到',
            )}`
          "
        >
          <el-select
            v-model="form.toProjectId"
            value-key="id"
            :placeholder="$t('请选择目标项目')"
            :popper-append-to-body="true"
          >
            <el-option
              v-for="item in projectList"
              :key="item.id"
              :value="item.id"
              :label="
                item.name +
                  (item.id === +projectId ? `(${$t('当前项目')})` : '')
              "
              >{{ item.name
              }}{{
                item.id === +projectId ? `(${$t('当前项目')})` : ''
              }}</el-option
            >
          </el-select>
        </el-form-item>
        <el-form-item :label="$t('创建人')">
          <el-radio v-model="form.keepCreateUser" :label="true"
            >{{ $t('保留原') }}{{ $isEnglishDisplaySpace()
            }}{{ workItemTypeName }}{{ $isEnglishDisplaySpace()
            }}{{ $t('的创建人') }}</el-radio
          >
          <el-radio v-model="form.keepCreateUser" :label="false"
            >{{ $t('我') }}({{ userInfo.userName }})</el-radio
          >
        </el-form-item>
        <el-form-item
          v-show="workItemType == 1"
          :label="
            `${$t('复制子')}${$isEnglishDisplaySpace()}}${workItemTypeName}`
          "
        >
          <el-radio v-model="form.copyChild" :label="true">{{
            $t('是')
          }}</el-radio>
          <el-radio v-model="form.copyChild" :label="false">{{
            $t('否')
          }}</el-radio>
        </el-form-item>
      </el-form>
      <p class="center notice">
        ({{ $t('注') }}：{{ $t('复制后的相关状态都为初始状态') }})
      </p>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button type="default" @click="cancelModalClick">{{
        $t('取消')
      }}</el-button>
      <el-button
        type="primary"
        :disabled="loadingObject.posting"
        @click="saveCopy"
        >{{ $t('保存')
        }}{{ loadingObject.posting ? `${$t('中')}...` : '' }}</el-button
      >
    </span>
  </el-dialog>
</template>
<script>
import { i18n } from '@/i18n'
import { mapState } from 'vuex'

export default {
  /**
   * @title 工作项复制组件 根据 requirementClone 做了小调整
   * @author 刘峰
   * @date 2020.04.28
   */
  name: 'WorkItemClone',
  components: {},
  inject: {
    isInjectFromMine: {
      default: false,
    },

    refreshList: {
      default: () => () => {},
    },
  },

  mixins: [],
  props: {
    workItemType: {
      type: Number,
      required: false,
      default: 2,
      desc: '复制工作项的类型,默认为任务',
    },

    cloneTitle: {
      type: String,
      required: false,
      default: i18n.t('复制任务'),
      desc: '复制弹窗的标题',
    },

    workItemId: {
      type: [Number, String],
      required: true,
      desc: '工作项id',
    },

    projectId: {
      type: [Number, String],
    },

    cloneModalStatus: {
      type: Boolean,
      required: true,
    },

    closeModal: {
      type: Function,
      required: true,
    },
  },

  data() {
    return {
      loadingObject: {
        getting: false,
        posting: false,
      },

      form: {
        toProjectId: +this.projectId,
        keepCreateUser: true,
        copyChild: true,
      },

      userInfo: {},
    }
  },
  computed: {
    ...mapState({
      cloneProjectList: state => state.workItemManage.cloneProjectList.list, // 获取进行中项目的列表信息
    }),
    projectList() {
      const projectList = [...this.cloneProjectList].filter(
        project => !project.completed,
      )

      // 如果之前选择过的项目不再列表中，则默认为当前项目
      if (!projectList.some(item => item.id === this.form.toProjectId)) {
        this.$set(this.form, 'toProjectId', +this.projectId)
      }
      return projectList
    },
    workItemTypeName() {
      const WorkItemTypeNameObj = {
        1: i18n.t('需求'),
        2: i18n.t('任务'),
        3: i18n.t('缺陷'),
      }
      return WorkItemTypeNameObj[this.workItemType]
    },
  },

  watch: {
    // 当打开 modal 的时候，需要初始化分页信息，然后再获取数据
    cloneModalStatus(value) {
      if (value) {
        this.$store.dispatch('getWorkItemCloneProjectList', {
          type: this.workItemType,
        })
      }
    },
  },

  mounted() {
    this.userInfo = this.$store.state.gd.userInfo
  },
  methods: {
    // 复制需求
    async saveCopy() {
      // 同项目下复制打开创建表单
      if (this.form.toProjectId === this.projectId) {
        this.$emit('cloneInProject', {
          ...this.form,
          projectId: this.projectId,
          workItemId: this.workItemId,
          workItemType: this.workItemType,
        })
        this.$emit('update:cloneModalStatus', false)
        return
      }

      this.loadingObject.posting = true
      const res = await this.$store.dispatch('copyWorkItemContent', {
        ...this.form,
        projectId: this.projectId,
        workItemId: this.workItemId,
        workItemType: this.workItemType,
      })
      this.loadingObject.posting = false

      if (res.status === 200) {
        this.closeModal()
        // 是否是在工作台操作，是则刷新列表
        if (this.isInjectFromMine && typeof this.refreshList === 'function') {
          this.refreshList()
        }
        if (this.form.toProjectId === this.projectId) {
          const { name, query } = this.$route
          const customQuery = {
            1: {
              requireId: res.data,
            },
            2: {
              taskId: res.data,
            },
            3: {
              bugId: res.data,
            },
          }
          this.$router.push({
            name,
            query: {
              ...query,
              ...customQuery[this.workItemType],
            },
          })
        }
      }
    },
    // 取消按钮
    cancelModalClick() {
      this.$emit('update:cloneModalStatus', false)
    },
  },
}
</script>
<style lang="scss" scoped></style>
