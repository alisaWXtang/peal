<template>
  <div class="coteam-flow-chart-box">
    <el-popover
      ref="pop"
      v-model="visible"
      placement="left"
      trigger="click"
      popper-class="flow-chart-content"
      :visible-arrow="false"
      :width="canvasWidth"
    >
      <i class="el-icon-close flow-chart-close" @click="visible = !visible"></i>
      <div ref="mountCanvas" class="a-c-b"></div>
      <el-button slot="reference" class="work-flow-chart-width">
        <slot></slot>
      </el-button>
    </el-popover>
  </div>
</template>

<script>
import G6 from '@antv/g6'
import '@antv/g6/build/plugin.edge.polyline'
import '@antv/g6/build/plugin.layout.dagre'
G6.track(false)

export default {
  name: 'WorkFlowChart',
  components: {},
  mixins: [],
  props: {
    transfers: {
      type: Array,
      required: true,
      desc: '工作流状态流转',
    },

    // 已改为 ref ，不需要传容器 id
    // container: {
    //   type: [String, Number],
    //   required: false,
    //   default: 'mountNode',
    //   desc:
    //     '在一个页面有两个流程图的话，这时候id就重复，这个保存id的唯一性,传个不为mountNode的id',
    // },
  },

  data() {
    return {
      canvasWidth: '', //canvas宽度
      canvasHeight: '', //canvas高度
      visible: false,
    }
  },
  computed: {},
  watch: {
    visible(newValue) {
      if (newValue && this.transfers.length) {
        this.initData(this.transfers)
      }
    },
    transfers() {
      this.initData(this.transfers)
    },
  },

  methods: {
    initData(transfer) {
      if (this.$refs.mountCanvas) {
        this.$refs.mountCanvas.innerHTML = ''
      }
      let chartData1 = {
        nodes: [],
        edges: [],
      }

      transfer.forEach(item => {
        let defname = item.def.name
        if (defname.length >= 8) {
          defname = defname.substr(0, 6) + '...'
        }
        chartData1.nodes.push({
          id: item.def.name,
          label: defname,
          style: {
            fill: item.def.color,
            stroke: item.def.color,
            // lineWidth: 2,
            fillOpacity: 0.8,
          },
        })

        item.rules.forEach(ele => {
          chartData1.edges.push({
            source: item.def.name,
            target: ele.toStatusName,
          })
        })
      })
      this.setCanvasSize(transfer.length)
      if (chartData1.nodes.length) {
        this.initOptions(chartData1, this.canvasWidth, this.canvasHeight)
      }
    },
    initOptions(chartData1) {
      G6.registerNode('rect', {
        getPath: function getPath() {
          var width = 100 // 一半宽
          var height = 34 // 一半高
          return G6.Util.getRectPath(
            -width / 2, //文字相对图形位置
            -height / 2, //文字相对图形位置
            width, //图形宽度
            height, //图形高度
            10, //图形圆角度
          )
        },
      })

      var graph = new G6.Graph({
        container: this.$refs.mountCanvas,
        fitView: 'autoZoom', //自动缩放
        maxZoom: 1, //最大缩放倍率为1
        modes: {
          red: ['mouseEnterFillRed', 'mouseLeaveResetFill'],
        },

        mode: 'red',
        // fitView:"cc",
        height: this.canvasHeight, // 画布高
        width: this.canvasWidth,
        plugins: [
          new G6.Plugins['layout.dagre']({
            // rankdir:"LR",
            //  align:"UL",  //节点的对齐方式
            //  nodesep:150, //同层节点的距离
            edgesep: 10, //同层边距离,
            //  rankdir:"LR",
            // ranker:"tight-tree", //只是节点的位置不同
            // acyclicer:"greedy",
            marginx: 5,
            marginy: 5,
            // marginx:10,
          }),
        ],

        defaultIntersectBox: 'rect', // 使用矩形包围盒
      })
      graph.node({
        shape: 'rect',
        label: function label(model) {
          return {
            text: model.label,
            fill: '#fff',
          }
        },
      })

      graph.edge({
        shape: 'polyline',
        labelpos: 'C',
        style: {
          endArrow: true,
        },
      })

      graph.read(chartData1)
    },
    // 根据流转状态的个数来设置canvas的大小，解决，状态太多看不清的问题
    setCanvasSize(length) {
      if (length <= 6) {
        this.canvasWidth = 400
        this.canvasHeight = 400
      } else if (length <= 8) {
        this.canvasWidth = 520
        this.canvasHeight = 520
      } else if (length <= 10) {
        this.canvasWidth = 640
        this.canvasHeight = 640
      } else if (length <= 13) {
        this.canvasWidth = 720
        this.canvasHeight = 720
      } else if (length <= 16) {
        this.canvasWidth = 850
        this.canvasHeight = 720
      } else {
        this.canvasWidth = 1000
        this.canvasHeight = 720
      }
      this.$nextTick(() => {
        this.$refs.pop.updatePopper()
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.coteam-flow-chart-box {
  font-size: 14px;
  margin-left: 5px;
  flex: 1 1 0;
}
.a-c-b {
  overflow: hidden;
}

.coteam-flow-chart-box .el-button {
  border: none;
  font-size: 14px;
  padding: 0 5px;
  color: $--color-primary;
}
.flow-chart-close {
  position: absolute;
  width: 40px;
  height: 40px;
  line-height: 40px;
  text-align: center;
  right: 0px;
  top: 0px !important;
  z-index: 30000;
  cursor: pointer;
}
// .flow-chart-close:hover {
//    background: #F8F8FC;
// }
</style>
<style lang="scss">
.flow-chart-content {
  max-height: 90vh;
  overflow-y: auto;
}
.work-flow-chart-width {
  min-width: auto;
}
</style>
