<template>
  <div style="display: inline-block;width:50%;vertical-align: middle;">
    <tree-multiple-select
      :tree-list="sprintData"
      :check-parents-info.sync="checkParentsInfo"
      :check-chlid-info="checkChlidInfo"
      :select-init="selectInit"
      :default-key="defaultKey"
      @exportValue="exportValue"
    ></tree-multiple-select>
  </div>
</template>

<script>
import TreeMultipleSelect from '@/components/tree-multiple-select/main/main'
import { getFilterSprintList } from '@/service/project/projectCommon'
export default {
  name: 'SprintTreeMultipleSelect',
  components: {
    TreeMultipleSelect,
  },

  mixins: [],
  model: {
    prop: 'value',
    event: 'setValue',
  },
  props: {
    value: Array,
    panelWidth: {
      type: [String, Number],
    },

    // selectAllInit: {
    //   type: Boolean,
    //   required: false,
    //   default: false,
    //   desc: '是否初始选中全部'
    // }
  },
  data() {
    return {
      sprintData: [], // 封装好的数据格式
      sprintDataOriginal: [], // 保存获取到的数据
      checkParentsInfo: [], // 获取子传递过来checkbox的信息
      selectInit: [], //获取初始值
      checkChlidInfo: { tag: [], checkbox: [], label: 'name', id: 'id' }, //子传递给父的tag&checkbox信息
      recordData: [], //已归档数据
      unrecordData: [], //未归档数据
      defaultKey: ['all'], //设置默认展开值
    }
  },
  computed: {},
  watch: {
    value() {
      this.selectInit = [...this.value]
    },
    checkParentsInfo: {
      handler(newVal) {
        this.filterData(newVal.data)
      },
      deep: true,
    },
  },

  mounted() {
    this.getSprintName()
    this.selectInit = [...this.value]
  },
  methods: {
    //checkbox多余字段过滤
    filterData(arr) {
      let selectLabel = []
      // selectLabel = arr.filter(item=>{ return [-1,-2,-4].indexOf(item.id)==-1})
      // this.checkChlidInfo = {tag:selectLabel,checkbox:arr,label:'label',id:'id'}
      selectLabel = arr.filter(item => {
        return ['all', 'unarchived', 'archived'].indexOf(item.id) == -1
      })
      this.checkChlidInfo = {
        tag: selectLabel,
        checkbox: arr,
        label: 'name',
        id: 'id',
      }
    },
    //输出最终值
    exportValue(val) {
      this.$emit('setValue', val)
    },
    // 初始化 - 获取迭代列表 - 首次获取第一页数据及总页数
    getSprintName() {
      // $http.get($http.api.sprint.list_sprint_name).then(res => {
      //   if (res.status === 200 && Array.isArray(res.data)) {
      //     this.sprintDataOriginal = [...res.data];
      //     this.generateData()
      //   }
      // });
      getFilterSprintList({
        projectId: this.$getUrlParams().projectId,
      }).then(res => {
        if (res.status === 200) {
          this.sprintData = [res.data]
          // this.generateData(res.data.children)
        }
      })
    },
    // 封装数据格式
    // generateData() {
    //   const originData = this.sprintDataOriginal;
    //   const activeData = originData.filter(item => item.status === 1); // 未归档迭代
    //   const inactiveData = originData.filter(item => item.status !== 1); // 已归档迭代
    //   this.sprintData = [
    //     { label: " 全部", id: -1, value: -1, isLeaf: true, children: [
    //       {
    //         label: "未归档", id: -4,value: -4, isLeaf: false, children: [
    //           ...activeData.map(item => {
    //             return { label: item.name, id: item.id, children: null, value: item.id, isLeaf: true }
    //           })
    //         ]
    //       },
    //       {
    //       label: "已归档", id: -2,value: -2, isLeaf: false, children: [
    //           ...inactiveData.map(item => {
    //             return { label: item.name, id: item.id, children: null, value: item.id, isLeaf: true }
    //           })
    //         ]
    //       },]
    //     },
    //   ]
    // }
  },
}
</script>
<style lang="scss" scoped></style>
