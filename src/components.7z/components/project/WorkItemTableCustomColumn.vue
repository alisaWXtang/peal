<template>
  <div>
    <div v-if="isUserSelect">
      <global-user-select
        v-if="assignUserChoice.isShow"
        ref="globalUserSelect"
        env-type="PROJECT"
        :multiple="field.attrValue == 'MULTI_MEMBER_CHOICE'"
        :filter-invalid="true"
        :api-params="{ projectId: scope.row.projectId }"
        :value="defaultUserSelectValue"
        :placeholder="$t('输入拼音/工号/姓名')"
        @visibleChange="selectUserVisibleChange"
      ></global-user-select>
      <span
        v-if="!assignUserChoice.isShow"
        class="select-user"
        @click="clickSelectUser"
        >{{ scope.row.display[field.displayAttrName || field.attrName] }}
        <i
          v-if="isMemberChoiceShowClose"
          class="el-icon-circle-close user-select-close"
          @mousedown="
            clearFieldInfo(
              { clearFields: [field.attrName] },
              scope.row,
              'isCustomClearMemeberChoice',
            )
          "
        >
        </i>
      </span>
    </div>
    <div v-else-if="field.attrName === 'requireId'">
      <span class="select-user text-ellipsis" @click="selectClick">{{
        scope.row.display[field.displayAttrName || field.attrName]
      }}</span>
    </div>
    <span v-else :class="{ table_cell: isStatus }">
      <!-- 1 select -->
      <template
        v-if="
          attrValueToInputTypeMap[field.attrValue] === 'select' &&
            !field.readonly
        "
      >
        <!-- 展示 -->
        <!-- 缺陷预计工时不可更改 -->
        <span
          v-if="
            scope.row.workItemtype === 3 &&
              ['expectHour'].includes(field.attrName)
          "
          >{{
            scope.row.display[field.displayAttrName || field.attrName]
          }}</span
        >
        <span v-else-if="'delayType' === field.attrName">
          {{ scope.row.display[field.displayAttrName || field.attrName] }}
        </span>
        <span
          v-else-if="!scope.row.isNewAdd"
          class="cursor-pointer"
          :class="{
            status_wrap: isStatus,
            'none-box-shadow':
              (['priority'].includes(field.attrName) || isStatus) && !simple,
          }"
          @click="selectClick"
        >
          <span
            v-if="isStatus && !simple"
            class="status_name"
            v-html="
              initNameStatus(
                scope.row.detail.status.color,
                scope.row.display.status,
              )
            "
          ></span>
          <span
            v-else-if="['priority'].includes(field.attrName) && !simple"
            v-html="
              initNameStatus(
                scope.row.detail.priority.color,
                scope.row.display.priority,
              )
            "
          ></span>
          <span
            v-else-if="['expectHour', 'actualHour'].includes(field.attrName)"
            class="expect-actual-hour-wrapper current-hover"
          >
            {{
              scope.row.display[field.displayAttrName || field.attrName] +
                (scope.row.display[field.displayAttrName || field.attrName] ===
                '--'
                  ? ''
                  : 'h')
            }}
            <i
              class="el-icon-circle-close hour-select-close"
              @mousedown="clearFieldInfo({ [field.attrName]: 0 }, scope.row)"
            ></i>
          </span>
          <span v-else class="current-hover">{{
            scope.row.display[field.displayAttrName || field.attrName]
          }}</span>
        </span>
        <!-- 新建，保留 add by heyunjiang on 2020.1.16 -->
        <!-- <typed-form-item  v-else
        @change="updateModel"
        v-model="cruentCreateFieldValue"
        :type="field.attrValue"
        :selectList="selectList"
        :popperAppendToBody="true"
        :filterField="false"></typed-form-item> -->
      </template>
      <!-- 2 日期、数字、text、textarea、boolean -->
      <template
        v-else-if="
          ['text', 'textarea', 'number', 'time', 'date', 'boolean'].includes(
            attrValueToInputTypeMap[field.attrValue],
          )
        "
        &&
        !field.readonly
      >
        <!-- 展示 -->
        <!-- 缺陷预计开始时间、预计结束时间不可更改 -->
        <span
          v-if="
            scope.row.workItemtype === 3 &&
              ['startTime', 'endTime'].includes(field.attrName)
          "
          >{{
            scope.row.display[field.displayAttrName || field.attrName] || '--'
          }}</span
        >
        <global-input
          v-else-if="!scope.row.isNewAdd"
          class="table-input-column"
          :init-value="scope.row[field.attrName]"
          :input-type="getProgressType"
          :attr-value-type="field.attrValue"
          :on-change="
            value => {
              globalInputUpdate(
                { [field.attrName]: value },
                scope.row,
                field.userDefined,
              )
            }
          "
        >
          <span
            slot
            :class="{
              'common-input-edit-text': ['SINGLE_TEXT'].includes(
                field.attrValue,
              ),
              'cursor-pointer': !['SINGLE_TEXT'].includes(field.attrValue),
            }"
            class="current-hover"
            v-on="$listeners"
          >
            <template
              v-if="(field.displayAttrName || field.attrName) === 'progress'"
            >
              {{
                getProgressValue(
                  scope.row.display[field.displayAttrName || field.attrName],
                )
              }}
            </template>
            <template v-else
              >{{
                scope.row.display[field.displayAttrName || field.attrName] ||
                  '--'
              }}
            </template>
          </span>
        </global-input>
        <!-- 新建，保留 add by heyunjiang on 2020.1.16 -->
        <!-- <typed-form-item  v-else
        @change="updateModel"
        v-model="cruentCreateFieldValue"
        :type="field.attrValue"
        :filterField="false"></typed-form-item> -->
      </template>
      <span v-else>{{
        scope.row.display[field.displayAttrName || field.attrName] || '--'
      }}</span>
    </span>
  </div>
</template>
<script>
/**
 * @title 工作项 - table list 自定义字段 column
 * @desc 需求、任务、缺陷表格字段自定义展示，排除 id + title
 * @function 1. 支持新建模式
 * @function 2. 支持单元格编辑
 * @function 3. 支持表头排序
 * @author heyunjiang
 * @date 2019.12.26
 */
import isEqual from 'lodash/isEqual'
import ProjectCommonMixin from '@/mixin/ProjectCommonMixin'
import GlobalInput from '@/components/field-edit/GlobalInput.vue'
// import { setTimeout } from 'timers';
import GlobalUserSelect from '@/components/global-user-select/src/GlobalUserSelect'

const attrValueToInputTypeMap = {
  SINGLE_TEXT: 'text',
  MULTI_TEXT: 'textarea',
  MEMBER_CHOICE: 'select',
  MULTI_MEMBER_CHOICE: 'select',
  LITE_DATE_ATTR: 'date',
  // BOOLEAN_ATTR: 'boolean',
  BOOLEAN_ATTR: 'select',
  INT_ATTR: 'number',
  FLOAT_ATTR: 'number',
  SINGLE_CHOICE: 'select',
  MULTI_CHOICE: 'select',
}

// 工作项类型更新方法对象
const UpdateMethodObj = {
  '1': 'GlobalRequirementUpdate',
  '2': 'GlobalTaskUpdate',
  '3': 'GlobalBugUpdate',
}

export default {
  name: 'WorkItemTableCustomColumn',
  components: {
    GlobalInput,
    GlobalUserSelect,
  },

  mixins: [ProjectCommonMixin],
  props: {
    scope: {
      type: Object,
      required: true,
      desc: '字段 table column scope 信息',
    },

    field: {
      type: Object,
      required: true,
      desc: '字段基本信息',
    },
    simple: {
      type: Boolean,
      default: false,
      desc: '是否是简洁模式，主要是针对状态、优先级是否使用 initNameStatus',
    },
  },

  data() {
    return {
      attrValueToInputTypeMap,
      cruentCreateFieldValue: this.$store.state.cm.customFieldInitTypeMap[
        this.field.attrValue
      ],

      selectList: [],
      assignUserChoice: {
        value: '',
        isShow: false,
      },

      isClearHour: false, // 是否清除工时
      isCustomClearMemeberChoice: false, // 是否清除自定义人员单选
      showRequireDialog: false, // 父需求dialog显示
    }
  },
  computed: {
    getProgressType() {
      const isProgress =
        (this.field.displayAttrName || this.field.attrName) === 'progress'
      return isProgress
        ? 'progress'
        : attrValueToInputTypeMap[this.field.attrValue]
    },
    isUserSelect() {
      return (
        ['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(
          this.field.attrValue,
        ) && !this.field.readonly
      )
    },
    // 用户选择默认数据
    defaultUserSelectValue() {
      if (
        ['MULTI_MEMBER_CHOICE', 'MEMBER_CHOICE'].includes(this.field.attrValue)
      ) {
        const value = []

        if (this.field.attrValue.indexOf('MULTI_MEMBER_CHOICE') > -1) {
          const userNames = this.scope.row.display[this.field.attrName].split(
            ',',
          )

          const userIds = this.scope.row[this.field.attrName]

          if (Array.isArray(userIds) && userIds.length) {
            userIds.forEach((element, key) => {
              value.push({
                userId: element,
                userName: userNames[key],
              })
            })
          }

          return value
        } else {
          return ''
        }
      }

      return ''
    },
    // 是否是状态
    isStatus() {
      return 'statusId' === this.field.attrName
    },
    // 人员单选框是否显示清除按钮
    isMemberChoiceShowClose() {
      const { attrValue, userDefined, displayAttrName, attrName } = this.field
      const fieldValue = this.scope.row.display[displayAttrName || attrName]
      return attrValue == 'MEMBER_CHOICE' && userDefined && fieldValue !== '--'
    },
  },

  watch: {
    'assignUserChoice.isShow': {
      handler: function(newVal) {
        if (newVal) {
          this.$nextTick(() => {
            this.$refs.globalUserSelect.$children[0].focus()
            // 解决选择后点击不可聚焦问题
            this.$refs.globalUserSelect.$children[0].visible = true
          })
        }
      },
    },
  },

  created() {},
  mounted() {
    if (
      this.attrValueToInputTypeMap[this.field.attrValue] === 'select' &&
      this.scope.row.isNewAdd
    ) {
      this.getSelectList()
    }
  },
  methods: {
    // 获取 select list 可选项
    async getSelectList() {
      const result = await this.GlobalGetCommonDataList({
        projectId: this.scope.row.projectId,
        workItemType: this.scope.row.workItemType,
        attrName: this.field.attrName,
      })

      this.selectList = result
    },
    // 更新成功之后的回调
    updateSuccess(info) {
      this.$emit('updateSuccess', info)
    },
    // 全局数据更新，用于 text，textarea，date，boolean，number
    globalInputUpdate(updateInfo, originInfo, isCustomField = false) {
      // eslint-disable-next-line no-prototype-builtins
      if (updateInfo.hasOwnProperty('progress') && updateInfo.progress === '') {
        updateInfo = {
          ...updateInfo,
          clearFields: ['progress'],
        }
      }
      let cloneUpdateInfo = { ...updateInfo }
      updateInfo = isCustomField ? { userDefinedAttrs: updateInfo } : updateInfo
      for (let field in cloneUpdateInfo) {
        if (cloneUpdateInfo[field] === null) {
          updateInfo.clearFields = updateInfo.clearFields
            ? updateInfo.clearFields.push(field)
            : [field]
        }
      }
      let workItemType = originInfo.workItemType || 1
      let updateMethod = 'GlobalRequirementUpdate'
      switch (workItemType) {
        case 3:
          updateMethod = 'GlobalBugUpdate'
          break
        case 2:
          updateMethod = 'GlobalTaskUpdate'
          break
        case 1:
          updateMethod = 'GlobalRequirementUpdate'
          break
      }

      this[updateMethod]({
        ...updateInfo,
        id: originInfo.id,
        projectId: originInfo.projectId || this.$getUrlParams().projectId,
        cb: () => this.updateSuccess(originInfo),
      })
    },
    // select 类型字段点击
    selectClick(e) {
      if (this.isClearHour) {
        this.isClearHour = false
        return
      }
      if (this.field.attrName === 'statusId') {
        // 点击状态
        this.$emit('selectStatusClick', e)
      } else {
        this.$emit('selectClick', e)
      }
    },
    // 新建 - 更新绑定的数据对象
    updateModel() {
      this.$emit('update:createFieldValue', this.cruentCreateFieldValue)
    },
    // 选择用户失去焦点时触发事件
    selectUserVisibleChange(visible) {
      if (!visible) {
        const val = this.$refs.globalUserSelect.selectValue

        if (Array.isArray(val)) {
          const userIds = []
          val.forEach(element => {
            userIds.push(element.userId)
          })
          !isEqual(this.defaultUserSelectValue, val) &&
            this.globalInputUpdate(
              { [this.field.attrName]: userIds },
              this.scope.row,
              this.field.userDefined,
            )
        } else {
          if (val && val.userId) {
            this.globalInputUpdate(
              { [this.field.attrName]: val.userId },
              this.scope.row,
              this.field.userDefined,
            )
          }
        }

        this.assignUserChoice.isShow = false
      }
    },
    /**
     * 清空字段信息
     * @param { Object } updateInfo 字段的更新信息
     * @param { Object } originInfo 字段的初始信息
     * @param { String } clearFieldSign 字段清除的标识符
     */
    clearFieldInfo(updateInfo, originInfo, clearFieldSign = 'isClearHour') {
      this[clearFieldSign] = true
      let { workItemType = 1, id, projectId } = originInfo
      projectId = projectId || this.$getUrlParams().projectId
      this[UpdateMethodObj[workItemType]]({
        ...updateInfo,
        id,
        projectId,
        cb: () => this.updateSuccess(originInfo),
      })
    },
    // 人员选择
    clickSelectUser() {
      if (this.isCustomClearMemeberChoice) {
        this.isCustomClearMemeberChoice = false
        return
      }
      this.assignUserChoice.isShow = true
    },
    // 格式化进度时间,且保留1位小数
    getProgressValue(value) {
      return value == 0 || value ? Number(value).toFixed(1) : '--'
    },
  },
}
</script>
<style lang="scss" scoped>
.el-table .status_wrap:hover {
  box-shadow: none;
}
.table_cell {
  width: 100%;
  .status_name {
    display: inline-block;
    vertical-align: middle;
    border-radius: 4px;
    max-width: 100%;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
}
.table-input-column {
  /deep/ .ellipsis {
    padding: 0;
  }
}

.select-user {
  display: inline-block;
  padding: 1px 4px;
  border: 1px solid transparent;
  cursor: pointer;
  .user-select-close {
    display: none;
  }
  &:hover {
    box-sizing: border-box;
    border: 1px solid #dcdcdc;
    padding: 1px 4px;
    .user-select-close {
      display: inline-block;
      color: #c2c6ce;
    }
  }

  &:focus {
    outline: unset;
  }

  &.text-ellipsis {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}

.expect-actual-hour-wrapper {
  .hour-select-close {
    display: none;
  }
  &:hover {
    .hour-select-close {
      display: inline-block;
      color: #c2c6ce;
    }
  }
}
.cursor-pointer {
  &.none-box-shadow {
    box-shadow: none !important;
  }
}
</style>
