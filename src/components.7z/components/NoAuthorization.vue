<template>
  <div class="page-noAuthorization">
    <div class="img-box">
      <img src="~@/assets/no-auth.png" alt="no-auth-image" />
    </div>
    <div class="text-box">
      您没有该应用访问权限
    </div>
    <div class="link-box">
      <a href="/user/setting">开通访问权限 ></a>
    </div>
  </div>
</template>

<script>
export default {
  name: 'NoAuthorization',
}
</script>

<style scoped lang="scss">
.page-noAuthorization {
  height: 100%;
  width: 100%;
  overflow-x: hidden;
  text-align: center;
  margin-top: 50px;

  .img-box,
  .text-box,
  .link-box {
    font-size: 16px;
    line-height: 40px;
  }
}
</style>
