<template>
  <el-dialog
    :title="$t(wordsFormate)"
    :visible.sync="show"
    :modal-append-to-body="false"
    :close-on-click-modal="false"
    :before-close="handleBeforeClose"
    :width="'94%'"
    :append-to-body="true"
    class="import-dialog"
    id="importDialog"
    @closed="closed"
  >
      <div class="SerialItem">
        <div class="SerialItem-title">
          <span class="SerialItem-title-color"
            >1.{{ $t("选择需要导入的工作项模板") }}</span
          >
        </div>
        <div class="p-t-10 chlid-m-b-5">
          <el-radio-group
            v-model="activeWorkItemTemplates"
            @change="activeWorkItemChange"
            class="radioGroupCs"
          >
            <el-radio
              class="limitWidth"
              v-for="(item, index) in workItemTemplates"
              :label="item.id"
              :key="index"
              >{{ item.name }}
              </el-radio
            >
          </el-radio-group>
        </div>
      </div>
      <div class="SerialItem">
        <div class="SerialItem-title">
          <span class="SerialItem-title-color m-r-10"
            >2.{{ $t("下载模板") }}</span
          >
          <!-- 缺陷的下载模板有权限 -->
          <el-button
            type="primary"
            v-if="
             $authFunction(
                'FUNC_COOP_DEFECT_EXCEL_MODEL',
                3,
                $getUrlParams().projectId || projectId
              ) && title === 3
            "
            @click="downtemplate"
            >{{ $t("下载导入模板") }}</el-button
          >
          <el-button
            type="primary"
            v-if="title === 1 || title === 2"
            @click="downtemplate"
            >{{ $t("下载导入模板") }}</el-button
          >
        </div>
        <div class="SerialItem-des">
          {{ $t(`下载${wordsFormate}导入模板`) }}，{{ $t("按照以下规则填写导入数据") }}
        </div>
      </div>
      <div>
        <el-table class="m-b-10" border :data="vaildDesTableData" :height="tableMax">
          <el-table-column min-width="260">
            <template slot="header">
              <span
                >{{ $t("属性") }}（{{ $t("带") }}“<span style="color:red">*</span
                >”{{ $t("的为必填项") }}）</span
              >
            </template>
            <template slot-scope="scope">
              <span
                >{{ scope.row.name
                }}<span v-if="scope.row.required" style="color:red">*</span>
              </span>
            </template>
          </el-table-column>
          <el-table-column  min-width="700">
            <template slot="header">
              <span>{{ $t("填写规则") }}</span>
            </template>
            <template slot-scope="scope">
              <span>{{ scope.row.ruleTips }}</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="SerialItem">
        <div class="SerialItem-title">
          <span class="SerialItem-title-color">3.{{ $t("上传文件") }}</span>
        </div>
        <div class="SerialItem-des">
          {{ $t("上传需要导入的Excel文件") }}，{{
            $t("上传文件的表头字段名必须和对应工作项属性一致")
          }}
        </div>
        <div class="fileUpLoad">
          <el-upload
            class="uploadTemplate"
            :show-file-list="false"
            :on-progress="fileuploadprocess"
            :on-success="handleUploadSuccess"
            :on-error="handleUploadError"
            :on-change="handleUploadChange"
            :http-request="uploadSectionFile"
            :action="''"
            accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
          >
            <div class="textCenter">
              <span v-if="!filetypeSvg" class="clickHere">{{
                $t("点击此处")
              }}</span>
              <span v-else class="textCenter">
                <svg class="icon" aria-hidden="true">
                  <use
                    :xlink:href="
                      iconClass[filetypeSvg]
                        ? iconClass[filetypeSvg]
                        : '#icon-TET'
                    "
                  ></use>
                </svg>
                <span class="m-l-r-8">{{ filefullName }}</span>
              </span>
              <el-button type="text">{{
                file ? $t("重新选择") : $t("上传文件")
              }}</el-button>
            </div>
          </el-upload>
        </div>
      </div>
    <div slot="footer" class="dialog-footer">
      <el-button @click="handleBeforeClose">{{ $t("取消") }}</el-button>
      <el-button type="primary" @click="starHandle">{{
        $t("开始导入")
      }}</el-button>
    </div>
  </el-dialog>
</template>
<script>
import { i18n } from "@/i18n";
/**
 * @title 导入验证弹窗
 * @desc
 * @author wx
 * @date 2021/4/1
 */
import axios from 'axios'
import { getWorkItemTempValidDetail } from "@/service/project/projectCommon";
import ImportBox from "@/components/columbusImporter";
import { WORKITEMCONST } from '@/utils/constant'
import { requirementExportNew } from '@/api/requirement'
import { downloadFile } from '@/utils/index'

import {
  importExcelRequirement,
  importExcelTask,
  importExcelDefect
} from '@/api/project-common'
// 导入标题
const titleObj = {
  [WORKITEMCONST.workItemTypeMap.requirement]: "导入需求",
  [WORKITEMCONST.workItemTypeMap.task]: "导入任务",
  [WORKITEMCONST.workItemTypeMap.bug]: "导入缺陷"
};

// 导入标题
const templateTitleObj = {
  [WORKITEMCONST.workItemTypeMap.requirement]: "需求导入模板",
  [WORKITEMCONST.workItemTypeMap.task]: "任务导入模板",
  [WORKITEMCONST.workItemTypeMap.bug]: "缺陷导入模板"
};
// 导入链接地址
const urlObj = {
  [WORKITEMCONST.workItemTypeMap.requirement]:
    importExcelRequirement.url,
  [WORKITEMCONST.workItemTypeMap.task]:
    importExcelTask.url,
  [WORKITEMCONST.workItemTypeMap.bug]:
    importExcelDefect.url
};

export default {
  name: "ImportVaildDialog",
  mixins: [],
  props: {
    visible: Boolean,
    title: {
      type: [String, Number],
      require: true,
      desc: "1-需求 2-任务 3-缺陷"
    }
  },

  data() {
    return {
      fistStep: false,
      fileList: [],
      vaildDesTableData: [],
      workItemTemplates: [],
      activeWorkItemTemplates: "",
      projectId: this.$getUrlParams().projectId,
      tableMax:0,
      iconClass: {
        xlsx: "#icon-ECEL",
        xls: "#icon-ECEL",
        json: "#icon-zonghewendang",
        ppt: "#icon-PPT",
        txt: "#icon-TET",
        png: "#icon-PNG",
        gif: "#icon-GIF",
        jpge: "#icon-JPG",
        zip: "#icon-ZIP",
        mp4: "#icon-VIDEO",
        pdf: "#icon-PDF",
        doc: "#icon-WORD",
        docx: "#icon-WORD"
      },
      filetypeSvg: "",
      filefullName: "",
      file: null
    };
  },
  computed: {
    wordsFormate() {
      return titleObj[this.title];
    },
    show: {
      get() {
        return this.visible;
      },
      set(val) {
        this.$emit("update:visible", val);
      }
    },
  },
  mounted(){
    window.addEventListener('resize', this.initTableHeit);
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.initTableHeit);
  },  
  watch:{
    show(n,o){
      n&&this.getTemplateList(this.projectId, this.title)
    }
  },
  methods: {
    // 获取工作项模板
    async getTemplateList(projectId, workItemType = 1) {
      this.workItemTemplates = await this.$store.dispatch({
        type: "initProjectWorkItemTemplateList",
        payload: {
          projectId: projectId || this.$getUrlParams().projectId,
          workItemType
        }
      });
      this.activeWorkItemTemplates = this.workItemTemplates.find(
        item => item.active
      )?.id;
      this.queryWorkItemTemplateDetail(this.activeWorkItemTemplates);
    },
    async queryWorkItemTemplateDetail(tmplId) {
      const result = await getWorkItemTempValidDetail({
        projectId: this.projectId,
        templateId: tmplId
      });

      if (result.status === 200) {
        this.vaildDesTableData = result.data.fieldRuleList;
        this.initTableHeit()
      }
    },
    activeWorkItemChange(val) {
      this.queryWorkItemTemplateDetail(val);
    },
    starHandle() {
      const tempItem = this.workItemTemplates.find(item => item.active);
      tempItem.id = 112879;
      if (!this.filefullName) {
        this.$message({
          message: "请先上传文件",
          type: "warning"
        });
        return;
      }

      let fileExtension = this.filefullName.substring(this.filefullName.lastIndexOf(".") + 1)

      if(fileExtension !== 'xlsx' && fileExtension !== 'xls'){
        return
      }

      const importBox = ImportBox.install(this, {
        title: titleObj[this.title],
        importUrl: urlObj[this.title],
        file: this.file
      });

      // 刷新列表
      importBox.once("closed", () => {
        this.$emit("imported");
      });

      this.$emit("starHandle");
      this.show = false;
    },
    async initTableHeit(){
      let bigWarpHei = 0;
      let allSerialItem = [];
      let allSerialItemHei = 0
      bigWarpHei = document.querySelector('#importDialog').getBoundingClientRect().height
      allSerialItem = document.querySelectorAll('.SerialItem')
      allSerialItem.forEach(item=>{
        allSerialItemHei+=item.getBoundingClientRect().height
      })
      this.tableMax = Math.floor(bigWarpHei*0.9)-allSerialItemHei-180
    },    
    // 关闭
    closed() {
      this.file = "";
      this.filefullName = "";
      this.filetypeSvg = "";
      this.activeWorkItemTemplates = this.workItemTemplates.find(
        item => item.active
      )?.id;
    },
    downtemplate() {
      let projectId = this.$getUrlParams().projectId;
      let url = `${requirementExportNew.url}?projectId=${projectId}&templateId=${this.activeWorkItemTemplates}`;
      downloadFile(url, `${templateTitleObj[this.title]}.xlsx`, 'post')
    },
    handleBeforeClose() {
      this.$emit("update:visible", false);
    },
    fileuploadprocess() {},
    handleUploadSuccess(response, file, fileList) {},
    handleUploadError() {},
    handleUploadChange(file, fileList) {
      this.file = file.raw;
    },
    uploadSectionFile(file) {
      // 新增文件名长度控制
      if (file.file.name && file.file.name.length > 230) {
        this.$message({
          message: i18n.t("文件名过长"),
          type: "error"
        });

        return false;
      }
      let fileExtension = file.file.name.substring(file.file.name.lastIndexOf(".") + 1)
      if(fileExtension!=='xlsx'&&fileExtension!=='xls'){
        this.$message({
          message: i18n.t("请选择.xlsx、.xls格式的文件"),
          type: "error"
        });
        return false;
      }
      this.filetypeSvg = file.file.name.substring(
        file.file.name.lastIndexOf(".") + 1
      );
      this.filefullName = file.file.name;
    }
  }
};
</script>
<style lang="scss" scoped>
.SerialItem {
  .SerialItem-title {
    line-height: 34px;
    .SerialItem-title-color {
      color: #000;
    }
  }
  .SerialItem-des {
    line-height: 26px;
    color: rgb(142, 138, 138);
    font-size: 12px;
  }
}
/deep/.el-dialog{
  display: flex;
  flex-direction: column;
  padding-left: 30px;
  padding-right: 30px;
  position:absolute;
  top:50%;
  left:50%;
  transform:translate(-50%,-50%);
  margin: 0!important;
  height: 90%;
  box-sizing: border-box;
  min-height: 500px;
  .el-dialog__body{
    flex: 1;
  }
  .dialog-footer {
    margin-top: 15px;
  }
}
.m-b-10 {
  margin-bottom: 10px;
}
.m-r-10 {
  margin-right: 10px;
}
.fileUpLoad {
  background-color: #f1f4f9;
  border-radius: 4px;
  border: 1px solid #e5e5e5;
  padding: 12px 10px;
  .clickHere {
    margin-right: 10px;
    color: rgb(142, 138, 138);
  }
  .textCenter {
    display: flex;
    align-items: center;
    .m-l-r-8 {
      margin: 0 8px;
    }
    .icon{
      width: 30px;
      height: 30px;
    }
  }
}
.p-t-10.chlid-m-b-5 {
  padding: 10px 0px 5px;
  .radioGroupCs{
    display: block;
  }
  .el-radio {
    margin-bottom: 5px;
  }
  .el-radio.limitWidth{
    width: 10%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-block;
  }
}
</style>
