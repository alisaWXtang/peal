<template>
  <div class="more-filter-wrap">
    <div style="display: inline" @click="showDialog">
      <slot name="text"></slot>
    </div>
    <co-dialog
      :visible.sync="dialogVisible"
      :close-on-press-escape="false"
      :modal-append-to-body="false"
      :modal="true"
      @closed="closed"
      title="更多过滤条件"
      class="more-filter-dialog-box"
    >
      <div v-if="dialogVisible" class="dialog-content-box">
        <div>
          <p class="group-title">
            <span>已选条件</span>
          </p>
          <div class="check-box-wrap">
            <!-- 默认选项 不可取消 -->
            <template v-for="item in defaultFieldSelected">
              <co-row
                v-if="item.owner && item.owner.includes(owner)"
                :key="item[attrName]"
                class="item-box"
              >
                <co-checkbox checked size="medium" :disabled="item.disabled">
                  {{ item[fieldName] }}
                </co-checkbox>
              </co-row>
            </template>
            <template v-for="item in selectRender">
              <co-row v-if="item.owner" :key="item[attrName]" class="item-box">
                <co-checkbox
                  v-if="item.isSelect && item.owner.includes(owner)"
                  v-model="item.isChecked"
                  size="medium"
                >
                  {{ item[fieldName] }}
                </co-checkbox>
              </co-row>
              <co-row v-else :key="item[attrName]" class="item-box">
                <co-checkbox
                  v-if="item.isSelect"
                  v-model="item.isChecked"
                  size="medium"
                >
                  {{ item[fieldName] }}
                </co-checkbox>
              </co-row>
            </template>
          </div>
        </div>
      </div>
      <div class="dialog-content-box">
        <div>
          <p class="group-title">
            <span>可选条件</span>
          </p>
          <div class="check-box-wrap">
            <template v-for="item in selectRender">
              <co-row v-if="item.owner" :key="item[attrName]" class="item-box">
                <co-checkbox
                  v-if="!item.isSelect && item.owner.includes(owner)"
                  v-model="item.isChecked"
                  size="medium"
                >
                  {{ item[fieldName] }}
                </co-checkbox>
              </co-row>
              <co-row v-else :key="item[attrName]" class="item-box">
                <co-checkbox
                  v-if="!item.isSelect"
                  v-model="item.isChecked"
                  size="medium"
                >
                  {{ item[fieldName] }}
                </co-checkbox>
              </co-row>
            </template>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <co-button @click="cancel">取 消</co-button>
        <co-button type="primary" @click="submit">确 定</co-button>
      </div>
    </co-dialog>
  </div>
</template>

<script>
export default {
  name: 'MoreFilter',
  model: {
    prop: 'defaultSelected',
    event: 'change',
  },
  props: {
    owner: String,
    // 默认选中值
    defaultSelected: {
      type: [String, Array],
      default() {
        return ''
      },
    },
    // 所有选项 静态、固定、自定义
    stateFixedCustomFieldList: {
      type: Array,
      default() {
        return []
      },
    },
    // 默认选项
    defaultFieldList: {
      type: Array,
      default() {
        return []
      },
    },
    // 数据项 label 属性
    fieldName: {
      type: String,
      default() {
        return 'fieldName'
      },
    },
    // 数据项 value属性
    attrName: {
      type: String,
      default() {
        return 'attrName'
      },
    },
    isCardPageType: {
      type: Boolean,
      default: false,
    },
    // 是否多选 改造前有此属性 不知起什么作用 暂时保留
    multiple: {
      type: Boolean,
      default() {
        return false
      },
    },
  },
  data() {
    return {
      dialogVisible: false,
      defaultFieldSelected: [], // 默认字段已勾选项
      selectRender: [],
      selectRenderCopy: [],
      cancelSelected: [],
    }
  },
  watch: {
    dialogVisible: {
      handler(val) {
        if (val) {
          const keys = this.filterValues(this.defaultSelected, false)
          this.filterRenderSelected(keys, this.stateFixedCustomFieldList)
          this.selectRenderCopy = JSON.parse(JSON.stringify(this.selectRender))
        }
      },
      immediate: true,
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // 初始化默认的选项
      this.defaultFieldSelected = [...this.defaultFieldList]
      if (!this.isCardPageType) {
        this.defaultFieldSelected.shift()
      }
    },
    showDialog() {
      this.dialogVisible = true
    },
    closed() {
      this.selectRender = []
    },
    submit() {
      this.dialogVisible = false
      const selected = this.filterValues(this.selectRender, true)
      this.cancelSelected.forEach(key => {
        this.$emit('cancelValue', key)
      })
      this.$emit('change', this.multiple ? selected : [])
    },
    cancel() {
      this.dialogVisible = false
      this.selectRender = JSON.parse(JSON.stringify(this.selectRenderCopy))
    },
    filterRenderSelected(keys, val) {
      val.forEach(item => {
        const key = this.filterVal(item)
        let obj = {
          fieldName: typeof item === 'string' ? item : item.fieldName,
          isChecked: keys.includes(item.key) ? true : false,
          isSelect: keys.includes(item.key) ? true : false, // 是否显示为已选
          owner: null,
          key: key,
        }
        if ('owner' in item) {
          obj.owner = item.owner
        }
        this.selectRender.push(obj)
      })
    },
    filterValues(value, submit = false) {
      const vals = []
      value.forEach(item => {
        if (!submit || (!vals.includes(item.key) && item.isChecked)) {
          const str = this.filterVal(item)
          vals.push(str)
        }
      })
      return vals
    },
    filterVal(item) {
      let str = ''
      if (item.key) {
        str = item.key
      } else if (typeof item === 'string') {
        str = item
      }
      return str
    },
  },
}
</script>

<style lang="scss" scoped>
.more-filter-wrap {
  //padding-top: 30px;
  .more-filter-dialog-box {
    /deep/ .el-dialog__body {
      padding: 8px 0;
    }
    /deep/ .el-dialog {
      width: 556px;
      //height: 350px;
      border-radius: 4px;
      border: 1px solid #dcdfe6;
      box-shadow: 0 3px 12px 0 rgba(102, 102, 102, 0.15);
    }
    /deep/ .el-dialog__header {
      border-bottom: 1px solid #e5e5e5;
      padding-bottom: 8px;
      .el-dialog__title {
        font-family: PingFangSC-Medium;
        font-size: 16px;
        color: #333333;
      }
    }
  }
  .dialog-content-box {
    .group-title {
      margin: 0;
      margin-bottom: 10px;
    }
    .check-box-wrap {
      display: flex;
      flex-wrap: wrap;
      .item-box {
        .el-checkbox {
          /deep/ .el-checkbox__label {
            width: 88px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            vertical-align: middle;
          }
          ///deep/ .el-checkbox__inner {
          //  border-color: #e5e5e5;
          //}
        }
      }
    }
    /deep/ .el-checkbox__input.is-disabled + span.el-checkbox__label {
      color: #666666;
    }
    /deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
      color: #666666;
    }
  }
}
</style>
